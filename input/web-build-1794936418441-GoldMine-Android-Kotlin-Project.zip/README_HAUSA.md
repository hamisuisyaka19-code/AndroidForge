# GoldMine Android App — Kotlin WebView

Wannan **Android Studio source project** ne, ba APK da aka riga aka gina ba.

- Yana buɗe https://goalmindai.com.ng/goldmine-cpanel/
- Yana amfani da PHP/MySQL website ɗin da ake da shi; babu sabon database.
- Canje-canjen Admin za su bayyana daga website idan an sabunta bayanai daga server.
- Yana goyon bayan JavaScript, cookies/session, file upload da downloads.

## Gina APK
1. Buɗe wannan folder a Android Studio.
2. Jira Gradle Sync ya gama.
3. Zaɓi Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK zai kasance a `app/build/outputs/apk/debug/app-debug.apk`.

Kafin a rarraba shi, a gwada login, registration, uploads, downloads da sauran shafuka a na'urar gwaji. A saka ainihin GoldMine launcher icon. Wannan project ba ya ɗauke da `.env`, API keys ko bayanan database.
