package com.goldmine.investmentplatform.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.adapter.TransactionsAdapter;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentDashboardBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.Transaction;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.ui.deposit.DepositActivity;
import com.goldmine.investmentplatform.ui.main.MainActivity;
import com.goldmine.investmentplatform.ui.transactions.TransactionsFragment;
import com.goldmine.investmentplatform.ui.withdraw.WithdrawActivity;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {
    private FragmentDashboardBinding binding;
    private SessionManager sessionManager;
    private TransactionsAdapter transactionsAdapter;
    private boolean isBalanceVisible = true;
    private double currentBalance = 0.00;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        setupRecyclerView();
        setupClickListeners();
        loadDashboardData();
    }

    private void setupRecyclerView() {
        transactionsAdapter = new TransactionsAdapter();
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionsAdapter);
    }

    private void setupClickListeners() {
        binding.swipeRefresh.setOnRefreshListener(this::loadDashboardData);

        binding.btnQuickDeposit.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), DepositActivity.class));
        });

        binding.btnQuickWithdraw.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), WithdrawActivity.class));
        });

        binding.btnInvestNow.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToTab(R.id.nav_plans);
            }
        });

        binding.cardInvestBanner.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToTab(R.id.nav_plans);
            }
        });

        binding.cardCountdownBanner.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToTab(R.id.nav_countdown);
            }
        });

        binding.tvViewAllTransactions.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new TransactionsFragment());
            }
        });

        binding.ivToggleBalance.setOnClickListener(v -> {
            isBalanceVisible = !isBalanceVisible;
            updateBalanceDisplay();
        });
    }

    private void updateBalanceDisplay() {
        if (isBalanceVisible) {
            binding.tvAvailableBalance.setText(CurrencyFormatter.formatNaira(currentBalance));
        } else {
            binding.tvAvailableBalance.setText("₦ ••••••••");
        }
    }

    public void loadDashboardData() {
        binding.swipeRefresh.setRefreshing(true);
        int userId = sessionManager.getUserId();

        ApiClient.getService().getDashboard(userId).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                if (!isAdded()) return;
                binding.swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null) {
                        // User info
                        if (data.has("user")) {
                            User user = new Gson().fromJson(data.get("user"), User.class);
                            currentBalance = user.getBalance();
                            sessionManager.updateUserBalance(currentBalance);
                            updateBalanceDisplay();

                            binding.tvTotalInvested.setText(CurrencyFormatter.formatNaira(user.getTotalInvested()));
                            binding.tvTotalProfit.setText(CurrencyFormatter.formatNaira(user.getTotalProfit()));
                        }

                        // Active countdowns
                        int activeCount = data.has("active_investments_count") ? data.get("active_investments_count").getAsInt() : 0;
                        if (activeCount > 0) {
                            binding.cardCountdownBanner.setVisibility(View.VISIBLE);
                            binding.tvCountdownSummary.setText(activeCount + " active plan(s) maturing with 45% ROI. Tap to view timer.");
                        } else {
                            binding.cardCountdownBanner.setVisibility(View.GONE);
                        }

                        // Notifications badge
                        int unread = data.has("unread_notifications") ? data.get("unread_notifications").getAsInt() : 0;
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).setNotificationBadgeVisible(unread > 0);
                            ((MainActivity) getActivity()).updateHeader();
                        }

                        // Recent transactions
                        if (data.has("recent_transactions")) {
                            JsonArray txArr = data.getAsJsonArray("recent_transactions");
                            List<Transaction> list = new ArrayList<>();
                            Gson gson = new Gson();
                            for (JsonElement el : txArr) {
                                list.add(gson.fromJson(el, Transaction.class));
                            }
                            transactionsAdapter.setTransactions(list);
                            binding.tvEmptyTransactions.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                        }
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                binding.swipeRefresh.setRefreshing(false);
                // Fallback to cached balance
                currentBalance = sessionManager.getUserBalance();
                updateBalanceDisplay();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadDashboardData();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
