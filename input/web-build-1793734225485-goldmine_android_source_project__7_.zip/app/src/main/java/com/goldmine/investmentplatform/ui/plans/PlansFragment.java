package com.goldmine.investmentplatform.ui.plans;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.adapter.PlansAdapter;
import com.goldmine.investmentplatform.api.GoldMineRepository;
import com.goldmine.investmentplatform.databinding.FragmentPlansBinding;
import com.goldmine.investmentplatform.databinding.ItemPlanBinding;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.ui.invest.InvestActivity;
import java.util.List;

public class PlansFragment extends Fragment {
    private FragmentPlansBinding binding;
    private PlansAdapter adapter;
    private final PlansAdapter.OnPlanClickListener planClickListener = plan -> {
        if (!isAdded()) return;
        Intent intent = new Intent(requireContext(), InvestActivity.class);
        intent.putExtra("selected_plan", plan);
        startActivity(intent);
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPlansBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new PlansAdapter(planClickListener);
        binding.rvPlans.setLayoutManager(new LinearLayoutManager(requireContext()) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });
        binding.rvPlans.setAdapter(adapter);

        // Immediately render all 5 official packages so the screen is never empty or partial
        renderPlanCards(GoldMineRepository.getInstance().getOfficialPlansList());

        binding.swipeRefresh.setOnRefreshListener(this::fetchPlans);
        fetchPlans();
    }

    private void renderPlanCards(List<InvestmentPlan> list) {
        if (!isAdded() || binding == null || list == null) return;
        adapter.setPlans(list);
        binding.layoutPlansContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (InvestmentPlan plan : list) {
            ItemPlanBinding cardBinding = ItemPlanBinding.inflate(inflater, binding.layoutPlansContainer, false);
            PlansAdapter.bindPlanCard(cardBinding, plan, planClickListener);
            binding.layoutPlansContainer.addView(cardBinding.getRoot());
        }
    }

    private void fetchPlans() {
        if (binding == null) return;
        binding.progressBar.setVisibility(View.VISIBLE);

        GoldMineRepository.getInstance().getPlans(new GoldMineRepository.PlansCallback() {
            @Override
            public void onSuccess(List<InvestmentPlan> list) {
                if (!isAdded() || binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
                renderPlanCards(list);
            }

            @Override
            public void onError(String message) {
                if (!isAdded() || binding == null) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
                renderPlanCards(GoldMineRepository.getInstance().getOfficialPlansList());
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
