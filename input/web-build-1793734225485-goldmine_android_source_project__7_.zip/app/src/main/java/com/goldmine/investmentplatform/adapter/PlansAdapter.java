package com.goldmine.investmentplatform.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemPlanBinding;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PlansAdapter extends RecyclerView.Adapter<PlansAdapter.PlanViewHolder> {
    private List<InvestmentPlan> plans = new ArrayList<>();
    private final OnPlanClickListener listener;

    public interface OnPlanClickListener {
        void onPlanClick(InvestmentPlan plan);
    }

    public PlansAdapter(OnPlanClickListener listener) {
        this.listener = listener;
    }

    public void setPlans(List<InvestmentPlan> plans) {
        this.plans = plans != null ? plans : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PlanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPlanBinding binding = ItemPlanBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new PlanViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PlanViewHolder holder, int position) {
        holder.bind(plans.get(position));
    }

    @Override
    public int getItemCount() {
        return plans.size();
    }

    public static void bindPlanCard(ItemPlanBinding binding, InvestmentPlan plan, OnPlanClickListener listener) {
        int durationDays = TimeUtils.resolveCanonicalDurationDays(plan.getName(), plan.getDurationDays());
        double minAmount = plan.getMinAmount();
        double maxAmount = plan.getMaxAmount();
        double roi = TimeUtils.resolveCanonicalRoiPercentage(
                plan.getName(), minAmount, plan.getRoiPercentage()
        );
        double minProfit = TimeUtils.calculateProfit(minAmount, roi);
        double maxProfit = TimeUtils.calculateProfit(maxAmount, roi);
        double minDailyProfit = TimeUtils.calculateDailyProfit(minAmount, roi, durationDays);
        double maxDailyProfit = TimeUtils.calculateDailyProfit(maxAmount, roi, durationDays);
        double minTotalReturn = TimeUtils.calculateExpectedReturn(minAmount, roi);
        double maxTotalReturn = TimeUtils.calculateExpectedReturn(maxAmount, roi);

        // Left Image Box Labels
        String shortTitle = plan.getName() != null
                ? plan.getName().replace("Gold", "").trim().toUpperCase(Locale.US)
                : "GOLD";
        binding.tvPlanTierTag.setText("TIER " + Math.max(1, plan.getId()) + " • " + (int) roi + "%");
        binding.tvPlanImageTitle.setText(shortTitle);
        binding.tvPlanImageDuration.setText(durationDays + " Days");

        // Right Column Header & Top-Right ROI Badge
        binding.tvPlanName.setText(plan.getName());
        binding.tvPlanRoiBadge.setText((int) roi + "% ROI");

        // Financial Details on the Right
        binding.tvPlanDailyProfitLabel.setText("Daily Profit:");
        binding.tvPlanProfitRate.setText(String.format(
                Locale.US,
                "+%s – %s/day",
                CurrencyFormatter.formatNaira(minDailyProfit),
                CurrencyFormatter.formatNaira(maxDailyProfit)
        ));

        binding.tvPlanDuration.setText(durationDays + " Days");
        binding.tvPlanMin.setText(CurrencyFormatter.formatNaira(minAmount));
        binding.tvPlanMax.setText(CurrencyFormatter.formatNaira(maxAmount));

        binding.tvPlanTotalReturnLabel.setText("Total Return:");
        binding.tvPlanTotalReturn.setText("Capital + " + (int) roi + "% profit");

        binding.tvPlanDescription.setText(String.format(
                Locale.US,
                "Profit: +%s – %s • Payout: %s – %s",
                CurrencyFormatter.formatNaira(minProfit),
                CurrencyFormatter.formatNaira(maxProfit),
                CurrencyFormatter.formatNaira(minTotalReturn),
                CurrencyFormatter.formatNaira(maxTotalReturn)
        ));

        binding.btnInvestPlan.setText("Invest Now");
        binding.btnInvestPlan.setOnClickListener(v -> {
            if (listener != null) {
                listener.onPlanClick(plan);
            }
        });
        binding.getRoot().setOnClickListener(v -> {
            if (listener != null) {
                listener.onPlanClick(plan);
            }
        });
    }

    class PlanViewHolder extends RecyclerView.ViewHolder {
        private final ItemPlanBinding binding;

        public PlanViewHolder(ItemPlanBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(InvestmentPlan plan) {
            bindPlanCard(binding, plan, listener);
        }
    }
}
