package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class InvestmentPlan implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("slug")
    private String slug;

    @SerializedName("min_amount")
    private double minAmount;

    @SerializedName("max_amount")
    private double maxAmount;

    @SerializedName("roi_percentage")
    private double roiPercentage;

    @SerializedName("duration_days")
    private int durationDays;

    @SerializedName("description")
    private String description;

    @SerializedName("status")
    private String status;

    public int getId() { return id; }
    public String getName() { return name != null ? name : "Gold Plan"; }
    public String getSlug() { return slug != null ? slug : ""; }
    public double getMinAmount() { return minAmount; }
    public double getMaxAmount() { return maxAmount; }
    public double getRoiPercentage() {
        return com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalRoiPercentage(name, minAmount, roiPercentage);
    }
    public int getDurationDays() {
        return com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalDurationDays(name, durationDays);
    }
    public String getDescription() { return description != null ? description : ""; }
    public String getStatus() { return status != null ? status : "active"; }

    public double getDailyRoiRate() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateDailyRoiRate(getRoiPercentage(), getDurationDays());
    }

    public double getMinProfit() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateProfit(minAmount, getRoiPercentage());
    }

    public double getMaxProfit() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateProfit(maxAmount, getRoiPercentage());
    }

    public double getMinDailyProfit() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateDailyProfit(minAmount, getRoiPercentage(), getDurationDays());
    }

    public double getMinTotalReturn() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(minAmount, getRoiPercentage());
    }

    public double getMaxTotalReturn() {
        return com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(maxAmount, getRoiPercentage());
    }
}
