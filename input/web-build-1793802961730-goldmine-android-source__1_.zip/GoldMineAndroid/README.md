# GoldMine Investment Platform - Android Mobile App Source Project

Official native Android application source project for **GoldMine Investment Platform** (https://goalmindai.com.ng).

## ✨ Features
- **100% Native Kotlin & Jetpack Architecture** with ViewBinding, Coroutines, and ViewModel.
- **Retrofit 2 & OkHttp 3** connected directly to the existing cPanel PHP backend (`/api/`).
- **Live Real-Time Investment Countdown**: Synchronized with server timestamps (Days, Hours, Minutes, Seconds).
- **All 4 Official Investment Packages**:
  - **Starter Plan**: 35% Profit, 3 Days, Min ₦1,000, Total return ₦1,350
  - **Growth Plan**: 50% Profit, 7 Days, Min ₦5,000, Total return ₦7,500
  - **Premium Plan**: 75% Profit, 15 Days, Min ₦10,000, Total return ₦17,500
  - **Elite Plan**: 100% Profit, 30 Days, Min ₦50,000, Total return ₦100,000
- **Secure Authentication**: Users log in with existing website email/phone credentials.
- **Wallet & Transactions**: Instant balance updates, deposit submission with transfer receipt, and withdrawal requests.
- **GitHub Actions Cloud Build**: Build an installable APK in 2 minutes directly on your Android phone without needing a computer!

---

## 📱 How to Build the Installable APK on Your Android Phone (Zero Computer Required!)

You can build and install the APK entirely from your phone using GitHub Actions:

### Step 1: Create a GitHub Repository
1. Open [github.com](https://github.com) in your mobile browser (Chrome/Brave).
2. Tap the **+** icon in the top right -> **New repository**.
3. Name it `goldmine-android-app` and keep it Private (or Public). Tap **Create repository**.

### Step 2: Upload Project Files
1. Extract this `goldmine-android-source.zip` on your phone (using Google Files, ZArchiver, or RAR app).
2. In your GitHub repository, tap **Add file** -> **Upload files**.
3. Select and upload the project files (ensure `.github/workflows/build-apk.yml` is uploaded).
4. Tap **Commit changes**.

### Step 3: Cloud Compilation Starts Automatically
1. In your GitHub repo, tap the **Actions** tab at the top.
2. You will see a workflow running named **"Build GoldMine Android APK"**.
3. Wait approximately 2–3 minutes until the green checkmark appears (Success).

### Step 4: Download & Install on Android Phone
1. Tap on the completed build run.
2. Scroll down to the **Artifacts** section.
3. Tap **GoldMine-Investment-v1.0-Debug** (or Release) to download the APK.
4. Open the downloaded `app-debug.apk` file on your phone, tap **Install**, and launch GoldMine!

---

## 💻 Optional: Building in Android Studio (If Using PC / Mac)
1. Open Android Studio (Hedgehog or newer).
2. Choose **Open Project** and select this directory.
3. Allow Gradle to sync.
4. Click **Run** or go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
