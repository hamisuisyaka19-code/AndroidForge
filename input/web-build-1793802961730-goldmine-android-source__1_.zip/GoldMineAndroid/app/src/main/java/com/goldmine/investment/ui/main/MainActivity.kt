package com.goldmine.investment.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.goldmine.investment.R
import com.goldmine.investment.databinding.ActivityMainBinding
import com.goldmine.investment.ui.countdown.CountdownFragment
import com.goldmine.investment.ui.home.HomeFragment
import com.goldmine.investment.ui.plans.InvestmentPlansFragment
import com.goldmine.investment.ui.profile.ProfileFragment
import com.goldmine.investment.ui.wallet.WalletFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initial default tab: HomeFragment
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.nav_invest -> {
                    loadFragment(InvestmentPlansFragment())
                    true
                }
                R.id.nav_countdown -> {
                    loadFragment(CountdownFragment())
                    true
                }
                R.id.nav_wallet -> {
                    loadFragment(WalletFragment())
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    fun navigateToTab(tabId: Int) {
        binding.bottomNavigation.selectedItemId = tabId
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
