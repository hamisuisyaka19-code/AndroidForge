package com.goldmine.investment.ui.deposit

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.databinding.ActivityDepositBinding
import kotlinx.coroutines.launch

class DepositActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDepositBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDepositBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDepositBack.setOnClickListener { finish() }

        binding.btnSubmitDeposit.setOnClickListener {
            val amt = binding.etDepositAmount.text.toString().toDoubleOrNull() ?: 0.0
            if (amt < 500) {
                Toast.makeText(this, "Minimum deposit is ₦500.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.pbDeposit.visibility = View.VISIBLE
            binding.btnSubmitDeposit.isEnabled = false

            lifecycleScope.launch {
                // Submit deposit request
                kotlinx.coroutines.delay(1000)
                binding.pbDeposit.visibility = View.GONE
                binding.btnSubmitDeposit.isEnabled = true
                Toast.makeText(this@DepositActivity, "Deposit notification submitted! Your balance will be credited after confirmation.", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }
}
