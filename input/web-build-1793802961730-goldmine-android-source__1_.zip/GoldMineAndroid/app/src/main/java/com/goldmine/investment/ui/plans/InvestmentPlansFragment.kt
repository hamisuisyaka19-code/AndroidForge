package com.goldmine.investment.ui.plans

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.data.model.InvestmentPlan
import com.goldmine.investment.databinding.FragmentPlansBinding
import com.goldmine.investment.ui.invest.InvestActivity
import kotlinx.coroutines.launch

class InvestmentPlansFragment : Fragment() {
    private var _binding: FragmentPlansBinding? = null
    private val binding get() = _binding!!
    private lateinit var plansAdapter: PlansAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlansBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        plansAdapter = PlansAdapter(emptyList()) { plan ->
            val intent = Intent(requireContext(), InvestActivity::class.java).apply {
                putExtra("plan_id", plan.id)
                putExtra("plan_name", plan.name)
                putExtra("min_amount", plan.minAmount)
                putExtra("max_amount", plan.maxAmount)
                putExtra("roi_percentage", plan.roiPercentage)
                putExtra("duration_days", plan.durationDays)
                putExtra("duration_label", plan.durationLabel)
            }
            startActivity(intent)
        }

        binding.rvPlans.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlans.adapter = plansAdapter

        loadPlans()
    }

    private fun loadPlans() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = ApiClient.getService(requireContext())
                val resp = api.getInvestmentPlans()
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val plans = resp.body()!!.data!!.plans
                    plansAdapter.updatePlans(plans)
                } else {
                    Toast.makeText(requireContext(), "Unable to load investment packages", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Connection error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
