package com.goldmine.investment

import android.app.Application

class GoldMineApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: GoldMineApp
            private set
    }
}
