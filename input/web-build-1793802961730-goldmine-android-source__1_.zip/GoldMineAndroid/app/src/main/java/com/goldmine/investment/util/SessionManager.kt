package com.goldmine.investment.util

import android.content.Context
import android.content.SharedPreferences
import com.goldmine.investment.data.model.User
import com.google.gson.Gson

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveAuthToken(token: String) {
        prefs.edit().putString(Constants.KEY_AUTH_TOKEN, token).apply()
    }

    fun getAuthToken(): String? {
        return prefs.getString(Constants.KEY_AUTH_TOKEN, null)
    }

    fun saveUser(user: User) {
        prefs.edit().putString(Constants.KEY_USER_JSON, gson.toJson(user)).apply()
    }

    fun getUser(): User? {
        val json = prefs.getString(Constants.KEY_USER_JSON, null) ?: return null
        return try {
            gson.fromJson(json, User::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun isLoggedIn(): Boolean {
        return !getAuthToken().isNullOrEmpty()
    }

    fun isBalanceHidden(): Boolean {
        return prefs.getBoolean(Constants.KEY_BALANCE_HIDDEN, false)
    }

    fun toggleBalanceHidden(): Boolean {
        val current = isBalanceHidden()
        prefs.edit().putBoolean(Constants.KEY_BALANCE_HIDDEN, !current).apply()
        return !current
    }

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
