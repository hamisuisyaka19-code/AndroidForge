package com.goldmine.investment.data.api

import com.goldmine.investment.data.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface GoldMineApiService {

    @POST("auth.php?action=login")
    suspend fun login(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthResponse>>

    @POST("auth.php?action=register")
    suspend fun register(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthResponse>>

    @GET("plans.php")
    suspend fun getInvestmentPlans(): Response<ApiResponse<PlansResponse>>

    @POST("invest.php")
    suspend fun placeInvestment(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("my_investments.php")
    suspend fun getMyInvestments(): Response<ApiResponse<InvestmentsResponse>>

    @GET("wallet.php")
    suspend fun getWalletData(): Response<ApiResponse<WalletResponse>>

    @GET("withdraw.php")
    suspend fun getWithdrawalInfo(): Response<ApiResponse<Map<String, Any>>>

    @POST("withdraw.php")
    suspend fun submitWithdrawal(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("deposit.php")
    suspend fun getDepositInfo(): Response<ApiResponse<Map<String, Any>>>

    @Multipart
    @POST("deposit.php")
    suspend fun submitDeposit(
        @Part("amount") amount: RequestBody,
        @Part receipt: MultipartBody.Part?
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("transactions.php")
    suspend fun getTransactions(
        @Query("type") type: String? = null,
        @Query("limit") limit: Int = 20
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("profile.php")
    suspend fun getProfile(): Response<ApiResponse<ProfileResponse>>

    @POST("profile.php")
    suspend fun updateProfile(
        @Body request: Map<String, String>
    ): Response<ApiResponse<Any>>
}
