package com.goldmine.investment.ui.wallet

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.FragmentWalletBinding
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.Formatters
import kotlinx.coroutines.launch

class WalletFragment : Fragment() {
    private var _binding: FragmentWalletBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: TransactionsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWalletBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = TransactionsAdapter(emptyList())
        binding.rvWalletTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvWalletTransactions.adapter = adapter

        binding.btnWalletDeposit.setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }

        binding.btnWalletWithdraw.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }

        loadWalletData()
    }

    private fun loadWalletData() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = ApiClient.getService(requireContext())
                val resp = api.getWalletData()
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val data = resp.body()!!.data!!
                    binding.tvWalletBalance.text = Formatters.formatNaira(data.walletBalance)
                    adapter.updateList(data.recentTransactions)
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
