package com.goldmine.investment.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.ActivityLoginBinding
import com.goldmine.investment.ui.main.MainActivity
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        binding.btnLogin.setOnClickListener {
            val input = binding.etLoginInput.text.toString().trim()
            val pass = binding.etPassword.text.toString().trim()

            if (input.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter your email/phone and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performLogin(input, pass)
        }

        binding.btnCreateAccount.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        binding.tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Please contact GoldMine support to reset your password", Toast.LENGTH_LONG).show()
        }
    }

    private fun performLogin(input: String, pass: String) {
        binding.pbLogin.visibility = View.VISIBLE
        binding.btnLogin.isEnabled = false

        lifecycleScope.launch {
            try {
                val api = ApiClient.getService(this@LoginActivity)
                val resp = api.login(mapOf("login_input" to input, "password" to pass))
                binding.pbLogin.visibility = View.GONE
                binding.btnLogin.isEnabled = true

                if (resp.isSuccessful && resp.body()?.success == true) {
                    val auth = resp.body()!!.data!!
                    session.saveAuthToken(auth.token)
                    session.saveUser(auth.user)
                    Toast.makeText(this@LoginActivity, "Welcome back, ${auth.user.fullName}!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                } else {
                    val err = resp.body()?.message ?: "Invalid email/phone or password"
                    Toast.makeText(this@LoginActivity, err, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.pbLogin.visibility = View.GONE
                binding.btnLogin.isEnabled = true
                Toast.makeText(this@LoginActivity, "Connection error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
