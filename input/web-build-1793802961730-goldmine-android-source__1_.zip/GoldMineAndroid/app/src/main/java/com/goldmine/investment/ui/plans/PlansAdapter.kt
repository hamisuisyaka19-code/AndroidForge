package com.goldmine.investment.ui.plans

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.InvestmentPlan
import com.goldmine.investment.databinding.ItemPlanCardBinding
import com.goldmine.investment.util.Formatters

class PlansAdapter(
    private var plans: List<InvestmentPlan>,
    private val onInvestClick: (InvestmentPlan) -> Unit
) : RecyclerView.Adapter<PlansAdapter.PlanViewHolder>() {

    fun updatePlans(newPlans: List<InvestmentPlan>) {
        this.plans = newPlans
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {
        val binding = ItemPlanCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PlanViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        holder.bind(plans[position])
    }

    override fun getItemCount(): Int = plans.size

    inner class PlanViewHolder(private val binding: ItemPlanCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(plan: InvestmentPlan) {
            binding.tvPlanName.text = plan.name
            binding.tvBadge.text = "${plan.profitRate.toInt()}% Profit"
            binding.tvMinAmount.text = "Min: ${Formatters.formatNaira(plan.minAmount)}"
            binding.tvDuration.text = "Duration: ${plan.durationLabel}"

            binding.btnInvestNow.setOnClickListener {
                onInvestClick(plan)
            }
        }
    }
}
