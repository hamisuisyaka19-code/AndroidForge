package com.goldmine.investment.ui.countdown

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.FragmentCountdownBinding
import kotlinx.coroutines.launch

class CountdownFragment : Fragment() {
    private var _binding: FragmentCountdownBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ActiveInvestmentsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCountdownBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ActiveInvestmentsAdapter(emptyList())
        binding.rvActiveInvestments.layoutManager = LinearLayoutManager(requireContext())
        binding.rvActiveInvestments.adapter = adapter

        loadCountdownData()
    }

    override fun onResume() {
        super.onResume()
        adapter.startTicker()
    }

    override fun onPause() {
        super.onPause()
        adapter.stopTicker()
    }

    private fun loadCountdownData() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = ApiClient.getService(requireContext())
                val resp = api.getMyInvestments()
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val data = resp.body()!!.data!!
                    binding.tvActiveCount.text = data.summary.activeCount.toString()
                    binding.tvCompletedCount.text = data.summary.completedCount.toString()
                    adapter.updateInvestments(data.active)
                } else {
                    Toast.makeText(requireContext(), "Unable to fetch countdown data", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Connection error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
