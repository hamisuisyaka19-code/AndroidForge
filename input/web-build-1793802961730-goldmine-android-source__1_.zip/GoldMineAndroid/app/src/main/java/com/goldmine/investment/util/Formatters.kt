package com.goldmine.investment.util

import java.text.NumberFormat
import java.util.Locale

object Formatters {
    private val currencyFormat = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    fun formatNaira(amount: Double): String {
        return "₦${currencyFormat.format(amount)}"
    }

    fun formatDuration(totalSeconds: Long): String {
        if (totalSeconds <= 0) return "Matured"
        val days = totalSeconds / 86400
        val hours = (totalSeconds % 86400) / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (days > 0) {
            "${days}d ${hours}h ${minutes}m ${seconds}s"
        } else {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        }
    }
}
