package com.goldmine.investment.ui.invest

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.ActivityInvestBinding
import com.goldmine.investment.util.Formatters
import kotlinx.coroutines.launch

class InvestActivity : AppCompatActivity() {
    private lateinit var binding: ActivityInvestBinding
    private var planId: Int = 1
    private var planName: String = "Starter Plan"
    private var minAmount: Double = 1000.0
    private var maxAmount: Double = 4999.0
    private var roiPercent: Double = 35.0
    private var durationDays: Int = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInvestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        planId = intent.getIntExtra("plan_id", 1)
        planName = intent.getStringExtra("plan_name") ?: "Starter Plan"
        minAmount = intent.getDoubleExtra("min_amount", 1000.0)
        maxAmount = intent.getDoubleExtra("max_amount", 4999.0)
        roiPercent = intent.getDoubleExtra("roi_percentage", 35.0)
        durationDays = intent.getIntExtra("duration_days", 3)

        binding.tvInvestPlanTitle.text = planName
        binding.tvInvestPlanDesc.text = "Invest and earn ${roiPercent.toInt()}% profit in ${durationDays} days."
        binding.tvInvestMin.text = "Minimum Amount: ${Formatters.formatNaira(minAmount)}"
        binding.tvInvestDuration.text = "Duration: ${durationDays} Days"
        binding.etInvestAmount.setText(minAmount.toInt().toString())

        updateCalculation(minAmount)

        binding.btnInvestBack.setOnClickListener { finish() }

        binding.etInvestAmount.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val amt = s.toString().toDoubleOrNull() ?: 0.0
                updateCalculation(amt)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnSubmitInvest.setOnClickListener {
            val amount = binding.etInvestAmount.text.toString().toDoubleOrNull() ?: 0.0
            if (amount < minAmount) {
                Toast.makeText(this, "Minimum investment is ${Formatters.formatNaira(minAmount)}", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (amount > maxAmount) {
                Toast.makeText(this, "Maximum investment is ${Formatters.formatNaira(maxAmount)}", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            executeInvest(amount)
        }
    }

    private fun updateCalculation(amount: Double) {
        val profit = amount * (roiPercent / 100.0)
        val total = amount + profit
        binding.tvCalculatedReturn.text = "Total Return: ${Formatters.formatNaira(total)} (Profit: ${Formatters.formatNaira(profit)})"
    }

    private fun executeInvest(amount: Double) {
        binding.pbInvest.visibility = View.VISIBLE
        binding.btnSubmitInvest.isEnabled = false

        lifecycleScope.launch {
            try {
                val api = ApiClient.getService(this@InvestActivity)
                val resp = api.placeInvestment(mapOf("plan_id" to planId, "amount" to amount))
                binding.pbInvest.visibility = View.GONE
                binding.btnSubmitInvest.isEnabled = true

                if (resp.isSuccessful && resp.body()?.success == true) {
                    Toast.makeText(this@InvestActivity, "Investment activated! Countdown started.", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    val msg = resp.body()?.message ?: "Investment failed"
                    Toast.makeText(this@InvestActivity, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.pbInvest.visibility = View.GONE
                binding.btnSubmitInvest.isEnabled = true
                Toast.makeText(this@InvestActivity, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
