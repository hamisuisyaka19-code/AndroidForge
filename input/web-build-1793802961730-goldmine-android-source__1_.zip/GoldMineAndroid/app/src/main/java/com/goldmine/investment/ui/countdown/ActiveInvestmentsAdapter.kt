package com.goldmine.investment.ui.countdown

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.Investment
import com.goldmine.investment.databinding.ItemActiveInvestmentBinding
import com.goldmine.investment.util.Formatters

class ActiveInvestmentsAdapter(
    private var investments: List<Investment>
) : RecyclerView.Adapter<ActiveInvestmentsAdapter.InvestmentViewHolder>() {

    private val handler = Handler(Looper.getMainLooper())
    private val tickerRunnable = object : Runnable {
        override fun run() {
            notifyDataSetChanged()
            handler.postDelayed(this, 1000)
        }
    }

    fun startTicker() {
        handler.removeCallbacks(tickerRunnable)
        handler.postDelayed(tickerRunnable, 1000)
    }

    fun stopTicker() {
        handler.removeCallbacks(tickerRunnable)
    }

    fun updateInvestments(newList: List<Investment>) {
        this.investments = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvestmentViewHolder {
        val binding = ItemActiveInvestmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return InvestmentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: InvestmentViewHolder, position: Int) {
        holder.bind(investments[position])
    }

    override fun getItemCount(): Int = investments.size

    inner class InvestmentViewHolder(private val binding: ItemActiveInvestmentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(inv: Investment) {
            binding.tvActivePlanName.text = inv.planName
            binding.tvActiveAmount.text = Formatters.formatNaira(inv.amount)
            binding.tvActiveProfit.text = "Profit: ${Formatters.formatNaira(inv.profit)} (${inv.roiPercentage.toInt()}%)"

            // Compute exact real-time seconds remaining
            val nowSeconds = System.currentTimeMillis() / 1000
            val remaining = Math.max(0L, inv.maturityTimestamp - nowSeconds)

            if (remaining > 0) {
                val days = remaining / 86400
                val hours = (remaining % 86400) / 3600
                val minutes = (remaining % 3600) / 60
                val seconds = remaining % 60
                binding.tvCountdownTicker.text = "Time Left: ${days} Days ${String.format("%02d", hours)} Hours ${String.format("%02d", minutes)} Minutes ${String.format("%02d", seconds)} Seconds"
            } else {
                binding.tvCountdownTicker.text = "Status: Matured & Credited to Wallet"
            }

            // Progress bar
            val totalSec = Math.max(1L, inv.maturityTimestamp - inv.startTimestamp)
            val elapsed = Math.max(0L, nowSeconds - inv.startTimestamp)
            val percent = Math.min(100, ((elapsed.toDouble() / totalSec) * 100).toInt())
            binding.pbElapsed.progress = percent
        }
    }
}
