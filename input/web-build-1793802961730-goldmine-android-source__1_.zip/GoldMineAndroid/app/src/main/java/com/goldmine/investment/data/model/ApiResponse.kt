package com.goldmine.investment.data.model

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("data") val data: T?,
    @SerializedName("timestamp") val timestamp: Long
)

data class AuthResponse(
    @SerializedName("token") val token: String,
    @SerializedName("user") val user: User
)

data class User(
    @SerializedName("id") val id: Int,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("balance") val balance: Double,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double,
    @SerializedName("status") val status: String,
    @SerializedName("is_verified") val isVerified: Boolean = true
)

data class InvestmentPlan(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String,
    @SerializedName("profit_rate") val profitRate: Double,
    @SerializedName("roi_percentage") val roiPercentage: Double,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("duration_label") val durationLabel: String,
    @SerializedName("min_amount") val minAmount: Double,
    @SerializedName("max_amount") val maxAmount: Double,
    @SerializedName("example_min_profit") val exampleMinProfit: Double,
    @SerializedName("example_total_return") val exampleTotalReturn: Double,
    @SerializedName("description") val description: String,
    @SerializedName("badge") val badge: String,
    @SerializedName("is_popular") val isPopular: Boolean
)

data class PlansResponse(
    @SerializedName("plans") val plans: List<InvestmentPlan>,
    @SerializedName("currency") val currency: String,
    @SerializedName("risk_disclosure") val riskDisclosure: String
)

data class Investment(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("plan_name") val planName: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("profit") val profit: Double,
    @SerializedName("roi_percentage") val roiPercentage: Double,
    @SerializedName("expected_return") val expectedReturn: Double,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("start_date") val startDate: String?,
    @SerializedName("maturity_date") val maturityDate: String?,
    @SerializedName("start_timestamp") val startTimestamp: Long,
    @SerializedName("maturity_timestamp") val maturityTimestamp: Long,
    @SerializedName("remaining_seconds") var remainingSeconds: Long,
    @SerializedName("progress_percent") var progressPercent: Double,
    @SerializedName("status") val status: String
)

data class InvestmentsResponse(
    @SerializedName("summary") val summary: InvestmentSummary,
    @SerializedName("server_time") val serverTime: Long,
    @SerializedName("active") val active: List<Investment>,
    @SerializedName("completed") val completed: List<Investment>,
    @SerializedName("pending") val pending: List<Investment>
)

data class InvestmentSummary(
    @SerializedName("active_count") val activeCount: Int,
    @SerializedName("completed_count") val completedCount: Int,
    @SerializedName("pending_count") val pendingCount: Int,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double
)

data class WalletResponse(
    @SerializedName("wallet_balance") val walletBalance: Double,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double,
    @SerializedName("pending_deposits") val pendingDeposits: Double,
    @SerializedName("pending_withdrawals") val pendingWithdrawals: Double,
    @SerializedName("currency") val currency: String,
    @SerializedName("recent_transactions") val recentTransactions: List<Transaction>
)

data class Transaction(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("type") val type: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("balance_after") val balanceAfter: Double?,
    @SerializedName("status") val status: String,
    @SerializedName("description") val description: String,
    @SerializedName("created_at") val createdAt: String
)

data class BankDetails(
    @SerializedName("bank_name") val bankName: String,
    @SerializedName("account_number") val accountNumber: String,
    @SerializedName("account_name") val accountName: String
)

data class ProfileResponse(
    @SerializedName("user") val user: User,
    @SerializedName("bank_details") val bankDetails: BankDetails?,
    @SerializedName("unread_notifications") val unreadNotifications: Int
)
