package com.goldmine.investment.util

object Constants {
    // Official cPanel Production Backend Base URL
    const val BASE_URL = "https://goalmindai.com.ng/api/"
    
    const val CURRENCY = "₦"
    const val PREFS_NAME = "goldmine_secure_prefs"
    const val KEY_AUTH_TOKEN = "auth_token"
    const val KEY_USER_JSON = "user_json"
    const val KEY_BALANCE_HIDDEN = "balance_hidden"
}
