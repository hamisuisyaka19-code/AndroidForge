package com.goldmine.investment.ui.withdraw

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.ActivityWithdrawBinding
import com.goldmine.investment.util.Formatters
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class WithdrawActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWithdrawBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWithdrawBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        val user = session.getUser()
        if (user != null) {
            binding.tvAvailableWithdraw.text = Formatters.formatNaira(user.balance)
        }

        binding.btnWithdrawBack.setOnClickListener { finish() }

        binding.btnSubmitWithdraw.setOnClickListener {
            val amount = binding.etWithdrawAmount.text.toString().toDoubleOrNull() ?: 0.0
            val bankName = binding.etBankName.text.toString().trim()
            val accNo = binding.etAccountNumber.text.toString().trim()
            val accName = binding.etAccountName.text.toString().trim()

            if (amount < 2000) {
                Toast.makeText(this, "Minimum withdrawal is ₦2,000.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val currentBal = user?.balance ?: 0.0
            if (amount > currentBal) {
                Toast.makeText(this, "Insufficient balance (${Formatters.formatNaira(currentBal)})", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (bankName.isEmpty() || accNo.isEmpty() || accName.isEmpty()) {
                Toast.makeText(this, "Please enter complete bank account details", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performWithdrawal(amount, bankName, accNo, accName)
        }
    }

    private fun performWithdrawal(amount: Double, bank: String, accNo: String, accName: String) {
        binding.pbWithdraw.visibility = View.VISIBLE
        binding.btnSubmitWithdraw.isEnabled = false

        lifecycleScope.launch {
            try {
                val api = ApiClient.getService(this@WithdrawActivity)
                val body = mapOf(
                    "amount" to amount,
                    "bank_name" to bank,
                    "account_number" to accNo,
                    "account_name" to accName
                )
                val resp = api.submitWithdrawal(body)
                binding.pbWithdraw.visibility = View.GONE
                binding.btnSubmitWithdraw.isEnabled = true

                if (resp.isSuccessful && resp.body()?.success == true) {
                    Toast.makeText(this@WithdrawActivity, "Withdrawal submitted for administrator approval!", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    val msg = resp.body()?.message ?: "Withdrawal request failed"
                    Toast.makeText(this@WithdrawActivity, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.pbWithdraw.visibility = View.GONE
                binding.btnSubmitWithdraw.isEnabled = true
                Toast.makeText(this@WithdrawActivity, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
