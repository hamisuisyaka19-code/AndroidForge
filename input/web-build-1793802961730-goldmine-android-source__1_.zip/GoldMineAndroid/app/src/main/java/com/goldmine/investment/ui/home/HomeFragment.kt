package com.goldmine.investment.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.R
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.data.model.InvestmentPlan
import com.goldmine.investment.databinding.FragmentHomeBinding
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.invest.InvestActivity
import com.goldmine.investment.ui.main.MainActivity
import com.goldmine.investment.ui.plans.PlansAdapter
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.Formatters
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var session: SessionManager
    private lateinit var plansAdapter: PlansAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        val user = session.getUser()
        if (user != null) {
            binding.tvGreeting.text = "Hello, ${user.fullName.split(" ")[0]} 👋"
            binding.tvBalance.text = Formatters.formatNaira(user.balance)
            binding.tvInvested.text = Formatters.formatNaira(user.totalInvested)
            binding.tvProfit.text = "+${Formatters.formatNaira(user.totalProfit)}"
        }

        binding.ivEyeToggle.setOnClickListener {
            val hidden = session.toggleBalanceHidden()
            if (hidden) {
                binding.tvBalance.text = "₦ ••••••••"
            } else {
                binding.tvBalance.text = Formatters.formatNaira(session.getUser()?.balance ?: 0.0)
            }
        }

        plansAdapter = PlansAdapter(emptyList()) { plan ->
            navigateToInvest(plan)
        }
        binding.rvPlansPreview.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlansPreview.adapter = plansAdapter

        binding.tvSeeAll.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }

        binding.btnDepositAction.setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }

        binding.btnInvestAction.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }

        binding.btnWithdrawAction.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }

        binding.btnSupportAction.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_profile)
        }

        fetchDashboardData()
    }

    private fun navigateToInvest(plan: InvestmentPlan) {
        val intent = Intent(requireContext(), InvestActivity::class.java).apply {
            putExtra("plan_id", plan.id)
            putExtra("plan_name", plan.name)
            putExtra("min_amount", plan.minAmount)
            putExtra("max_amount", plan.maxAmount)
            putExtra("roi_percentage", plan.roiPercentage)
            putExtra("duration_days", plan.durationDays)
            putExtra("duration_label", plan.durationLabel)
        }
        startActivity(intent)
    }

    private fun fetchDashboardData() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val api = ApiClient.getService(requireContext())
                // Fetch wallet and plans in parallel
                val walletResp = api.getWalletData()
                if (walletResp.isSuccessful && walletResp.body()?.success == true) {
                    val w = walletResp.body()!!.data!!
                    binding.tvBalance.text = Formatters.formatNaira(w.walletBalance)
                    binding.tvInvested.text = Formatters.formatNaira(w.totalInvested)
                    binding.tvProfit.text = "+${Formatters.formatNaira(w.totalProfit)}"
                }

                val plansResp = api.getInvestmentPlans()
                if (plansResp.isSuccessful && plansResp.body()?.success == true) {
                    val plans = plansResp.body()!!.data!!.plans
                    plansAdapter.updatePlans(plans.take(2))
                }
            } catch (e: Exception) {
                // Fallback graceful load
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
