package com.goldmine.investment.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.ActivityRegisterBinding
import com.goldmine.investment.ui.main.MainActivity
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        binding.btnBack.setOnClickListener { finish() }
        binding.tvLoginLink.setOnClickListener { finish() }

        binding.btnRegister.setOnClickListener {
            val name = binding.etFullName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val pass = binding.etPassword.text.toString().trim()
            val confirmPass = binding.etConfirmPassword.text.toString().trim()

            if (name.isEmpty() || phone.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Full name, phone, and password are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (pass != confirmPass) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!binding.cbAgree.isChecked) {
                Toast.makeText(this, "Please agree to the Terms & Conditions", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            performRegister(name, phone, email, pass)
        }
    }

    private fun performRegister(name: String, phone: String, email: String, pass: String) {
        binding.pbRegister.visibility = View.VISIBLE
        binding.btnRegister.isEnabled = false

        lifecycleScope.launch {
            try {
                val api = ApiClient.getService(this@RegisterActivity)
                val body = mutableMapOf(
                    "full_name" to name,
                    "phone" to phone,
                    "password" to pass
                )
                if (email.isNotEmpty()) body["email"] = email

                val resp = api.register(body)
                binding.pbRegister.visibility = View.GONE
                binding.btnRegister.isEnabled = true

                if (resp.isSuccessful && resp.body()?.success == true) {
                    val auth = resp.body()!!.data!!
                    session.saveAuthToken(auth.token)
                    session.saveUser(auth.user)
                    Toast.makeText(this@RegisterActivity, "Account created successfully!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@RegisterActivity, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                } else {
                    val err = resp.body()?.message ?: "Registration failed"
                    Toast.makeText(this@RegisterActivity, err, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.pbRegister.visibility = View.GONE
                binding.btnRegister.isEnabled = true
                Toast.makeText(this@RegisterActivity, "Connection error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
