package com.goldmine.investment.ui.wallet

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.Transaction
import com.goldmine.investment.databinding.ItemTransactionBinding
import com.goldmine.investment.util.Formatters

class TransactionsAdapter(
    private var transactions: List<Transaction>
) : RecyclerView.Adapter<TransactionsAdapter.TxViewHolder>() {

    fun updateList(newList: List<Transaction>) {
        this.transactions = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TxViewHolder {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TxViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TxViewHolder, position: Int) {
        holder.bind(transactions[position])
    }

    override fun getItemCount(): Int = transactions.size

    inner class TxViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(tx: Transaction) {
            binding.tvTxDesc.text = tx.description
            binding.tvTxDate.text = tx.createdAt
            binding.tvTxStatus.text = tx.status.capitalize()

            val isCredit = tx.type == "deposit" || tx.type == "roi_payout"
            val prefix = if (isCredit) "+" else "-"
            binding.tvTxAmount.text = "$prefix${Formatters.formatNaira(tx.amount)}"
            binding.tvTxAmount.setTextColor(if (isCredit) Color.parseColor("#22C55E") else Color.parseColor("#EAB308"))
        }
    }
}
