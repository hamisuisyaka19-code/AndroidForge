package com.goldmine.investment.ui.deposit

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import kotlinx.coroutines.launch

class DepositActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deposit)

        val tvBank = findViewById<TextView>(R.id.tvBankName)
        val tvAcc = findViewById<TextView>(R.id.tvAccountNumber)
        val tvHolder = findViewById<TextView>(R.id.tvAccountHolder)
        val etAmount = findViewById<EditText>(R.id.etDepositAmount)
        val btnSubmit = findViewById<Button>(R.id.btnSubmitDeposit)

        lifecycleScope.launch {
            repository.getBankDetails().onSuccess { bank ->
                tvBank.text = bank.bankName
                tvAcc.text = bank.accountNumber
                tvHolder.text = bank.accountName
            }
        }

        btnSubmit.setOnClickListener {
            val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
            if (amount < 500) {
                Toast.makeText(this, "Minimum deposit is ₦500.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnSubmit.isEnabled = false
            lifecycleScope.launch {
                repository.submitDeposit(amount, "Manual Bank Transfer", null).onSuccess {
                    Toast.makeText(this@DepositActivity, "Deposit submitted for approval!", Toast.LENGTH_LONG).show()
                    finish()
                }.onFailure {
                    btnSubmit.isEnabled = true
                    Toast.makeText(this@DepositActivity, it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
