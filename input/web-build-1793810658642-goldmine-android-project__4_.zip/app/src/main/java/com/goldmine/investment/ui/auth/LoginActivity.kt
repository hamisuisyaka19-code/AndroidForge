package com.goldmine.investment.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.main.MainActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etInput = findViewById<EditText>(R.id.etLoginInput)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnSubmit = findViewById<Button>(R.id.btnLoginSubmit)

        btnSubmit.setOnClickListener {
            val input = etInput.text.toString().trim()
            val pass = etPassword.text.toString()

            if (input.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnSubmit.isEnabled = false
            lifecycleScope.launch {
                repository.login(input, pass).onSuccess { auth ->
                    GoldMineApplication.instance.sessionManager.saveAuth(auth.token, auth.user)
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finishAffinity()
                }.onFailure { err ->
                    btnSubmit.isEnabled = true
                    Toast.makeText(this@LoginActivity, err.message ?: "Login failed", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
