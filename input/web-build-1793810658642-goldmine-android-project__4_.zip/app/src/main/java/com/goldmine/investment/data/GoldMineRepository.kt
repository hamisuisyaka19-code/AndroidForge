package com.goldmine.investment.data

import com.goldmine.investment.api.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class GoldMineRepository(private val api: GoldMineApiService = ApiClient.apiService) {

    suspend fun login(loginInput: String, pass: String): Result<AuthData> {
        return try {
            val res = api.login(mapOf("login_input" to loginInput, "password" to pass))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Login failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(fullName: String, email: String, phone: String, pass: String): Result<AuthData> {
        return try {
            val res = api.register(mapOf(
                "full_name" to fullName,
                "email" to email,
                "phone" to phone,
                "password" to pass
            ))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Registration failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getProfile(): Result<UserDto> {
        return try {
            val res = api.getProfile()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Failed to fetch profile"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPlans(): Result<List<PlanDto>> {
        return try {
            val res = api.getPlans()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Failed to fetch plans"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getInvestments(): Result<InvestmentData> {
        return try {
            val res = api.getInvestments()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Failed to fetch investments"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun invest(planId: Int, amount: Double): Result<Map<String, Any>> {
        return try {
            val res = api.createInvestment(mapOf("plan_id" to planId, "amount" to amount))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Investment failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getBankDetails(): Result<BankDetailsDto> {
        return try {
            val res = api.getBankDetails()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Failed to get bank details"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitDeposit(amount: Double, method: String, receiptFile: File?): Result<Map<String, Any>> {
        return try {
            val amountBody = amount.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val methodBody = method.toRequestBody("text/plain".toMediaTypeOrNull())
            val receiptPart = receiptFile?.let {
                val reqFile = it.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("receipt", it.name, reqFile)
            }
            val res = api.submitDepositMultipart(amountBody, methodBody, receiptPart)
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Deposit submission failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitWithdrawal(amount: Double, bankName: String, accNum: String, accName: String): Result<Map<String, Any>> {
        return try {
            val res = api.requestWithdrawal(mapOf(
                "amount" to amount,
                "bank_name" to bankName,
                "account_number" to accNum,
                "account_name" to accName
            ))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Withdrawal request failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTransactions(): Result<List<TransactionDto>> {
        return try {
            val res = api.getTransactions()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(res.body()?.message ?: "Failed to fetch transactions"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
