<?php
/**
 * GoldMine Investment Platform - Mobile REST API Configuration & Auth Guard
 * Target Server: goalmindai.com.ng
 * Compatible with existing cPanel database & admin dashboard
 */
declare(strict_types=1);

// Set strict JSON and UTF-8 encoding
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');

// Preflight OPTIONS response
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Load core platform configurations
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/payment.php';
require_once __DIR__ . '/../includes/functions.php';

/**
 * Standardized JSON API response helper
 */
function api_response(bool $success, string $message, mixed $data = null, int $status_code = 200): void {
    http_response_code($status_code);
    echo json_encode([
        'success'   => $success,
        'message'   => $message,
        'data'      => $data,
        'timestamp' => time(),
        'server_time' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Extract Bearer Token from HTTP request
 */
function get_bearer_token(): ?string {
    $headers = null;
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } elseif (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER['Authorization']);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
            $headers = trim($requestHeaders['Authorization']);
        }
    }

    if (!empty($headers)) {
        if (preg_match('/Bearer\s(\S+)/i', $headers, $matches)) {
            return $matches[1];
        }
    }
    return null;
}

/**
 * Require valid authenticated user session token
 */
function require_api_user(): array {
    $token = get_bearer_token();
    if (!$token) {
        api_response(false, 'Missing authentication token. Please login.', null, 401);
    }

    $pdo = get_db_connection();
    if (!$pdo) {
        api_response(false, 'Database connection error.', null, 500);
    }

    $stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, remember_token, created_at FROM users WHERE remember_token = ? LIMIT 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        api_response(false, 'Invalid or expired session. Please login again.', null, 401);
    }

    if ($user['status'] === 'suspended') {
        api_response(false, 'Your account is suspended. Please contact support.', null, 403);
    }

    // Auto-check any matured investments for this user
    check_matured_investments_for_user((int)$user['id'], $pdo);

    // Refresh user balance in case of maturity payouts
    $ref_stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, created_at FROM users WHERE id = ?");
    $ref_stmt->execute([(int)$user['id']]);
    $fresh_user = $ref_stmt->fetch();

    return $fresh_user ?: $user;
}

/**
 * Check matured investments and credit user balance atomically
 */
function check_matured_investments_for_user(int $user_id, PDO $pdo): void {
    try {
        $now = date('Y-m-d H:i:s');
        $stmt = $pdo->prepare("SELECT * FROM investments WHERE user_id = ? AND status = 'active' AND maturity_date IS NOT NULL AND maturity_date <= ?");
        $stmt->execute([$user_id, $now]);
        $matured = $stmt->fetchAll();

        foreach ($matured as $inv) {
            $pdo->beginTransaction();
            $upd = $pdo->prepare("UPDATE investments SET status = 'completed' WHERE id = ?");
            $upd->execute([$inv['id']]);

            $payout = (float)$inv['expected_return'];
            $profit = $payout - (float)$inv['amount'];

            $cred = $pdo->prepare("UPDATE users SET balance = balance + ?, total_profit = total_profit + ? WHERE id = ?");
            $cred->execute([$payout, $profit, $user_id]);

            $ref = generate_reference('ROI');
            $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'roi_payout', ?, 'completed', ?)");
            $tx->execute([$ref, $user_id, $payout, "Matured Return for " . $inv['plan_name']]);

            add_user_notification(
                $user_id,
                "Investment Matured & Credited!",
                "Your investment {$inv['reference_code']} in {$inv['plan_name']} has matured! " . format_currency($payout) . " has been credited to your wallet balance.",
                "success",
                "/my-invest.php"
            );

            $pdo->commit();
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Maturity check failed: " . $e->getMessage());
    }
}

/**
 * Parse JSON or POST payload safely
 */
function get_json_input(): array {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            return $json;
        }
    }
    return $_POST;
}
