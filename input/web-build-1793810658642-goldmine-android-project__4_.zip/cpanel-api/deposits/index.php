<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 20");
    $stmt->execute([$user_id]);
    $deposits = $stmt->fetchAll();

    $formatted = array_map(function($d) {
        return [
            'id'             => (int)$d['id'],
            'reference_code' => $d['reference_code'],
            'amount'         => (float)$d['amount'],
            'amount_formatted' => format_currency($d['amount']),
            'payment_method' => $d['payment_method'],
            'status'         => $d['status'],
            'receipt_path'   => $d['receipt_path'] ? (APP_URL . '/' . ltrim($d['receipt_path'], '/')) : null,
            'created_at'     => $d['created_at']
        ];
    }, $deposits);

    api_response(true, 'Deposit history retrieved.', $formatted);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (float)($_POST['amount'] ?? 0);
    $method = trim($_POST['payment_method'] ?? 'Bank Transfer');

    if ($amount <= 0) {
        $json = get_json_input();
        $amount = (float)($json['amount'] ?? 0);
        $method = trim($json['payment_method'] ?? 'Bank Transfer');
    }

    if ($amount < 500) {
        api_response(false, 'Minimum deposit amount is ₦500.00', null, 400);
    }

    $upload_rel_path = null;
    $upload_dir = __DIR__ . '/../../uploads/deposit_receipts';

    // Handle multipart file upload if present
    if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }
        $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'pdf'])) {
            $ext = 'jpg';
        }
        $filename = bin2hex(random_bytes(24)) . '.' . $ext;
        $dest = $upload_dir . '/' . $filename;
        if (move_uploaded_file($_FILES['receipt']['tmp_name'], $dest)) {
            $upload_rel_path = 'uploads/deposit_receipts/' . $filename;
        }
    } elseif (!empty($_POST['receipt_base64']) || !empty($json['receipt_base64'])) {
        // Handle Base64 encoded receipt image from mobile
        $b64 = $_POST['receipt_base64'] ?? $json['receipt_base64'];
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }
        if (preg_match('/^data:image\/(\w+);base64,/', $b64, $type)) {
            $b64 = substr($b64, strpos($b64, ',') + 1);
            $ext = strtolower($type[1]);
        } else {
            $ext = 'jpg';
        }
        $data = base64_decode($b64);
        if ($data !== false) {
            $filename = bin2hex(random_bytes(24)) . '.' . $ext;
            file_put_contents($upload_dir . '/' . $filename, $data);
            $upload_rel_path = 'uploads/deposit_receipts/' . $filename;
        }
    }

    $ref = generate_reference('DEP');

    try {
        $pdo->beginTransaction();

        $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path) VALUES (?, ?, ?, ?, 'pending', ?)");
        $ins->execute([$ref, $user_id, $amount, $method, $upload_rel_path]);
        $dep_id = (int)$pdo->lastInsertId();

        $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'deposit', ?, 'pending', ?)");
        $tx->execute([$ref, $user_id, $amount, "Deposit request via " . $method]);

        add_user_notification(
            $user_id,
            "Deposit Request Submitted",
            "Your deposit request of " . format_currency($amount) . " ($ref) has been submitted for administrator review.",
            "info",
            "/deposit.php"
        );

        log_audit_action(null, $user_id, "Mobile App Deposit Submitted", "Ref: $ref, Amount: " . format_currency($amount));

        $pdo->commit();

        api_response(true, "Deposit request submitted! Once verified by administrator, your balance will be credited.", [
            'id'             => $dep_id,
            'reference_code' => $ref,
            'amount'         => $amount,
            'payment_method' => $method,
            'status'         => 'pending',
            'receipt_path'   => $upload_rel_path ? (APP_URL . '/' . $upload_rel_path) : null
        ], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        api_response(false, 'Deposit submission error: ' . $e->getMessage(), null, 500);
    }
}
