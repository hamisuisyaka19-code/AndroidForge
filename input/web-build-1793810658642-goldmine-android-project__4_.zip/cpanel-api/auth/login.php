<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    api_response(false, 'Method not allowed. Use POST.', null, 405);
}

$input = get_json_input();
$login_input = trim($input['login_input'] ?? $input['email'] ?? '');
$password = $input['password'] ?? '';

if (empty($login_input) || empty($password)) {
    api_response(false, 'Please provide email/phone and password.', null, 400);
}

$pdo = get_db_connection();
if (!$pdo) {
    api_response(false, 'Database unavailable.', null, 500);
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR phone = ?) LIMIT 1");
$stmt->execute([$login_input, $login_input]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    api_response(false, 'Invalid login credentials.', null, 401);
}

if ($user['status'] === 'suspended') {
    api_response(false, 'Your account is suspended. Contact support.', null, 403);
}

// Generate secure session token
$token = bin2hex(random_bytes(32));
$upd = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
$upd->execute([$token, $user['id']]);

log_audit_action(null, (int)$user['id'], 'Mobile App Login', 'Authenticated from Android App');

$userData = [
    'id'             => (int)$user['id'],
    'full_name'      => $user['full_name'],
    'email'          => $user['email'],
    'phone'          => $user['phone'],
    'balance'        => (float)$user['balance'],
    'balance_formatted' => format_currency($user['balance']),
    'total_invested' => (float)$user['total_invested'],
    'total_profit'   => (float)$user['total_profit'],
    'member_id'      => 'GM' . str_pad((string)$user['id'], 6, '0', STR_PAD_LEFT),
    'membership'     => 'VIP Member',
    'status'         => $user['status'],
    'created_at'     => $user['created_at']
];

api_response(true, 'Welcome back, ' . $user['full_name'], [
    'token' => $token,
    'user'  => $userData
]);
