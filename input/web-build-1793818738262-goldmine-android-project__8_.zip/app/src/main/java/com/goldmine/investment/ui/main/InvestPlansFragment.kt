package com.goldmine.investment.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.adapters.PlanAdapter
import kotlinx.coroutines.launch

class InvestPlansFragment : Fragment() {

    private val repository = GoldMineRepository()
    private lateinit var adapter: PlanAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_invest_plans, container, false)
        val rv = root.findViewById<RecyclerView>(R.id.rvPlans)
        rv.layoutManager = LinearLayoutManager(requireContext())

        adapter = PlanAdapter { plan ->
            viewLifecycleOwner.lifecycleScope.launch {
                repository.invest(plan.id, plan.minAmount).onSuccess {
                    Toast.makeText(requireContext(), "Order submitted! Ref: ${it["reference_code"]}", Toast.LENGTH_LONG).show()
                    (activity as? MainActivity)?.navigateToTab(R.id.nav_my_invest)
                }.onFailure {
                    Toast.makeText(requireContext(), it.message ?: "Investment failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
        rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getPlans().onSuccess { plans ->
                adapter.submitList(plans)
            }.onFailure {
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
            }
        }

        return root
    }
}
