package com.goldmine.investment.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.adapters.InvestmentAdapter
import kotlinx.coroutines.launch

class MyInvestmentsFragment : Fragment() {

    private val repository = GoldMineRepository()
    private lateinit var adapter: InvestmentAdapter
    private var showingActive = true

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_my_investments, container, false)
        val rv = root.findViewById<RecyclerView>(R.id.rvInvestments)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = InvestmentAdapter()
        rv.adapter = adapter

        val btnActive = root.findViewById<TextView>(R.id.tabActive)
        val btnCompleted = root.findViewById<TextView>(R.id.tabCompleted)

        loadInvestments(root)

        btnActive.setOnClickListener {
            showingActive = true
            loadInvestments(root)
        }

        btnCompleted.setOnClickListener {
            showingActive = false
            loadInvestments(root)
        }

        return root
    }

    private fun loadInvestments(root: View) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.getInvestments().onSuccess { data ->
                root.findViewById<TextView>(R.id.tabActive)?.text = "Active (${data.totalActive})"
                root.findViewById<TextView>(R.id.tabCompleted)?.text = "Completed (${data.totalCompleted})"
                adapter.submitList(if (showingActive) data.active else data.completed)
            }
        }
    }
}
