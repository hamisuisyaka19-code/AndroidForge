package com.goldmine.investment.util

import java.util.Locale
import java.util.concurrent.TimeUnit

object CountdownHelper {
    fun formatSeconds(seconds: Long): String {
        if (seconds <= 0) return "Matured / Completed"
        val days = TimeUnit.SECONDS.toDays(seconds)
        val hours = TimeUnit.SECONDS.toHours(seconds) % 24
        val minutes = TimeUnit.SECONDS.toMinutes(seconds) % 60
        val secs = seconds % 60

        return if (days > 0) {
            String.format(Locale.US, "%d Days %02d:%02d:%02d", days, hours, minutes, secs)
        } else {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
        }
    }
}
