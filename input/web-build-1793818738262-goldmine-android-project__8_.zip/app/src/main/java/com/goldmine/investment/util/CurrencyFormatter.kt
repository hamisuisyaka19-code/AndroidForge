package com.goldmine.investment.util

import java.text.DecimalFormat

object CurrencyFormatter {
    private val formatter = DecimalFormat("#,##0.00")

    fun format(amount: Double): String {
        return "₦" + formatter.format(amount)
    }

    fun formatClean(amount: Double): String {
        return "₦" + DecimalFormat("#,##0").format(amount)
    }
}
