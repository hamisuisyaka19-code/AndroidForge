package com.goldmine.investment.data

import android.content.Context
import android.content.SharedPreferences
import com.goldmine.investment.api.UserDto
import com.google.gson.Gson

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("goldmine_secure_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_USER = "user_profile"
        private const val KEY_BALANCE_HIDDEN = "balance_hidden"
    }

    fun saveAuth(token: String, user: UserDto) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER, gson.toJson(user))
            .apply()
    }

    fun saveUser(user: UserDto) {
        prefs.edit()
            .putString(KEY_USER, gson.toJson(user))
            .apply()
    }

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)

    fun getUser(): UserDto? {
        val json = prefs.getString(KEY_USER, null) ?: return null
        return try {
            gson.fromJson(json, UserDto::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun isLoggedIn(): Boolean = !getToken().isNullOrEmpty()

    fun isBalanceHidden(): Boolean = prefs.getBoolean(KEY_BALANCE_HIDDEN, false)

    fun toggleBalanceHidden(): Boolean {
        val newState = !isBalanceHidden()
        prefs.edit().putBoolean(KEY_BALANCE_HIDDEN, newState).apply()
        return newState
    }

    fun logout() {
        prefs.edit().clear().apply()
    }
}
