package com.goldmine.investment

import android.app.Application
import com.goldmine.investment.data.SessionManager

class GoldMineApplication : Application() {
    companion object {
        lateinit var instance: GoldMineApplication
            private set
    }

    lateinit var sessionManager: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        sessionManager = SessionManager(applicationContext)
    }
}
