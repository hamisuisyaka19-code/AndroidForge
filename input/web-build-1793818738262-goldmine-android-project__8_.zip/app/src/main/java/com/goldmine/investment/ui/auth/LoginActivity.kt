package com.goldmine.investment.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.main.MainActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etInput = findViewById<EditText>(R.id.etLoginInput)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnSubmit = findViewById<Button>(R.id.btnLoginSubmit)
        val tvError = findViewById<TextView>(R.id.tvLoginError)

        tvError.visibility = View.GONE

        btnSubmit.setOnClickListener {
            val input = etInput.text.toString().trim()
            val pass = etPassword.text.toString()

            if (input.isEmpty() || pass.isEmpty()) {
                tvError.text = "Please enter both email/phone and your password."
                tvError.visibility = View.VISIBLE
                return@setOnClickListener
            }

            tvError.visibility = View.GONE
            btnSubmit.isEnabled = false
            btnSubmit.text = "Signing In..."

            lifecycleScope.launch {
                repository.login(input, pass).onSuccess { auth ->
                    GoldMineApplication.instance.sessionManager.saveAuth(auth.token, auth.user)
                    Toast.makeText(this@LoginActivity, "Welcome back, ${auth.user.fullName}!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finishAffinity()
                }.onFailure { err ->
                    btnSubmit.isEnabled = true
                    btnSubmit.text = "Login"
                    val message = err.message ?: "Authentication failed. Please check credentials."
                    tvError.text = message
                    tvError.visibility = View.VISIBLE
                    Toast.makeText(this@LoginActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
