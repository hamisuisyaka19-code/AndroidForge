package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.transactions.TransactionsActivity
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private val repository = GoldMineRepository()
    private var currentBalance: Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        setupViews(root)
        fetchLatestData(root)
        return root
    }

    private fun setupViews(root: View) {
        val session = GoldMineApplication.instance.sessionManager
        val user = session.getUser()

        val tvUserName = root.findViewById<TextView>(R.id.tvUserName)
        tvUserName.text = user?.fullName ?: "Hamisu Isiyaka"

        val tvBalance = root.findViewById<TextView>(R.id.tvTotalBalance)
        val btnEye = root.findViewById<ImageButton>(R.id.btnEyeToggle)

        currentBalance = user?.balance ?: 125600.00
        updateBalanceDisplay(tvBalance, session.isBalanceHidden())

        btnEye.setOnClickListener {
            val isHidden = session.toggleBalanceHidden()
            updateBalanceDisplay(tvBalance, isHidden)
        }

        // Quick action buttons
        root.findViewById<View>(R.id.cardActionInvest).setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }
        root.findViewById<View>(R.id.cardActionDeposit).setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }
        root.findViewById<View>(R.id.cardActionWithdraw).setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }
        root.findViewById<View>(R.id.cardActionTransactions).setOnClickListener {
            startActivity(Intent(requireContext(), TransactionsActivity::class.java))
        }

        root.findViewById<View>(R.id.btnInvestNowBanner).setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }
    }

    private fun updateBalanceDisplay(tvBalance: TextView, isHidden: Boolean) {
        if (isHidden) {
            tvBalance.text = "₦ • • • • • •"
        } else {
            tvBalance.text = CurrencyFormatter.format(currentBalance)
        }
    }

    private fun fetchLatestData(root: View) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.getProfile().onSuccess { user ->
                GoldMineApplication.instance.sessionManager.saveUser(user)
                currentBalance = user.balance
                root.findViewById<TextView>(R.id.tvUserName)?.text = user.fullName
                root.findViewById<TextView>(R.id.tvTotalInvested)?.text = CurrencyFormatter.format(user.totalInvested)
                root.findViewById<TextView>(R.id.tvTotalProfit)?.text = CurrencyFormatter.format(user.totalProfit)
                updateBalanceDisplay(
                    root.findViewById(R.id.tvTotalBalance),
                    GoldMineApplication.instance.sessionManager.isBalanceHidden()
                )
            }
        }
    }
}
