package com.goldmine.investment.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.TransactionDto
import com.goldmine.investment.util.CurrencyFormatter

class TransactionAdapter : RecyclerView.Adapter<TransactionAdapter.TxViewHolder>() {

    private var items = listOf<TransactionDto>()

    fun submitList(list: List<TransactionDto>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TxViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
        return TxViewHolder(view)
    }

    override fun onBindViewHolder(holder: TxViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class TxViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDesc = itemView.findViewById<TextView>(R.id.tvTxDesc)
        private val tvRef = itemView.findViewById<TextView>(R.id.tvTxRef)
        private val tvAmount = itemView.findViewById<TextView>(R.id.tvTxAmount)
        private val tvStatus = itemView.findViewById<TextView>(R.id.tvTxStatus)

        fun bind(tx: TransactionDto) {
            tvDesc.text = tx.description ?: tx.type.replaceFirstChar { it.uppercase() }
            tvRef.text = tx.referenceCode
            tvAmount.text = CurrencyFormatter.format(tx.amount)
            tvStatus.text = tx.status.uppercase()
        }
    }
}
