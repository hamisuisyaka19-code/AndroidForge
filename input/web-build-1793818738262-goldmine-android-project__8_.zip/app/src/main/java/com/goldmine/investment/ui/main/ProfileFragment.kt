package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.ui.splash.SplashActivity

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_profile, container, false)
        val user = GoldMineApplication.instance.sessionManager.getUser()

        root.findViewById<TextView>(R.id.tvProfileName).text = user?.fullName ?: "Hamisu Isiyaka"
        root.findViewById<TextView>(R.id.tvMemberId).text = "Member ID: ${user?.memberId ?: "GM102356"}"

        root.findViewById<Button>(R.id.btnLogout).setOnClickListener {
            GoldMineApplication.instance.sessionManager.logout()
            val intent = Intent(requireContext(), SplashActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        return root
    }
}
