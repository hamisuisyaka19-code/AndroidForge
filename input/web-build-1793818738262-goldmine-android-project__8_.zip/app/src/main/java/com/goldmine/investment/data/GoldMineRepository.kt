package com.goldmine.investment.data

import com.goldmine.investment.api.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Response
import java.io.File

class GoldMineRepository(private val api: GoldMineApiService = ApiClient.apiService) {

    private fun <T> parseError(response: Response<ApiResponse<T>>, defaultMsg: String): String {
        val code = response.code()
        val errorBody = try { response.errorBody()?.string() } catch (e: Exception) { null }

        if (!errorBody.isNullOrEmpty()) {
            try {
                val json = JSONObject(errorBody)
                if (json.has("message") && !json.isNull("message")) {
                    val serverMsg = json.optString("message", "")
                    if (serverMsg.isNotBlank()) {
                        return serverMsg
                    }
                }
            } catch (e: Exception) {
                if (errorBody.contains("404") || errorBody.contains("Not Found")) {
                    return "API endpoint not found (HTTP 404). Please ensure the 'api' folder from goldmine-cpanel-api.zip is uploaded to public_html/ in cPanel.\nTarget URL: https://goalmindai.com.ng/api/auth/login.php"
                }
                if (errorBody.contains("500") || errorBody.contains("Internal Server Error")) {
                    return "Server internal error (HTTP 500). Please check MySQL database credentials in cPanel config/database.php."
                }
            }
        }

        return when (code) {
            400 -> "Invalid request parameters (HTTP 400). Please check your input."
            401 -> "Invalid credentials (HTTP 401). Please check your email or phone and password."
            403 -> "Account access restricted or suspended (HTTP 403)."
            404 -> "API endpoint not found (HTTP 404). Please upload the 'api' folder from goldmine-cpanel-api.zip to public_html/ in cPanel."
            500 -> "Server internal error (HTTP 500). Please check cPanel MySQL database connection in config/database.php."
            else -> "$defaultMsg (HTTP $code)"
        }
    }

    private fun handleException(e: Exception, defaultMsg: String): String {
        return when (e) {
            is java.net.UnknownHostException ->
                "Cannot resolve goalmindai.com.ng. Please check your internet connection."
            is java.net.SocketTimeoutException ->
                "Connection to goalmindai.com.ng timed out. Server took too long to respond."
            is java.net.ConnectException ->
                "Failed to connect to goalmindai.com.ng. Server may be down or unreachable."
            is javax.net.ssl.SSLException ->
                "Secure SSL connection failed: ${e.localizedMessage}"
            else ->
                e.localizedMessage ?: defaultMsg
        }
    }

    suspend fun login(loginInput: String, pass: String): Result<AuthData> {
        val req = mapOf("login_input" to loginInput, "password" to pass)

        // 1. Primary endpoint: https://goalmindai.com.ng/api/auth/login.php
        try {
            val res = api.login(req)
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                return Result.success(res.body()!!.data!!)
            }
            if (res.code() != 404) {
                return Result.failure(Exception(parseError(res, "Login failed")))
            }
        } catch (e: Exception) {
            // If network failure other than 404, capture it
            if (e !is retrofit2.HttpException) {
                // proceed to try fallback endpoints
            }
        }

        // 2. Fallback 1 (Direct alias): https://goalmindai.com.ng/api/login.php
        try {
            val resDirect = api.loginDirect(req)
            if (resDirect.isSuccessful && resDirect.body()?.success == true && resDirect.body()?.data != null) {
                return Result.success(resDirect.body()!!.data!!)
            }
            if (resDirect.code() != 404) {
                return Result.failure(Exception(parseError(resDirect, "Login failed")))
            }
        } catch (e: Exception) {
            // proceed to try nested fallback
        }

        // 3. Fallback 2 (Nested directory safeguard): https://goalmindai.com.ng/api/api/auth/login.php
        try {
            val resNested = api.loginNested(req)
            if (resNested.isSuccessful && resNested.body()?.success == true && resNested.body()?.data != null) {
                return Result.success(resNested.body()!!.data!!)
            }
            if (resNested.code() != 404) {
                return Result.failure(Exception(parseError(resNested, "Login failed")))
            }
        } catch (e: Exception) {
            // proceed to final error
        }

        return Result.failure(
            Exception(
                "API endpoint not found (HTTP 404). Please ensure the 'api' folder from goldmine-cpanel-api.zip is uploaded to public_html/ in cPanel.\nVerified Target: https://goalmindai.com.ng/api/auth/login.php"
            )
        )
    }

    suspend fun register(fullName: String, email: String, phone: String, pass: String): Result<AuthData> {
        return try {
            val res = api.register(mapOf(
                "full_name" to fullName,
                "email" to email,
                "phone" to phone,
                "password" to pass
            ))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Registration failed")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Registration error")))
        }
    }

    suspend fun getProfile(): Result<UserDto> {
        return try {
            val res = api.getProfile()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to fetch profile")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Profile connection error")))
        }
    }

    suspend fun getPlans(): Result<List<PlanDto>> {
        return try {
            val res = api.getPlans()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to fetch plans")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Plans connection error")))
        }
    }

    suspend fun getInvestments(): Result<InvestmentData> {
        return try {
            val res = api.getInvestments()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to fetch investments")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Investments connection error")))
        }
    }

    suspend fun invest(planId: Int, amount: Double): Result<Map<String, Any>> {
        return try {
            val res = api.createInvestment(mapOf("plan_id" to planId, "amount" to amount))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Investment order failed")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Investment error")))
        }
    }

    suspend fun getBankDetails(): Result<BankDetailsDto> {
        return try {
            val res = api.getBankDetails()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to get bank details")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Bank details connection error")))
        }
    }

    suspend fun getDeposits(): Result<List<DepositDto>> {
        return try {
            val res = api.getDeposits()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to fetch deposits")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Deposits connection error")))
        }
    }

    suspend fun submitDeposit(amount: Double, method: String, receiptFile: File?): Result<Map<String, Any>> {
        return try {
            val amountBody = amount.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val methodBody = method.toRequestBody("text/plain".toMediaTypeOrNull())
            val receiptPart = receiptFile?.let {
                val reqFile = it.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("receipt", it.name, reqFile)
            }
            val res = api.submitDepositMultipart(amountBody, methodBody, receiptPart)
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Deposit submission failed")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Deposit upload error")))
        }
    }

    suspend fun submitWithdrawal(amount: Double, bankName: String, accNum: String, accName: String): Result<Map<String, Any>> {
        return try {
            val res = api.requestWithdrawal(mapOf(
                "amount" to amount,
                "bank_name" to bankName,
                "account_number" to accNum,
                "account_name" to accName
            ))
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Withdrawal failed")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Withdrawal error")))
        }
    }

    suspend fun getTransactions(): Result<List<TransactionDto>> {
        return try {
            val res = api.getTransactions()
            if (res.isSuccessful && res.body()?.success == true && res.body()?.data != null) {
                Result.success(res.body()!!.data!!)
            } else {
                Result.failure(Exception(parseError(res, "Failed to fetch transactions")))
            }
        } catch (e: Exception) {
            Result.failure(Exception(handleException(e, "Transactions connection error")))
        }
    }
}
