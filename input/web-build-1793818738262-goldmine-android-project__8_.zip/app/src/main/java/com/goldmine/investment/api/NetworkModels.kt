package com.goldmine.investment.api

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("data") val data: T?,
    @SerializedName("server_time") val serverTime: String?
)

data class AuthData(
    @SerializedName("token") val token: String,
    @SerializedName("user") val user: UserDto
)

data class UserDto(
    @SerializedName("id") val id: Int,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("balance") val balance: Double,
    @SerializedName("balance_formatted") val balanceFormatted: String?,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_invested_formatted") val totalInvestedFormatted: String?,
    @SerializedName("total_profit") val totalProfit: Double,
    @SerializedName("total_profit_formatted") val totalProfitFormatted: String?,
    @SerializedName("member_id") val memberId: String?,
    @SerializedName("membership") val membership: String?,
    @SerializedName("status") val status: String
)

data class PlanDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String,
    @SerializedName("min_amount") val minAmount: Double,
    @SerializedName("min_formatted") val minFormatted: String?,
    @SerializedName("max_amount") val maxAmount: Double,
    @SerializedName("max_formatted") val maxFormatted: String?,
    @SerializedName("roi_percentage") val roiPercentage: Double,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("description") val description: String?
)

data class InvestmentData(
    @SerializedName("active") val active: List<InvestmentDto>,
    @SerializedName("completed") val completed: List<InvestmentDto>,
    @SerializedName("total_active") val totalActive: Int,
    @SerializedName("total_completed") val totalCompleted: Int,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double
)

data class InvestmentDto(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("plan_id") val planId: Int,
    @SerializedName("plan_name") val planName: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("amount_formatted") val amountFormatted: String?,
    @SerializedName("roi_percentage") val roiPercentage: Double,
    @SerializedName("expected_return") val expectedReturn: Double,
    @SerializedName("expected_formatted") val expectedFormatted: String?,
    @SerializedName("profit_amount") val profitAmount: Double,
    @SerializedName("profit_formatted") val profitFormatted: String?,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("status") val status: String,
    @SerializedName("start_date") val startDate: String?,
    @SerializedName("maturity_date") val maturityDate: String?,
    @SerializedName("seconds_remaining") val secondsRemaining: Long
)

data class BankDetailsDto(
    @SerializedName("bank_name") val bankName: String,
    @SerializedName("account_number") val accountNumber: String,
    @SerializedName("account_name") val accountName: String,
    @SerializedName("min_deposit") val minDeposit: Double,
    @SerializedName("min_formatted") val minFormatted: String?,
    @SerializedName("instructions") val instructions: String
)

data class DepositDto(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("amount_sent") val amountSent: Double?,
    @SerializedName("amount_formatted") val amountFormatted: String?,
    @SerializedName("received_amount") val receivedAmount: Double?,
    @SerializedName("received_formatted") val receivedFormatted: String?,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("status") val status: String, // 'pending', 'under_review', 'approved', 'rejected'
    @SerializedName("status_label") val statusLabel: String?,
    @SerializedName("receipt_path") val receiptPath: String?,
    @SerializedName("admin_notes") val adminNotes: String?,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("date_formatted") val dateFormatted: String?
) {
    val isPending: Boolean get() = status.equals("pending", ignoreCase = true) || status.equals("under_review", ignoreCase = true)
    val isApproved: Boolean get() = status.equals("approved", ignoreCase = true)
    val isRejected: Boolean get() = status.equals("rejected", ignoreCase = true)
}

data class WithdrawalDto(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("amount_formatted") val amountFormatted: String?,
    @SerializedName("bank_name") val bankName: String,
    @SerializedName("account_number") val accountNumber: String,
    @SerializedName("account_name") val accountName: String,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String
)

data class TransactionDto(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("type") val type: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("amount_formatted") val amountFormatted: String?,
    @SerializedName("status") val status: String,
    @SerializedName("description") val description: String?,
    @SerializedName("created_at") val createdAt: String
)
