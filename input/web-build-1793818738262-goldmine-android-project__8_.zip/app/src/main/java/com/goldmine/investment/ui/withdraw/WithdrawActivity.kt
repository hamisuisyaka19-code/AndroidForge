package com.goldmine.investment.ui.withdraw

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class WithdrawActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_withdraw)

        val user = GoldMineApplication.instance.sessionManager.getUser()
        val tvBalance = findViewById<TextView>(R.id.tvAvailableBalance)
        tvBalance.text = CurrencyFormatter.format(user?.balance ?: 0.0)

        val etAmount = findViewById<EditText>(R.id.etWithdrawAmount)
        val etBank = findViewById<EditText>(R.id.etBankName)
        val etAccNum = findViewById<EditText>(R.id.etAccountNumber)
        val etAccName = findViewById<EditText>(R.id.etAccountName)
        val btnWithdraw = findViewById<Button>(R.id.btnWithdrawNow)

        btnWithdraw.setOnClickListener {
            val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
            val bank = etBank.text.toString().trim()
            val accNum = etAccNum.text.toString().trim()
            val accName = etAccName.text.toString().trim()

            if (amount < 2000) {
                Toast.makeText(this, "Minimum withdrawal is ₦2,000.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnWithdraw.isEnabled = false
            lifecycleScope.launch {
                repository.submitWithdrawal(amount, bank, accNum, accName).onSuccess {
                    Toast.makeText(this@WithdrawActivity, "Withdrawal submitted for admin review!", Toast.LENGTH_LONG).show()
                    finish()
                }.onFailure {
                    btnWithdraw.isEnabled = true
                    Toast.makeText(this@WithdrawActivity, it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
