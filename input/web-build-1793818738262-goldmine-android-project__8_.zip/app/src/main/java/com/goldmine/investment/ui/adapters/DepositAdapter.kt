package com.goldmine.investment.ui.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.DepositDto
import com.goldmine.investment.util.CurrencyFormatter

class DepositAdapter : RecyclerView.Adapter<DepositAdapter.DepositViewHolder>() {

    private var items = listOf<DepositDto>()

    fun submitList(list: List<DepositDto>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DepositViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_deposit, parent, false)
        return DepositViewHolder(view)
    }

    override fun onBindViewHolder(holder: DepositViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class DepositViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRef = itemView.findViewById<TextView>(R.id.tvDepositRef)
        private val tvStatus = itemView.findViewById<TextView>(R.id.tvDepositStatus)
        private val tvSent = itemView.findViewById<TextView>(R.id.tvAmountSent)
        private val tvReceived = itemView.findViewById<TextView>(R.id.tvReceivedAmount)
        private val tvDate = itemView.findViewById<TextView>(R.id.tvDepositDate)
        private val tvMethod = itemView.findViewById<TextView>(R.id.tvDepositMethod)

        fun bind(item: DepositDto) {
            tvRef.text = item.referenceCode
            tvSent.text = item.amountFormatted ?: CurrencyFormatter.format(item.amount)
            tvDate.text = item.dateFormatted ?: item.createdAt
            tvMethod.text = item.paymentMethod

            when {
                item.isApproved -> {
                    tvStatus.text = "APPROVED"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                    tvStatus.setBackgroundColor(Color.parseColor("#153625"))
                    tvReceived.text = item.receivedFormatted ?: CurrencyFormatter.format(item.receivedAmount ?: item.amount)
                    tvReceived.setTextColor(Color.parseColor("#10B981"))
                }
                item.isRejected -> {
                    tvStatus.text = "REJECTED"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                    tvStatus.setBackgroundColor(Color.parseColor("#361515"))
                    tvReceived.text = "₦0.00 (Declined)"
                    tvReceived.setTextColor(Color.parseColor("#EF4444"))
                }
                else -> {
                    tvStatus.text = "PENDING"
                    tvStatus.setTextColor(Color.parseColor("#E5A93C"))
                    tvStatus.setBackgroundColor(Color.parseColor("#2B2313"))
                    tvReceived.text = "₦0.00 (Pending Review)"
                    tvReceived.setTextColor(Color.parseColor("#E5A93C"))
                }
            }
        }
    }
}
