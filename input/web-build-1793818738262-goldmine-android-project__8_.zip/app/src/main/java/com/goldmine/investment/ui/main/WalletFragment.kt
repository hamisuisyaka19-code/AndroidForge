package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.transactions.TransactionsActivity
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class WalletFragment : Fragment() {

    private val repository = GoldMineRepository()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_wallet, container, false)

        val tvBalance = root.findViewById<TextView>(R.id.tvWalletBalance)
        val tvInvested = root.findViewById<TextView>(R.id.tvWalletInvested)
        val tvProfit = root.findViewById<TextView>(R.id.tvWalletProfit)

        val user = GoldMineApplication.instance.sessionManager.getUser()
        tvBalance.text = CurrencyFormatter.format(user?.balance ?: 0.0)
        tvInvested.text = CurrencyFormatter.format(user?.totalInvested ?: 0.0)
        tvProfit.text = CurrencyFormatter.format(user?.totalProfit ?: 0.0)

        root.findViewById<Button>(R.id.btnDepositFunds).setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }
        root.findViewById<Button>(R.id.btnWithdrawFunds).setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }
        root.findViewById<View>(R.id.cardViewTransactions).setOnClickListener {
            startActivity(Intent(requireContext(), TransactionsActivity::class.java))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getProfile().onSuccess { fresh ->
                GoldMineApplication.instance.sessionManager.saveUser(fresh)
                tvBalance.text = CurrencyFormatter.format(fresh.balance)
                tvInvested.text = CurrencyFormatter.format(fresh.totalInvested)
                tvProfit.text = CurrencyFormatter.format(fresh.totalProfit)
            }
        }

        return root
    }
}
