package com.goldmine.investment.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.InvestmentDto
import com.goldmine.investment.util.CountdownHelper
import com.goldmine.investment.util.CurrencyFormatter

class InvestmentAdapter : RecyclerView.Adapter<InvestmentAdapter.InvViewHolder>() {

    private var items = listOf<InvestmentDto>()

    fun submitList(list: List<InvestmentDto>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_investment, parent, false)
        return InvViewHolder(view)
    }

    override fun onBindViewHolder(holder: InvViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class InvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAmount = itemView.findViewById<TextView>(R.id.tvInvAmount)
        private val tvStatus = itemView.findViewById<TextView>(R.id.tvInvStatus)
        private val tvPlanName = itemView.findViewById<TextView>(R.id.tvInvPlanName)
        private val tvProfit = itemView.findViewById<TextView>(R.id.tvInvProfit)
        private val tvCountdown = itemView.findViewById<TextView>(R.id.tvInvCountdown)

        fun bind(item: InvestmentDto) {
            tvAmount.text = CurrencyFormatter.format(item.amount)
            tvStatus.text = item.status.replaceFirstChar { it.uppercase() }
            tvPlanName.text = item.planName
            tvProfit.text = "Profit: ${CurrencyFormatter.format(item.profitAmount)} (${item.roiPercentage.toInt()}%)"
            tvCountdown.text = "Matures In: " + CountdownHelper.formatSeconds(item.secondsRemaining)
        }
    }
}
