package com.goldmine.investment.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.PlanDto
import com.goldmine.investment.util.CurrencyFormatter

class PlanAdapter(private val onInvestClick: (PlanDto) -> Unit) :
    RecyclerView.Adapter<PlanAdapter.PlanViewHolder>() {

    private var items = listOf<PlanDto>()

    fun submitList(list: List<PlanDto>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_plan, parent, false)
        return PlanViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class PlanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName = itemView.findViewById<TextView>(R.id.tvPlanName)
        private val tvAmount = itemView.findViewById<TextView>(R.id.tvPlanAmount)
        private val tvDuration = itemView.findViewById<TextView>(R.id.tvPlanDuration)
        private val tvProfit = itemView.findViewById<TextView>(R.id.tvPlanProfit)
        private val btnInvest = itemView.findViewById<Button>(R.id.btnInvest)

        fun bind(plan: PlanDto) {
            tvName.text = plan.name
            tvAmount.text = CurrencyFormatter.formatClean(plan.minAmount)
            tvDuration.text = "Duration: ${plan.durationDays} Days"
            tvProfit.text = "Profit: ${plan.roiPercentage.toInt()}%"

            btnInvest.setOnClickListener {
                onInvestClick(plan)
            }
        }
    }
}
