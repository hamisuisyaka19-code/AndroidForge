package com.goldmine.investment.ui.deposit

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.GoldMineApplication
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.adapters.DepositAdapter
import kotlinx.coroutines.launch

class DepositActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()
    private val depositAdapter = DepositAdapter()

    private lateinit var rvHistory: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var btnRefresh: Button
    private lateinit var btnSubmit: Button
    private lateinit var etAmount: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deposit)

        val tvBank = findViewById<TextView>(R.id.tvBankName)
        val tvAcc = findViewById<TextView>(R.id.tvAccountNumber)
        val tvHolder = findViewById<TextView>(R.id.tvAccountHolder)
        etAmount = findViewById(R.id.etDepositAmount)
        btnSubmit = findViewById(R.id.btnSubmitDeposit)
        btnRefresh = findViewById(R.id.btnRefreshDeposits)
        tvEmpty = findViewById(R.id.tvEmptyHistory)
        rvHistory = findViewById(R.id.rvDepositHistory)

        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = depositAdapter

        // 1. Fetch official bank details
        lifecycleScope.launch {
            repository.getBankDetails().onSuccess { bank ->
                tvBank.text = bank.bankName
                tvAcc.text = bank.accountNumber
                tvHolder.text = bank.accountName
            }
        }

        // 2. Fetch existing deposit history from live database
        loadDepositHistory()

        // 3. Handle submit deposit
        btnSubmit.setOnClickListener {
            val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
            if (amount < 500) {
                Toast.makeText(this, "Minimum deposit is ₦500.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnSubmit.isEnabled = false
            btnSubmit.text = "Submitting..."

            lifecycleScope.launch {
                repository.submitDeposit(amount, "Manual Bank Transfer", null).onSuccess {
                    btnSubmit.isEnabled = true
                    btnSubmit.text = "Submit Deposit for Verification"
                    etAmount.text.clear()
                    Toast.makeText(this@DepositActivity, "Deposit submitted! Status is PENDING admin approval.", Toast.LENGTH_LONG).show()
                    loadDepositHistory()
                }.onFailure { err ->
                    btnSubmit.isEnabled = true
                    btnSubmit.text = "Submit Deposit for Verification"
                    Toast.makeText(this@DepositActivity, err.message ?: "Deposit submission failed", Toast.LENGTH_LONG).show()
                }
            }
        }

        // 4. Manual Refresh Status Button
        btnRefresh.setOnClickListener {
            loadDepositHistory(showToast = true)
        }
    }

    override fun onResume() {
        super.onResume()
        loadDepositHistory()
    }

    private fun loadDepositHistory(showToast: Boolean = false) {
        lifecycleScope.launch {
            repository.getDeposits().onSuccess { list ->
                depositAdapter.submitList(list)
                tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                if (showToast) {
                    Toast.makeText(this@DepositActivity, "Deposit history updated (${list.size} records)", Toast.LENGTH_SHORT).show()
                }

                // If any deposit is approved, update user's profile to refresh available wallet balance
                if (list.any { it.isApproved }) {
                    repository.getProfile().onSuccess { freshUser ->
                        GoldMineApplication.instance.sessionManager.saveUser(freshUser)
                    }
                }
            }.onFailure { err ->
                if (showToast) {
                    Toast.makeText(this@DepositActivity, "Failed to refresh: ${err.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
