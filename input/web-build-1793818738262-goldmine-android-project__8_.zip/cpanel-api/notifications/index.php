<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 30");
    $stmt->execute([$user_id]);
    $notifs = $stmt->fetchAll();

    $formatted = array_map(function($n) {
        return [
            'id'         => (int)$n['id'],
            'title'      => $n['title'],
            'message'    => $n['message'],
            'type'       => $n['type'],
            'is_read'    => (bool)($n['is_read'] ?? 0),
            'link'       => $n['link'] ?? null,
            'created_at' => $n['created_at']
        ];
    }, $notifs);

    api_response(true, 'Notifications retrieved.', $formatted);
} catch (PDOException $e) {
    api_response(false, 'Failed to fetch notifications: ' . $e->getMessage(), null, 500);
}
