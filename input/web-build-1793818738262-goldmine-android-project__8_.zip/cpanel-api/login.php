<?php
/**
 * Direct login endpoint alias for GoldMine Investment Platform
 * Path: /api/login.php -> forwards to /api/auth/login.php
 * Target: goalmindai.com.ng
 */
declare(strict_types=1);
require_once __DIR__ . '/auth/login.php';
