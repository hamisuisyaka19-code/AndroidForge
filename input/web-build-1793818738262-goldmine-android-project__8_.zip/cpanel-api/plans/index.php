<?php
require_once __DIR__ . '/../config.php';

$pdo = get_db_connection();
if (!$pdo) {
    api_response(false, 'Database unavailable.', null, 500);
}

try {
    $stmt = $pdo->query("SELECT id, name, slug, min_amount, max_amount, roi_percentage, duration_days, description FROM investment_plans WHERE status = 'active' ORDER BY sort_order ASC, min_amount ASC");
    $plans = $stmt->fetchAll();

    $formatted = array_map(function($p) {
        return [
            'id'             => (int)$p['id'],
            'name'           => $p['name'],
            'slug'           => $p['slug'],
            'min_amount'     => (float)$p['min_amount'],
            'min_formatted'  => format_currency($p['min_amount']),
            'max_amount'     => (float)$p['max_amount'],
            'max_formatted'  => format_currency($p['max_amount']),
            'roi_percentage' => (float)$p['roi_percentage'],
            'duration_days'  => (int)$p['duration_days'],
            'description'    => $p['description']
        ];
    }, $plans);

    api_response(true, 'Investment plans retrieved.', $formatted);
} catch (PDOException $e) {
    api_response(false, 'Failed to fetch plans: ' . $e->getMessage(), null, 500);
}
