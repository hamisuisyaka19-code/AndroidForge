<?php
/**
 * GoldMine Investment Platform - Mobile REST API Configuration & Auth Guard
 * Target Server: goalmindai.com.ng
 * Compatible with existing cPanel database & admin dashboard
 */
declare(strict_types=1);

// Set strict JSON and UTF-8 encoding
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Auth-Token');

// Preflight OPTIONS response
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Resilient loading of core website configuration files
$base_configs = [
    __DIR__ . '/../config/app.php',
    __DIR__ . '/../config/database.php',
    __DIR__ . '/../config/payment.php',
    __DIR__ . '/../includes/functions.php'
];

foreach ($base_configs as $cfg) {
    if (file_exists($cfg)) {
        require_once $cfg;
    } else {
        error_log("GoldMine API Notice: Config file not found at $cfg");
    }
}

// Fallback constants if not loaded
if (!defined('APP_URL')) define('APP_URL', 'https://goalmindai.com.ng');
if (!defined('APP_CURRENCY')) define('APP_CURRENCY', '₦');
if (!defined('COMPANY_BANK_NAME')) define('COMPANY_BANK_NAME', 'Kuda Bank');
if (!defined('COMPANY_ACCOUNT_NUMBER')) define('COMPANY_ACCOUNT_NUMBER', '2009888249');
if (!defined('COMPANY_ACCOUNT_NAME')) define('COMPANY_ACCOUNT_NAME', 'Hamisu Isiyaka');

/**
 * Standardized JSON API response helper
 */
function api_response(bool $success, string $message, mixed $data = null, int $status_code = 200): void {
    http_response_code($status_code);
    echo json_encode([
        'success'     => $success,
        'message'     => $message,
        'data'        => $data,
        'timestamp'   => time(),
        'server_time' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Robust extraction of Bearer Token across all cPanel / Apache environments
 */
function get_bearer_token(): ?string {
    $headers = null;
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } elseif (!empty($_SERVER['Authorization'])) {
        $headers = trim($_SERVER['Authorization']);
    } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['REDIRECT_HTTP_AUTHORIZATION']);
    } elseif (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) {
        return trim($_SERVER['HTTP_X_AUTH_TOKEN']);
    } elseif (function_exists('apache_request_headers')) {
        $reqHeaders = apache_request_headers();
        $reqHeaders = array_combine(array_map('ucwords', array_keys($reqHeaders)), array_values($reqHeaders));
        if (isset($reqHeaders['Authorization'])) {
            $headers = trim($reqHeaders['Authorization']);
        } elseif (isset($reqHeaders['X-Auth-Token'])) {
            return trim($reqHeaders['X-Auth-Token']);
        }
    }

    if (!empty($headers) && preg_match('/Bearer\s(\S+)/i', $headers, $matches)) {
        return $matches[1];
    }

    // Direct token parameter fallback
    if (!empty($_GET['token'])) return trim((string)$_GET['token']);
    if (!empty($_POST['token'])) return trim((string)$_POST['token']);

    return null;
}

/**
 * Parse JSON or Form POST input safely
 */
function get_json_input(): array {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            return $json;
        }
    }
    return !empty($_POST) ? $_POST : $_REQUEST;
}

/**
 * Require valid authenticated user session token
 */
function require_api_user(): array {
    $token = get_bearer_token();
    if (!$token) {
        api_response(false, 'Missing authentication token. Please login again.', null, 401);
    }

    $pdo = function_exists('get_db_connection') ? get_db_connection() : null;
    if (!$pdo) {
        api_response(false, 'Database connection unavailable on server.', null, 500);
    }

    // 1. First check remember_token in users table
    $stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, remember_token, created_at FROM users WHERE remember_token = ? LIMIT 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    // 2. If token not matched in DB, test HMAC fallback token format (uid:signature)
    if (!$user && strpos($token, '.') !== false) {
        $parts = explode('.', $token);
        if (count($parts) === 3) {
            $payload = json_decode(base64_decode($parts[1]), true);
            if (!empty($payload['uid'])) {
                $s2 = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, remember_token, created_at FROM users WHERE id = ? LIMIT 1");
                $s2->execute([(int)$payload['uid']]);
                $user = $s2->fetch();
            }
        }
    }

    if (!$user) {
        api_response(false, 'Session expired or invalid. Please login again.', null, 401);
    }

    if ($user['status'] === 'suspended') {
        api_response(false, 'Your GoldMine account has been suspended. Please contact support.', null, 403);
    }

    // Auto-check matured investments for this user
    check_matured_investments_for_user((int)$user['id'], $pdo);

    // Refresh balance after maturity check
    $ref_stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, created_at FROM users WHERE id = ?");
    $ref_stmt->execute([(int)$user['id']]);
    $fresh_user = $ref_stmt->fetch();

    return $fresh_user ?: $user;
}

/**
 * Auto-credit matured investments
 */
function check_matured_investments_for_user(int $user_id, PDO $pdo): void {
    try {
        $now = date('Y-m-d H:i:s');
        $stmt = $pdo->prepare("SELECT * FROM investments WHERE user_id = ? AND status = 'active' AND maturity_date IS NOT NULL AND maturity_date <= ?");
        $stmt->execute([$user_id, $now]);
        $matured = $stmt->fetchAll();

        foreach ($matured as $inv) {
            $pdo->beginTransaction();
            $upd = $pdo->prepare("UPDATE investments SET status = 'completed' WHERE id = ?");
            $upd->execute([$inv['id']]);

            $payout = (float)$inv['expected_return'];
            $profit = $payout - (float)$inv['amount'];

            $cred = $pdo->prepare("UPDATE users SET balance = balance + ?, total_profit = total_profit + ? WHERE id = ?");
            $cred->execute([$payout, $profit, $user_id]);

            $ref = function_exists('generate_reference') ? generate_reference('ROI') : ('ROI-' . date('Ymd') . '-' . substr(bin2hex(random_bytes(4)), 0, 6));
            $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'roi_payout', ?, 'completed', ?)");
            $tx->execute([$ref, $user_id, $payout, "Matured Return for " . $inv['plan_name']]);

            if (function_exists('add_user_notification')) {
                add_user_notification(
                    $user_id,
                    "Investment Matured & Credited!",
                    "Your investment {$inv['reference_code']} in {$inv['plan_name']} has matured! " . APP_CURRENCY . number_format($payout, 2) . " credited to your balance.",
                    "success",
                    "/my-invest.php"
                );
            }

            $pdo->commit();
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Maturity check error: " . $e->getMessage());
    }
}
