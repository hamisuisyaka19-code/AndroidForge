<?php
require_once __DIR__ . '/config.php';

$pdo = get_db_connection();
$db_status = $pdo !== null;

api_response($db_status, $db_status ? 'GoldMine API is online and operational.' : 'Database connection error.', [
    'service'     => 'GoldMine Investment Platform Android REST API',
    'version'     => '1.0.0',
    'environment' => APP_ENV,
    'site_url'    => APP_URL,
    'database'    => $db_status ? 'Connected' : 'Offline',
    'server_time' => date('Y-m-d H:i:s'),
    'currency'    => APP_CURRENCY
]);
