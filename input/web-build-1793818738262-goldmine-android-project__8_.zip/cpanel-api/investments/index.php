<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare("SELECT i.*, p.slug as plan_slug FROM investments i LEFT JOIN investment_plans p ON i.plan_id = p.id WHERE i.user_id = ? ORDER BY i.id DESC");
        $stmt->execute([$user_id]);
        $rows = $stmt->fetchAll();

        $active = [];
        $completed = [];

        $now = time();

        foreach ($rows as $row) {
            $matures_time = $row['maturity_date'] ? strtotime($row['maturity_date']) : 0;
            $seconds_remaining = max(0, $matures_time - $now);

            $item = [
                'id'                => (int)$row['id'],
                'reference_code'    => $row['reference_code'],
                'plan_id'           => (int)$row['plan_id'],
                'plan_name'         => $row['plan_name'],
                'amount'            => (float)$row['amount'],
                'amount_formatted'  => format_currency($row['amount']),
                'roi_percentage'    => (float)$row['roi_percentage'],
                'expected_return'   => (float)$row['expected_return'],
                'expected_formatted'=> format_currency($row['expected_return']),
                'profit_amount'     => (float)$row['expected_return'] - (float)$row['amount'],
                'profit_formatted'  => format_currency((float)$row['expected_return'] - (float)$row['amount']),
                'duration_days'     => (int)$row['duration_days'],
                'status'            => $row['status'],
                'start_date'        => $row['start_date'],
                'maturity_date'     => $row['maturity_date'],
                'seconds_remaining' => $seconds_remaining,
                'created_at'        => $row['created_at']
            ];

            if ($row['status'] === 'active' || $row['status'] === 'pending') {
                $active[] = $item;
            } else {
                $completed[] = $item;
            }
        }

        api_response(true, 'Investments loaded.', [
            'active'         => $active,
            'completed'      => $completed,
            'total_active'   => count($active),
            'total_completed'=> count($completed),
            'total_invested' => (float)$user['total_invested'],
            'total_profit'   => (float)$user['total_profit']
        ]);
    } catch (PDOException $e) {
        api_response(false, 'Failed to retrieve investments: ' . $e->getMessage(), null, 500);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = get_json_input();
    $plan_id = (int)($input['plan_id'] ?? 0);
    $amount = (float)($input['amount'] ?? 0);

    $p_stmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND status = 'active' LIMIT 1");
    $p_stmt->execute([$plan_id]);
    $plan = $p_stmt->fetch();

    if (!$plan) {
        api_response(false, 'Selected investment plan is invalid or inactive.', null, 400);
    }

    if ($amount < (float)$plan['min_amount']) {
        api_response(false, "Minimum investment for {$plan['name']} is " . format_currency($plan['min_amount']), null, 400);
    }

    if ($amount > (float)$plan['max_amount']) {
        api_response(false, "Maximum investment for {$plan['name']} is " . format_currency($plan['max_amount']), null, 400);
    }

    if ((float)$user['balance'] < $amount) {
        api_response(false, "Insufficient balance (" . format_currency($user['balance']) . "). Please deposit funds first.", null, 400);
    }

    $ref = generate_reference('INV');
    $roi = (float)$plan['roi_percentage'];
    $expected_return = $amount + ($amount * ($roi / 100));

    try {
        $pdo->beginTransaction();

        // Deduct balance and add to total invested
        $deduct = $pdo->prepare("UPDATE users SET balance = balance - ?, total_invested = total_invested + ? WHERE id = ?");
        $deduct->execute([$amount, $amount, $user_id]);

        // Insert investment record in pending status for admin dashboard approval
        $ins = $pdo->prepare("INSERT INTO investments (reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $ins->execute([$ref, $user_id, $plan['id'], $plan['name'], $amount, $roi, $expected_return, (int)$plan['duration_days']]);
        $inv_id = (int)$pdo->lastInsertId();

        // Insert transaction record
        $new_bal = (float)$user['balance'] - $amount;
        $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'investment', ?, ?, 'pending', ?)");
        $tx->execute([$ref, $user_id, $amount, $new_bal, "Invested in {$plan['name']} ($ref)"]);

        // Send notification
        add_user_notification(
            $user_id,
            "Investment Order Submitted: " . $plan['name'],
            "Your order $ref for " . format_currency($amount) . " in {$plan['name']} ({$roi}% ROI) has been submitted and is awaiting administrator verification.",
            "info",
            "/counting-date.php"
        );

        log_audit_action(null, $user_id, "Mobile App Investment Submitted", "Ref: $ref, Amount: " . format_currency($amount));

        $pdo->commit();

        api_response(true, "Investment order submitted successfully! Ref: $ref", [
            'id'              => $inv_id,
            'reference_code'  => $ref,
            'plan_name'       => $plan['name'],
            'amount'          => $amount,
            'expected_return' => $expected_return,
            'status'          => 'pending',
            'new_balance'     => $new_bal
        ], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        api_response(false, 'Investment processing failed: ' . $e->getMessage(), null, 500);
    }
}
