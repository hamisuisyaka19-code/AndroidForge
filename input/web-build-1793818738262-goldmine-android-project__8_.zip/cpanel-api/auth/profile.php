<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Return fresh user profile
    $userData = [
        'id'             => (int)$user['id'],
        'full_name'      => $user['full_name'],
        'email'          => $user['email'],
        'phone'          => $user['phone'],
        'balance'        => (float)$user['balance'],
        'balance_formatted' => format_currency($user['balance']),
        'total_invested' => (float)$user['total_invested'],
        'total_invested_formatted' => format_currency($user['total_invested']),
        'total_profit'   => (float)$user['total_profit'],
        'total_profit_formatted' => format_currency($user['total_profit']),
        'member_id'      => 'GM' . str_pad((string)$user['id'], 6, '0', STR_PAD_LEFT),
        'membership'     => 'VIP Member',
        'status'         => $user['status'],
        'created_at'     => $user['created_at']
    ];

    api_response(true, 'Profile loaded.', $userData);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = get_json_input();
    $action = $input['action'] ?? 'update_profile';

    if ($action === 'change_password') {
        $old_pwd = $input['old_password'] ?? '';
        $new_pwd = $input['new_password'] ?? '';

        if (empty($old_pwd) || empty($new_pwd)) {
            api_response(false, 'Please provide old and new password.', null, 400);
        }

        // Verify old password
        $s = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
        $s->execute([(int)$user['id']]);
        $row = $s->fetch();

        if (!password_verify($old_pwd, $row['password_hash'])) {
            api_response(false, 'Current password is incorrect.', null, 400);
        }

        if (strlen($new_pwd) < 6) {
            api_response(false, 'New password must be at least 6 characters.', null, 400);
        }

        $new_hash = password_hash($new_pwd, PASSWORD_DEFAULT);
        $upd = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $upd->execute([$new_hash, (int)$user['id']]);

        api_response(true, 'Password updated successfully.');
    } else {
        $full_name = trim($input['full_name'] ?? $user['full_name']);
        $phone = trim($input['phone'] ?? $user['phone']);

        $upd = $pdo->prepare("UPDATE users SET full_name = ?, phone = ? WHERE id = ?");
        $upd->execute([$full_name, $phone, (int)$user['id']]);

        api_response(true, 'Profile updated successfully.', [
            'full_name' => $full_name,
            'phone'     => $phone
        ]);
    }
}
