<?php
/**
 * GoldMine Investment Platform - User Login REST API Endpoint
 * Target: goalmindai.com.ng
 * Compatible with existing users table and bcrypt password_hash
 */
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    api_response(false, 'Method not allowed. Use POST.', null, 405);
}

$input = get_json_input();
$login_input = trim((string)($input['login_input'] ?? $input['email'] ?? $input['phone'] ?? $input['username'] ?? ''));
$password = (string)($input['password'] ?? '');

if (empty($login_input) || empty($password)) {
    api_response(false, 'Please provide email/phone and password.', null, 400);
}

$pdo = function_exists('get_db_connection') ? get_db_connection() : null;
if (!$pdo) {
    api_response(false, 'Database connection unavailable. Please check cPanel config/database.php.', null, 500);
}

try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR phone = ?) LIMIT 1");
    $stmt->execute([$login_input, $login_input]);
    $user = $stmt->fetch();

    if (!$user) {
        api_response(false, 'No account found with this email or phone number.', null, 401);
    }

    if (!password_verify($password, $user['password_hash'])) {
        api_response(false, 'Incorrect password. Please verify your credentials.', null, 401);
    }

    if ($user['status'] === 'suspended') {
        api_response(false, 'Your account has been suspended. Please contact platform support.', null, 403);
    }

    // Generate secure session token (Stored in remember_token)
    $token = bin2hex(random_bytes(32));
    try {
        $upd = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
        $upd->execute([$token, $user['id']]);
    } catch (PDOException $e) {
        error_log("Failed to update remember_token: " . $e->getMessage());
    }

    // Start PHP session for cookie compatibility
    if (session_status() === PHP_SESSION_NONE) {
        @session_start();
    }
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['full_name'];

    if (function_exists('log_audit_action')) {
        log_audit_action(null, (int)$user['id'], 'Mobile App Login', 'Authenticated from Android App via ' . $login_input);
    }

    $userData = [
        'id'                => (int)$user['id'],
        'full_name'         => $user['full_name'],
        'email'             => $user['email'],
        'phone'             => $user['phone'],
        'balance'           => (float)$user['balance'],
        'balance_formatted' => APP_CURRENCY . ' ' . number_format((float)$user['balance'], 2),
        'total_invested'    => (float)$user['total_invested'],
        'total_profit'      => (float)$user['total_profit'],
        'member_id'         => 'GM' . str_pad((string)$user['id'], 6, '0', STR_PAD_LEFT),
        'membership'        => 'VIP Member',
        'status'            => $user['status'],
        'created_at'        => $user['created_at']
    ];

    api_response(true, 'Welcome back, ' . $user['full_name'], [
        'token' => $token,
        'user'  => $userData
    ], 200);

} catch (PDOException $e) {
    api_response(false, 'Server database error: ' . $e->getMessage(), null, 500);
}
