<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    api_response(false, 'Method not allowed. Use POST.', null, 405);
}

$input = get_json_input();
$full_name = trim($input['full_name'] ?? '');
$email = trim(strtolower($input['email'] ?? ''));
$phone = trim($input['phone'] ?? '');
$password = $input['password'] ?? '';

if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
    api_response(false, 'All fields are required.', null, 400);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    api_response(false, 'Invalid email address.', null, 400);
}

if (strlen($password) < 6) {
    api_response(false, 'Password must be at least 6 characters.', null, 400);
}

$pdo = get_db_connection();
if (!$pdo) {
    api_response(false, 'Database unavailable.', null, 500);
}

// Check duplicate email
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    api_response(false, 'An account with this email already exists.', null, 409);
}

// Check duplicate phone
$stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ? LIMIT 1");
$stmt->execute([$phone]);
if ($stmt->fetch()) {
    api_response(false, 'An account with this phone number already exists.', null, 409);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(32));

$ins = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, remember_token, status, balance, total_invested, total_profit) VALUES (?, ?, ?, ?, ?, 'active', 0.00, 0.00, 0.00)");
$ins->execute([$full_name, $email, $phone, $hash, $token]);
$user_id = (int)$pdo->lastInsertId();

// Add welcome notification
add_user_notification(
    $user_id,
    "Welcome to GoldMine!",
    "Your GoldMine account is ready. Deposit funds and choose an investment plan to start earning daily returns.",
    "success",
    "/dashboard.php"
);

log_audit_action(null, $user_id, 'User Registered', 'Registered via Android Mobile Application');

$userData = [
    'id'             => $user_id,
    'full_name'      => $full_name,
    'email'          => $email,
    'phone'          => $phone,
    'balance'        => 0.00,
    'balance_formatted' => format_currency(0),
    'total_invested' => 0.00,
    'total_profit'   => 0.00,
    'member_id'      => 'GM' . str_pad((string)$user_id, 6, '0', STR_PAD_LEFT),
    'membership'     => 'VIP Member',
    'status'         => 'active',
    'created_at'     => date('Y-m-d H:i:s')
];

api_response(true, 'Registration successful. Welcome to GoldMine!', [
    'token' => $token,
    'user'  => $userData
], 201);
