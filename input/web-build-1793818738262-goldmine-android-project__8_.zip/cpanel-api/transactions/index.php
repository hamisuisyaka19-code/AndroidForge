<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

try {
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 50");
    $stmt->execute([$user_id]);
    $txs = $stmt->fetchAll();

    $formatted = array_map(function($t) {
        return [
            'id'             => (int)$t['id'],
            'reference_code' => $t['reference_code'],
            'type'           => $t['type'],
            'amount'         => (float)$t['amount'],
            'amount_formatted' => format_currency($t['amount']),
            'status'         => $t['status'],
            'description'    => $t['description'],
            'created_at'     => $t['created_at']
        ];
    }, $txs);

    api_response(true, 'Transactions retrieved.', $formatted);
} catch (PDOException $e) {
    api_response(false, 'Failed to fetch transactions: ' . $e->getMessage(), null, 500);
}
