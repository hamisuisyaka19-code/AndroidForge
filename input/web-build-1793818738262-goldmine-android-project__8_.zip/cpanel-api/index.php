<?php
/**
 * GoldMine Investment Platform - API Router & Status Explorer
 * Target Server: goalmindai.com.ng
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$pdo = function_exists('get_db_connection') ? get_db_connection() : null;

api_response(true, "GoldMine REST API is online and operational.", [
    'service'     => 'GoldMine Investment Platform API',
    'version'     => '1.0.0',
    'status'      => 'online',
    'database'    => $pdo ? 'Connected' : 'Disconnected (Check cPanel config/database.php)',
    'server_time' => date('Y-m-d H:i:s'),
    'endpoints'   => [
        'login'        => 'POST /api/auth/login.php (or /api/login.php)',
        'register'     => 'POST /api/auth/register.php',
        'profile'      => 'GET  /api/auth/profile.php',
        'plans'        => 'GET  /api/plans/index.php',
        'investments'  => 'GET,POST /api/investments/index.php',
        'deposits'     => 'GET,POST /api/deposits/index.php',
        'bank_details' => 'GET  /api/deposits/bank-details.php',
        'withdrawals'  => 'GET,POST /api/withdrawals/index.php',
        'transactions' => 'GET  /api/transactions/index.php',
        'health'       => 'GET  /api/health.php'
    ]
], 200);
