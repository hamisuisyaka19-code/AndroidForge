<?php
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY id DESC LIMIT 20");
    $stmt->execute([$user_id]);
    $withdrawals = $stmt->fetchAll();

    $formatted = array_map(function($w) {
        return [
            'id'             => (int)$w['id'],
            'reference_code' => $w['reference_code'],
            'amount'         => (float)$w['amount'],
            'amount_formatted' => format_currency($w['amount']),
            'bank_name'      => $w['bank_name'],
            'account_number' => $w['account_number'],
            'account_name'   => $w['account_name'],
            'status'         => $w['status'],
            'created_at'     => $w['created_at']
        ];
    }, $withdrawals);

    api_response(true, 'Withdrawals history retrieved.', $formatted);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = get_json_input();
    $amount = (float)($input['amount'] ?? 0);
    $bank_name = sanitize($input['bank_name'] ?? '');
    $account_number = sanitize($input['account_number'] ?? '');
    $account_name = sanitize($input['account_name'] ?? '');

    if ($amount < 2000) {
        api_response(false, 'Minimum withdrawal amount is ₦2,000.00', null, 400);
    }

    if ($amount > (float)$user['balance']) {
        api_response(false, 'Insufficient balance. Available: ' . format_currency($user['balance']), null, 400);
    }

    if (empty($bank_name) || empty($account_number) || empty($account_name)) {
        api_response(false, 'Please provide complete bank account details.', null, 400);
    }

    $ref = generate_reference('WTH');

    try {
        $pdo->beginTransaction();

        // Lock balance
        $upd = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $upd->execute([$amount, $user_id]);

        $ins = $pdo->prepare("INSERT INTO withdrawals (reference_code, user_id, amount, bank_name, account_number, account_name, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $ins->execute([$ref, $user_id, $amount, $bank_name, $account_number, $account_name]);
        $wth_id = (int)$pdo->lastInsertId();

        $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'withdrawal', ?, 'pending', ?)");
        $tx->execute([$ref, $user_id, $amount, "Withdrawal to {$bank_name} - {$account_number}"]);

        add_user_notification(
            $user_id,
            "Withdrawal Requested",
            "Your withdrawal request for " . format_currency($amount) . " ($ref) is under administrative review.",
            "info",
            "/withdraw.php"
        );

        log_audit_action(null, $user_id, "Mobile App Withdrawal Requested", "Ref: $ref, Amount: " . format_currency($amount));

        $pdo->commit();

        $new_bal = (float)$user['balance'] - $amount;

        api_response(true, "Withdrawal request submitted! It is currently awaiting administrative approval.", [
            'id'             => $wth_id,
            'reference_code' => $ref,
            'amount'         => $amount,
            'bank_name'      => $bank_name,
            'account_number' => $account_number,
            'account_name'   => $account_name,
            'status'         => 'pending',
            'new_balance'    => $new_bal
        ], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        api_response(false, 'Withdrawal processing failed: ' . $e->getMessage(), null, 500);
    }
}
