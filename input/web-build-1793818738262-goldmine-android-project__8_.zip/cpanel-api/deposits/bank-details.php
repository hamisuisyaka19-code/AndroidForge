<?php
require_once __DIR__ . '/../config.php';

api_response(true, 'Bank payment details retrieved.', [
    'bank_name'      => COMPANY_BANK_NAME,
    'account_number' => COMPANY_ACCOUNT_NUMBER,
    'account_name'   => COMPANY_ACCOUNT_NAME,
    'min_deposit'    => 500.00,
    'min_formatted'  => format_currency(500),
    'instructions'   => 'Transfer the exact amount to the GoldMine official account, save your bank receipt/screenshot, and upload it in the app for instant verification.'
]);
