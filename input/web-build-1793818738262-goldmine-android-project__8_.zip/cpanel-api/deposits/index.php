<?php
/**
 * GoldMine Investment Platform - Deposits REST API Endpoint
 * Synchronizes deposits with existing cPanel website & Admin Dashboard
 * Supports: Amount Sent, Received Amount, Pending/Approved/Rejected statuses
 */
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

$user = require_api_user();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 50");
        $stmt->execute([$user_id]);
        $deposits = $stmt->fetchAll();

        $formatted = array_map(function($d) {
            $amount = (float)$d['amount'];
            $status = strtolower($d['status']);

            // Received Amount logic:
            // When pending or under_review, received_amount is 0.00 (awaiting admin review).
            // When approved by admin in /admin/deposits.php, received_amount is the credited amount.
            // When rejected, received_amount is 0.00.
            $received_amount = ($status === 'approved') ? $amount : 0.00;

            return [
                'id'                 => (int)$d['id'],
                'reference_code'     => $d['reference_code'],
                'amount'             => $amount,
                'amount_sent'        => $amount,
                'amount_formatted'   => APP_CURRENCY . ' ' . number_format($amount, 2),
                'received_amount'    => $received_amount,
                'received_formatted' => APP_CURRENCY . ' ' . number_format($received_amount, 2),
                'payment_method'     => $d['payment_method'],
                'status'             => $status, // 'pending', 'under_review', 'approved', 'rejected'
                'status_label'       => ucfirst(str_replace('_', ' ', $status)),
                'receipt_path'       => !empty($d['receipt_path']) ? (APP_URL . '/' . ltrim($d['receipt_path'], '/')) : null,
                'admin_notes'        => $d['admin_notes'] ?? null,
                'created_at'         => $d['created_at'],
                'date_formatted'     => date('M d, Y, h:i A', strtotime($d['created_at']))
            ];
        }, $deposits);

        api_response(true, 'Deposit history retrieved.', $formatted);
    } catch (PDOException $e) {
        api_response(false, 'Failed to retrieve deposits: ' . $e->getMessage(), null, 500);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = get_json_input();
    $amount = (float)($input['amount'] ?? 0);
    $method = trim((string)($input['payment_method'] ?? 'Manual Bank Transfer'));

    if ($amount < 500) {
        api_response(false, 'Minimum deposit amount is ₦500.00', null, 400);
    }

    $upload_rel_path = null;
    $upload_dir = __DIR__ . '/../../uploads/deposit_receipts';

    // 1. Handle multipart receipt image upload if present
    if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }
        $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'pdf'])) {
            $ext = 'jpg';
        }
        $filename = bin2hex(random_bytes(24)) . '.' . $ext;
        $dest = $upload_dir . '/' . $filename;
        if (move_uploaded_file($_FILES['receipt']['tmp_name'], $dest)) {
            $upload_rel_path = 'uploads/deposit_receipts/' . $filename;
        }
    } elseif (!empty($input['receipt_base64'])) {
        // 2. Handle Base64 encoded receipt image from mobile
        $b64 = $input['receipt_base64'];
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }
        if (preg_match('/^data:image\/(\w+);base64,/', $b64, $type)) {
            $b64 = substr($b64, strpos($b64, ',') + 1);
            $ext = strtolower($type[1]);
        } else {
            $ext = 'jpg';
        }
        $data = base64_decode($b64);
        if ($data !== false) {
            $filename = bin2hex(random_bytes(24)) . '.' . $ext;
            file_put_contents($upload_dir . '/' . $filename, $data);
            $upload_rel_path = 'uploads/deposit_receipts/' . $filename;
        }
    }

    $ref = function_exists('generate_reference') ? generate_reference('DEP') : ('DEP-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6)));

    try {
        $pdo->beginTransaction();

        // Save deposit in PENDING status for Admin Approval
        $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path) VALUES (?, ?, ?, ?, 'pending', ?)");
        $ins->execute([$ref, $user_id, $amount, $method, $upload_rel_path]);
        $dep_id = (int)$pdo->lastInsertId();

        // Create pending transaction in transactions table
        $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'deposit', ?, 'pending', ?)");
        $tx->execute([$ref, $user_id, $amount, "Deposit request via " . $method]);

        if (function_exists('add_user_notification')) {
            add_user_notification(
                $user_id,
                "Deposit Request Submitted",
                "Your deposit request of " . APP_CURRENCY . number_format($amount, 2) . " ($ref) has been submitted for administrator review.",
                "info",
                "/deposit.php"
            );
        }

        if (function_exists('log_audit_action')) {
            log_audit_action(null, $user_id, "Mobile App Deposit Submitted", "Ref: $ref, Amount: " . APP_CURRENCY . number_format($amount, 2));
        }

        $pdo->commit();

        api_response(true, "Deposit request submitted! Once verified by administrator, your balance will be credited.", [
            'id'                 => $dep_id,
            'reference_code'     => $ref,
            'amount'             => $amount,
            'amount_sent'        => $amount,
            'received_amount'    => 0.00,
            'received_formatted' => APP_CURRENCY . ' 0.00',
            'payment_method'     => $method,
            'status'             => 'pending',
            'status_label'       => 'Pending',
            'receipt_path'       => $upload_rel_path ? (APP_URL . '/' . $upload_rel_path) : null,
            'created_at'         => date('Y-m-d H:i:s'),
            'date_formatted'     => date('M d, Y, h:i A')
        ], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        api_response(false, 'Deposit submission error: ' . $e->getMessage(), null, 500);
    }
}
