# GoldMine Database Compatibility & Audit Report

- Compatible with: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+
- Existing Database Configuration: `config/database.php` (DB_NAME: lhzmylpw_goldmine)
- Zero Schemas Dropped or Reset: 100% Non-destructive.

### Verified Tables
1. `users` - Read profile, balance, total_invested, total_profit. Session tokens stored in `remember_token`.
2. `deposits` - Deposit requests saved in `pending` status with `receipt_path`. Admin approves in `/admin/deposits.php` to credit balance exactly once.
3. `withdrawals` - Withdrawal requests saved in `pending` status. Admin approves in `/admin/withdrawals.php`. Rejecting refunds the user's balance automatically.
4. `investments` - Investment orders saved with start_date and maturity_date.
5. `transactions` - Complete ledger with reference codes.
6. `investment_plans` - Dynamic plans table.
7. `notifications` - In-app user notifications.
