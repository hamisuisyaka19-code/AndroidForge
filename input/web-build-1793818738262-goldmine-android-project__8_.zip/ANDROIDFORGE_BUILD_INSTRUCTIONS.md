# GoldMine Android Project - AndroidForge & Local Build Guide

Package: `com.goldmine.investment`
Compile SDK: 34
Min SDK: 24
Gradle: 8.5
Java: JDK 17

### Building in AndroidForge
1. Upload this zip (`goldmine-android-project.zip`) directly to AndroidForge.
2. Select Gradle Version 8.5 and JDK 17.
3. Choose Build Variant: `release` or `debug`.
4. Click **Start Build**. AndroidForge will execute `./gradlew assembleRelease` and provide the compiled `GoldMine.apk`.

### Building locally in Android Studio
1. Extract this zip file.
2. Open Android Studio > **File > Open...** > select the extracted folder.
3. Wait for Gradle sync to complete.
4. In terminal:
   ```bash
   ./gradlew assembleDebug
   # Or for release:
   ./gradlew assembleRelease
   ```
5. Output APK will be at: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Kotlin Build Verification
- `:app:compileDebugKotlin` and `:app:compileReleaseKotlin` are 100% verified.
- Error body parsing in `GoldMineRepository.kt` uses Android's native `org.json.JSONObject` to eliminate any Gson `parseString` unresolved references.
- Gradle wrapper executable bit `0o755` is preserved.
