# GoldMine Investment Platform - REST API Reference

Base URL: `https://goalmindai.com.ng/api/`

All endpoints accept JSON or standard Form POST data and return JSON responses.
Protected endpoints require `Authorization: Bearer <token>`.

### Authentication
- `POST auth/login.php` - Body: `{"login_input":"...", "password":"..."}`
- `POST auth/register.php` - Body: `{"full_name":"...", "email":"...", "phone":"...", "password":"..."}`
- `GET auth/profile.php` - Header: `Authorization: Bearer <token>`
- `POST auth/profile.php` - Header: `Authorization: Bearer <token>`

### Investment Plans & Orders
- `GET plans/index.php` - Returns active investment plans (Starter, Basic, Growth, Premium, VIP Gold).
- `GET investments/index.php` - Returns active and completed investments with live countdown seconds.
- `POST investments/index.php` - Body: `{"plan_id": 4, "amount": 10000}`. Deducts balance, saves to DB, visible in admin dashboard.

### Deposits & Payments
- `GET deposits/bank-details.php` - Returns Kuda Bank, 2009888249, Hamisu Isiyaka.
- `GET deposits/index.php` - List user deposit history.
- `POST deposits/index.php` - Multipart upload: `amount`, `payment_method`, `receipt` (image file). Enters Pending status for admin approval.

### Withdrawals
- `GET withdrawals/index.php` - List user withdrawal history.
- `POST withdrawals/index.php` - Body: `{"amount": 5000, "bank_name":"Kuda Bank", "account_number":"2009888249", "account_name":"Hamisu Isiyaka"}`. Deducts balance, enters Pending status for admin review.

### Ledger & Notifications
- `GET transactions/index.php` - Returns ledger history.
- `GET notifications/index.php` - Returns user alerts.
