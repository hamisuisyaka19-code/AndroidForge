# GoldMine Investment Platform — Official cPanel API Installation Guide

Target Website: **https://goalmindai.com.ng/**  
Target Location: **public_html/api/**  
Android API Base URL: **https://goalmindai.com.ng/api/**  
Primary Login Endpoint: **https://goalmindai.com.ng/api/auth/login.php**  

---

## Why You Received the HTTP 404 Error
The Android application connects directly to your live website at `https://goalmindai.com.ng/api/auth/login.php`.
Because the `api/` folder had not yet been uploaded and extracted in your cPanel `public_html/`, your Apache web server returned **HTTP 404 Not Found**.

Once you follow the steps below and upload the API files, your Android app will immediately log in, fetch balances, and synchronize with your existing database.

---

## Step-by-Step cPanel Installation Guide

### Step 1: Download the API ZIP
Download **`goldmine-cpanel-api.zip`** from the web portal.

### Step 2: Open cPanel File Manager
1. Log into your cPanel account for `goalmindai.com.ng`.
2. Open **File Manager** (under Files section).
3. Navigate into the **`public_html`** directory.

### Step 3: Upload and Extract
You can choose either of these two methods (both are supported):

#### Method A: Direct Upload into public_html (Recommended)
1. Stay in `public_html/`.
2. Click **Upload** at the top toolbar.
3. Select `goldmine-cpanel-api.zip` and wait for the upload bar to reach 100% (green).
4. Go back to `public_html/`, right-click `goldmine-cpanel-api.zip` and select **Extract**.
5. When prompted for directory, leave it as `/public_html` and click **Extract Files**.
6. This automatically creates `public_html/api/` with all necessary endpoints.

#### Method B: Upload inside public_html/api
1. In `public_html/`, click **+ Folder** and name it `api`.
2. Double-click to open `public_html/api/`.
3. Click **Upload** and upload `goldmine-cpanel-api.zip`.
4. Right-click the zip and select **Extract** into `/public_html/api`.

---

## Step 4: Verify the Installation in Your Web Browser
Open this link in your browser to confirm the API and database are connected:

👉 **https://goalmindai.com.ng/api/health.php**  
or  
👉 **https://goalmindai.com.ng/api/index.php**

### Expected JSON Output:
```json
{
  "success": true,
  "message": "GoldMine API is online and operational.",
  "data": {
    "database": "Connected",
    "server_time": "2026-11-04 17:55:00"
  }
}
```

If it displays `"database": "Connected"`, the API is successfully communicating with your live MySQL database (`lhzmylpw_goldmine`).

---

## Android Endpoint Mapping Reference

| Android Screen / Action | HTTP Method | Live Endpoint URL |
|-------------------------|-------------|-------------------|
| **Health Check** | `GET` | `https://goalmindai.com.ng/api/health.php` |
| **API Explorer** | `GET` | `https://goalmindai.com.ng/api/index.php` |
| **User Login** | `POST` | `https://goalmindai.com.ng/api/auth/login.php` (Fallback: `https://goalmindai.com.ng/api/login.php`) |
| **User Registration** | `POST` | `https://goalmindai.com.ng/api/auth/register.php` |
| **User Profile & Balance** | `GET` | `https://goalmindai.com.ng/api/auth/profile.php` |
| **Investment Plans** | `GET` | `https://goalmindai.com.ng/api/plans/index.php` |
| **Active & Completed Investments** | `GET` | `https://goalmindai.com.ng/api/investments/index.php` |
| **Create Investment Order** | `POST` | `https://goalmindai.com.ng/api/investments/index.php` |
| **Company Bank Details** | `GET` | `https://goalmindai.com.ng/api/deposits/bank-details.php` |
| **Deposit History** | `GET` | `https://goalmindai.com.ng/api/deposits/index.php` |
| **Submit Deposit (Pending)** | `POST` | `https://goalmindai.com.ng/api/deposits/index.php` |
| **Withdrawal Request** | `POST` | `https://goalmindai.com.ng/api/withdrawals/index.php` |
| **Transaction History** | `GET` | `https://goalmindai.com.ng/api/transactions/index.php` |

---

## Deposit & Admin Synchronization Verification
1. **User Submits Deposit in Android App:**
   - Deposit is saved into the `deposits` table with `status = 'pending'`, `amount_sent = amount`, and `received_amount = 0.00`.
   - Android shows status badge: **PENDING** in gold/amber.
2. **Admin Approves in Website Admin Panel:**
   - Log into `https://goalmindai.com.ng/admin/deposits.php`.
   - Click **Approve** on the deposit record.
   - The cPanel backend updates `status = 'approved'` and credits the user's balance.
3. **Android App Updates Immediately:**
   - When the user pulls to refresh or opens Deposit History, the status badge turns green **APPROVED**, and **Received Amount** displays the credited amount (e.g., `₦10,000.00`).
