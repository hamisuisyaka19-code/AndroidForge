import 'package:flutter/material.dart';
import '../core/config/app_config.dart';
import '../core/theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
            child: Row(
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: const BoxDecoration(color: AppTheme.green, shape: BoxShape.circle),
                  child: const Center(child: Text('GM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                ),
                const SizedBox(width: 11),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('GOLDMINE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: AppTheme.deepGreen, letterSpacing: .5)),
                  Text('FOOTBALL', style: TextStyle(fontSize: 11, color: AppTheme.gold, fontWeight: FontWeight.w800, letterSpacing: 2)),
                ])),
                IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, color: AppTheme.green)),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppTheme.deepGreen, AppTheme.green]),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('WELCOME TO', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text('GOLDMINE FOOTBALL', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('Your home for football scores, fixtures and analysis.', style: TextStyle(color: Colors.white, height: 1.4)),
                SizedBox(height: 18),
                Row(children: [
                  Icon(Icons.sports_soccer, color: AppTheme.gold),
                  SizedBox(width: 8),
                  Text('Football information. One destination.', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ]),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text("Today's Football", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppTheme.ink)),
              Text('GOLDMINE', style: TextStyle(color: AppTheme.gold.shade700, fontSize: 10, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Container(
              padding: const EdgeInsets.all(17),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE2EAE5))),
              child: Column(children: [
                const Icon(Icons.cloud_off_outlined, size: 32, color: AppTheme.green),
                const SizedBox(height: 8),
                const Text('Ba a haɗa Mobile API ba tukuna', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.ink)),
                const SizedBox(height: 5),
                const Text('Da zarar an shirya sabon API na website, live matches da fixtures za su bayyana a nan.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.4, fontSize: 12)),
                if (!AppConfig.mobileApiEnabled) ...[
                  const SizedBox(height: 12),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: AppTheme.gold.withValues(alpha: .16), borderRadius: BorderRadius.circular(20)), child: const Text('API CONNECTION: NOT ENABLED', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: AppTheme.deepGreen))),
                ],
              ]),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 10),
            child: const Text('Explore GOLDMINE', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppTheme.ink)),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
          sliver: SliverGrid.count(
            crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.65,
            children: const [
              _FeatureTile(icon: Icons.emoji_events_outlined, title: 'Leagues', subtitle: 'Competitions'),
              _FeatureTile(icon: Icons.table_chart_outlined, title: 'Standings', subtitle: 'League tables'),
              _FeatureTile(icon: Icons.insights_outlined, title: 'Analysis', subtitle: 'Match insights'),
              _FeatureTile(icon: Icons.newspaper_outlined, title: 'Football News', subtitle: 'Latest updates'),
            ],
          ),
        ),
      ],
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE4EBE6))),
    child: Row(children: [
      Container(width: 36, height: 36, decoration: BoxDecoration(color: AppTheme.green.withValues(alpha: .09), borderRadius: BorderRadius.circular(11)), child: Icon(icon, color: AppTheme.green, size: 20)),
      const SizedBox(width: 9),
      Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.ink, fontSize: 12)),
        Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 10)),
      ])),
    ]),
  );
}
