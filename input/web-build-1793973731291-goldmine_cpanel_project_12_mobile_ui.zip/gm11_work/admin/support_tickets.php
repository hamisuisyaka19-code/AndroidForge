<?php
/**
 * Support Tickets & Client Helpdesk Management
 * GoldMine Investment Platform - Admin Console
 */
$page_title = "Support Tickets & Helpdesk";
require_once __DIR__ . '/header.php';

// Ensure support_tickets table exists safely without affecting any existing records
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `support_tickets` (
          `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          `user_id` INT UNSIGNED NOT NULL,
          `ticket_code` VARCHAR(30) DEFAULT NULL,
          `subject` VARCHAR(200) NOT NULL,
          `priority` ENUM('low', 'normal', 'high', 'urgent') NOT NULL DEFAULT 'normal',
          `message` TEXT NOT NULL,
          `status` ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
          `admin_reply` TEXT DEFAULT NULL,
          `replied_at` DATETIME DEFAULT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX `idx_support_user` (`user_id`),
          INDEX `idx_support_status` (`status`),
          INDEX `idx_support_code` (`ticket_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
} catch (Exception $e) {
    // Ignore if table already exists
}

// Handle Admin Reply or Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $_SESSION['flash_error'] = "Security token validation failed. Please refresh and try again.";
        header("Location: support_tickets.php");
        exit;
    }

    $ticket_id = (int)($_POST['ticket_id'] ?? 0);
    $action = $_POST['action'];

    if ($action === 'reply_ticket' && $ticket_id > 0) {
        $admin_reply = trim($_POST['admin_reply'] ?? '');
        $new_status = in_array($_POST['status'] ?? 'answered', ['open', 'answered', 'closed'], true)
            ? $_POST['status']
            : 'answered';

        if (empty($admin_reply)) {
            $_SESSION['flash_error'] = "Please enter a reply message before submitting.";
        } else {
            try {
                $stmtTkt = $pdo->prepare("SELECT * FROM support_tickets WHERE id = ? LIMIT 1");
                $stmtTkt->execute([$ticket_id]);
                $tktRow = $stmtTkt->fetch();

                if ($tktRow) {
                    $upd = $pdo->prepare("
                        UPDATE support_tickets
                        SET admin_reply = ?, status = ?, replied_at = NOW(), updated_at = NOW()
                        WHERE id = ?
                    ");
                    $upd->execute([$admin_reply, $new_status, $ticket_id]);

                    create_notification(
                        $pdo,
                        (int)$tktRow['user_id'],
                        "Support Ticket #" . ($tktRow['ticket_code'] ?: $ticket_id) . " Updated",
                        "An administrator has responded to your support inquiry: \"" . $tktRow['subject'] . "\".",
                        "info"
                    );

                    record_audit_log(
                        $pdo,
                        (int)$admin['id'],
                        (int)$tktRow['user_id'],
                        'SUPPORT_TICKET_REPLIED',
                        "Replied to support ticket #" . ($tktRow['ticket_code'] ?: $ticket_id) . " (Status: {$new_status})"
                    );

                    $_SESSION['flash_success'] = "Response dispatched for ticket #" . escape($tktRow['ticket_code'] ?: (string)$ticket_id) . ".";
                }
            } catch (Exception $e) {
                $_SESSION['flash_error'] = "Failed to save ticket reply: " . $e->getMessage();
            }
        }
        header("Location: support_tickets.php");
        exit;
    }

    if ($action === 'close_ticket' && $ticket_id > 0) {
        try {
            $pdo->prepare("UPDATE support_tickets SET status = 'closed', updated_at = NOW() WHERE id = ?")
                ->execute([$ticket_id]);
            record_audit_log($pdo, (int)$admin['id'], null, 'SUPPORT_TICKET_CLOSED', "Closed support ticket ID #{$ticket_id}");
            $_SESSION['flash_success'] = "Support ticket #{$ticket_id} marked as closed.";
        } catch (Exception $e) {
            $_SESSION['flash_error'] = "Error closing ticket.";
        }
        header("Location: support_tickets.php");
        exit;
    }
}

$status_filter = trim($_GET['status'] ?? 'all');
$sql = "
    SELECT t.*, u.full_name, u.email
    FROM support_tickets t
    LEFT JOIN users u ON t.user_id = u.id
";
$params = [];
if (in_array($status_filter, ['open', 'answered', 'closed'], true)) {
    $sql .= " WHERE t.status = ?";
    $params[] = $status_filter;
}
$sql .= " ORDER BY CASE WHEN t.status = 'open' THEN 0 WHEN t.status = 'answered' THEN 1 ELSE 2 END, t.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Support Tickets &amp; Helpdesk
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Review client support inquiries, respond to deposit/withdrawal questions, and manage resolution statuses.
      </p>
    </div>

    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="support_tickets.php?status=all" class="<?php echo $status_filter === 'all' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 14px; font-size: 0.8rem;">All Tickets</a>
      <a href="support_tickets.php?status=open" class="<?php echo $status_filter === 'open' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 14px; font-size: 0.8rem;">Open</a>
      <a href="support_tickets.php?status=answered" class="<?php echo $status_filter === 'answered' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 14px; font-size: 0.8rem;">Answered</a>
      <a href="support_tickets.php?status=closed" class="<?php echo $status_filter === 'closed' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 14px; font-size: 0.8rem;">Closed</a>
    </div>
  </div>

  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>Ticket Code</th>
          <th>Investor</th>
          <th>Subject &amp; Message</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Created</th>
          <th style="text-align: right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($tickets)): ?>
          <tr>
            <td colspan="7" style="text-align: center; color: #8E9E94; padding: 32px;">
              No support tickets found for the selected filter.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($tickets as $t): ?>
            <tr>
              <td>
                <strong class="tabular-nums" style="color: #D4AF37;">#<?php echo escape($t['ticket_code'] ?: (string)$t['id']); ?></strong>
              </td>
              <td>
                <strong style="color: #FFF;"><?php echo escape($t['full_name'] ?: 'Investor #' . $t['user_id']); ?></strong><br>
                <span style="font-size: 0.75rem; color: #D4AF37;"><?php echo escape($t['email'] ?: ''); ?></span>
              </td>
              <td style="max-width: 340px;">
                <div style="font-weight: 700; color: #FFF; margin-bottom: 4px;"><?php echo escape($t['subject']); ?></div>
                <div style="font-size: 0.8rem; color: #9FB1A6; line-height: 1.4;"><?php echo nl2br(escape($t['message'])); ?></div>
                <?php if (!empty($t['admin_reply'])): ?>
                  <div style="margin-top: 8px; padding: 8px 10px; background: rgba(16,185,129,0.1); border-left: 3px solid #10B981; border-radius: 4px; font-size: 0.78rem; color: #D1FAE5;">
                    <strong style="color: #34D399; display: block; margin-bottom: 2px;">Admin Reply:</strong>
                    <?php echo nl2br(escape($t['admin_reply'])); ?>
                  </div>
                <?php endif; ?>
              </td>
              <td>
                <span style="text-transform: uppercase; font-size: 0.72rem; font-weight: 700; color: <?php echo $t['priority'] === 'urgent' || $t['priority'] === 'high' ? '#F87171' : '#D4AF37'; ?>;">
                  <?php echo escape($t['priority']); ?>
                </span>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo $t['status'] === 'answered' ? 'approved' : ($t['status'] === 'open' ? 'pending' : 'rejected'); ?>">
                  <?php echo escape($t['status']); ?>
                </span>
              </td>
              <td class="tabular-nums" style="font-size: 0.78rem; color: #8E9E94;">
                <?php echo date('M d, Y H:i', strtotime($t['created_at'])); ?>
              </td>
              <td style="text-align: right;">
                <div style="display: flex; gap: 6px; justify-content: flex-end;">
                  <button
                    type="button"
                    class="btn-gold"
                    style="padding: 6px 12px; font-size: 0.75rem; cursor: pointer;"
                    onclick="openReplyTicketModal(<?php echo (int)$t['id']; ?>, <?php echo htmlspecialchars(json_encode($t['ticket_code'] ?: (string)$t['id']), ENT_QUOTES); ?>, <?php echo htmlspecialchars(json_encode($t['subject']), ENT_QUOTES); ?>, <?php echo htmlspecialchars(json_encode($t['admin_reply'] ?? ''), ENT_QUOTES); ?>, <?php echo htmlspecialchars(json_encode($t['status']), ENT_QUOTES); ?>)"
                  >
                    Reply
                  </button>
                  <?php if ($t['status'] !== 'closed'): ?>
                    <form method="POST" action="support_tickets.php" style="display: inline;">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="action" value="close_ticket">
                      <input type="hidden" name="ticket_id" value="<?php echo (int)$t['id']; ?>">
                      <button type="submit" class="btn-outline-gold" style="padding: 6px 10px; font-size: 0.75rem; cursor: pointer;">
                        Close
                      </button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Reply Ticket Modal -->
<div id="replyTicketModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 500px; width: 100%; padding: 26px; border-color: rgba(212,175,55,0.45);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 10px; border-bottom: 1px solid rgba(27,56,40,0.7);">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin: 0;" id="replyModalTitle">Reply to Ticket</h3>
      <button type="button" onclick="closeModal('replyTicketModal')" style="background: none; border: none; color: #9FB1A6; font-size: 1.4rem; cursor: pointer;">&times;</button>
    </div>

    <form method="POST" action="support_tickets.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="reply_ticket">
      <input type="hidden" name="ticket_id" id="replyTicketId" value="0">

      <div class="form-group">
        <label class="form-label">Subject</label>
        <input type="text" id="replyTicketSubject" class="form-control" readonly style="opacity: 0.75;">
      </div>

      <div class="form-group">
        <label class="form-label">Update Ticket Status</label>
        <select name="status" id="replyTicketStatus" class="form-control">
          <option value="answered">Answered</option>
          <option value="open">Open</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Official Response *</label>
        <textarea name="admin_reply" id="replyTicketMessage" rows="5" class="form-control" required placeholder="Enter response to investor..."></textarea>
      </div>

      <div style="display: flex; gap: 10px; margin-top: 18px;">
        <button type="button" onclick="closeModal('replyTicketModal')" class="btn-outline-gold" style="flex: 1;">Cancel</button>
        <button type="submit" class="btn-gold" style="flex: 1;">Send Response</button>
      </div>
    </form>
  </div>
</div>

<script>
function openReplyTicketModal(id, code, subject, existingReply, status) {
  document.getElementById('replyTicketId').value = id;
  document.getElementById('replyModalTitle').textContent = 'Reply to Ticket #' + code;
  document.getElementById('replyTicketSubject').value = subject;
  document.getElementById('replyTicketMessage').value = existingReply || '';
  document.getElementById('replyTicketStatus').value = status === 'open' ? 'answered' : status;
  openModal('replyTicketModal');
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
