<?php
/**
 * Master Platform, Bank & Gateway Settings
 * GoldMine Investment Platform - Admin Console
 */
$page_title = "Platform & Gateway Settings";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'save_settings') {
            $new_proj_rate = trim($_POST['target_projection_rate'] ?? '45.00');
            $settings_to_update = [
                'site_name'                => trim($_POST['site_name'] ?? 'GoldMine Investment Platform'),
                'site_currency'            => trim($_POST['site_currency'] ?? 'NGN'),
                'currency_symbol'          => trim($_POST['currency_symbol'] ?? '₦'),
                'contact_email'            => trim($_POST['contact_email'] ?? ''),
                'min_deposit'              => trim($_POST['min_deposit'] ?? '1000.00'),
                'min_withdrawal'           => trim($_POST['min_withdrawal'] ?? '1000.00'),
                'withdrawal_fee_percent'   => trim($_POST['withdrawal_fee_percent'] ?? '1.50'),
                'referral_bonus_percent'   => trim($_POST['referral_bonus_percent'] ?? '10.00'),
                'target_projection_rate'   => $new_proj_rate,
                'company_bank_name'        => trim($_POST['company_bank_name'] ?? ''),
                'company_account_name'     => trim($_POST['company_account_name'] ?? ''),
                'company_account_number'   => trim($_POST['company_account_number'] ?? ''),
                'company_routing_number'   => trim($_POST['company_routing_number'] ?? ''),
                'company_swift_code'       => trim($_POST['company_swift_code'] ?? ''),
                'flutterwave_public_key'   => trim($_POST['flutterwave_public_key'] ?? ''),
                'flutterwave_secret_key'   => trim($_POST['flutterwave_secret_key'] ?? ''),
                'flutterwave_secret_hash'  => trim($_POST['flutterwave_secret_hash'] ?? ''),
                'flutterwave_encryption_key' => trim($_POST['flutterwave_encryption_key'] ?? '')
            ];

            foreach ($settings_to_update as $k => $v) {
                save_setting($pdo, $k, $v);
            }

            if ((float)$new_proj_rate > 0 && has_column($pdo, 'investment_plans', 'roi_percentage')) {
                $official_names = array_keys(get_official_six_plans_spec());
                $placeholders = implode(',', array_fill(0, count($official_names), '?'));
                $pdo->prepare("UPDATE investment_plans SET roi_percentage = ? WHERE name IN ($placeholders)")
                    ->execute(array_merge([(float)$new_proj_rate], $official_names));
            }

            record_audit_log($pdo, $admin['id'], null, 'SETTINGS_UPDATED', 'Platform settings and bank configurations updated');
            $success = "Platform settings saved successfully.";
        }

        // Change Admin Password
        elseif ($action === 'change_admin_password') {
            $current_pwd = $_POST['current_password'] ?? '';
            $new_pwd = $_POST['new_password'] ?? '';
            $confirm_pwd = $_POST['confirm_new_password'] ?? '';

            if (empty($current_pwd) || empty($new_pwd)) {
                $error = "Please fill in all password fields.";
            } elseif (!password_verify($current_pwd, $admin['password'])) {
                $error = "Current master password is incorrect.";
            } elseif (strlen($new_pwd) < 6) {
                $error = "New password must be at least 6 characters.";
            } elseif ($new_pwd !== $confirm_pwd) {
                $error = "New passwords do not match.";
            } else {
                $hash = password_hash($new_pwd, PASSWORD_DEFAULT);
                $adm_cols = get_table_columns($pdo, 'admins');
                $sets = [];
                $params = [];
                if (isset($adm_cols['password'])) {
                    $sets[] = "`password` = ?";
                    $params[] = $hash;
                }
                if (isset($adm_cols['password_hash'])) {
                    $sets[] = "`password_hash` = ?";
                    $params[] = $hash;
                }
                if (!empty($sets)) {
                    $params[] = (int)$admin['id'];
                    $pdo->prepare("UPDATE `admins` SET " . implode(", ", $sets) . " WHERE `id` = ?")->execute($params);
                }
                $admin['password'] = $hash;
                $admin['password_hash'] = $hash;
                record_audit_log($pdo, $admin['id'], null, 'ADMIN_PASSWORD_CHANGED', 'Administrator updated master password');
                $success = "Administrator password updated successfully.";
            }
        }
    }
}

// Fetch current values
$site_name = get_setting($pdo, 'site_name', 'GoldMine Investment Platform');
$site_currency = get_setting($pdo, 'site_currency', 'NGN');
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$contact_email = get_setting($pdo, 'contact_email', 'support@goalmindai.com.ng');

$min_deposit = get_setting($pdo, 'min_deposit', '1000.00');
$min_withdrawal = get_setting($pdo, 'min_withdrawal', '1000.00');
$withdrawal_fee_percent = get_setting($pdo, 'withdrawal_fee_percent', '1.50');
$referral_bonus_percent = get_setting($pdo, 'referral_bonus_percent', '10.00');
$target_projection_rate = get_setting($pdo, 'target_projection_rate', '45.00');

$company_bank_name = get_setting($pdo, 'company_bank_name', 'Zenith Bank');
$company_account_name = get_setting($pdo, 'company_account_name', 'GoldMine Investment');
$company_account_number = get_setting($pdo, 'company_account_number', '1234567890');
$company_routing_number = get_setting($pdo, 'company_routing_number', '057150013');
$company_swift_code = get_setting($pdo, 'company_swift_code', 'ZEIBNGLA');

$flw_pub = get_setting($pdo, 'flutterwave_public_key', '');
$flw_sec = get_setting($pdo, 'flutterwave_secret_key', '');
$flw_hash = get_setting($pdo, 'flutterwave_secret_hash', '');
$flw_enc = get_setting($pdo, 'flutterwave_encryption_key', '');
?>

<div style="max-width: 1050px; margin: 0 auto; padding-bottom: 70px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Platform Settings &amp; Banking Coordinates
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Configure vault account coordinates, operational parameters, and payment gateway keys.
    </p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="settings.php">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" value="save_settings">

    <!-- Section 1: General & Currency -->
    <div class="gm-card" style="margin-bottom: 24px;">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        1. General &amp; Currency Configuration
      </h3>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;" class="calc-grid">
        <div class="form-group">
          <label class="form-label">Platform Title</label>
          <input type="text" name="site_name" class="form-control" value="<?php echo escape($site_name); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Support Email</label>
          <input type="email" name="contact_email" class="form-control" value="<?php echo escape($contact_email); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Currency Code (ISO)</label>
          <input type="text" name="site_currency" class="form-control" value="<?php echo escape($site_currency); ?>" placeholder="NGN, USD, EUR">
        </div>
        <div class="form-group">
          <label class="form-label">Display Symbol</label>
          <input type="text" name="currency_symbol" class="form-control" value="<?php echo escape($currency_symbol); ?>" placeholder="₦, $, €">
        </div>
      </div>
    </div>

    <!-- Section 2: Financial Limits & Projection Rate -->
    <div class="gm-card" style="margin-bottom: 24px;">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        2. Transaction Limits, Target Projection Rate &amp; Affiliate Rules
      </h3>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(195px, 1fr)); gap: 16px;">
        <div class="form-group">
          <label class="form-label">Target Projection Rate (%)</label>
          <input type="number" step="0.01" name="target_projection_rate" class="form-control" value="<?php echo escape($target_projection_rate); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Minimum Deposit (<?php echo escape($currency_symbol); ?>)</label>
          <input type="number" step="0.01" name="min_deposit" class="form-control" value="<?php echo escape($min_deposit); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Minimum Withdrawal (<?php echo escape($currency_symbol); ?>)</label>
          <input type="number" step="0.01" name="min_withdrawal" class="form-control" value="<?php echo escape($min_withdrawal); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Withdrawal Fee (%)</label>
          <input type="number" step="0.01" name="withdrawal_fee_percent" class="form-control" value="<?php echo escape($withdrawal_fee_percent); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Direct Referral Reward (%)</label>
          <input type="number" step="0.01" name="referral_bonus_percent" class="form-control" value="<?php echo escape($referral_bonus_percent); ?>" required>
        </div>
      </div>
    </div>

    <!-- Section 3: Company Bank Details -->
    <div class="gm-card" style="margin-bottom: 24px;">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        3. Company Bank Coordinates (Wire Transfer Channel)
      </h3>
      <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
        These exact details are displayed to investors when submitting bank wire deposits.
      </p>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;" class="calc-grid">
        <div class="form-group">
          <label class="form-label">Bank Institution Name</label>
          <input type="text" name="company_bank_name" class="form-control" value="<?php echo escape($company_bank_name); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Account Beneficiary Name</label>
          <input type="text" name="company_account_name" class="form-control" value="<?php echo escape($company_account_name); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Account / IBAN Number</label>
          <input type="text" name="company_account_number" class="form-control" value="<?php echo escape($company_account_number); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Routing / Sort Code</label>
          <input type="text" name="company_routing_number" class="form-control" value="<?php echo escape($company_routing_number); ?>">
        </div>
        <div class="form-group" style="grid-column: 1 / -1;">
          <label class="form-label">SWIFT / BIC Code</label>
          <input type="text" name="company_swift_code" class="form-control" value="<?php echo escape($company_swift_code); ?>">
        </div>
      </div>
    </div>

    <!-- Section 4: Flutterwave Payment Gateway API Keys -->
    <div class="gm-card" style="margin-bottom: 24px;">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        4. Flutterwave Payment Gateway Configuration
      </h3>
      <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
        Server-side API keys are protected inside MySQL and never exposed to client browsers.
      </p>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;" class="calc-grid">
        <div class="form-group">
          <label class="form-label">Flutterwave Public Key</label>
          <input type="text" name="flutterwave_public_key" class="form-control" value="<?php echo escape($flw_pub); ?>" placeholder="FLWPUBK_TEST-xxxxxxxxxxxx">
        </div>
        <div class="form-group">
          <label class="form-label">Flutterwave Secret Key</label>
          <input type="password" name="flutterwave_secret_key" class="form-control" value="<?php echo escape($flw_sec); ?>" placeholder="FLWSECK_TEST-xxxxxxxxxxxx">
        </div>
        <div class="form-group">
          <label class="form-label">Webhook Secret Hash (HTTP_VERIF_HASH)</label>
          <input type="password" name="flutterwave_secret_hash" class="form-control" value="<?php echo escape($flw_hash); ?>" placeholder="Webhook verification secret hash">
        </div>
        <div class="form-group">
          <label class="form-label">Encryption Key</label>
          <input type="password" name="flutterwave_encryption_key" class="form-control" value="<?php echo escape($flw_enc); ?>" placeholder="FLWSECK_TESTxxxxxxxx">
        </div>
      </div>
    </div>

    <button type="submit" class="btn-gold" style="padding: 12px 30px; font-size: 0.95rem;">
      Save All Platform Configurations
    </button>
  </form>

  <!-- Section 5: Admin Password Change -->
  <div class="gm-card" style="margin-top: 36px; max-width: 600px;">
    <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
      Change Administrator Master Password
    </h3>

    <form method="POST" action="settings.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="change_admin_password">

      <div class="form-group">
        <label class="form-label">Current Master Password</label>
        <input type="password" name="current_password" class="form-control" required placeholder="••••••••">
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" required placeholder="••••••••">
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_new_password" class="form-control" required placeholder="••••••••">
        </div>
      </div>

      <button type="submit" class="btn-outline-gold" style="padding: 10px 22px; font-size: 0.88rem;">
        Update Master Password
      </button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
