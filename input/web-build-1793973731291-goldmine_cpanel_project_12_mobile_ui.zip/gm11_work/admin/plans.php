<?php
/**
 * Six Official Investment Plans Management
 * GoldMine Investment Platform - Admin Console
 * 
 * Dynamically inspects `investment_plans` columns so updates succeed even if optional
 * columns (`tagline`, `payout_interval`, `capital_returned`, `risk_level`) are absent.
 */
$page_title = "Investment Plan Management";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');

// Synchronize and ensure the 6 official plans exist
ensure_six_investment_plans($pdo, true);
$official_names = array_keys(get_official_six_plans_spec());
$plan_cols = get_table_columns($pdo, 'investment_plans');

// Handle Plan & Projection Rate Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $action = $_POST['action'];

        // 1. Update Global Target Projection Rate (Applies to all 6 plans)
        if ($action === 'update_global_rate') {
            $new_rate = (float)($_POST['target_projection_rate'] ?? 45.00);
            if ($new_rate <= 0 || $new_rate > 500) {
                $error = "Please enter a valid target projection rate between 1% and 500%.";
            } else {
                save_setting($pdo, 'target_projection_rate', number_format($new_rate, 2, '.', ''));

                // Apply to all 6 official plans
                if (isset($plan_cols['roi_percentage'])) {
                    $placeholders = implode(',', array_fill(0, count($official_names), '?'));
                    $updPlans = $pdo->prepare("UPDATE investment_plans SET roi_percentage = ? WHERE name IN ($placeholders)");
                    $updPlans->execute(array_merge([$new_rate], $official_names));
                }

                record_audit_log($pdo, $admin['id'], null, 'PROJECTION_RATE_UPDATED', "Updated global target projection rate to {$new_rate}% across all 6 plans");
                $success = "Target projection rate updated to {$new_rate}% across all six investment plans.";
            }
        }

        // 2. Edit One of the 6 Official Plans
        elseif ($action === 'save_plan') {
            $plan_id = (int)($_POST['plan_id'] ?? 0);
            $investment_amount = (float)($_POST['investment_amount'] ?? 0);
            $roi_percentage = (float)($_POST['roi_percentage'] ?? 45.00);
            $duration_days = (int)($_POST['duration_days'] ?? 1);
            $tagline = trim($_POST['tagline'] ?? '');
            $payout_interval = in_array($_POST['payout_interval'] ?? '', ['daily', 'weekly', 'end_of_term']) ? $_POST['payout_interval'] : 'end_of_term';
            $capital_returned = isset($_POST['capital_returned']) ? 1 : 0;
            $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

            if ($plan_id <= 0 || $investment_amount <= 0 || $roi_percentage <= 0 || $duration_days <= 0) {
                $error = "Please provide a valid positive investment amount, target projection rate, and duration in days.";
            } else {
                $chk = $pdo->prepare("SELECT name FROM investment_plans WHERE id = ? LIMIT 1");
                $chk->execute([$plan_id]);
                $existing_name = $chk->fetchColumn();

                if (!$existing_name || !in_array($existing_name, $official_names)) {
                    $error = "Only the six official GoldMine plans (Starter, Silver, Gold, Platinum, Elite, VIP) can be configured.";
                } else {
                    $sets = [];
                    $params = [];

                    $candidates = [
                        'tagline'          => $tagline,
                        'description'      => $tagline,
                        'min_amount'       => $investment_amount,
                        'max_amount'       => $investment_amount,
                        'amount'           => $investment_amount,
                        'roi_percentage'   => $roi_percentage,
                        'roi'              => $roi_percentage,
                        'duration_days'    => $duration_days,
                        'duration'         => $duration_days,
                        'payout_interval'  => $payout_interval,
                        'capital_returned' => $capital_returned,
                        'status'           => $status,
                    ];

                    foreach ($candidates as $c_key => $c_val) {
                        if (isset($plan_cols[$c_key])) {
                            $sets[] = "`{$plan_cols[$c_key]}` = ?";
                            $params[] = $c_val;
                        }
                    }

                    if (!empty($sets)) {
                        $params[] = $plan_id;
                        $upd = $pdo->prepare("UPDATE `investment_plans` SET " . implode(", ", $sets) . " WHERE `id` = ?");
                        $upd->execute($params);
                    }

                    record_audit_log($pdo, $admin['id'], null, 'PLAN_UPDATED', "Updated {$existing_name} Plan (#{$plan_id}): Amount={$investment_amount}, Projection={$roi_percentage}%, Duration={$duration_days}d, Status={$status}");
                    $success = "{$existing_name} Plan saved to MySQL (Amount: " . format_money($investment_amount, $currency_symbol) . ", Projection: {$roi_percentage}%, Duration: {$duration_days} Days).";
                }
            }
        }

        // 3. Toggle Plan Status (Active / Inactive)
        elseif ($action === 'toggle_plan') {
            $plan_id = (int)($_POST['plan_id'] ?? 0);
            $new_status = ($_POST['new_status'] === 'inactive') ? 'inactive' : 'active';
            if (isset($plan_cols['status'])) {
                $pdo->prepare("UPDATE investment_plans SET status = ? WHERE id = ?")->execute([$new_status, $plan_id]);
            }
            record_audit_log($pdo, $admin['id'], null, 'PLAN_STATUS_CHANGED', "Plan #{$plan_id} toggled to {$new_status}");
            $success = "Investment plan status updated to {$new_status}.";
        }
    }
}

$target_projection_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
$plans = ensure_six_investment_plans($pdo, true);
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Six Official Investment Plans Configuration
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Manage the 6 official plans (Starter, Silver, Gold, Platinum, Elite, VIP), edit investment amounts, durations, and target projection rates.
      </p>
    </div>

    <!-- Global Target Projection Rate Quick Form -->
    <form method="POST" action="plans.php" style="display: flex; align-items: center; gap: 10px; background: #0C140F; border: 1px solid rgba(245,197,24,0.35); padding: 10px 16px; border-radius: 12px;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="update_global_rate">
      <label style="font-size: 0.8rem; color: #C8D5CE; font-weight: 600; white-space: nowrap;">Target Projection Rate (%):</label>
      <input type="number" step="0.01" min="1" max="500" name="target_projection_rate" value="<?php echo number_format($target_projection_rate, 2, '.', ''); ?>" class="form-control" style="width: 90px; padding: 6px 10px; font-size: 0.85rem;" required>
      <button type="submit" class="btn-gold" style="padding: 7px 14px; font-size: 0.78rem; white-space: nowrap;">
        Apply to All 6 Plans
      </button>
    </form>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>Plan Name</th>
          <th>Investment Amount</th>
          <th>Projection Rate</th>
          <th>Projected Profit</th>
          <th>Projected Total</th>
          <th>Duration</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($plans as $p): ?>
          <tr>
            <td>
              <strong style="color: #FFF; font-size: 1rem;"><?php echo escape($p['name']); ?></strong><br>
              <span style="font-size: 0.75rem; color: #8E9E94;"><?php echo escape($p['tagline'] ?? ''); ?></span>
            </td>
            <td class="tabular-nums" style="font-size: 0.98rem; color: #FFF; font-weight: 700;">
              <?php echo $currency_symbol . number_format((float)$p['investment_amount'], 0); ?>
            </td>
            <td class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 1.1rem; font-weight: 800;">
              <?php echo (float)$p['roi_percentage']; ?>%
            </td>
            <td class="tabular-nums" style="color: #34D399; font-weight: 700;">
              +<?php echo $currency_symbol . number_format((float)$p['projected_profit'], 0); ?>
            </td>
            <td class="tabular-nums" style="color: #F5C518; font-weight: 800; font-size: 1rem;">
              <?php echo $currency_symbol . number_format((float)$p['projected_total'], 0); ?>
            </td>
            <td class="tabular-nums" style="font-weight: 600; color: #FFF;">
              <?php echo (int)$p['duration_days']; ?> Days
            </td>
            <td>
              <span class="badge-clean badge-<?php echo ($p['status'] === 'active') ? 'approved' : 'rejected'; ?>">
                <?php echo escape($p['status']); ?>
              </span>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <button type="button" onclick='openEditPlanModal(<?php echo json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' class="btn-gold" style="padding: 5px 12px; font-size: 0.75rem;">
                  Edit Plan
                </button>

                <form method="POST" action="plans.php" style="display: inline;">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="action" value="toggle_plan">
                  <input type="hidden" name="plan_id" value="<?php echo (int)$p['id']; ?>">
                  <input type="hidden" name="new_status" value="<?php echo ($p['status'] === 'active') ? 'inactive' : 'active'; ?>">
                  <button type="submit" class="btn-outline-gold" style="padding: 5px 10px; font-size: 0.75rem;">
                    <?php echo ($p['status'] === 'active') ? 'Deactivate' : 'Activate'; ?>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Edit Official Plan -->
<div id="planModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 560px; width: 100%; max-height: 90vh; overflow-y: auto; padding: 28px;">
    <h3 id="planModalTitle" class="font-gold-serif" style="font-size: 1.3rem; color: #FFF; margin-bottom: 16px;">Configure Plan</h3>

    <form method="POST" action="plans.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="save_plan">
      <input type="hidden" name="plan_id" id="modalPlanId" value="0">

      <div class="form-group">
        <label class="form-label">Official Plan Name</label>
        <input type="text" id="modalPlanName" class="form-control" readonly style="opacity: 0.75; cursor: not-allowed;">
      </div>

      <div class="form-group">
        <label class="form-label">Subtitle / Description</label>
        <input type="text" name="tagline" id="modalPlanTagline" class="form-control" placeholder="Short description of tier">
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div class="form-group">
          <label class="form-label">Investment Amount (<?php echo escape($currency_symbol); ?>) *</label>
          <input type="number" step="0.01" min="1" name="investment_amount" id="modalPlanAmount" class="form-control" required oninput="updateModalPreview()">
        </div>
        <div class="form-group">
          <label class="form-label">Target Projection Rate (%) *</label>
          <input type="number" step="0.01" min="1" name="roi_percentage" id="modalPlanRoi" class="form-control" required oninput="updateModalPreview()">
        </div>
      </div>

      <!-- Live Projection Preview Box -->
      <div style="background: #080E0B; border: 1px solid rgba(245,197,24,0.3); border-radius: 10px; padding: 12px 16px; margin-bottom: 16px; font-size: 0.84rem;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span style="color: #8E9E94;">Projected Profit:</span>
          <strong id="previewProfit" class="tabular-nums" style="color: #34D399;">+<?php echo escape($currency_symbol); ?>0</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #FFF; font-weight: 600;">Projected Total:</span>
          <strong id="previewTotal" class="tabular-nums" style="color: #F5C518;"><?php echo escape($currency_symbol); ?>0</strong>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div class="form-group">
          <label class="form-label">Duration (Days) *</label>
          <input type="number" min="1" name="duration_days" id="modalPlanDays" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="modalPlanStatus" class="form-control">
            <option value="active">Active (Visible on Invest Page)</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      <input type="hidden" name="payout_interval" id="modalPlanInterval" value="end_of_term">
      <input type="hidden" name="capital_returned" value="1">

      <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px;">
        <button type="button" onclick="closeModal('planModal')" class="btn-outline-gold" style="padding: 10px 20px;">Cancel</button>
        <button type="submit" class="btn-gold" style="padding: 10px 24px;">Save Changes to MySQL</button>
      </div>
    </form>
  </div>
</div>

<script>
const CURR_SYM = <?php echo json_encode($currency_symbol); ?>;

function updateModalPreview() {
  const amt = parseFloat(document.getElementById('modalPlanAmount').value) || 0;
  const roi = parseFloat(document.getElementById('modalPlanRoi').value) || 0;
  const profit = Math.round((amt * roi) / 100);
  const total = amt + profit;
  document.getElementById('previewProfit').innerText = '+' + CURR_SYM + profit.toLocaleString();
  document.getElementById('previewTotal').innerText = CURR_SYM + total.toLocaleString();
}

function openEditPlanModal(p) {
  document.getElementById('planModalTitle').innerText = 'Configure ' + p.name + ' Plan';
  document.getElementById('modalPlanId').value = p.id;
  document.getElementById('modalPlanName').value = p.name;
  document.getElementById('modalPlanTagline').value = p.tagline || '';
  document.getElementById('modalPlanAmount').value = parseFloat(p.min_amount);
  document.getElementById('modalPlanRoi').value = parseFloat(p.roi_percentage);
  document.getElementById('modalPlanDays').value = parseInt(p.duration_days, 10);
  document.getElementById('modalPlanInterval').value = p.payout_interval || 'end_of_term';
  document.getElementById('modalPlanStatus').value = p.status;
  updateModalPreview();
  openModal('planModal');
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
