<?php
/**
 * Active Portfolios & Investment Holdings
 * GoldMine Investment Platform - Admin Console
 * 
 * Uses the authoritative `investments` table schema:
 * id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage,
 * expected_return, duration_days, start_date, maturity_date, status,
 * admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 */
$page_title = "Investment Portfolio Ledger";
require_once __DIR__ . '/header.php';

$default_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
if ($default_rate <= 0) {
    $default_rate = 45.00;
}

// Optional Admin Action: Mark matured active investments
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $_SESSION['flash_error'] = "Security token validation failed.";
        header("Location: investments.php");
        exit;
    }

    $inv_id = (int)($_POST['investment_id'] ?? 0);
    if ($_POST['action'] === 'mark_matured' && $inv_id > 0) {
        try {
            $inv_cols = get_table_columns($pdo, 'investments');
            $sets = ["`status` = 'completed'"];
            $params = [];
            if (isset($inv_cols['admin_action_by'])) {
                $sets[] = "`admin_action_by` = ?";
                $params[] = (int)$admin['id'];
            }
            if (isset($inv_cols['admin_action_at'])) {
                $sets[] = "`admin_action_at` = NOW()";
            }
            if (isset($inv_cols['updated_at'])) {
                $sets[] = "`updated_at` = NOW()";
            }
            $params[] = $inv_id;
            $pdo->prepare("UPDATE `investments` SET " . implode(", ", $sets) . " WHERE `id` = ? AND `status` = 'active'")->execute($params);
            record_audit_log($pdo, (int)$admin['id'], null, 'INVESTMENT_STATUS_MATURED', "Marked investment #{$inv_id} as matured/completed.");
            $_SESSION['flash_success'] = "Investment #{$inv_id} marked as matured.";
        } catch (Exception $e) {
            $_SESSION['flash_error'] = "Failed to update investment status.";
        }
        header("Location: investments.php");
        exit;
    }
}

// Fetch all investments across the 6 official plans using actual `investments` and `users` columns
$status_filter = trim($_GET['status'] ?? 'all');
$sql = "
    SELECT i.*,
           COALESCE(NULLIF(i.plan_name, ''), p.name) AS resolved_plan_name,
           COALESCE(NULLIF(i.roi_percentage, 0), p.roi_percentage) AS resolved_roi_percentage,
           COALESCE(NULLIF(i.duration_days, 0), p.duration_days) AS resolved_duration_days,
           u.full_name,
           u.email
    FROM investments i
    LEFT JOIN investment_plans p ON i.plan_id = p.id
    LEFT JOIN users u ON i.user_id = u.id
";
$params = [];

if ($status_filter !== 'all' && !empty($status_filter)) {
    $sql .= " WHERE i.status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY i.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$raw_investments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$investments = [];
foreach ($raw_investments as $row) {
    $row['plan_name'] = $row['resolved_plan_name'] ?? $row['plan_name'] ?? 'GoldMine';
    $row['roi_percentage'] = $row['resolved_roi_percentage'] ?? $row['roi_percentage'] ?? $default_rate;
    $row['duration_days'] = $row['resolved_duration_days'] ?? $row['duration_days'] ?? 7;
    $investments[] = normalize_investment_row($row, $default_rate);
}
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Investor Portfolio Holdings
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Monitor active and matured investments across all 6 official plans.
      </p>
    </div>

    <!-- Filter Buttons -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="investments.php?status=all" class="<?php echo $status_filter === 'all' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">All Positions</a>
      <a href="investments.php?status=active" class="<?php echo $status_filter === 'active' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Active</a>
      <a href="investments.php?status=completed" class="<?php echo $status_filter === 'completed' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Matured</a>
    </div>
  </div>

  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>Reference / Start Date</th>
          <th>Investor</th>
          <th>Plan Name</th>
          <th>Investment Amount</th>
          <th>ROI Rate</th>
          <th>Projected Profit</th>
          <th>Expected Return (Total)</th>
          <th>Maturity Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($investments)): ?>
          <tr>
            <td colspan="9" style="text-align: center; color: #8E9E94; padding: 32px;">
              No investment records found in database.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($investments as $inv): 
            $start_ts = strtotime($inv['start_date']);
            $maturity_ts = strtotime($inv['maturity_date']);
            $now_ts = time();
            $duration = max(1, $maturity_ts - $start_ts);
            $elapsed = max(0, min($duration, $now_ts - $start_ts));
            $pct = min(100, round(($elapsed / $duration) * 100, 1));
            $amt = (float)$inv['amount'];
            $rate = (float)$inv['roi_percentage'];
            $proj_total = (float)$inv['expected_return'];
            $proj_profit = (float)$inv['projected_profit'];
            $ref_code = $inv['reference_code'];
            $is_matured = ($inv['status'] === 'completed' || $now_ts >= $maturity_ts);
          ?>
            <tr>
              <td>
                <strong class="tabular-nums" style="color: #D4AF37;"><?php echo escape($ref_code); ?></strong><br>
                <span class="tabular-nums" style="font-size: 0.75rem; color: #8E9E94;">
                  <?php echo date('M d, Y H:i', $start_ts); ?>
                </span>
              </td>
              <td>
                <strong style="color: #FFF;"><?php echo escape($inv['full_name'] ?: ('Investor #' . $inv['user_id'])); ?></strong><br>
                <span style="font-size: 0.78rem; color: #D4AF37;"><?php echo escape($inv['email'] ?? ''); ?></span>
              </td>
              <td>
                <strong style="color: #D4AF37;"><?php echo escape($inv['plan_name']); ?></strong><br>
                <span style="font-size: 0.75rem; color: #8E9E94;"><?php echo (int)$inv['duration_days']; ?> Days Cycle</span>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #FFF; font-size: 0.95rem;">
                <?php echo format_money($amt, $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="color: #F5C518; font-weight: 700;">
                <?php echo number_format($rate, 2); ?>%
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #D4AF37;">
                +<?php echo format_money($proj_profit, $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #34D399;">
                <?php echo format_money($proj_total, $currency_symbol); ?>
              </td>
              <td>
                <span class="tabular-nums" style="font-size: 0.82rem; color: #FFF;"><?php echo date('M d, Y H:i', $maturity_ts); ?></span><br>
                <div style="background: #06110B; height: 4px; border-radius: 2px; overflow: hidden; margin-top: 4px; width: 100px;">
                  <div style="background: #D4AF37; height: 100%; width: <?php echo $pct; ?>%;"></div>
                </div>
                <span style="font-size: 0.7rem; color: #8E9E94;"><?php echo $pct; ?>% elapsed</span>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo (!$is_matured && $inv['status'] === 'active') ? 'approved' : 'pending'; ?>">
                  <?php echo (!$is_matured && $inv['status'] === 'active') ? 'Active' : 'Matured'; ?>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
