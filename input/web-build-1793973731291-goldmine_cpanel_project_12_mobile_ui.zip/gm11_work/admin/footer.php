  </main>
</div>

<script>
// Global mobile navigation toggle
function toggleAdminSidebar() {
  const sb = document.getElementById('adminSidebar');
  if (sb) {
    sb.classList.toggle('mobile-open');
  }
}

// Global admin modal dismiss helper
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'none';
}

function openModal(id) {
  const el = document.getElementById(id);
  if (el) {
    el.style.display = 'flex';
    el.style.zIndex = '99999';
  }
}

// Close modals on backdrop click
window.addEventListener('click', function(e) {
  if (e.target && e.target.classList && e.target.classList.contains('gm-modal-overlay')) {
    e.target.style.display = 'none';
  }
});
</script>
</body>
</html>
