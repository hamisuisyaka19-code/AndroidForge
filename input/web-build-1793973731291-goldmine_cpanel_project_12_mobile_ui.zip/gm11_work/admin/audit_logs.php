<?php
/**
 * Master Security & Compliance Audit Trail
 * GoldMine Investment Platform - Admin Console
 */
$page_title = "Compliance Audit Logs";
require_once __DIR__ . '/header.php';

// Fetch audit logs safely
$adm_label_col = has_column($pdo, 'admins', 'username') ? 'adm.username' : (has_column($pdo, 'admins', 'email') ? 'adm.email' : 'adm.id');
$logs = [];
try {
    $logs = $pdo->query("
        SELECT a.*, {$adm_label_col} AS admin_name, u.full_name AS user_name
        FROM audit_logs a
        LEFT JOIN admins adm ON a.admin_id = adm.id
        LEFT JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
        LIMIT 200
    ")->fetchAll();
} catch (Exception $e) {
    $logs = [];
}
?>

<div style="padding-bottom: 60px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Master Security &amp; Compliance Audit Trail
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Immutable audit log of all administrative actions, deposit reviews, payouts, adjustments, and logins.
    </p>
  </div>

  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>Timestamp</th>
          <th>Actor (Staff / User)</th>
          <th>Action Type</th>
          <th>Audit Details</th>
          <th>Network IP</th>
          <th>User Agent</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($logs)): ?>
          <tr>
            <td colspan="6" style="text-align: center; color: #8E9E94; padding: 32px;">
              No audit log entries recorded yet.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($logs as $l): ?>
            <tr>
              <td class="tabular-nums" style="font-size: 0.8rem; color: #94A3B8;">
                <?php echo date('Y-m-d H:i:s', strtotime($l['created_at'])); ?>
              </td>
              <td>
                <?php if (!empty($l['admin_name'])): ?>
                  <span style="color: #D4AF37; font-weight: 600;">Admin: <?php echo escape($l['admin_name']); ?></span>
                <?php elseif (!empty($l['user_name'])): ?>
                  <span style="color: #FFF;">User: <?php echo escape($l['user_name']); ?></span>
                <?php else: ?>
                  <span style="color: #64748B;">System / Guest</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge-clean" style="color: #34D399; font-size: 0.75rem;">
                  <?php echo escape($l['action']); ?>
                </span>
              </td>
              <td style="font-size: 0.85rem; color: #E2ECE5; max-width: 380px;">
                <?php echo escape($l['details']); ?>
              </td>
              <td class="tabular-nums" style="font-size: 0.8rem; color: #8E9E94;">
                <?php echo escape($l['ip_address'] ?? '-'); ?>
              </td>
              <td style="font-size: 0.72rem; color: #64748B; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                <?php echo escape($l['user_agent'] ?? '-'); ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
