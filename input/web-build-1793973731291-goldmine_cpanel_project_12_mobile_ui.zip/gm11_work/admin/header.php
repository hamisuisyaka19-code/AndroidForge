<?php
/**
 * Admin Panel Header
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin_login();
$admin = get_current_admin_data($pdo);

$site_name = get_setting($pdo, 'site_name', 'GoldMine Investment Platform');
$currency_symbol = get_setting($pdo, 'currency_symbol', '$');

// Count pending deposits and withdrawals for badges
$pending_deposits_count = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")->fetchColumn();
$pending_withdrawals_count = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? escape($page_title) . ' | ' : ''; ?>Admin Console | <?php echo escape($site_name); ?></title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
      .admin-layout {
        display: flex;
        min-height: 100vh;
      }
      .admin-sidebar {
        width: 260px;
        background: #040906;
        border-right: 1px solid rgba(212, 175, 55, 0.2);
        padding: 24px 16px;
        flex-shrink: 0;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .admin-main {
        flex: 1;
        background: #050B08;
        padding: 30px 36px;
        overflow-y: auto;
      }
      .admin-nav-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        border-radius: 8px;
        color: #9FB1A6;
        font-size: 0.88rem;
        font-weight: 500;
        margin-bottom: 4px;
        transition: all 0.2s ease;
      }
      .admin-nav-item:hover, .admin-nav-item.active {
        background: rgba(212, 175, 55, 0.12);
        color: #D4AF37;
        font-weight: 600;
      }
      .admin-pill-badge {
        font-size: 0.72rem;
        background: #D4AF37;
        color: #000;
        padding: 2px 7px;
        border-radius: 10px;
        font-weight: 800;
      }
      .admin-mobile-bar {
        display: none;
        padding: 14px 18px;
        background: #040906;
        border-bottom: 1px solid rgba(212, 175, 55, 0.25);
        align-items: center;
        justify-content: space-between;
      }
      @media (max-width: 900px) {
        .admin-layout { flex-direction: column; }
        .admin-mobile-bar { display: flex !important; }
        .admin-sidebar {
          width: 100% !important;
          border-right: none;
          border-bottom: 1px solid rgba(212,175,55,0.2);
          display: none;
        }
        .admin-sidebar.mobile-open {
          display: flex !important;
        }
        .admin-main { padding: 20px 14px; }
      }
    </style>
</head>
<body>

<!-- Mobile Header Bar -->
<div class="admin-mobile-bar">
  <div style="display: flex; align-items: center; gap: 8px;">
    <a href="index.php" class="font-gold-serif text-gold-gradient" style="font-size: 1.2rem; font-weight: 800;">
      GOLDMINE ADMIN
    </a>
  </div>
  <button type="button" onclick="toggleAdminSidebar()" class="btn-outline-gold" style="padding: 6px 14px; font-size: 0.8rem; cursor: pointer;">
    ☰ Navigation Menu
  </button>
</div>

<div class="admin-layout">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <div>
      <div style="padding: 0 10px 24px; border-bottom: 1px solid rgba(27,56,40,0.6); margin-bottom: 20px;">
        <a href="index.php" class="font-gold-serif text-gold-gradient" style="font-size: 1.35rem; font-weight: 800; display: block;">
          GOLDMINE
        </a>
        <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase; letter-spacing: 0.08em;">
          Master Administration
        </span>
      </div>

      <nav>
        <a href="index.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
          <span>Dashboard Overview</span>
        </a>

        <a href="deposits.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'deposits.php' ? 'active' : ''; ?>">
          <span>Deposits & Receipts</span>
          <?php if ($pending_deposits_count > 0): ?>
            <span class="admin-pill-badge"><?php echo $pending_deposits_count; ?></span>
          <?php endif; ?>
        </a>

        <a href="withdrawals.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'withdrawals.php' ? 'active' : ''; ?>">
          <span>Withdrawals</span>
          <?php if ($pending_withdrawals_count > 0): ?>
            <span class="admin-pill-badge" style="background: #F87171; color: #FFF;"><?php echo $pending_withdrawals_count; ?></span>
          <?php endif; ?>
        </a>

        <a href="users.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
          <span>User Management</span>
        </a>

        <a href="plans.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'plans.php' ? 'active' : ''; ?>">
          <span>Investment Plans</span>
        </a>

        <a href="investments.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'investments.php' ? 'active' : ''; ?>">
          <span>Active Portfolios</span>
        </a>

        <a href="settings.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
          <span>System & Bank Settings</span>
        </a>

        <a href="notifications.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
          <span>Broadcast Notices</span>
        </a>

        <a href="support_tickets.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'support_tickets.php' ? 'active' : ''; ?>">
          <span>Support Tickets</span>
        </a>

        <a href="audit_logs.php" class="admin-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'audit_logs.php' ? 'active' : ''; ?>">
          <span>Audit Trail Logs</span>
        </a>
      </nav>
    </div>

    <!-- Admin User Badge -->
    <div style="border-top: 1px solid rgba(27,56,40,0.6); padding-top: 16px; margin-top: 20px;">
      <div style="font-size: 0.85rem; font-weight: 600; color: #FFF;">
        <?php echo escape($admin['name'] ?? $admin['username']); ?>
      </div>
      <div style="font-size: 0.75rem; color: #D4AF37; margin-bottom: 12px; text-transform: uppercase;">
        <?php echo escape($admin['role'] ?? 'Super Admin'); ?>
      </div>
      <div style="display: flex; gap: 10px;">
        <a href="../dashboard.php" class="btn-outline-gold" style="font-size: 0.75rem; padding: 5px 10px; flex: 1; text-align: center;">View Client App</a>
        <a href="logout.php" style="color: #F87171; font-size: 0.78rem; display: flex; align-items: center; padding: 5px;">Logout</a>
      </div>
    </div>
  </aside>

  <!-- Main Viewport -->
  <main class="admin-main">
    <?php if (!empty($_SESSION['flash_success'])): ?>
      <div class="flash-msg flash-success" style="margin-bottom: 20px;">
        <?php echo escape($_SESSION['flash_success']); unset($_SESSION['flash_success']); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <div class="flash-msg flash-error" style="margin-bottom: 20px;">
        <?php echo escape($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?>
      </div>
    <?php endif; ?>
