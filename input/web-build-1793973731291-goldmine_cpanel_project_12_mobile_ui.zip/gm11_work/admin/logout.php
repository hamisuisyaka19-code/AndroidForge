<?php
/**
 * Admin Logout
 */
require_once __DIR__ . '/../includes/auth.php';

unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_name']);

header("Location: login.php");
exit;
