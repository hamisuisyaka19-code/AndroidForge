<?php
/**
 * Deposit Management & Receipt Verification
 * GoldMine Investment Platform - Admin Console
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`balance`, `full_name`, `email`).
 */
$page_title = "Deposit Management";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Handle Deposit Actions (Approve / Reject)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $deposit_id = (int)($_POST['deposit_id'] ?? 0);
        $admin_action = $_POST['action'];
        $notes = trim($_POST['admin_notes'] ?? '');

        try {
            $pdo->beginTransaction();
            $dStmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
            $dStmt->execute([$deposit_id]);
            $dep = normalize_deposit_row($dStmt->fetch(PDO::FETCH_ASSOC));

            if (!$dep) {
                $pdo->rollBack();
                $error = "Deposit record not found.";
            } elseif ($dep['status'] !== 'pending') {
                $pdo->rollBack();
                $error = "This deposit has already been " . $dep['status'] . ".";
            } else {
                $user_id = (int)$dep['user_id'];
                $amount = round((float)$dep['amount'], 2);
                $dep_ref = $dep['reference_code'] ?: ('DEP-' . $deposit_id);

                // Lock user row compatible with `balance`
                $userRow = lock_user_row($pdo, $user_id);

                if (!$userRow) {
                    $pdo->rollBack();
                    $error = "Associated user account (#{$user_id}) not found.";
                } elseif ($admin_action === 'approve') {
                    $new_balance = round((float)$userRow['balance'] + $amount, 2);

                    // 1. Update deposit status (`status`, `admin_action_by`, `admin_action_at`, `admin_notes`, `updated_at`)
                    update_deposit_status($pdo, $deposit_id, 'approved', $notes, (int)$admin['id']);

                    // 2. Update user balance
                    update_user_balance($pdo, $user_id, $new_balance);

                    // 3. Record transaction ledger entry (`reference_code`)
                    record_transaction(
                        $pdo,
                        $user_id,
                        'deposit',
                        $amount,
                        $new_balance,
                        $dep_ref,
                        "Manual bank transfer verified and approved by admin",
                        0.00,
                        'completed'
                    );

                    // 4. Check and credit referral bonus once per deposit (if referral columns exist)
                    if (!empty($userRow['referred_by']) && has_column($pdo, 'users', 'referral_code')) {
                        $refBonusPct = (float)get_setting($pdo, 'referral_bonus_percent', '10.00');
                        if ($refBonusPct > 0) {
                            $refBonusCode = 'REF-BONUS-DEP' . $deposit_id;

                            if (!transaction_reference_exists($pdo, $refBonusCode, true)) {
                                $refUserStmt = $pdo->prepare("SELECT * FROM users WHERE referral_code = ? LIMIT 1 FOR UPDATE");
                                $refUserStmt->execute([$userRow['referred_by']]);
                                $refUser = normalize_user_row($refUserStmt->fetch(PDO::FETCH_ASSOC));

                                if ($refUser) {
                                    $bonusAmount = round($amount * ($refBonusPct / 100), 2);
                                    if ($bonusAmount > 0) {
                                        $refNewBal = round((float)$refUser['balance'] + $bonusAmount, 2);
                                        update_user_balance($pdo, (int)$refUser['id'], $refNewBal);

                                        record_transaction(
                                            $pdo,
                                            (int)$refUser['id'],
                                            'referral_bonus',
                                            $bonusAmount,
                                            $refNewBal,
                                            $refBonusCode,
                                            "Referral commission ({$refBonusPct}%) on approved deposit #{$deposit_id}",
                                            0.00,
                                            'completed'
                                        );

                                        create_notification(
                                            $pdo,
                                            (int)$refUser['id'],
                                            "Referral Bonus Received!",
                                            "You earned " . format_money($bonusAmount, $currency_symbol) . " from your partner deposit.",
                                            "success"
                                        );
                                    }
                                }
                            }
                        }
                    }

                    // 5. Notify user
                    create_notification(
                        $pdo,
                        $user_id,
                        "Deposit Approved",
                        "Your deposit of " . format_money($amount, $currency_symbol) . " (Ref: {$dep_ref}) has been approved and credited to your wallet.",
                        "success"
                    );

                    // 6. Record audit log
                    record_audit_log($pdo, $admin['id'], $user_id, 'DEPOSIT_APPROVED', "Approved deposit #{$deposit_id} ({$dep_ref}) for {$amount}. Notes: {$notes}");

                    $pdo->commit();
                    $success = "Deposit #{$deposit_id} for " . format_money($amount, $currency_symbol) . " has been approved and credited to the user's wallet.";

                } elseif ($admin_action === 'reject') {
                    update_deposit_status($pdo, $deposit_id, 'rejected', $notes, (int)$admin['id']);

                    create_notification(
                        $pdo,
                        $user_id,
                        "Deposit Declined",
                        "Your deposit proof for " . format_money($amount, $currency_symbol) . " (Ref: {$dep_ref}) was declined. Reason: " . ($notes ?: 'Verification mismatch'),
                        "warning"
                    );

                    record_audit_log($pdo, $admin['id'], $user_id, 'DEPOSIT_REJECTED', "Rejected deposit #{$deposit_id} ({$dep_ref}) for {$amount}. Reason: {$notes}");

                    $pdo->commit();
                    $success = "Deposit #{$deposit_id} has been marked as rejected.";
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Deposit action failed: " . $e->getMessage();
        }
    }
}

// Filter parameters (avoid selecting nonexistent `u.username`)
$status_filter = trim($_GET['status'] ?? 'all');
$sql = "
    SELECT d.*, u.full_name, u.email
    FROM deposits d
    LEFT JOIN users u ON d.user_id = u.id
";
$params = [];

if ($status_filter !== 'all' && !empty($status_filter)) {
    $sql .= " WHERE d.status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY d.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$deposits = array_map('normalize_deposit_row', $stmt->fetchAll(PDO::FETCH_ASSOC));
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Deposit Management &amp; Receipt Audit
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Review payment proofs, inspect uploaded wire receipts, and authorize client wallet credits.
      </p>
    </div>

    <!-- Filter Buttons -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="deposits.php?status=all" class="<?php echo $status_filter === 'all' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">All</a>
      <a href="deposits.php?status=pending" class="<?php echo $status_filter === 'pending' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Pending (<?php echo $pending_deposits_count; ?>)</a>
      <a href="deposits.php?status=approved" class="<?php echo $status_filter === 'approved' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Approved</a>
      <a href="deposits.php?status=rejected" class="<?php echo $status_filter === 'rejected' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Rejected</a>
    </div>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <!-- Deposits Table -->
  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>ID / Date</th>
          <th>Investor</th>
          <th>Amount</th>
          <th>Method</th>
          <th>Reference</th>
          <th>Receipt Proof</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($deposits)): ?>
          <tr>
            <td colspan="8" style="text-align: center; color: #8E9E94; padding: 32px;">
              No deposit submissions found matching this filter.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($deposits as $d): ?>
            <tr>
              <td>
                <strong style="color: #FFF;">#<?php echo (int)$d['id']; ?></strong><br>
                <span class="tabular-nums" style="font-size: 0.75rem; color: #8E9E94;">
                  <?php echo date('M d, Y H:i', strtotime($d['created_at'])); ?>
                </span>
              </td>
              <td>
                <strong style="color: #FFF;"><?php echo escape($d['full_name'] ?: ('Investor #' . $d['user_id'])); ?></strong><br>
                <span style="font-size: 0.78rem; color: #D4AF37;"><?php echo escape($d['email'] ?? ''); ?></span>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #34D399; font-size: 1.05rem;">
                <?php echo format_money($d['amount'], $currency_symbol); ?>
              </td>
              <td style="text-transform: capitalize; font-size: 0.85rem;">
                <?php echo str_replace('_', ' ', escape($d['payment_method'])); ?>
              </td>
              <td class="tabular-nums" style="font-size: 0.8rem; color: #D4AF37;">
                <?php echo escape($d['reference_code']); ?>
                <?php if (!empty($d['gateway_ref'])): ?>
                  <div style="font-size: 0.72rem; color: #94A3B8;">Gateway/Sender Ref: <?php echo escape($d['gateway_ref']); ?></div>
                <?php endif; ?>
                <?php if (!empty($d['admin_notes'])): ?>
                  <div style="font-size: 0.72rem; color: #8E9E94;"><?php echo escape($d['admin_notes']); ?></div>
                <?php endif; ?>
              </td>
              <td>
                <?php if (!empty($d['receipt_path'])): ?>
                  <button type="button" onclick="previewReceipt('../uploads/receipts/<?php echo escape(basename((string)$d['receipt_path'])); ?>')" class="btn-outline-gold" style="padding: 4px 10px; font-size: 0.75rem;">
                    Inspect Receipt
                  </button>
                <?php else: ?>
                  <span style="color: #64748B; font-size: 0.75rem;">Automated Gateway</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo escape($d['status']); ?>">
                  <?php echo escape($d['status']); ?>
                </span>
              </td>
              <td>
                <?php if ($d['status'] === 'pending'): ?>
                  <div style="display: flex; gap: 6px;">
                    <form method="POST" action="deposits.php" style="display: inline;" onsubmit="return confirm('Confirm approval of this deposit? User wallet will be credited immediately.');">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="deposit_id" value="<?php echo (int)$d['id']; ?>">
                      <input type="hidden" name="action" value="approve">
                      <button type="submit" class="btn-gold" style="padding: 5px 12px; font-size: 0.75rem;">
                        Approve
                      </button>
                    </form>

                    <button type="button" onclick="openRejectModal(<?php echo (int)$d['id']; ?>, '<?php echo escape(addslashes($d['reference_code'])); ?>')" class="btn-outline-gold" style="padding: 5px 10px; font-size: 0.75rem; border-color: #EF4444; color: #F87171;">
                      Reject
                    </button>
                  </div>
                <?php else: ?>
                  <span style="font-size: 0.78rem; color: #8E9E94;">Settled</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Receipt Viewing Modal -->
<div id="receiptModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 750px; width: 100%; max-height: 90vh; overflow-y: auto; padding: 24px; position: relative;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
      <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF;">Bank Transfer Payment Receipt</h3>
      <button type="button" onclick="closeModal('receiptModal')" style="background: none; border: none; color: #FFF; font-size: 1.5rem; cursor: pointer;">&times;</button>
    </div>
    <div style="text-align: center; background: #000; padding: 10px; border-radius: 8px;">
      <img id="receiptModalImg" src="" alt="Deposit Proof" style="max-width: 100%; max-height: 70vh; border-radius: 6px; object-fit: contain;">
    </div>
  </div>
</div>

<!-- Rejection Modal -->
<div id="rejectModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 480px; width: 100%; padding: 28px;">
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 12px;">Reject Deposit Submission</h3>
    <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
      Provide a justification reason. This note will be sent to the user's notification center.
    </p>

    <form method="POST" action="deposits.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="deposit_id" id="rejectDepositId" value="">

      <div class="form-group">
        <label class="form-label">Rejection Reason</label>
        <textarea name="admin_notes" class="form-control" rows="3" required placeholder="e.g. Unverified sender reference, illegible receipt, payment reversed by bank"></textarea>
      </div>

      <div style="display: flex; gap: 10px; justify-content: flex-end;">
        <button type="button" onclick="closeModal('rejectModal')" class="btn-outline-gold" style="padding: 8px 16px;">Cancel</button>
        <button type="submit" class="btn-gold" style="background: #DC2626; color: #FFF; padding: 8px 18px;">Confirm Rejection</button>
      </div>
    </form>
  </div>
</div>

<script>
function previewReceipt(src) {
  document.getElementById('receiptModalImg').src = src;
  openModal('receiptModal');
}
function openRejectModal(id, ref) {
  document.getElementById('rejectDepositId').value = id;
  openModal('rejectModal');
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
