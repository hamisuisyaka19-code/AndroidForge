<?php
/**
 * User & Investor Management
 * GoldMine Investment Platform - Admin Console
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`balance`, `total_invested`, `total_profit`).
 */
$page_title = "User Management";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Handle User Balance Adjustments or Status Toggles
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $target_user_id = (int)($_POST['user_id'] ?? 0);
        $action = $_POST['action'];

        // 1. Balance Adjustment (Credit / Debit)
        if ($action === 'adjust_balance') {
            $adjust_type = $_POST['adjust_type'] ?? 'credit'; // credit or debit
            $adjust_amount = round((float)($_POST['adjust_amount'] ?? 0), 2);
            $reason = trim($_POST['adjust_reason'] ?? '');

            if ($adjust_amount <= 0 || empty($reason)) {
                $error = "A valid positive adjustment amount and justification reason are required.";
            } else {
                try {
                    $pdo->beginTransaction();

                    $targetUser = lock_user_row($pdo, $target_user_id);

                    if (!$targetUser) {
                        $pdo->rollBack();
                        $error = "User not found.";
                    } else {
                        $current_bal = (float)$targetUser['balance'];
                        if ($adjust_type === 'debit' && $current_bal < $adjust_amount) {
                            $pdo->rollBack();
                            $error = "User has insufficient balance (" . format_money($current_bal, $currency_symbol) . ") for this debit adjustment.";
                        } else {
                            $new_bal = ($adjust_type === 'credit')
                                ? round($current_bal + $adjust_amount, 2)
                                : round($current_bal - $adjust_amount, 2);

                            update_user_balance($pdo, $target_user_id, $new_bal);

                            // Record transaction
                            $refTx = generate_reference('ADJ-' . strtoupper($adjust_type));
                            $txType = ($adjust_type === 'credit') ? 'refund' : 'withdrawal';
                            record_transaction(
                                $pdo,
                                $target_user_id,
                                $txType,
                                $adjust_amount,
                                $new_bal,
                                $refTx,
                                "Administrative balance adjustment: " . $reason,
                                0.00,
                                'completed'
                            );

                            // Notify user
                            create_notification(
                                $pdo,
                                $target_user_id,
                                "Balance Adjusted by Treasury",
                                "Your wallet was " . ($adjust_type === 'credit' ? 'credited with ' : 'debited by ') . format_money($adjust_amount, $currency_symbol) . ". Reason: " . $reason,
                                ($adjust_type === 'credit' ? 'success' : 'warning')
                            );

                            record_audit_log($pdo, $admin['id'], $target_user_id, 'USER_BALANCE_ADJUSTED', "{$adjust_type} of {$adjust_amount} applied to user #{$target_user_id}. Reason: {$reason}");

                            $pdo->commit();
                            $success = "Successfully " . ($adjust_type === 'credit' ? 'credited ' : 'debited ') . format_money($adjust_amount, $currency_symbol) . " to {$targetUser['full_name']}. New balance: " . format_money($new_bal, $currency_symbol);
                        }
                    }
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = "Adjustment failed: " . $e->getMessage();
                }
            }
        }

        // 2. Change User Status (Active / Suspended)
        elseif ($action === 'toggle_status') {
            $new_status = ($_POST['new_status'] === 'suspended') ? 'suspended' : 'active';
            $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$new_status, $target_user_id]);
            record_audit_log($pdo, $admin['id'], $target_user_id, 'USER_STATUS_CHANGED', "User #{$target_user_id} status changed to {$new_status}");
            $success = "User status updated to {$new_status}.";
        }
    }
}

// Search and list users compatible with actual `users` columns
$search = trim($_GET['search'] ?? '');
$sql = "SELECT u.*, b.bank_name, b.account_number FROM users u LEFT JOIN user_bank_details b ON u.id = b.user_id";
$params = [];

if (!empty($search)) {
    $term = "%{$search}%";
    $where_parts = ["u.full_name LIKE ?", "u.email LIKE ?", "u.phone LIKE ?"];
    $params = [$term, $term, $term];

    if (has_column($pdo, 'users', 'username')) {
        $where_parts[] = "u.username LIKE ?";
        $params[] = $term;
    }
    if (has_column($pdo, 'users', 'referral_code')) {
        $where_parts[] = "u.referral_code LIKE ?";
        $params[] = $term;
    }
    $sql .= " WHERE (" . implode(" OR ", $where_parts) . ")";
}

$sql .= " ORDER BY u.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$raw_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$users = [];
foreach ($raw_users as $ru) {
    $norm = normalize_user_row($ru);
    $norm['bank_name'] = $ru['bank_name'] ?? '';
    $norm['account_number'] = $ru['account_number'] ?? '';
    $users[] = $norm;
}
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Investor Accounts Directory
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        View verified portfolios, adjust client balances with audit justifications, and manage access statuses.
      </p>
    </div>

    <!-- Search Bar -->
    <form method="GET" action="users.php" style="display: flex; gap: 8px;">
      <input type="text" name="search" class="form-control" style="width: 260px; padding: 8px 14px; font-size: 0.85rem;" placeholder="Search name, email, phone..." value="<?php echo escape($search); ?>">
      <button type="submit" class="btn-gold" style="padding: 8px 16px; font-size: 0.85rem;">Search</button>
      <?php if (!empty($search)): ?>
        <a href="users.php" class="btn-outline-gold" style="padding: 8px 14px; font-size: 0.85rem;">Clear</a>
      <?php endif; ?>
    </form>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>ID / Joined</th>
          <th>Investor Details</th>
          <th>Wallet Balance</th>
          <th>Total Invested</th>
          <th>Total Profits</th>
          <th>Bank Details</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($users)): ?>
          <tr>
            <td colspan="8" style="text-align: center; color: #8E9E94; padding: 32px;">
              No investor records found.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($users as $u): ?>
            <tr>
              <td>
                <strong style="color: #FFF;">#<?php echo (int)$u['id']; ?></strong><br>
                <span class="tabular-nums" style="font-size: 0.75rem; color: #8E9E94;">
                  <?php echo date('M d, Y', strtotime($u['created_at'])); ?>
                </span>
              </td>
              <td>
                <strong style="color: #FFF;"><?php echo escape($u['full_name']); ?></strong><br>
                <span style="font-size: 0.78rem; color: #D4AF37;"><?php echo escape($u['email']); ?></span>
                <?php if (!empty($u['phone'])): ?>
                  <br><span style="font-size: 0.75rem; color: #8E9E94;"><?php echo escape($u['phone']); ?></span>
                <?php endif; ?>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #FFF; font-size: 1.05rem;">
                <?php echo format_money($u['balance'], $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="color: #D4AF37; font-weight: 600;">
                <?php echo format_money($u['total_invested'], $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="color: #34D399; font-weight: 600;">
                +<?php echo format_money($u['total_profit'], $currency_symbol); ?>
              </td>
              <td style="font-size: 0.78rem; color: #A3B5AA;">
                <?php if (!empty($u['bank_name'])): ?>
                  <?php echo escape($u['bank_name']); ?><br>
                  <span class="tabular-nums"><?php echo escape($u['account_number']); ?></span>
                <?php else: ?>
                  <span style="color: #64748B;">Not Configured</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo ($u['status'] === 'active') ? 'approved' : 'rejected'; ?>">
                  <?php echo escape($u['status']); ?>
                </span>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <button type="button" onclick="openAdjustModal(<?php echo (int)$u['id']; ?>, '<?php echo escape(addslashes($u['full_name'])); ?>', '<?php echo format_money($u['balance'], $currency_symbol); ?>')" class="btn-gold" style="padding: 5px 10px; font-size: 0.75rem;">
                    Adjust Bal
                  </button>

                  <form method="POST" action="users.php" style="display: inline;" onsubmit="return confirm('Toggle status for this user?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="user_id" value="<?php echo (int)$u['id']; ?>">
                    <input type="hidden" name="new_status" value="<?php echo ($u['status'] === 'active') ? 'suspended' : 'active'; ?>">
                    <button type="submit" class="btn-outline-gold" style="padding: 5px 10px; font-size: 0.75rem; border-color: <?php echo ($u['status'] === 'active') ? '#F87171' : '#34D399'; ?>; color: <?php echo ($u['status'] === 'active') ? '#F87171' : '#34D399'; ?>;">
                      <?php echo ($u['status'] === 'active') ? 'Suspend' : 'Activate'; ?>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Adjust Balance -->
<div id="adjustModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 480px; width: 100%; padding: 28px;">
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 6px;">Adjust Client Balance</h3>
    <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
      Adjusting account for <strong id="modalUserName" style="color: #FFF;"></strong> (Current: <span id="modalCurrentBal" style="color: #D4AF37;"></span>)
    </p>

    <form method="POST" action="users.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="adjust_balance">
      <input type="hidden" name="user_id" id="modalUserId" value="">

      <div class="form-group">
        <label class="form-label">Adjustment Type</label>
        <select name="adjust_type" class="form-control" required>
          <option value="credit">Credit Funds (Add to Balance)</option>
          <option value="debit">Debit Funds (Deduct from Balance)</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Amount (<?php echo escape($currency_symbol); ?>)</label>
        <input type="number" step="0.01" min="0.01" name="adjust_amount" class="form-control" required placeholder="Amount to add/deduct">
      </div>

      <div class="form-group">
        <label class="form-label">Reason / Audit Justification</label>
        <input type="text" name="adjust_reason" class="form-control" required placeholder="e.g. Loyalty compensation, manual wire credit">
      </div>

      <div style="display: flex; gap: 10px; justify-content: flex-end;">
        <button type="button" onclick="closeModal('adjustModal')" class="btn-outline-gold" style="padding: 8px 16px;">Cancel</button>
        <button type="submit" class="btn-gold" style="padding: 8px 18px;">Confirm Adjustment</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAdjustModal(id, name, bal) {
  document.getElementById('modalUserId').value = id;
  document.getElementById('modalUserName').innerText = name;
  document.getElementById('modalCurrentBal').innerText = bal;
  openModal('adjustModal');
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
