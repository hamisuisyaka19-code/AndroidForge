<?php
/**
 * Master Administrator Authentication Portal
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$page_title = "Admin Login";

if (is_admin_logged_in()) {
    header("Location: index.php");
    exit;
}

$error = '';

// Check if any admin account exists in database
$adminCount = 0;
try {
    $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
} catch (Exception $e) {
    $adminCount = 0;
}

// If no admin exists, facilitate secure initial admin setup
$needs_bootstrap = ($adminCount === 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $error = "Security validation token expired. Please retry.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($needs_bootstrap) {
            $name = trim($_POST['name'] ?? 'Super Admin');
            $email = trim($_POST['email'] ?? 'admin@goalmindai.com.ng');

            if (empty($username) || empty($password)) {
                $error = "Please provide username and master password.";
            } else {
                try {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $adm_cols = get_table_columns($pdo, 'admins');
                    $ins_cols = [];
                    $ins_vals = [];
                    $ins_params = [];

                    $candidates = [
                        'username'      => $username,
                        'email'         => $email,
                        'password'      => $hash,
                        'password_hash' => $hash,
                        'name'          => $name,
                        'full_name'     => $name,
                        'role'          => 'superadmin',
                    ];

                    foreach ($candidates as $k => $v) {
                        if (isset($adm_cols[$k])) {
                            $ins_cols[] = "`{$adm_cols[$k]}`";
                            $ins_vals[] = "?";
                            $ins_params[] = $v;
                        }
                    }
                    if (isset($adm_cols['created_at'])) {
                        $ins_cols[] = "`created_at`";
                        $ins_vals[] = "NOW()";
                    }

                    $ins = $pdo->prepare("INSERT INTO `admins` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")");
                    $ins->execute($ins_params);

                    $newAdminId = (int)$pdo->lastInsertId();
                    session_regenerate_id(true);
                    $_SESSION['admin_id'] = $newAdminId;
                    $_SESSION['admin_username'] = $username;
                    $_SESSION['admin_name'] = $name;
                    record_audit_log($pdo, $newAdminId, null, 'ADMIN_BOOTSTRAP', 'Initial master administrator account configured');

                    $_SESSION['flash_success'] = "Master administrator account created successfully!";
                    header("Location: index.php");
                    exit;
                } catch (Exception $e) {
                    error_log("Admin Bootstrap Error: " . $e->getMessage());
                    $error = "Failed to initialize administrator account.";
                }
            }
        } else {
            if (empty($username) || empty($password)) {
                $error = "Please enter administrator username/email and password.";
            } else {
                try {
                    if (has_column($pdo, 'admins', 'username') && has_column($pdo, 'admins', 'email')) {
                        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
                        $stmt->execute([$username, $username]);
                    } elseif (has_column($pdo, 'admins', 'username')) {
                        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? LIMIT 1");
                        $stmt->execute([$username]);
                    } else {
                        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
                        $stmt->execute([$username]);
                    }

                    $adminRow = normalize_admin_row($stmt->fetch(PDO::FETCH_ASSOC));

                    if ($adminRow && !empty($adminRow['password']) && password_verify($password, $adminRow['password'])) {
                        session_regenerate_id(true);
                        $_SESSION['admin_id'] = (int)$adminRow['id'];
                        $_SESSION['admin_username'] = $adminRow['username'];
                        $_SESSION['admin_name'] = $adminRow['name'];

                        record_audit_log($pdo, (int)$adminRow['id'], null, 'ADMIN_LOGIN', 'Administrator logged into console');
                        header("Location: index.php");
                        exit;
                    } else {
                        $error = "Invalid administrator credentials.";
                        record_audit_log($pdo, null, null, 'ADMIN_LOGIN_FAILED', "Failed login attempt for username: {$username}");
                    }
                } catch (Exception $e) {
                    error_log("Admin Login Error: " . $e->getMessage());
                    $error = "Database error during administrator authentication.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Access | GoldMine</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body style="display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #030705; padding: 20px;">

<div class="gm-card" style="max-width: 440px; width: 100%; padding: 36px 30px; border-color: rgba(212,175,55,0.4);">
  <div style="text-align: center; margin-bottom: 24px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.8rem; margin-bottom: 4px;">
      GOLDMINE
    </h1>
    <span style="font-size: 0.8rem; color: #8E9E94; text-transform: uppercase; letter-spacing: 0.1em;">
      <?php echo $needs_bootstrap ? 'Initial Admin Setup' : 'Master Admin Portal'; ?>
    </span>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="login.php">
    <?php echo csrf_field(); ?>

    <?php if ($needs_bootstrap): ?>
      <div style="background: rgba(212,175,55,0.1); border: 1px solid rgba(212,175,55,0.3); border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; font-size: 0.82rem; color: #F3E5AB;">
        No administrator is currently in the database. Create the master admin account below.
      </div>

      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control" required value="Super Administrator">
      </div>

      <div class="form-group">
        <label class="form-label">Admin Email</label>
        <input type="email" name="email" class="form-control" required value="admin@goalmindai.com.ng">
      </div>
    <?php endif; ?>

    <div class="form-group">
      <label class="form-label">Admin Username or Email</label>
      <input type="text" name="username" class="form-control" required placeholder="admin" autofocus>
    </div>

    <div class="form-group">
      <label class="form-label">Master Password</label>
      <input type="password" name="password" class="form-control" required placeholder="••••••••">
    </div>

    <button type="submit" class="btn-gold" style="width: 100%; padding: 12px; font-size: 0.95rem; margin-top: 10px;">
      <?php echo $needs_bootstrap ? 'Initialize Admin Account' : 'Authenticate & Enter Console'; ?>
    </button>
  </form>

  <div style="text-align: center; margin-top: 20px;">
    <a href="../index.php" style="color: #7D8F84; font-size: 0.8rem;">&larr; Back to Public Website</a>
  </div>
</div>

</body>
</html>
