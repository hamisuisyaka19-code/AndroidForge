<?php
/**
 * Announcements & User Broadcasts
 * GoldMine Investment Platform - Admin Console
 */
$page_title = "Announcements & Broadcasts";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Handle Notification Dispatch
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_notification') {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $target = $_POST['target_user'] ?? 'all'; // 'all' or user_id
        $title = trim($_POST['title'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'info';

        if (empty($title) || empty($message)) {
            $error = "Notice title and message body are required.";
        } else {
            $user_id = ($target === 'all') ? null : (int)$target;
            create_notification($pdo, $user_id, $title, $message, $type);
            record_audit_log($pdo, $admin['id'], $user_id, 'BROADCAST_SENT', "Notice sent: '{$title}' to " . ($user_id ? "user #{$user_id}" : "all users"));
            $success = "Announcement successfully dispatched!";
        }
    }
}

// Fetch users for target dropdown (avoid selecting nonexistent `username` column)
$users = $pdo->query("SELECT id, full_name, email FROM users ORDER BY full_name ASC LIMIT 200")->fetchAll();

// Fetch recent notifications
$notifs = $pdo->query("
    SELECT n.*, u.full_name, u.email
    FROM notifications n
    LEFT JOIN users u ON n.user_id = u.id
    ORDER BY n.created_at DESC
    LIMIT 50
")->fetchAll();
?>

<div style="max-width: 1050px; margin: 0 auto; padding-bottom: 60px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Announcements &amp; Notice Dispatch
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Send system broadcasts, trading alerts, and direct notifications to investor portfolios.
    </p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 1.3fr; gap: 24px;" class="calc-grid">
    <!-- Send Form -->
    <div class="gm-card">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        Dispatch New Notification
      </h3>

      <form method="POST" action="notifications.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="send_notification">

        <div class="form-group">
          <label class="form-label">Recipient Target</label>
          <select name="target_user" class="form-control">
            <option value="all">Global Broadcast (All Active Investors)</option>
            <optgroup label="Direct Investor">
              <?php foreach ($users as $u): ?>
                <option value="<?php echo (int)$u['id']; ?>">
                  <?php echo escape($u['full_name']); ?> (<?php echo escape($u['email']); ?>)
                </option>
              <?php endforeach; ?>
            </optgroup>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Notice Type</label>
          <select name="type" class="form-control">
            <option value="info">Information (Standard)</option>
            <option value="success">Success / Yield Announcement</option>
            <option value="warning">Compliance / Warning Alert</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Subject Title</label>
          <input type="text" name="title" class="form-control" required placeholder="e.g. Scheduled Treasury Maintenance">
        </div>

        <div class="form-group">
          <label class="form-label">Message Content</label>
          <textarea name="message" class="form-control" rows="4" required placeholder="Type the notification text..."></textarea>
        </div>

        <button type="submit" class="btn-gold" style="width: 100%; padding: 12px;">
          Send Notification
        </button>
      </form>
    </div>

    <!-- Notification Feed -->
    <div class="gm-card">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        Dispatched Announcements History
      </h3>

      <div style="display: flex; flex-direction: column; gap: 12px; max-height: 520px; overflow-y: auto;">
        <?php if (empty($notifs)): ?>
          <p style="color: #8E9E94; font-size: 0.85rem; text-align: center; padding: 24px;">No notices sent yet.</p>
        <?php else: ?>
          <?php foreach ($notifs as $nt): ?>
            <div style="background: #07120C; border: 1px solid rgba(27,56,40,0.6); border-radius: 8px; padding: 12px 16px;">
              <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px;">
                <strong style="color: #FFF; font-size: 0.9rem;"><?php echo escape($nt['title']); ?></strong>
                <span class="tabular-nums" style="font-size: 0.72rem; color: #8E9E94;">
                  <?php echo date('M d, H:i', strtotime($nt['created_at'])); ?>
                </span>
              </div>
              <div style="font-size: 0.75rem; color: #D4AF37; margin-bottom: 6px;">
                Target: <?php echo empty($nt['user_id']) ? 'Global Broadcast' : escape($nt['full_name'] ?: ('Investor #' . $nt['user_id'])); ?>
              </div>
              <p style="font-size: 0.82rem; color: #C2D1C7; line-height: 1.4;">
                <?php echo escape($nt['message']); ?>
              </p>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
