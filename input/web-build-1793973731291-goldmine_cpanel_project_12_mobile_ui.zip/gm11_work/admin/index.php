<?php
/**
 * Master Admin Overview & Analytics
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` schema (`balance`, `full_name`, `email`).
 */
$page_title = "Overview & System Analytics";
require_once __DIR__ . '/header.php';

// Calculate System Financial Aggregates directly from MySQL
$total_approved_deposits = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE status = 'approved'")->fetchColumn();
$pending_deposits_count = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")->fetchColumn();
$pending_deposits_sum = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE status = 'pending'")->fetchColumn();

$total_approved_withdrawals = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE status = 'approved'")->fetchColumn();
$pending_withdrawals_count = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")->fetchColumn();
$pending_withdrawals_sum = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE status = 'pending'")->fetchColumn();

$total_active_investments_sum = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM investments WHERE status = 'active'")->fetchColumn();
$active_investments_count = (int)$pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'active'")->fetchColumn();

$total_users_count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_user_balances_sum = sum_all_user_balances($pdo);

// Fetch pending deposits for immediate action (avoid referencing nonexistent `u.username`)
$pendingDepStmt = $pdo->query("
    SELECT d.*, u.full_name, u.email
    FROM deposits d
    LEFT JOIN users u ON d.user_id = u.id
    WHERE d.status = 'pending'
    ORDER BY d.created_at ASC
    LIMIT 6
");
$pending_deposits = array_map('normalize_deposit_row', $pendingDepStmt->fetchAll(PDO::FETCH_ASSOC));

// Fetch pending withdrawals for immediate action (avoid referencing nonexistent `u.username` or `u.wallet_balance`)
$pendingWdStmt = $pdo->query("
    SELECT w.*, u.full_name, u.email
    FROM withdrawals w
    LEFT JOIN users u ON w.user_id = u.id
    WHERE w.status = 'pending'
    ORDER BY w.created_at ASC
    LIMIT 6
");
$pending_withdrawals = $pendingWdStmt->fetchAll();

// Fetch recent audit logs
$recentAudit = [];
try {
    $recentAudit = $pdo->query("
        SELECT * FROM audit_logs
        ORDER BY created_at DESC
        LIMIT 8
    ")->fetchAll();
} catch (Exception $e) {
    $recentAudit = [];
}
?>

<div style="padding-bottom: 50px;">
  <!-- Header Bar -->
  <div style="margin-bottom: 28px; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Treasury &amp; System Operations Console
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Database: <strong style="color: #D4AF37;">lhzmylpw_goldmine</strong> · Real-time liquidity, compliance queues, and ledger tracking.
      </p>
    </div>

    <div style="display: flex; gap: 10px;">
      <a href="deposits.php" class="btn-gold" style="font-size: 0.85rem; padding: 9px 18px;">
        Review Deposits (<?php echo $pending_deposits_count; ?>)
      </a>
      <a href="withdrawals.php" class="btn-outline-gold" style="font-size: 0.85rem; padding: 9px 18px;">
        Payouts (<?php echo $pending_withdrawals_count; ?>)
      </a>
    </div>
  </div>

  <!-- Real Analytics KPI Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 18px; margin-bottom: 32px;">
    <!-- Approved Deposits -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Total Capital Deposited
      </div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 2rem; font-weight: 800;">
        <?php echo format_money($total_approved_deposits, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #FBBF24; margin-top: 6px;">
        Pending Review: <?php echo format_money($pending_deposits_sum, $currency_symbol); ?> (<?php echo $pending_deposits_count; ?>)
      </div>
    </div>

    <!-- Approved Withdrawals -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Total Capital Withdrawn
      </div>
      <div class="tabular-nums" style="font-size: 2rem; font-weight: 800; color: #FFF;">
        <?php echo format_money($total_approved_withdrawals, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #F87171; margin-top: 6px;">
        Pending Payouts: <?php echo format_money($pending_withdrawals_sum, $currency_symbol); ?> (<?php echo $pending_withdrawals_count; ?>)
      </div>
    </div>

    <!-- Active Investments -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Active Portfolio Holdings
      </div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 2rem; font-weight: 800;">
        <?php echo format_money($total_active_investments_sum, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #34D399; margin-top: 6px;">
        <?php echo $active_investments_count; ?> positions currently maturing
      </div>
    </div>

    <!-- Total Platform Users & Liquidity -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Registered Investors
      </div>
      <div class="tabular-nums" style="font-size: 2rem; font-weight: 800; color: #FFF;">
        <?php echo $total_users_count; ?>
      </div>
      <div style="font-size: 0.78rem; color: #D4AF37; margin-top: 6px;">
        Client Balances: <?php echo format_money($total_user_balances_sum, $currency_symbol); ?>
      </div>
    </div>
  </div>

  <!-- Pending Queues Split Grid -->
  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 36px;" class="calc-grid">
    <!-- 1. Pending Deposits Queue -->
    <div class="gm-card">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 class="font-gold-serif" style="font-size: 1.15rem; color: #FFF;">
          Pending Deposit Proofs (<?php echo $pending_deposits_count; ?>)
        </h3>
        <a href="deposits.php" style="color: #D4AF37; font-size: 0.8rem;">View All &rarr;</a>
      </div>

      <?php if (empty($pending_deposits)): ?>
        <p style="color: #8E9E94; font-size: 0.85rem; text-align: center; padding: 24px;">
          All deposit submissions have been verified and processed.
        </p>
      <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <?php foreach ($pending_deposits as $pDep): ?>
            <div style="background: #07120C; border: 1px solid rgba(27,56,40,0.6); border-radius: 8px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong style="color: #FFF; font-size: 0.88rem;"><?php echo escape($pDep['full_name'] ?: ('Investor #' . $pDep['user_id'])); ?></strong>
                <div style="font-size: 0.75rem; color: #8E9E94;">
                  Ref: <span class="tabular-nums text-gold-gradient"><?php echo escape($pDep['reference_code']); ?></span> · <?php echo date('M d, H:i', strtotime($pDep['created_at'])); ?>
                </div>
              </div>
              <div style="text-align: right;">
                <div class="tabular-nums" style="font-weight: 700; color: #34D399; font-size: 1rem;">
                  <?php echo format_money($pDep['amount'], $currency_symbol); ?>
                </div>
                <a href="deposits.php?id=<?php echo (int)$pDep['id']; ?>" class="btn-gold" style="padding: 4px 10px; font-size: 0.72rem; margin-top: 4px;">
                  Verify &amp; Approve
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- 2. Pending Withdrawals Queue -->
    <div class="gm-card">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 class="font-gold-serif" style="font-size: 1.15rem; color: #FFF;">
          Pending Withdrawal Payouts (<?php echo $pending_withdrawals_count; ?>)
        </h3>
        <a href="withdrawals.php" style="color: #D4AF37; font-size: 0.8rem;">View All &rarr;</a>
      </div>

      <?php if (empty($pending_withdrawals)): ?>
        <p style="color: #8E9E94; font-size: 0.85rem; text-align: center; padding: 24px;">
          All withdrawal requests have been settled or completed.
        </p>
      <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <?php foreach ($pending_withdrawals as $pWd): ?>
            <div style="background: #07120C; border: 1px solid rgba(27,56,40,0.6); border-radius: 8px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong style="color: #FFF; font-size: 0.88rem;"><?php echo escape($pWd['full_name'] ?: ('Investor #' . $pWd['user_id'])); ?></strong>
                <div style="font-size: 0.75rem; color: #8E9E94;">
                  Bank: <?php echo escape($pWd['bank_name']); ?> (<?php echo escape($pWd['account_number']); ?>)
                </div>
              </div>
              <div style="text-align: right;">
                <div class="tabular-nums" style="font-weight: 700; color: #FFF; font-size: 1rem;">
                  <?php echo format_money($pWd['net_amount'], $currency_symbol); ?>
                </div>
                <a href="withdrawals.php?id=<?php echo (int)$pWd['id']; ?>" class="btn-outline-gold" style="padding: 4px 10px; font-size: 0.72rem; margin-top: 4px;">
                  Process Payout
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Recent Audit Logs Strip -->
  <div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
      <h3 class="font-gold-serif" style="font-size: 1.15rem; color: #FFF;">
        Administrative Security Audit Trail
      </h3>
      <a href="audit_logs.php" style="color: #D4AF37; font-size: 0.8rem;">Full Audit Trail &rarr;</a>
    </div>

    <div class="gm-table-container">
      <table class="gm-table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Action</th>
            <th>Details</th>
            <th>IP Address</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recentAudit)): ?>
            <tr>
              <td colspan="4" style="text-align: center; color: #8E9E94; padding: 20px;">
                No audit entries recorded yet.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($recentAudit as $log): ?>
              <tr>
                <td class="tabular-nums" style="font-size: 0.8rem; color: #94A3B8;">
                  <?php echo date('M d, Y H:i:s', strtotime($log['created_at'])); ?>
                </td>
                <td style="font-weight: 600; color: #D4AF37; font-size: 0.85rem;">
                  <?php echo escape($log['action']); ?>
                </td>
                <td style="font-size: 0.85rem; color: #C2D1C7;">
                  <?php echo escape($log['details']); ?>
                </td>
                <td class="tabular-nums" style="font-size: 0.8rem; color: #8E9E94;">
                  <?php echo escape($log['ip_address'] ?? '-'); ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
