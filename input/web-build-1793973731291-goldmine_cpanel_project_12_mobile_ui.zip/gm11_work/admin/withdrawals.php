<?php
/**
 * Withdrawal Payouts & Queue Management
 * GoldMine Investment Platform - Admin Console
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`balance`, `full_name`, `email`).
 */
$page_title = "Withdrawal Management";
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

// Handle Withdrawal Approval / Rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $withdrawal_id = (int)($_POST['withdrawal_id'] ?? 0);
        $admin_action = $_POST['action'];
        $notes = trim($_POST['admin_notes'] ?? '');

        try {
            $pdo->beginTransaction();

            $wStmt = $pdo->prepare("SELECT * FROM withdrawals WHERE id = ? FOR UPDATE");
            $wStmt->execute([$withdrawal_id]);
            $wd = $wStmt->fetch();

            if (!$wd) {
                $pdo->rollBack();
                $error = "Withdrawal record not found.";
            } elseif ($wd['status'] !== 'pending') {
                $pdo->rollBack();
                $error = "This withdrawal request has already been " . $wd['status'] . ".";
            } else {
                $user_id = (int)$wd['user_id'];
                $amount = round((float)$wd['amount'], 2);

                if ($admin_action === 'approve') {
                    // Update status to approved using actual `withdrawals` columns
                    update_withdrawal_status($pdo, $withdrawal_id, 'approved', $notes, (int)$admin['id']);

                    // Complete transaction
                    $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE user_id = ? AND type = 'withdrawal' AND amount = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1")
                        ->execute([$user_id, $amount]);

                    // Notify user
                    create_notification(
                        $pdo,
                        $user_id,
                        "Withdrawal Disbursed",
                        "Your withdrawal of " . format_money($amount, $currency_symbol) . " (Net: " . format_money($wd['net_amount'], $currency_symbol) . ") has been approved and disbursed to {$wd['bank_name']}.",
                        "success"
                    );

                    record_audit_log($pdo, $admin['id'], $user_id, 'WITHDRAWAL_APPROVED', "Approved withdrawal #{$withdrawal_id} for {$amount}. Payout Notes: {$notes}");

                    $pdo->commit();
                    $success = "Withdrawal #{$withdrawal_id} approved and marked as disbursed.";

                } elseif ($admin_action === 'reject') {
                    // Refund user wallet balance using schema-aware lock & update
                    $lockedUser = lock_user_row($pdo, $user_id);
                    $current_bal = (float)($lockedUser['balance'] ?? 0.00);
                    $new_balance = round($current_bal + $amount, 2);

                    // Update user balance
                    update_user_balance($pdo, $user_id, $new_balance);

                    // Update withdrawal status
                    update_withdrawal_status($pdo, $withdrawal_id, 'rejected', $notes, (int)$admin['id']);

                    // Record refund transaction
                    $refTx = generate_reference('REFUND');
                    record_transaction(
                        $pdo,
                        $user_id,
                        'refund',
                        $amount,
                        $new_balance,
                        $refTx,
                        "Refund for rejected withdrawal request: " . ($notes ?: 'Treasury rejection'),
                        0.00,
                        'completed'
                    );

                    // Notify user
                    create_notification(
                        $pdo,
                        $user_id,
                        "Withdrawal Request Declined",
                        "Your withdrawal request for " . format_money($amount, $currency_symbol) . " was declined. The full amount has been refunded back to your wallet balance. Reason: " . ($notes ?: 'Bank verification issue'),
                        "warning"
                    );

                    record_audit_log($pdo, $admin['id'], $user_id, 'WITHDRAWAL_REJECTED', "Rejected withdrawal #{$withdrawal_id} for {$amount}. Refunded to wallet. Reason: {$notes}");

                    $pdo->commit();
                    $success = "Withdrawal #{$withdrawal_id} has been rejected and " . format_money($amount, $currency_symbol) . " has been refunded back to the user's wallet.";
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Action failed: " . $e->getMessage();
        }
    }
}

// Fetch withdrawals list with filtering (avoid selecting nonexistent `u.username`)
$status_filter = trim($_GET['status'] ?? 'all');
$sql = "
    SELECT w.*, u.full_name, u.email
    FROM withdrawals w
    LEFT JOIN users u ON w.user_id = u.id
";
$params = [];

if ($status_filter !== 'all' && !empty($status_filter)) {
    $sql .= " WHERE w.status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY w.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$withdrawals = $stmt->fetchAll();
?>

<div style="padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Withdrawal Payouts &amp; Queue
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Authorize bank transfers, record wire disbursement tracking, or decline invalid payout requests with automated balance refund.
      </p>
    </div>

    <!-- Filter Buttons -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="withdrawals.php?status=all" class="<?php echo $status_filter === 'all' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">All</a>
      <a href="withdrawals.php?status=pending" class="<?php echo $status_filter === 'pending' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Pending (<?php echo $pending_withdrawals_count; ?>)</a>
      <a href="withdrawals.php?status=approved" class="<?php echo $status_filter === 'approved' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Approved</a>
      <a href="withdrawals.php?status=rejected" class="<?php echo $status_filter === 'rejected' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 7px 16px; font-size: 0.82rem;">Rejected</a>
    </div>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <!-- Withdrawals Table -->
  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>ID / Date</th>
          <th>Investor</th>
          <th>Gross Amount</th>
          <th>Fee</th>
          <th>Net Payout</th>
          <th>Destination Bank Details</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($withdrawals)): ?>
          <tr>
            <td colspan="8" style="text-align: center; color: #8E9E94; padding: 32px;">
              No withdrawal records found.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($withdrawals as $w): ?>
            <tr>
              <td>
                <strong style="color: #FFF;">#<?php echo (int)$w['id']; ?></strong><br>
                <span class="tabular-nums" style="font-size: 0.75rem; color: #8E9E94;">
                  <?php echo date('M d, Y H:i', strtotime($w['created_at'])); ?>
                </span>
              </td>
              <td>
                <strong style="color: #FFF;"><?php echo escape($w['full_name'] ?: ('Investor #' . $w['user_id'])); ?></strong><br>
                <span style="font-size: 0.78rem; color: #D4AF37;"><?php echo escape($w['email'] ?? ''); ?></span>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #FFF;">
                <?php echo format_money($w['amount'], $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="color: #94A3B8; font-size: 0.82rem;">
                <?php echo format_money($w['fee'], $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: #34D399; font-size: 1.05rem;">
                <?php echo format_money($w['net_amount'], $currency_symbol); ?>
              </td>
              <td style="font-size: 0.85rem;">
                <strong style="color: #D4AF37;"><?php echo escape($w['bank_name']); ?></strong><br>
                <span>Acc: <strong class="tabular-nums" style="color: #FFF;"><?php echo escape($w['account_number']); ?></strong></span><br>
                <span style="color: #8E9E94; font-size: 0.78rem;">Name: <?php echo escape($w['account_name']); ?></span>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo escape($w['status']); ?>">
                  <?php echo escape($w['status']); ?>
                </span>
                <?php if (!empty($w['admin_notes'])): ?>
                  <div style="font-size: 0.72rem; color: #94A3B8; margin-top: 3px;"><?php echo escape($w['admin_notes']); ?></div>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($w['status'] === 'pending'): ?>
                  <div style="display: flex; gap: 6px;">
                    <button type="button" onclick="openApproveWdModal(<?php echo (int)$w['id']; ?>, '<?php echo format_money($w['net_amount'], $currency_symbol); ?>')" class="btn-gold" style="padding: 5px 12px; font-size: 0.75rem;">
                      Disburse
                    </button>
                    <button type="button" onclick="openRejectWdModal(<?php echo (int)$w['id']; ?>, '<?php echo format_money($w['amount'], $currency_symbol); ?>')" class="btn-outline-gold" style="padding: 5px 10px; font-size: 0.75rem; border-color: #EF4444; color: #F87171;">
                      Decline
                    </button>
                  </div>
                <?php else: ?>
                  <span style="font-size: 0.78rem; color: #8E9E94;">Closed</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Approve Withdrawal -->
<div id="approveWdModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 480px; width: 100%; padding: 28px;">
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 8px;">Confirm Wire Disbursement</h3>
    <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
      Confirming payout of <strong id="approveNetDisplay" style="color: #34D399;"></strong> to the recipient's bank.
    </p>

    <form method="POST" action="withdrawals.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="approve">
      <input type="hidden" name="withdrawal_id" id="approveWdId" value="">

      <div class="form-group">
        <label class="form-label">Payment Tracking / Wire Reference</label>
        <input type="text" name="admin_notes" class="form-control" required placeholder="e.g. Wire Trace #8392104 or NIP Settle #291">
      </div>

      <div style="display: flex; gap: 10px; justify-content: flex-end;">
        <button type="button" onclick="closeModal('approveWdModal')" class="btn-outline-gold" style="padding: 8px 16px;">Cancel</button>
        <button type="submit" class="btn-gold" style="padding: 8px 18px;">Confirm Disbursement</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Reject Withdrawal -->
<div id="rejectWdModal" class="gm-modal-overlay" style="display: none;">
  <div class="gm-card" style="max-width: 480px; width: 100%; padding: 28px;">
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 8px;">Decline Withdrawal</h3>
    <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 16px;">
      The amount of <strong id="rejectAmountDisplay" style="color: #F87171;"></strong> will be automatically credited back to the user's wallet.
    </p>

    <form method="POST" action="withdrawals.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="withdrawal_id" id="rejectWdId" value="">

      <div class="form-group">
        <label class="form-label">Decline Justification</label>
        <textarea name="admin_notes" class="form-control" rows="3" required placeholder="e.g. Account number / name mismatch with verified investor identity"></textarea>
      </div>

      <div style="display: flex; gap: 10px; justify-content: flex-end;">
        <button type="button" onclick="closeModal('rejectWdModal')" class="btn-outline-gold" style="padding: 8px 16px;">Cancel</button>
        <button type="submit" class="btn-gold" style="background: #DC2626; color: #FFF; padding: 8px 18px;">Confirm Decline &amp; Refund</button>
      </div>
    </form>
  </div>
</div>

<script>
function openApproveWdModal(id, netStr) {
  document.getElementById('approveWdId').value = id;
  document.getElementById('approveNetDisplay').innerText = netStr;
  openModal('approveWdModal');
}
function openRejectWdModal(id, amtStr) {
  document.getElementById('rejectWdId').value = id;
  document.getElementById('rejectAmountDisplay').innerText = amtStr;
  openModal('rejectWdModal');
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
