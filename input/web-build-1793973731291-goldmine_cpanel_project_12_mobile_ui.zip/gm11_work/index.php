<?php
/**
 * Public Landing Page, Profit Calculator & Six Official Plans Showcase
 * GoldMine Investment Platform
 */
$page_title = "Digital Gold & Structured Investment Platform";
require_once __DIR__ . '/includes/header.php';

// Fetch the 6 official active investment plans with normalized keys (`payout_interval`, `capital_returned`, `projected_profit`, `projected_total`)
$plans = ensure_six_investment_plans($pdo, false);
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$target_projection_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
if ($target_projection_rate <= 0) {
    $target_projection_rate = 45.00;
}
?>

<!-- 1. Hero Banner Section -->
<section style="padding: 40px 0 60px; display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 40px; align-items: center;" class="hero-grid">
  <div>
    <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(212, 175, 55, 0.1); border: 1px solid rgba(212, 175, 55, 0.3); padding: 6px 14px; border-radius: 99px; font-size: 0.78rem; color: #D4AF37; margin-bottom: 20px;">
      <span>●</span>
      <span style="letter-spacing: 0.08em; text-transform: uppercase; font-weight: 600;">Structured Digital Gold Allocation</span>
    </div>

    <h1 class="font-gold-serif" style="font-size: 3rem; line-height: 1.12; margin-bottom: 20px; color: #FFF;">
      Precision <span class="text-gold-gradient">Gold Investment</span> Tiers &amp; Portfolio Management
    </h1>

    <p style="font-size: 1.05rem; color: #9FB1A6; margin-bottom: 32px; max-width: 580px; line-height: 1.7;">
      Select from six structured GoldMine investment plans starting at <?php echo escape($currency_symbol); ?>1,000. Fund your wallet via verified bank transfer or online gateway, activate your chosen tier, and track your portfolio maturity in real time.
    </p>

    <div style="display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 40px;">
      <?php if ($user): ?>
        <a href="dashboard.php" class="btn-gold" style="padding: 14px 32px; font-size: 1rem;">
          Enter Investor Dashboard &rarr;
        </a>
        <a href="invest.php" class="btn-outline-gold" style="padding: 14px 28px; font-size: 1rem;">
          View 6 Investment Plans
        </a>
      <?php else: ?>
        <a href="register.php" class="btn-gold" style="padding: 14px 32px; font-size: 1rem;">
          Start Investing Today &rarr;
        </a>
        <a href="login.php" class="btn-outline-gold" style="padding: 14px 28px; font-size: 1rem;">
          Investor Login
        </a>
      <?php endif; ?>
    </div>

    <!-- Verifiable Platform Highlights -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding-top: 28px; border-top: 1px solid rgba(27, 56, 40, 0.7);">
      <div>
        <div class="font-gold-serif text-gold-gradient tabular-nums" style="font-size: 1.55rem; font-weight: 800;">6 Tiers</div>
        <div style="font-size: 0.8rem; color: #7D8F84;">Starter (<?php echo escape($currency_symbol); ?>1K) to VIP (<?php echo escape($currency_symbol); ?>1M)</div>
      </div>
      <div>
        <div class="font-gold-serif text-gold-gradient tabular-nums" style="font-size: 1.55rem; font-weight: 800;"><?php echo number_format($target_projection_rate, 0); ?>% Est.</div>
        <div style="font-size: 0.8rem; color: #7D8F84;">Target Projection Rate</div>
      </div>
      <div>
        <div class="font-gold-serif text-gold-gradient tabular-nums" style="font-size: 1.55rem; font-weight: 800;">24/7 Ledger</div>
        <div style="font-size: 0.8rem; color: #7D8F84;">Real-Time Maturity Tracking</div>
      </div>
    </div>
  </div>

  <!-- Interactive Profit Calculator Card -->
  <div id="calculator" class="gm-card" style="padding: 32px; border-color: rgba(212, 175, 55, 0.45); background: linear-gradient(160deg, #0D1E15 0%, #07110C 100%);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h3 class="font-gold-serif text-gold-gradient" style="font-size: 1.35rem;">Projected Return Calculator</h3>
      <span class="badge-clean badge-active"><?php echo number_format($target_projection_rate, 0); ?>% Target Rate</span>
    </div>

    <div class="form-group">
      <label class="form-label">Select Official Investment Plan</label>
      <select id="calc_plan" class="form-control" onchange="updateCalculator()">
        <?php foreach ($plans as $idx => $plan): 
          $p_interval = $plan['payout_interval'] ?? 'end_of_term';
          $p_cap_ret = !empty($plan['capital_returned']) ? 1 : 0;
        ?>
          <option 
            value="<?php echo (int)$plan['id']; ?>"
            data-min="<?php echo (float)$plan['min_amount']; ?>"
            data-max="<?php echo (float)$plan['max_amount']; ?>"
            data-roi="<?php echo (float)$plan['roi_percentage']; ?>"
            data-days="<?php echo (int)$plan['duration_days']; ?>"
            data-interval="<?php echo escape($p_interval); ?>"
            data-cap="<?php echo (int)$p_cap_ret; ?>"
            <?php echo $idx === 0 ? 'selected' : ''; ?>
          >
            <?php echo escape($plan['name']); ?> — <?php echo $currency_symbol . number_format((float)$plan['min_amount'], 0); ?> (<?php echo (float)$plan['roi_percentage']; ?>% in <?php echo (int)$plan['duration_days']; ?> Days)
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-group">
      <label class="form-label">Plan Investment Amount (<?php echo escape($currency_symbol); ?>)</label>
      <input type="number" id="calc_amount" class="form-control tabular-nums" value="<?php echo isset($plans[0]) ? (float)$plans[0]['min_amount'] : 1000; ?>" min="1000" step="1000" readonly style="opacity: 0.9; font-weight: 700; color: #F5C518;">
    </div>

    <div style="background: #050C08; border: 1px solid #1B3828; border-radius: 10px; padding: 20px; margin-top: 20px;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 0.9rem;">
        <span style="color: #8E9E94;">Term Duration:</span>
        <strong id="res_duration" class="tabular-nums" style="color: #FFF;">-</strong>
      </div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 0.9rem;">
        <span style="color: #8E9E94;">Projected Profit (<?php echo number_format($target_projection_rate, 0); ?>%):</span>
        <strong id="res_profit" class="tabular-nums" style="color: #34D399;">-</strong>
      </div>
      <div style="display: flex; justify-content: space-between; padding-top: 12px; border-top: 1px solid #162E21; font-size: 1.05rem;">
        <span style="color: #D4AF37; font-weight: 600;">Projected Total at Maturity:</span>
        <strong id="res_total" class="tabular-nums text-gold-gradient" style="font-size: 1.25rem;">-</strong>
      </div>
    </div>

    <p style="font-size: 0.74rem; color: #8E9E94; margin-top: 12px; line-height: 1.4;">
      * Projected returns are estimates and depend on plan terms and actual platform performance.
    </p>

    <div style="margin-top: 18px;">
      <a href="<?php echo $user ? 'invest.php' : 'register.php'; ?>" class="btn-gold" style="width: 100%; padding: 13px;">
        Allocate Capital to This Plan
      </a>
    </div>
  </div>
</section>

<!-- 2. Six Official Investment Plans Section -->
<section id="plans" style="padding: 50px 0;">
  <div style="text-align: center; max-width: 680px; margin: 0 auto 44px;">
    <span style="color: #D4AF37; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.14em; font-weight: 700;">Six Official Investment Tiers</span>
    <h2 class="font-gold-serif" style="font-size: 2.2rem; color: #FFF; margin-top: 8px; margin-bottom: 12px;">
      GoldMine Investment Plans
    </h2>
    <p style="color: #8E9E94; font-size: 0.95rem;">
      Choose one of our six fixed-tier investment plans below. Each tier calculates projected profit at the configured <?php echo number_format($target_projection_rate, 0); ?>% target projection rate.
    </p>
  </div>

  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(290px, 1fr)); gap: 24px;">
    <?php foreach ($plans as $plan): 
      $amt = (float)($plan['min_amount'] ?? 0);
      $rate = (float)($plan['roi_percentage'] ?? $target_projection_rate);
      $cap_returned = !empty($plan['capital_returned']) ? 1 : 0;
      $payout_interval = $plan['payout_interval'] ?? 'end_of_term';
      $calc = calculate_projected_returns($amt, $rate, $cap_returned);
    ?>
      <div class="gm-card" style="display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden;">
        <div>
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px;">
            <div>
              <h3 class="font-gold-serif" style="font-size: 1.35rem; color: #FFF;"><?php echo escape($plan['name']); ?> Plan</h3>
              <p style="font-size: 0.8rem; color: #8E9E94;"><?php echo escape($plan['tagline'] ?? 'Structured Gold Allocation'); ?></p>
            </div>
            <span class="badge-clean badge-completed"><?php echo (int)$plan['duration_days']; ?> Days</span>
          </div>

          <div style="background: rgba(212, 175, 55, 0.07); border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 8px; padding: 16px; margin-bottom: 20px; text-align: center;">
            <div style="font-size: 0.72rem; color: #9FB1A6; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 4px;">
              Investment Amount
            </div>
            <div class="font-gold-serif text-gold-gradient tabular-nums" style="font-size: 2rem; font-weight: 800; line-height: 1.1;">
              <?php echo $currency_symbol . number_format($amt, 0); ?>
            </div>
          </div>

          <ul style="list-style: none; display: flex; flex-direction: column; gap: 10px; font-size: 0.88rem; margin-bottom: 24px;">
            <li style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid rgba(27,56,40,0.5);">
              <span style="color: #8E9E94;">Target Projection Rate:</span>
              <strong class="tabular-nums" style="color: #D4AF37;"><?php echo number_format($rate, 0); ?>%</strong>
            </li>
            <li style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid rgba(27,56,40,0.5);">
              <span style="color: #8E9E94;">Projected Profit:</span>
              <strong class="tabular-nums" style="color: #34D399;">+<?php echo $currency_symbol . number_format($calc['projected_profit'], 0); ?></strong>
            </li>
            <li style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid rgba(27,56,40,0.5);">
              <span style="color: #8E9E94;">Projected Total:</span>
              <strong class="tabular-nums" style="color: #FFF;"><?php echo $currency_symbol . number_format($calc['projected_total'], 0); ?></strong>
            </li>
            <li style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid rgba(27,56,40,0.5);">
              <span style="color: #8E9E94;">Settlement Schedule:</span>
              <strong style="color: #FFF; text-transform: capitalize;"><?php echo str_replace('_', ' ', escape($payout_interval)); ?></strong>
            </li>
            <li style="display: flex; justify-content: space-between;">
              <span style="color: #8E9E94;">Principal Capital:</span>
              <strong style="color: #34D399;"><?php echo $cap_returned ? 'Included at Maturity' : 'Included in ROI'; ?></strong>
            </li>
          </ul>
        </div>

        <a href="<?php echo $user ? 'invest.php?plan_id=' . (int)$plan['id'] : 'register.php'; ?>" class="btn-gold" style="width: 100%;">
          Invest <?php echo $currency_symbol . number_format($amt, 0); ?> Now
        </a>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- 3. Security & Architecture Section -->
<section id="security" style="padding: 50px 0 20px;">
  <div class="gm-card" style="padding: 40px; background: linear-gradient(135deg, #0A1710 0%, #050C08 100%);">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 32px;">
      <div>
        <div style="color: #D4AF37; font-weight: 700; font-size: 1.1rem; margin-bottom: 8px;" class="font-gold-serif">
          01. Verified Deposit Channels
        </div>
        <p style="color: #8E9E94; font-size: 0.88rem; line-height: 1.6;">
          Fund your investment wallet via direct bank transfer with receipt upload verification or server-verified Flutterwave online payment.
        </p>
      </div>
      <div>
        <div style="color: #D4AF37; font-weight: 700; font-size: 1.1rem; margin-bottom: 8px;" class="font-gold-serif">
          02. Real-Time Portfolio Ledger
        </div>
        <p style="color: #8E9E94; font-size: 0.88rem; line-height: 1.6;">
          Every deposit, plan activation, P2P transfer, and withdrawal request is logged with a unique reference in your immutable transaction history.
        </p>
      </div>
      <div>
        <div style="color: #D4AF37; font-weight: 700; font-size: 1.1rem; margin-bottom: 8px;" class="font-gold-serif">
          03. Transparent Accounting
        </div>
        <p style="color: #8E9E94; font-size: 0.88rem; line-height: 1.6;">
          Projected returns are clearly separated from actual earned profits until maturity settlement is verified by platform treasury.
        </p>
      </div>
    </div>
  </div>
</section>

<style>
  @media (max-width: 900px) {
    .hero-grid { grid-template-columns: 1fr !important; }
  }
</style>

<script>
const CURRENCY_SYM = <?php echo json_encode($currency_symbol); ?>;

function formatCurrency(num) {
  return CURRENCY_SYM + parseFloat(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function updateCalculator() {
  const select = document.getElementById('calc_plan');
  const amountInput = document.getElementById('calc_amount');
  if (!select || !select.options.length) return;

  const opt = select.options[select.selectedIndex];
  const min = parseFloat(opt.getAttribute('data-min')) || 1000;
  const roi = parseFloat(opt.getAttribute('data-roi')) || 45;
  const days = parseInt(opt.getAttribute('data-days')) || 7;
  const capReturned = parseInt(opt.getAttribute('data-cap')) === 1;

  amountInput.value = min;

  const profit = (min * roi) / 100;
  const totalReturn = capReturned ? (min + profit) : profit;

  document.getElementById('res_duration').innerText = days + ' Days';
  document.getElementById('res_profit').innerText = '+' + formatCurrency(profit) + ' (' + roi + '% Est.)';
  document.getElementById('res_total').innerText = formatCurrency(totalReturn);
}

document.addEventListener('DOMContentLoaded', updateCalculator);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
