<?php
/**
 * Transactions Ledger & History
 * GoldMine Investment Platform
 */
$page_title = "Financial Transaction Ledger";
require_once __DIR__ . '/includes/header.php';
require_user_login();

$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '$');

// Filter parameters
$filter_type = trim($_GET['type'] ?? 'all');
$filter_status = trim($_GET['status'] ?? 'all');

$sql = "SELECT * FROM transactions WHERE user_id = ?";
$params = [$user_id];

if ($filter_type !== 'all' && !empty($filter_type)) {
    $sql .= " AND type = ?";
    $params[] = $filter_type;
}

if ($filter_status !== 'all' && !empty($filter_status)) {
    $sql .= " AND status = ?";
    $params[] = $filter_status;
}

$sql .= " ORDER BY created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$transactions = array_map('normalize_transaction_row', $stmt->fetchAll(PDO::FETCH_ASSOC));
?>

<div style="max-width: 1200px; margin: 0 auto; padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Financial Activity Ledger
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Complete immutable record of all deposits, capital allocations, yield returns, and disbursements.
      </p>
    </div>

    <button onclick="window.print()" class="btn-outline-gold" style="padding: 8px 16px; font-size: 0.85rem;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
      Print / Export Statement
    </button>
  </div>

  <!-- Filter Bar -->
  <div class="gm-card" style="padding: 16px 20px; margin-bottom: 24px;">
    <form method="GET" action="transactions.php" style="display: flex; flex-wrap: wrap; gap: 14px; align-items: center;">
      <div style="display: flex; align-items: center; gap: 8px;">
        <label style="font-size: 0.82rem; color: #8E9E94;">Type:</label>
        <select name="type" class="form-control" style="width: auto; padding: 7px 12px; font-size: 0.85rem;">
          <option value="all" <?php echo $filter_type === 'all' ? 'selected' : ''; ?>>All Activity</option>
          <option value="deposit" <?php echo $filter_type === 'deposit' ? 'selected' : ''; ?>>Deposits</option>
          <option value="investment" <?php echo $filter_type === 'investment' ? 'selected' : ''; ?>>Investments</option>
          <option value="roi_profit" <?php echo $filter_type === 'roi_profit' ? 'selected' : ''; ?>>ROI Yields</option>
          <option value="withdrawal" <?php echo $filter_type === 'withdrawal' ? 'selected' : ''; ?>>Withdrawals</option>
          <option value="referral_bonus" <?php echo $filter_type === 'referral_bonus' ? 'selected' : ''; ?>>Affiliate Bonuses</option>
        </select>
      </div>

      <div style="display: flex; align-items: center; gap: 8px;">
        <label style="font-size: 0.82rem; color: #8E9E94;">Status:</label>
        <select name="status" class="form-control" style="width: auto; padding: 7px 12px; font-size: 0.85rem;">
          <option value="all" <?php echo $filter_status === 'all' ? 'selected' : ''; ?>>All Statuses</option>
          <option value="completed" <?php echo $filter_status === 'completed' ? 'selected' : ''; ?>>Completed</option>
          <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
          <option value="failed" <?php echo $filter_status === 'failed' ? 'selected' : ''; ?>>Failed</option>
        </select>
      </div>

      <button type="submit" class="btn-gold" style="padding: 7px 18px; font-size: 0.85rem;">
        Filter
      </button>

      <?php if ($filter_type !== 'all' || $filter_status !== 'all'): ?>
        <a href="transactions.php" class="btn-outline-gold" style="padding: 6px 14px; font-size: 0.82rem;">
          Reset Filters
        </a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Ledger Table -->
  <div class="gm-table-container">
    <table class="gm-table">
      <thead>
        <tr>
          <th>Date & Time</th>
          <th>Type</th>
          <th>Reference</th>
          <th>Description</th>
          <th>Amount</th>
          <th>Fee</th>
          <th>Balance After</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($transactions)): ?>
          <tr>
            <td colspan="8" style="text-align: center; color: #8E9E94; padding: 32px;">
              No matching records found for the selected criteria.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($transactions as $tx): 
            $is_credit = in_array($tx['type'], ['deposit', 'roi_profit', 'referral_bonus', 'refund']);
          ?>
            <tr>
              <td class="tabular-nums" style="font-size: 0.82rem; color: #94A3B8;">
                <?php echo date('M d, Y H:i:s', strtotime($tx['created_at'])); ?>
              </td>
              <td style="text-transform: capitalize; font-weight: 600; color: #FFF;">
                <?php echo str_replace('_', ' ', escape($tx['type'])); ?>
              </td>
              <td class="tabular-nums" style="font-size: 0.8rem; color: #D4AF37;">
                <?php echo escape($tx['reference_code']); ?>
              </td>
              <td style="font-size: 0.85rem; color: #C2D1C7;">
                <?php echo escape($tx['description']); ?>
              </td>
              <td class="tabular-nums" style="font-weight: 700; color: <?php echo $is_credit ? '#34D399' : '#F87171'; ?>;">
                <?php echo ($is_credit ? '+' : '-') . format_money($tx['amount'], $currency_symbol); ?>
              </td>
              <td class="tabular-nums" style="color: #8E9E94; font-size: 0.82rem;">
                <?php echo (float)$tx['fee'] > 0 ? format_money($tx['fee'], $currency_symbol) : '-'; ?>
              </td>
              <td class="tabular-nums" style="font-weight: 600; color: #FFF;">
                <?php echo format_money($tx['balance_after'], $currency_symbol); ?>
              </td>
              <td>
                <span class="badge-clean badge-<?php echo escape($tx['status']); ?>">
                  <?php echo escape($tx['status']); ?>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
