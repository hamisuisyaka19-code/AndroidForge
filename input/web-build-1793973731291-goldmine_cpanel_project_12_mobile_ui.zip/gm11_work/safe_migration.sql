-- =====================================================================
-- GOLDMINE INVESTMENT PLATFORM - SAFE ADDITIVE MIGRATION SCRIPT
-- Target Database: lhzmylpw_goldmine
-- Target Platform: cPanel phpMyAdmin / MySQL 8.0+ / MariaDB
-- 
-- SAFETY CERTIFICATION:
-- 1. This script NEVER executes DROP TABLE, TRUNCATE, DELETE, or RESET.
-- 2. It preserves all existing tables and records in `lhzmylpw_goldmine`:
--    - users (id, full_name, email, phone, password_hash, balance, total_invested, total_profit, status, email_verified, verification_token, remember_token, created_at, updated_at)
--    - admins
--    - deposits (id, reference_code, user_id, amount, payment_method, gateway_ref, receipt_path, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at)
--    - investments (id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at)
--    - investment_plans
--    - transactions (id, reference_code, user_id, type, amount, fee, balance_after, status, description, created_at)
--    - withdrawals
--    - settings (key_name, value, updated_at)
--    - notifications
--    - audit_logs
--    - user_bank_details
--    - password_resets
-- 3. It safely creates `api_tokens` and `support_tickets` if not present,
--    and seeds default settings in `settings` (`key_name`, `value`, `updated_at`).
-- =====================================================================

-- 1. API TOKENS TABLE
-- Required for Bearer token authentication across AndroidForce and REST API v1
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `admin_id` INT UNSIGNED DEFAULT NULL,
  `token` VARCHAR(128) NOT NULL UNIQUE,
  `device_name` VARCHAR(100) DEFAULT 'Android Client',
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_api_token` (`token`),
  INDEX `idx_api_user` (`user_id`),
  INDEX `idx_api_admin` (`admin_id`),
  INDEX `idx_api_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. SUPPORT TICKETS TABLE
-- Required for Customer Support Desk, ticket messaging, and Admin Helpdesk
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `ticket_code` VARCHAR(30) DEFAULT NULL,
  `subject` VARCHAR(200) NOT NULL,
  `priority` ENUM('low', 'normal', 'high', 'urgent') NOT NULL DEFAULT 'normal',
  `message` TEXT NOT NULL,
  `status` ENUM('open', 'answered', 'closed') NOT NULL DEFAULT 'open',
  `admin_reply` TEXT DEFAULT NULL,
  `replied_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_support_user` (`user_id`),
  INDEX `idx_support_status` (`status`),
  INDEX `idx_support_code` (`ticket_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. CONFIGURABLE TARGET PROJECTION RATE SETTING (45%) & CURRENCY
-- Matches the actual `settings` schema: (`key_name`, `value`, `updated_at`)
INSERT IGNORE INTO `settings` (`key_name`, `value`, `updated_at`) VALUES
('site_name', 'GoldMine Investment Platform', NOW()),
('site_currency', 'NGN', NOW()),
('currency_symbol', '₦', NOW()),
('target_projection_rate', '45.00', NOW()),
('referral_bonus_percent', '10.00', NOW()),
('flutterwave_secret_hash', '', NOW());
