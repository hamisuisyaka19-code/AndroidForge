<?php
/**
 * Reset Password Handler
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Set New Password";

$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$error = '';
$reset = null;

// Validate token
if (empty($token)) {
    $error = "Missing password recovery token.";
} else {
    $pr_cols = get_table_columns($pdo, 'password_resets');
    $where_used = isset($pr_cols['used']) ? "AND `used` = 0" : "";
    $where_exp = isset($pr_cols['expires_at']) ? "AND `expires_at` > NOW()" : "";
    $stmt = $pdo->prepare("SELECT * FROM `password_resets` WHERE `token` = ? {$where_used} {$where_exp} LIMIT 1");
    $stmt->execute([$token]);
    $reset = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$reset) {
        $error = "This password reset token is invalid or has expired. Please request a new link.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error) && $reset) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (strlen($password) < 6) {
            $error = "Password must be at least 6 characters.";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Update user password compatible with `password_hash` and `password`
            if (!empty($reset['email'])) {
                update_user_password_by_email($pdo, $reset['email'], $hashed);
            } elseif (!empty($reset['user_id'])) {
                update_user_password_by_id($pdo, (int)$reset['user_id'], $hashed);
            }

            // Mark token as used or remove consumed token
            if (has_column($pdo, 'password_resets', 'used')) {
                $pdo->prepare("UPDATE `password_resets` SET `used` = 1 WHERE `id` = ?")->execute([$reset['id']]);
            } elseif (isset($reset['id'])) {
                $pdo->prepare("DELETE FROM `password_resets` WHERE `id` = ?")->execute([$reset['id']]);
            }

            // Record audit
            record_audit_log($pdo, null, null, 'PASSWORD_RESET_COMPLETED', "Password reset for {$reset['email']}");

            $_SESSION['flash_success'] = "Your password has been successfully updated. You may now sign in.";
            header("Location: login.php");
            exit;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 440px; margin: 50px auto;">
  <div class="gm-card">
    <div style="text-align: center; margin-bottom: 24px;">
      <h2 class="font-gold-serif text-gold-gradient" style="font-size: 1.8rem; margin-bottom: 6px;">
        Create New Password
      </h2>
      <p style="color: #8E9E94; font-size: 0.88rem;">
        Choose a strong and secure password for your account.
      </p>
    </div>

    <?php if (!empty($error)): ?>
      <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
        <?php echo escape($error); ?>
      </div>
      <div style="text-align: center;">
        <a href="forgot-password.php" class="btn-outline-gold">Request New Reset Link</a>
      </div>
    <?php else: ?>
      <form method="POST" action="reset-password.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo escape($token); ?>">

        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="password" class="form-control" required placeholder="••••••••">
        </div>

        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" required placeholder="••••••••">
        </div>

        <button type="submit" class="btn-gold" style="width: 100%; font-size: 1rem; padding: 12px;">
          Update Password
        </button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
