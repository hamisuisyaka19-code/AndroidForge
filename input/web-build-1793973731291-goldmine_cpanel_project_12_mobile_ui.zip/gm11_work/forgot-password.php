<?php
/**
 * Forgot Password Request
 * GoldMine Investment Platform
 */
$page_title = "Password Recovery";
require_once __DIR__ . '/includes/header.php';

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $err = "Token mismatch. Please try again.";
    } else {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = "Please enter a valid email address.";
        } else {
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Generate secure random reset token
                $token = bin2hex(random_bytes(32));
                $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

                $pr_cols = get_table_columns($pdo, 'password_resets');
                $ins_cols = [];
                $ins_vals = [];
                $ins_params = [];

                $candidates = [
                    'user_id'    => (int)$user['id'],
                    'email'      => $email,
                    'token'      => $token,
                    'expires_at' => $expires_at,
                    'used'       => 0,
                ];
                foreach ($candidates as $k => $v) {
                    if (isset($pr_cols[$k])) {
                        $ins_cols[] = "`{$pr_cols[$k]}`";
                        $ins_vals[] = "?";
                        $ins_params[] = $v;
                    }
                }
                if (isset($pr_cols['created_at'])) {
                    $ins_cols[] = "`created_at`";
                    $ins_vals[] = "NOW()";
                }
                if (!empty($ins_cols)) {
                    $insStmt = $pdo->prepare("INSERT INTO `password_resets` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")");
                    $insStmt->execute($ins_params);
                }

                // Create audit log
                record_audit_log($pdo, null, $user['id'], 'PASSWORD_RESET_REQUESTED', 'Password reset link generated');

                // In production with mail server configured, mail() or SMTP would be dispatched.
                // We provide the direct recovery link confirmation:
                $reset_url = "reset-password.php?token=" . urlencode($token);
                $msg = "Password reset instructions have been dispatched. For immediate recovery, you may <a href='{$reset_url}' style='color: #D4AF37; text-decoration: underline;'>Click Here to Set New Password</a>.";
            } else {
                // Generic response to prevent email enumeration
                $msg = "If your email is registered in our records, you will receive password recovery instructions shortly.";
            }
        }
    }
}
?>

<div style="max-width: 440px; margin: 50px auto;">
  <div class="gm-card">
    <div style="text-align: center; margin-bottom: 24px;">
      <h2 class="font-gold-serif text-gold-gradient" style="font-size: 1.8rem; margin-bottom: 6px;">
        Reset Password
      </h2>
      <p style="color: #8E9E94; font-size: 0.88rem;">
        Enter your registered email address to receive recovery instructions.
      </p>
    </div>

    <?php if (!empty($err)): ?>
      <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
        <?php echo escape($err); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($msg)): ?>
      <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem; line-height: 1.5;">
        <?php echo $msg; ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="forgot-password.php">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" required placeholder="you@domain.com">
      </div>

      <button type="submit" class="btn-gold" style="width: 100%; font-size: 1rem; padding: 12px;">
        Send Recovery Link
      </button>
    </form>

    <div style="text-align: center; margin-top: 24px; font-size: 0.88rem; color: #8E9E94;">
      Remembered credentials? <a href="login.php" style="color: #D4AF37; font-weight: 600;">Back to Login</a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
