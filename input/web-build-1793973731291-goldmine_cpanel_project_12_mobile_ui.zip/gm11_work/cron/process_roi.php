<?php
/**
 * Automated Cron Job: Investment Maturity Synchronization & Verified Settlement
 * GoldMine Investment Platform
 * 
 * Recommended cPanel Cron Command (Runs via CLI):
 * 0 0 * * * /usr/local/bin/php /home/lhzmylpw/public_html/cron/process_roi.php > /dev/null 2>&1
 * 
 * Authoritative Schema Compatibility:
 * - `investments`: id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage,
 *   expected_return, duration_days, start_date, maturity_date, status, admin_action_by,
 *   admin_action_at, admin_notes, created_at, updated_at
 * - `transactions`: id, reference_code, user_id, type, amount, fee, balance_after, status, description, created_at
 * - `users`: id, full_name, email, phone, password_hash, balance, total_invested, total_profit, ...
 */

$is_cli = (php_sapi_name() === 'cli');

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/functions.php';

// 1. Enforce HTTP Cron Authentication
if (!$is_cli) {
    $configured_secret = defined('CRON_SECRET') ? trim(CRON_SECRET) : '';
    $provided_key = trim($_GET['key'] ?? '');

    if (empty($configured_secret) || empty($provided_key) || !hash_equals($configured_secret, $provided_key)) {
        http_response_code(403);
        die("Access denied. Direct CLI execution or valid CRON_SECRET key required.");
    }
}

$now_dt = new DateTime();
$settlement_enabled = defined('CRON_SETTLEMENT_ENABLED') && CRON_SETTLEMENT_ENABLED === true;
$verified_distributable_rate = (float)get_setting($pdo, 'verified_distributable_rate', '0.00');

echo "[" . $now_dt->format('Y-m-d H:i:s') . "] Starting GoldMine Investment Maturity & Accounting Sync...\n";
echo " - Automated Wallet Payouts (CRON_SETTLEMENT_ENABLED): " . ($settlement_enabled ? "ENABLED" : "DISABLED (Status & Audit Sync Only)") . "\n";

$matured_synced = 0;
$settled_count = 0;
$skipped_count = 0;
$errors_count = 0;

try {
    // Fetch all active investments joined safely with their plan specifications
    $stmt = $pdo->query("
        SELECT i.*,
               COALESCE(NULLIF(i.plan_name, ''), p.name) AS resolved_plan_name,
               COALESCE(NULLIF(i.roi_percentage, 0), p.roi_percentage) AS resolved_roi_percentage,
               COALESCE(NULLIF(i.duration_days, 0), p.duration_days) AS resolved_duration_days
        FROM investments i
        LEFT JOIN investment_plans p ON i.plan_id = p.id
        WHERE i.status = 'active'
        ORDER BY i.id ASC
    ");
    $investments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($investments as $rawInv) {
        $rawInv['plan_name'] = $rawInv['resolved_plan_name'] ?? $rawInv['plan_name'] ?? 'GoldMine';
        $rawInv['roi_percentage'] = $rawInv['resolved_roi_percentage'] ?? $rawInv['roi_percentage'] ?? 45.00;
        $rawInv['duration_days'] = $rawInv['resolved_duration_days'] ?? $rawInv['duration_days'] ?? 7;
        $inv = normalize_investment_row($rawInv);

        $inv_id = (int)$inv['id'];
        $user_id = (int)$inv['user_id'];
        $amount = (float)$inv['amount'];
        $projected_total = (float)$inv['expected_return'];
        $projected_profit = max(0.0, $projected_total - $amount);
        $plan_name = $inv['plan_name'];
        $ref_code = $inv['reference_code'];

        $maturity_dt = new DateTime($inv['maturity_date']);

        // Check if investment has reached its maturity_date
        if ($now_dt >= $maturity_dt) {
            try {
                $pdo->beginTransaction();

                // Lock investment record using actual `investments` columns
                $checkStmt = $pdo->prepare("SELECT id, status, maturity_date FROM investments WHERE id = ? FOR UPDATE");
                $checkStmt->execute([$inv_id]);
                $lockedInv = $checkStmt->fetch(PDO::FETCH_ASSOC);

                if (!$lockedInv || $lockedInv['status'] !== 'active') {
                    $pdo->rollBack();
                    $skipped_count++;
                    continue;
                }

                // Mark investment status as matured ('completed')
                $inv_cols = get_table_columns($pdo, 'investments');
                $sets = ["`status` = 'completed'"];
                if (isset($inv_cols['updated_at'])) {
                    $sets[] = "`updated_at` = NOW()";
                }
                $pdo->prepare("UPDATE `investments` SET " . implode(", ", $sets) . " WHERE `id` = ?")->execute([$inv_id]);

                // Optional Verified Settlement: ONLY if CRON_SETTLEMENT_ENABLED is true and verified earnings are approved
                if ($settlement_enabled && $verified_distributable_rate > 0) {
                    $refVerified = "ROI-VERIFIED-INV{$inv_id}";

                    if (!transaction_reference_exists($pdo, $refVerified, true)) {
                        $userRow = lock_user_row($pdo, $user_id);

                        if ($userRow) {
                            $verified_profit = round($amount * ($verified_distributable_rate / 100), 2);
                            $credit_total = round($amount + $verified_profit, 2);
                            $new_balance = round((float)$userRow['balance'] + $credit_total, 2);

                            update_user_balance($pdo, $user_id, $new_balance, 0.00, $verified_profit);

                            record_transaction(
                                $pdo,
                                $user_id,
                                'roi_profit',
                                $credit_total,
                                $new_balance,
                                $refVerified,
                                "Verified maturity settlement for {$plan_name} Plan ({$ref_code})",
                                0.00,
                                'completed'
                            );
                            $settled_count++;
                        }
                    }
                }

                // Create user notification & audit log for maturity milestone
                create_notification(
                    $pdo,
                    $user_id,
                    "Investment Reached Maturity ({$ref_code})",
                    "Your {$plan_name} Plan investment ({$ref_code}) has reached its maturity date and is queued for verified accounting settlement.",
                    "info"
                );

                record_audit_log(
                    $pdo,
                    null,
                    $user_id,
                    'INVESTMENT_MATURED_SYNC',
                    "Investment #{$inv_id} ({$ref_code} / {$plan_name}) reached maturity_date. Principal: {$amount}, Projected Profit: {$projected_profit} (Not auto-credited)."
                );

                $pdo->commit();
                $matured_synced++;
                echo " - Matured Investment #{$inv_id} ({$ref_code} - {$plan_name}) synchronized for User #{$user_id}\n";
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors_count++;
                error_log("Cron Maturity Error on Investment #{$inv_id}: " . $e->getMessage());
            }
        } else {
            $skipped_count++;
        }
    }

    echo "[" . date('Y-m-d H:i:s') . "] Sync complete. Matured Synced: {$matured_synced}, Verified Settlements: {$settled_count}, Active Remaining: {$skipped_count}, Errors: {$errors_count}\n";

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "CRON CRITICAL ERROR: " . $e->getMessage() . "\n";
    error_log("CRON CRITICAL ERROR: " . $e->getMessage());
}
