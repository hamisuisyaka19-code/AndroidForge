# GoldMine Investment Platform — cPanel Shared Hosting Deployment Guide

## 1. Overview & Directory Mapping
This package contains the complete, production-ready GoldMine Investment Platform built with **PHP 8+**, **MySQL PDO**, and secure sessions. It runs directly on shared cPanel hosting without requiring Node.js, terminal commands, or a VPS.

### Which files go into `public_html`?
Upload and extract the **contents** of this package directly into your cPanel root web folder:
- Primary domain: `/home/lhzmylpw/public_html/`
- Subdomain (if applicable): `/home/lhzmylpw/public_html/subdomain/`

```text
public_html/
├── .htaccess                      <- Security headers & clean URL rewriting
├── db.php                         <- Configured MySQL PDO database connection
├── schema.sql                     <- Safe, non-destructive migration script
├── index.php                      <- Luxury landing page with live plans & calculator
├── register.php                   <- Registration with auto-filled referral tracking
├── login.php                      <- Secure user login with CSRF & session hardening
├── logout.php                     <- Session termination
├── forgot-password.php            <- Password recovery
├── reset-password.php             <- Secure token-based password reset
├── dashboard.php                  <- Real-time investor metrics calculated from MySQL
├── deposit.php                    <- 3 Deposit channels: Bank wire receipt upload, Flutterwave, Card
├── invest.php                     <- Dynamic plans, countdown timers, risk disclosures
├── withdraw.php                   <- Bank payout requests with fee calculations
├── transactions.php               <- Searchable & exportable financial activity ledger
├── referrals.php                  <- Unique referral links, network tracking & commissions
├── profile.php                    <- Profile management, bank details, password change
├── notifications.php              <- In-app notification center
├── api/
│   └── verify_payment.php         <- Server-side Flutterwave/Card payment verification & idempotency
├── cron/
│   └── process_roi.php            <- Automated daily & term ROI accrual cron job
├── includes/
│   ├── auth.php                   <- Session checks and authentication guards
│   ├── csrf.php                   <- Cross-Site Request Forgery protection
│   ├── functions.php              <- Financial calculations, receipt validation, audit logging
│   ├── header.php                 <- Top bar luxury navigation
│   └── footer.php                 <- Mobile bottom bar, copyright, statutory risk disclosures
├── admin/
│   ├── index.php                  <- Master overview, liquidity metrics, pending queues
│   ├── login.php                  <- Dedicated admin login portal
│   ├── logout.php                 <- Admin session destroy
│   ├── header.php                 <- Admin layout and sidebar navigation
│   ├── footer.php                 <- Modal scripts and closing tags
│   ├── deposits.php               <- Receipt preview modal, approve/reject with instant wallet credit
│   ├── withdrawals.php            <- Approve wire disbursements or decline with automated balance refund
│   ├── users.php                  <- Search users, adjust balances with audit logs, suspend/activate
│   ├── plans.php                  <- Create/edit investment plans, yield %, durations, capital return
│   ├── investments.php            <- Active holdings monitor and maturity progress
│   ├── settings.php               <- Company bank details, Flutterwave keys, referral bonuses
│   ├── notifications.php          <- Dispatch broadcast notices or targeted messages
│   └── audit_logs.php             <- Complete compliance audit trail
└── uploads/
    └── receipts/
        └── .htaccess              <- Prevents script execution in uploads directory
```

---

## 2. Database Configuration (`db.php`)
Your database connection in `db.php` is pre-configured for your existing cPanel credentials:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'lhzmylpw_goldmine');
define('DB_USER', 'lhzmylpw_goldmineapp');
define('DB_PASS', 'YOUR_CPANEL_DB_PASSWORD_HERE'); // Enter your cPanel MySQL user password here
```

### Safe Deployment Guarantee (Zero Data Loss)
Your database `lhzmylpw_goldmine` already contains 12 tables:
`admins`, `audit_logs`, `deposits`, `investments`, `investment_plans`, `notifications`, `password_resets`, `settings`, `transactions`, `users`, `user_bank_details`, `withdrawals`.

- The provided `schema.sql` uses `CREATE TABLE IF NOT EXISTS` and `INSERT IGNORE`.
- It will **NEVER DROP, TRUNCATE, OR RESET** any table or record.
- If you import `schema.sql` via phpMyAdmin, all your pre-existing records, users, and transactions remain 100% intact.

---

## 3. Step-by-Step cPanel Deployment Instructions

1. **Log in to your cPanel account**.
2. **Open File Manager** and navigate into `public_html`.
3. Click **Upload** and upload `goldmine_cpanel_project.zip`.
4. Right-click `goldmine_cpanel_project.zip` and select **Extract**.
5. Edit `db.php` using the cPanel Code Editor to enter your MySQL password for user `lhzmylpw_goldmineapp`.
6. Ensure the directory permissions for `uploads/receipts/` are set to `0755`.
7. **Set up the ROI Cron Job**:
   - In cPanel, search for **Cron Jobs**.
   - Under *Add New Cron Job*, select **Once Per Day (0 0 * * *)**.
   - In the Command field, enter:
     ```bash
     /usr/local/bin/php /home/lhzmylpw/public_html/cron/process_roi.php > /dev/null 2>&1
     ```
   - Click **Add New Cron Job**.

---

## 4. Payment Gateway Setup
1. **Bank Transfer**: Go to Admin Console -> **System & Bank Settings**, enter your official bank name, account number, beneficiary, and routing/swift code.
2. **Flutterwave Gateway**:
   - Obtain your Public Key, Secret Key, and Encryption Key from your [Flutterwave Dashboard](https://dashboard.flutterwave.com).
   - Enter them in Admin Console -> **System & Bank Settings**.
   - In Flutterwave Dashboard, set your Webhook URL to:
     `https://yourdomain.com/api/verify_payment.php`

---

## 5. Security & Hardening Features
- **PDO Prepared Statements**: 100% parameter binding prevents SQL Injection across all user inputs.
- **CSRF Tokens**: Every POST form includes a session-validated token checked via `hash_equals()`.
- **XSS Prevention**: All database outputs pass through `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`.
- **Upload Hardening**: File types are verified via strict `finfo` MIME validation (JPEG, PNG, WEBP, PDF only). File names are randomly salted (`receipt_[time]_[random].[ext]`).
- **Uploads Directory `.htaccess`**: Script execution engines (`mod_php`) are disabled in `uploads/receipts/` to block executable payload exploits.
- **Idempotency & Double-Spending Prevention**: Database row locking (`SELECT ... FOR UPDATE`) and transaction rollbacks protect wallet credits and debits.

---

## 6. Troubleshooting
- **White screen or 500 error**: Ensure PHP 8.0, 8.1, or 8.2 is selected under cPanel **Select PHP Version**, and that `pdo_mysql` and `fileinfo` extensions are enabled.
- **Uploaded receipts not showing**: Verify that the folder `uploads/receipts/` exists and has `755` permissions.
- **Admin login issues**: If no admin exists in your database yet, visiting `/admin/login.php` will prompt you to initialize the master administrator account.
