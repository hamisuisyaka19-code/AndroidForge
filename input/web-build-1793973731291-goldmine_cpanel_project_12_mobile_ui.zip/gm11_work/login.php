<?php
/**
 * Investor Sign In
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`email`, `password_hash`, `balance`, `status`).
 * Processes authentication and HTTP redirects BEFORE outputting HTML to prevent blank black pages.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Sign In to Portfolio";

// Redirect if already logged in
if (is_user_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
if (isset($_GET['error']) && $_GET['error'] === 'account_suspended') {
    $error = "Your account has been suspended by platform compliance. Please contact support.";
}

$identifier = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $error = "Security token expired. Please refresh the page and try again.";
    } else {
        $identifier = trim($_POST['identifier'] ?? $_POST['email'] ?? $_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($identifier) || empty($password)) {
            $error = "Please enter your email address and password.";
        } else {
            try {
                // Uses dynamic schema check: queries `email` (and `username` only if column exists)
                $userRow = find_user_for_login($pdo, $identifier);
                $storedHash = $userRow['password_hash'] ?? '';

                if ($userRow && !empty($storedHash) && password_verify($password, $storedHash)) {
                    if (in_array($userRow['status'], ['suspended', 'banned', 'blocked'], true)) {
                        $error = "Your account has been suspended. Please contact customer support.";
                    } else {
                        // Regenerate session ID to prevent session fixation
                        session_regenerate_id(true);
                        $_SESSION['user_id'] = (int)$userRow['id'];
                        $_SESSION['username'] = $userRow['username'];
                        $_SESSION['full_name'] = $userRow['full_name'];
                        $_SESSION['email'] = $userRow['email'];

                        record_audit_log($pdo, null, (int)$userRow['id'], 'USER_LOGIN', 'User signed in successfully');

                        $redirect = $_SESSION['redirect_after_login'] ?? 'dashboard.php';
                        unset($_SESSION['redirect_after_login']);
                        // Ensure redirect target is safe local page
                        if (strpos($redirect, 'login.php') !== false || strpos($redirect, 'http') === 0) {
                            $redirect = 'dashboard.php';
                        }

                        header("Location: " . $redirect);
                        exit;
                    }
                } else {
                    $error = "Invalid email or password. Please verify your credentials.";
                    record_audit_log($pdo, null, null, 'USER_LOGIN_FAILED', "Failed login attempt for identifier: {$identifier}");
                }
            } catch (PDOException $e) {
                error_log("GoldMine Login Error: " . $e->getMessage());
                $error = "A temporary database error occurred during sign in. Please try again.";
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 440px; margin: 40px auto;">
  <div class="gm-card" style="padding: 36px 32px;">
    <div style="text-align: center; margin-bottom: 28px;">
      <div style="width: 48px; height: 48px; border-radius: 10px; background: linear-gradient(135deg, #D4AF37, #AA8010); display: inline-flex; align-items: center; justify-content: center; color: #040906; font-weight: 800; font-family: 'Cinzel', serif; font-size: 1.5rem; margin-bottom: 12px;">
        G
      </div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.75rem; margin-bottom: 6px;">
        Welcome Back
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Sign in to manage your digital gold investments &amp; yields
      </p>
    </div>

    <?php if (!empty($error)): ?>
      <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
        <?php echo escape($error); ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="login.php" novalidate>
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <input type="text" name="identifier" class="form-control" placeholder="you@example.com" value="<?php echo escape($identifier); ?>" required autofocus>
      </div>

      <div class="form-group">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <label class="form-label" style="margin-bottom: 0;">Password</label>
          <a href="forgot-password.php" style="font-size: 0.8rem; color: #D4AF37;">Forgot Password?</a>
        </div>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn-gold" style="width: 100%; font-size: 1rem; padding: 13px; margin-top: 8px;">
        Access Account
      </button>
    </form>

    <div style="text-align: center; margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(27,56,40,0.6); font-size: 0.88rem; color: #8E9E94;">
      Don't have an investor account? <a href="register.php" style="color: #D4AF37; font-weight: 600;">Register Now</a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
