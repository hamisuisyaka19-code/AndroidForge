<?php
/**
 * Profile & Security Settings
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`password_hash`, `full_name`, `email`, `phone`).
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Account Settings & Security";
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$error = '';
$success = '';

// Handle Profile Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $action = $_POST['action'] ?? '';

        // 1. Update Personal Info
        if ($action === 'update_profile') {
            $full_name = trim($_POST['full_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');

            if (empty($full_name)) {
                $error = "Full name cannot be empty.";
            } else {
                $upd_sql = has_column($pdo, 'users', 'updated_at')
                    ? "UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE id = ?"
                    : "UPDATE users SET full_name = ?, phone = ? WHERE id = ?";
                $upd = $pdo->prepare($upd_sql);
                $upd->execute([$full_name, $phone, $user_id]);
                $user['full_name'] = $full_name;
                $user['phone'] = $phone;
                $success = "Personal information updated successfully.";
                record_audit_log($pdo, null, $user_id, 'PROFILE_UPDATED', 'Personal info updated');
            }
        }

        // 2. Update Bank Details
        elseif ($action === 'update_bank') {
            $bank_name = trim($_POST['bank_name'] ?? '');
            $account_number = trim($_POST['account_number'] ?? '');
            $account_name = trim($_POST['account_name'] ?? '');
            $routing_code = trim($_POST['routing_code'] ?? '');

            if (empty($bank_name) || empty($account_number) || empty($account_name)) {
                $error = "Bank name, account number, and account name are required.";
            } else {
                save_user_bank_details($pdo, $user_id, $bank_name, $account_number, $account_name, $routing_code);
                $success = "Default withdrawal bank details saved.";
                record_audit_log($pdo, null, $user_id, 'BANK_DETAILS_UPDATED', "Bank details updated to {$bank_name}");
            }
        }

        // 3. Change Password
        elseif ($action === 'change_password') {
            $current_pwd = $_POST['current_password'] ?? '';
            $new_pwd = $_POST['new_password'] ?? '';
            $confirm_pwd = $_POST['confirm_new_password'] ?? '';

            if (empty($current_pwd) || empty($new_pwd)) {
                $error = "Please fill in all password fields.";
            } elseif (!password_verify($current_pwd, $user['password_hash'])) {
                $error = "Current password is incorrect.";
            } elseif (strlen($new_pwd) < 6) {
                $error = "New password must be at least 6 characters long.";
            } elseif ($new_pwd !== $confirm_pwd) {
                $error = "New passwords do not match.";
            } else {
                $new_hash = password_hash($new_pwd, PASSWORD_DEFAULT);
                update_user_password_by_id($pdo, $user_id, $new_hash);
                $user['password_hash'] = $new_hash;
                $user['password'] = $new_hash;
                $success = "Your password has been changed successfully.";
                record_audit_log($pdo, null, $user_id, 'PASSWORD_CHANGED', 'User updated account password');
            }
        }
    }
}

// Fetch current user bank details
$bStmt = $pdo->prepare("SELECT * FROM user_bank_details WHERE user_id = ? LIMIT 1");
$bStmt->execute([$user_id]);
$bank = $bStmt->fetch();

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 950px; margin: 0 auto; padding-bottom: 60px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Account Profile &amp; Bank Settings
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Manage your personal credentials, payout coordinates, and security keys.
    </p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;" class="calc-grid">
    <!-- 1. Personal Profile -->
    <div class="gm-card">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        Personal Profile
      </h3>

      <form method="POST" action="profile.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_profile">

        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" required value="<?php echo escape($user['full_name']); ?>">
        </div>

        <div class="form-group">
          <label class="form-label">Email Address (Immutable)</label>
          <input type="email" class="form-control" disabled value="<?php echo escape($user['email']); ?>" style="opacity: 0.7; cursor: not-allowed;">
        </div>

        <div class="form-group">
          <label class="form-label">Account Handle</label>
          <input type="text" class="form-control" disabled value="@<?php echo escape($user['username']); ?>" style="opacity: 0.7; cursor: not-allowed;">
        </div>

        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <input type="tel" name="phone" class="form-control" value="<?php echo escape($user['phone'] ?? ''); ?>">
        </div>

        <button type="submit" class="btn-gold" style="padding: 10px 22px; font-size: 0.88rem;">
          Save Profile Details
        </button>
      </form>
    </div>

    <!-- 2. Payout Bank Settings -->
    <div class="gm-card">
      <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
        Default Payout Bank Account
      </h3>

      <form method="POST" action="profile.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_bank">

        <div class="form-group">
          <label class="form-label">Bank Name</label>
          <input type="text" name="bank_name" class="form-control" required value="<?php echo escape($bank['bank_name'] ?? ''); ?>" placeholder="e.g. Zenith Bank, GTBank">
        </div>

        <div class="form-group">
          <label class="form-label">Account / IBAN Number</label>
          <input type="text" name="account_number" class="form-control" required value="<?php echo escape($bank['account_number'] ?? ''); ?>" placeholder="0123456789">
        </div>

        <div class="form-group">
          <label class="form-label">Account Holder Name</label>
          <input type="text" name="account_name" class="form-control" required value="<?php echo escape($bank['account_name'] ?? $user['full_name']); ?>" placeholder="Name on bank record">
        </div>

        <div class="form-group">
          <label class="form-label">Routing / Sort Code (Optional)</label>
          <input type="text" name="routing_code" class="form-control" value="<?php echo escape($bank['routing_code'] ?? ''); ?>" placeholder="Routing or Sort Code">
        </div>

        <button type="submit" class="btn-gold" style="padding: 10px 22px; font-size: 0.88rem;">
          Save Bank Coordinates
        </button>
      </form>
    </div>
  </div>

  <!-- 3. Change Password -->
  <div class="gm-card" style="margin-top: 24px; max-width: 600px;">
    <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 16px;">
      Change Password
    </h3>

    <form method="POST" action="profile.php">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="change_password">

      <div class="form-group">
        <label class="form-label">Current Password</label>
        <input type="password" name="current_password" class="form-control" required placeholder="••••••••">
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" required placeholder="••••••••">
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_new_password" class="form-control" required placeholder="••••••••">
        </div>
      </div>

      <button type="submit" class="btn-outline-gold" style="padding: 10px 22px; font-size: 0.88rem;">
        Update Password
      </button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
