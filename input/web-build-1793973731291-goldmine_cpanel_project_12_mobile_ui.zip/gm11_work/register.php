<?php
/**
 * Investor Account Registration
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema:
 * (`id`, `full_name`, `email`, `phone`, `password_hash`, `balance`, `total_invested`, `total_profit`, `status`, `created_at`, `updated_at`)
 * as well as optional columns (`username`, `referral_code`, `referred_by`).
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Create Investor Account";

// Redirect if already logged in
if (is_user_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$errors = [];
$full_name = '';
$username = '';
$email = '';
$phone = '';
$referred_by = trim($_GET['ref'] ?? $_POST['referred_by'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token()) {
        $errors[] = "Security token validation failed. Please refresh and try again.";
    } else {
        $full_name = trim($_POST['full_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($full_name)) {
            $errors[] = "Full legal name is required.";
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        }
        if (empty($username)) {
            $email_prefix = explode('@', $email)[0] ?? 'investor';
            $username = preg_replace('/[^a-zA-Z0-9_]/', '', $email_prefix) ?: ('investor' . rand(100, 999));
        } elseif (strlen($username) < 3 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $errors[] = "Username must be at least 3 characters (letters, numbers, underscores only).";
        }
        if (strlen($password) < 6) {
            $errors[] = "Password must be at least 6 characters long.";
        }
        if ($password !== $confirm_password) {
            $errors[] = "Passwords do not match.";
        }

        // Check email and optional username uniqueness
        if (empty($errors)) {
            try {
                if (has_column($pdo, 'users', 'username')) {
                    $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
                    $chk->execute([$email, $username]);
                } else {
                    $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                    $chk->execute([$email]);
                }

                if ($chk->fetch()) {
                    $errors[] = "An account with this email address already exists. Please sign in.";
                }
            } catch (PDOException $e) {
                error_log("Register Duplicate Check Error: " . $e->getMessage());
                $errors[] = "Unable to verify account availability. Please try again.";
            }
        }

        // Validate referral code if provided and supported by schema
        $valid_referrer = null;
        if (empty($errors) && !empty($referred_by) && has_column($pdo, 'users', 'referral_code')) {
            try {
                $refStmt = $pdo->prepare("SELECT referral_code FROM users WHERE referral_code = ? LIMIT 1");
                $refStmt->execute([$referred_by]);
                $refRow = $refStmt->fetch();
                if ($refRow) {
                    $valid_referrer = $refRow['referral_code'];
                }
            } catch (Exception $e) {
                $valid_referrer = null;
            }
        }

        if (empty($errors)) {
            try {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $my_referral_code = 'GM' . strtoupper(bin2hex(random_bytes(3))) . rand(10, 99);

                $user_cols = get_table_columns($pdo, 'users');
                $ins_cols = [];
                $ins_vals = [];
                $ins_params = [];

                $candidate_fields = [
                    'full_name'      => $full_name,
                    'username'       => $username,
                    'email'          => $email,
                    'phone'          => $phone,
                    'password_hash'  => $hashed_password,
                    'password'       => $hashed_password,
                    'balance'        => 0.00,
                    'wallet_balance' => 0.00,
                    'total_invested' => 0.00,
                    'total_profit'   => 0.00,
                    'referral_code'  => $my_referral_code,
                    'referred_by'    => $valid_referrer,
                    'status'         => 'active',
                    'email_verified' => 1,
                ];

                foreach ($candidate_fields as $col_key => $col_val) {
                    if (isset($user_cols[$col_key])) {
                        $ins_cols[] = "`{$user_cols[$col_key]}`";
                        $ins_vals[] = "?";
                        $ins_params[] = $col_val;
                    }
                }

                if (isset($user_cols['created_at'])) {
                    $ins_cols[] = "`created_at`";
                    $ins_vals[] = "NOW()";
                }
                if (isset($user_cols['updated_at'])) {
                    $ins_cols[] = "`updated_at`";
                    $ins_vals[] = "NOW()";
                }

                $sql = "INSERT INTO `users` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
                $insert = $pdo->prepare($sql);
                $insert->execute($ins_params);

                $new_user_id = (int)$pdo->lastInsertId();

                create_notification(
                    $pdo,
                    $new_user_id,
                    "Welcome to GoldMine Investment Platform",
                    "Your investor account has been activated. You can now fund your wallet and select one of our 6 official investment tiers.",
                    "success"
                );

                record_audit_log($pdo, null, $new_user_id, 'USER_REGISTERED', "New account registered: {$email}");

                session_regenerate_id(true);
                $_SESSION['user_id'] = $new_user_id;
                $_SESSION['username'] = $username;
                $_SESSION['full_name'] = $full_name;
                $_SESSION['email'] = $email;
                $_SESSION['flash_success'] = "Account created successfully! Welcome to your GoldMine portfolio.";

                header("Location: dashboard.php");
                exit;
            } catch (PDOException $e) {
                error_log("GoldMine Registration Error: " . $e->getMessage());
                $errors[] = "Unable to complete registration at this moment. Please verify your details and try again.";
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 520px; margin: 30px auto;">
  <div class="gm-card" style="padding: 36px 32px;">
    <div style="text-align: center; margin-bottom: 26px;">
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.8rem; margin-bottom: 6px;">
        Open Investor Account
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Register your digital gold investment portfolio in seconds.
      </p>
    </div>

    <?php if (!empty($errors)): ?>
      <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
        <ul style="margin: 0; padding-left: 18px;">
          <?php foreach ($errors as $err): ?>
            <li><?php echo escape($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="register.php" novalidate>
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label">Full Name *</label>
        <input type="text" name="full_name" class="form-control" placeholder="e.g. Alexander Sterling" value="<?php echo escape($full_name); ?>" required>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label">Email Address *</label>
          <input type="email" name="email" class="form-control" placeholder="you@domain.com" value="<?php echo escape($email); ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <input type="tel" name="phone" class="form-control" placeholder="+234 800 000 0000" value="<?php echo escape($phone); ?>">
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label">Password *</label>
          <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required>
        </div>

        <div class="form-group">
          <label class="form-label">Confirm Password *</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Referral Code (Optional)</label>
        <input type="text" name="referred_by" class="form-control" placeholder="Enter partner code if invited" value="<?php echo escape($referred_by); ?>">
      </div>

      <div style="font-size: 0.8rem; color: #7D8F84; margin-bottom: 18px; line-height: 1.5;">
        By creating an account, you acknowledge the platform risk disclosure and agree to the GoldMine Terms of Service.
      </div>

      <button type="submit" class="btn-gold" style="width: 100%; font-size: 1rem; padding: 13px;">
        Create Investor Account
      </button>
    </form>

    <div style="text-align: center; margin-top: 22px; padding-top: 18px; border-top: 1px solid rgba(27,56,40,0.6); font-size: 0.88rem; color: #8E9E94;">
      Already registered? <a href="login.php" style="color: #D4AF37; font-weight: 600;">Sign In Here</a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
