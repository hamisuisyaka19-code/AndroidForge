<?php
/**
 * Notifications Center
 * GoldMine Investment Platform
 */
$page_title = "Notifications & Announcements";
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];

// Mark all as read action
if (isset($_GET['mark_all']) && $_GET['mark_all'] === 'read') {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? OR user_id IS NULL")->execute([$user_id]);
    $_SESSION['flash_success'] = "All notifications marked as read.";
    header("Location: notifications.php");
    exit;
}

require_once __DIR__ . '/includes/header.php';

// Fetch user notifications
$stmt = $pdo->prepare("
    SELECT * FROM notifications
    WHERE user_id = ? OR user_id IS NULL
    ORDER BY created_at DESC
    LIMIT 50
");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>

<div style="max-width: 850px; margin: 0 auto; padding-bottom: 60px;">
  <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Notifications & Alerts
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Official treasury communications, security alerts, and yield settlement notices.
      </p>
    </div>

    <?php if (!empty($notifications)): ?>
      <a href="notifications.php?mark_all=read" class="btn-outline-gold" style="font-size: 0.8rem; padding: 6px 14px;">
        Mark All as Read
      </a>
    <?php endif; ?>
  </div>

  <div style="display: flex; flex-direction: column; gap: 14px;">
    <?php if (empty($notifications)): ?>
      <div class="gm-card" style="text-align: center; padding: 36px; color: #8E9E94;">
        You have no notifications at this time.
      </div>
    <?php else: ?>
      <?php foreach ($notifications as $n): ?>
        <div class="gm-card" style="padding: 18px 22px; border-left: 3px solid <?php echo $n['is_read'] ? 'rgba(212,175,55,0.2)' : '#D4AF37'; ?>;">
          <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px;">
            <strong style="color: #FFF; font-size: 0.98rem;"><?php echo escape($n['title']); ?></strong>
            <span class="tabular-nums" style="font-size: 0.78rem; color: #8E9E94;">
              <?php echo date('M d, Y H:i', strtotime($n['created_at'])); ?>
            </span>
          </div>
          <p style="color: #B2C2B8; font-size: 0.88rem; line-height: 1.5;">
            <?php echo escape($n['message']); ?>
          </p>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
