<?php
/**
 * Referral & Affiliate Program
 * GoldMine Investment Platform
 * 
 * Safely checks whether `referred_by` exists in `users` before querying so it never throws Unknown column errors.
 */
$page_title = "Partner & Affiliate Program";
require_once __DIR__ . '/includes/header.php';
require_user_login();

$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$referral_bonus_percent = (float)get_setting($pdo, 'referral_bonus_percent', '10.00');

// Calculate total referral bonus earned from transactions
$bonusStmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = ? AND type = 'referral_bonus'");
$bonusStmt->execute([$user_id]);
$total_bonus_earned = (float)$bonusStmt->fetchColumn();

// Fetch referred users list only if `referred_by` column exists in `users`
$referred_users = [];
if (has_column($pdo, 'users', 'referred_by') && !empty($user['referral_code'])) {
    try {
        $refUsersStmt = $pdo->prepare("
            SELECT *
            FROM users
            WHERE referred_by = ?
            ORDER BY created_at DESC
        ");
        $refUsersStmt->execute([$user['referral_code']]);
        $raw_referred = $refUsersStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($raw_referred as $ru) {
            $referred_users[] = normalize_user_row($ru);
        }
    } catch (Exception $e) {
        $referred_users = [];
    }
}
$total_referred_count = count($referred_users);

// Construct referral link
$app_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . ($_SERVER['HTTP_HOST'] ?? 'goalmindai.com.ng') . dirname($_SERVER['PHP_SELF']);
$referral_link = rtrim($app_url, '/') . '/register.php?ref=' . urlencode($user['referral_code'] ?? '');
?>

<div style="max-width: 1050px; margin: 0 auto; padding-bottom: 60px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Affiliate &amp; Partnership Program
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Grow with GoldMine by introducing investors to our six structured investment plans.
    </p>
  </div>

  <!-- Referral Metrics Overview -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px; margin-bottom: 30px;">
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Total Referred Partners
      </div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 2.2rem; font-weight: 800;">
        <?php echo $total_referred_count; ?>
      </div>
      <div style="font-size: 0.8rem; color: #8E9E94; margin-top: 4px;">
        Active direct accounts
      </div>
    </div>

    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Total Commission Earned
      </div>
      <div class="tabular-nums" style="font-size: 2.2rem; font-weight: 800; color: #34D399;">
        <?php echo format_money($total_bonus_earned, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.8rem; color: #8E9E94; margin-top: 4px;">
        Credited directly to available balance
      </div>
    </div>

    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; color: #8E9E94; letter-spacing: 0.05em; margin-bottom: 6px;">
        Commission Rate
      </div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 2.2rem; font-weight: 800;">
        <?php echo $referral_bonus_percent; ?>%
      </div>
      <div style="font-size: 0.8rem; color: #8E9E94; margin-top: 4px;">
        Reward on verified partner deposits
      </div>
    </div>
  </div>

  <!-- Referral Link Box -->
  <div class="gm-card" style="padding: 24px; margin-bottom: 36px; border-color: rgba(212,175,55,0.4);">
    <h3 class="font-gold-serif" style="font-size: 1.2rem; color: #FFF; margin-bottom: 12px;">
      Your Unique Invitation Link
    </h3>

    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
      <input type="text" id="ref_link_input" class="form-control" style="flex: 1; min-width: 280px; font-weight: 600; color: #D4AF37;" readonly value="<?php echo escape($referral_link); ?>">
      <button onclick="copyRefLink()" id="copy_btn" class="btn-gold" style="padding: 10px 24px; font-size: 0.88rem;">
        Copy Invitation Link
      </button>
    </div>
  </div>

  <!-- Referred Accounts Table -->
  <div>
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 16px;">
      Referred Accounts Ledger
    </h3>

    <div class="gm-table-container">
      <table class="gm-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Email / Handle</th>
            <th>Joined Date</th>
            <th>Account Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($referred_users)): ?>
            <tr>
              <td colspan="4" style="text-align: center; color: #8E9E94; padding: 28px;">
                No partners have registered through your link yet. Share your link above to begin earning commissions.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($referred_users as $ru): ?>
              <tr>
                <td style="font-weight: 600; color: #FFF;">
                  <?php echo escape($ru['full_name']); ?>
                </td>
                <td class="tabular-nums" style="color: #D4AF37;">
                  <?php echo escape($ru['email']); ?>
                </td>
                <td class="tabular-nums" style="font-size: 0.82rem; color: #94A3B8;">
                  <?php echo date('M d, Y', strtotime($ru['created_at'])); ?>
                </td>
                <td>
                  <span class="badge-clean badge-<?php echo escape($ru['status']); ?>">
                    <?php echo escape($ru['status']); ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function copyRefLink() {
  const input = document.getElementById('ref_link_input');
  input.select();
  input.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(input.value);
  const btn = document.getElementById('copy_btn');
  btn.innerText = 'Copied to Clipboard!';
  setTimeout(() => { btn.innerText = 'Copy Invitation Link'; }, 2000);
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
