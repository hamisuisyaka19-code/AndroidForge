<?php
/**
 * GoldMine Invest — Six Official Investment Plans & Allocation Engine
 * GoldMine Investment Platform
 * 
 * Official Plans:
 * 1. Starter   — ₦1,000
 * 2. Silver    — ₦5,000
 * 3. Gold      — ₦50,000
 * 4. Platinum  — ₦100,000
 * 5. Elite     — ₦500,000
 * 6. VIP       — ₦1,000,000
 * 
 * Configurable Target Projection Rate: 45%
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "GoldMine Invest";
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$target_projection_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
if ($target_projection_rate <= 0) {
    $target_projection_rate = 45.00;
}

// Synchronize and fetch ONLY the 6 official active plans
$plans = ensure_six_investment_plans($pdo, false);

$error = '';
$selected_plan_id = isset($_GET['plan_id']) ? (int)$_GET['plan_id'] : (int)($plans[0]['id'] ?? 0);

// Handle Investment Creation Form Submission BEFORE outputting HTML
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_investment') {
    if (!validate_csrf_token()) {
        $error = "Security token validation failed. Please refresh the page and try again.";
    } else {
        $plan_id = (int)($_POST['plan_id'] ?? 0);
        $selected_plan_id = $plan_id;

        // Verify the selected plan is one of the 6 active official plans
        $official_names = array_keys(get_official_six_plans_spec());
        $placeholders = implode(',', array_fill(0, count($official_names), '?'));
        $pStmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND name IN ($placeholders) LIMIT 1");
        $pStmt->execute(array_merge([$plan_id], $official_names));
        $rawPlan = $pStmt->fetch(PDO::FETCH_ASSOC);
        $plan = $rawPlan ? normalize_plan_row($rawPlan, $target_projection_rate) : null;

        if (!$plan || $plan['status'] !== 'active') {
            $error = "Selected investment plan is invalid or currently unavailable.";
        } else {
            // Fixed Plan Investment Amount from database
            $amount = round((float)$plan['min_amount'], 2);

            try {
                $pdo->beginTransaction();

                // Lock user row to prevent race conditions or double-spending
                $lockedUser = lock_user_row($pdo, $user_id);
                $current_balance = (float)($lockedUser['balance'] ?? 0.00);

                // Prevent accidental rapid duplicate submission within 8 seconds
                $dupStmt = $pdo->prepare("
                    SELECT id FROM investments
                    WHERE user_id = ? AND plan_id = ? AND amount = ?
                      AND created_at >= (NOW() - INTERVAL 8 SECOND)
                    LIMIT 1
                ");
                $dupStmt->execute([$user_id, $plan_id, $amount]);

                if ($dupStmt->fetch()) {
                    $pdo->rollBack();
                    $error = "Duplicate submission detected. Your investment was just created—please check My Investments.";
                } elseif ($current_balance < $amount) {
                    $pdo->rollBack();
                    $error = "Insufficient wallet balance for the {$plan['name']} Plan (" . format_money($amount, $currency_symbol) . "). Your available balance is " . format_money($current_balance, $currency_symbol) . ". Please deposit funds first.";
                } else {
                    // Server-side Projected Profit Calculation (Default 45%)
                    $roi_pct = (float)$plan['roi_percentage'] > 0 ? (float)$plan['roi_percentage'] : $target_projection_rate;
                    $calc = calculate_projected_returns($amount, $roi_pct, $plan['capital_returned']);
                    $projected_profit = $calc['projected_profit'];
                    $projected_total  = $calc['projected_total'];

                    $duration_days = max(1, (int)$plan['duration_days']);
                    $start_date    = date('Y-m-d H:i:s');
                    $maturity_date = date('Y-m-d H:i:s', strtotime("+{$duration_days} days"));
                    $new_balance   = round($current_balance - $amount, 2);
                    $ref           = generate_reference('INV-' . strtoupper(substr($plan['name'], 0, 3)));

                    // 1. Deduct principal from user balance and increment total_invested (Never auto-credit projected profit)
                    update_user_balance($pdo, $user_id, $new_balance, $amount, 0.00);

                    // 2. Insert active investment record using actual `investments` columns:
                    // (reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status)
                    $inv_id = create_investment_record($pdo, [
                        'reference_code'  => $ref,
                        'user_id'         => $user_id,
                        'plan_id'         => $plan_id,
                        'plan_name'       => $plan['name'],
                        'amount'          => $amount,
                        'roi_percentage'  => $roi_pct,
                        'expected_return' => $projected_total,
                        'duration_days'   => $duration_days,
                        'start_date'      => $start_date,
                        'maturity_date'   => $maturity_date,
                        'status'          => 'active',
                    ]);

                    // 3. Record transaction with unique reference_code
                    record_transaction(
                        $pdo,
                        $user_id,
                        'investment',
                        $amount,
                        $new_balance,
                        $ref,
                        "Activated {$plan['name']} Plan ({$duration_days} Days) - Projected Total: " . format_money($projected_total, $currency_symbol),
                        0.00,
                        'completed'
                    );

                    // 4. Send user notification
                    create_notification(
                        $pdo,
                        $user_id,
                        "{$plan['name']} Plan Activated",
                        "You invested " . format_money($amount, $currency_symbol) . " in the {$plan['name']} Plan (Ref: {$ref}). Projected Profit ({$roi_pct}%): " . format_money($projected_profit, $currency_symbol) . ", Projected Total: " . format_money($projected_total, $currency_symbol) . ".",
                        "success"
                    );

                    // 5. Record audit log
                    record_audit_log(
                        $pdo,
                        null,
                        $user_id,
                        'INVESTMENT_CREATED',
                        "Activated {$plan['name']} Plan (#{$plan_id}) with {$amount}. Ref: {$ref}, Projected Profit: {$projected_profit}, Projected Total: {$projected_total}"
                    );

                    $pdo->commit();

                    $_SESSION['flash_success'] = "Successfully activated the {$plan['name']} Plan (" . format_money($amount, $currency_symbol) . ")! Reference: {$ref}.";
                    header("Location: my-investments.php");
                    exit;
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log("Investment Creation Error: " . $e->getMessage());
                $error = "An error occurred while processing your investment. Please try again.";
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
  .gm-invest-shell {
    max-width: 540px;
    margin: 0 auto 48px;
    background: #0C140F;
    border: 1.5px solid rgba(212, 175, 55, 0.55);
    border-radius: 26px;
    padding: 24px 20px 28px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.75), inset 0 1px 0 rgba(255, 215, 0, 0.15);
  }
  .gm-invest-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-bottom: 16px;
    margin-bottom: 18px;
    border-bottom: 1px solid rgba(212, 175, 55, 0.25);
  }
  .gm-invest-brand {
    font-family: 'Plus Jakarta Sans', sans-serif;
    font-size: 1.35rem;
    font-weight: 800;
    color: #F5C518;
    letter-spacing: -0.01em;
  }
  .gm-invest-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: linear-gradient(135deg, #F5C518, #B58512);
    border: 2px solid #F5C518;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #060D09;
    font-weight: 800;
    font-size: 0.92rem;
    text-decoration: none;
  }
  .gm-wallet-banner {
    background: linear-gradient(180deg, #171814 0%, #10120E 100%);
    border: 1.5px solid #D4AF37;
    border-radius: 16px;
    padding: 18px 20px;
    margin-bottom: 20px;
  }
  .gm-wallet-label {
    font-size: 0.85rem;
    color: #B4BEB8;
    margin-bottom: 4px;
    font-weight: 500;
  }
  .gm-wallet-amount {
    font-size: 2.15rem;
    font-weight: 800;
    color: #F5C518;
    letter-spacing: -0.02em;
    line-height: 1.15;
  }
  .gm-action-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin-bottom: 24px;
  }
  .gm-action-btn {
    background: #171815;
    border: 1px solid rgba(212, 175, 55, 0.35);
    border-radius: 12px;
    padding: 11px 6px;
    text-align: center;
    color: #F5C518;
    font-weight: 700;
    font-size: 0.82rem;
    text-decoration: none;
    transition: all 0.2s ease;
    display: block;
  }
  .gm-action-btn:hover,
  .gm-action-btn.active {
    background: rgba(245, 197, 24, 0.16);
    border-color: #F5C518;
    color: #FFF;
  }
  .gm-section-title {
    font-size: 1.18rem;
    font-weight: 800;
    color: #FFFFFF;
    margin-bottom: 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .gm-plans-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
    margin-bottom: 20px;
  }
  .gm-plan-card {
    background: linear-gradient(180deg, #161814 0%, #10120F 100%);
    border: 1.5px solid rgba(212, 175, 55, 0.55);
    border-radius: 16px;
    padding: 16px 14px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
  }
  .gm-plan-card:hover,
  .gm-plan-card.selected-plan {
    border-color: #F5C518;
    box-shadow: 0 8px 24px rgba(245, 197, 24, 0.18);
    transform: translateY(-2px);
  }
  .gm-plan-tier {
    font-size: 1.05rem;
    font-weight: 800;
    color: #F5C518;
    margin-bottom: 4px;
  }
  .gm-plan-amount {
    font-size: 1.45rem;
    font-weight: 800;
    color: #FFFFFF;
    margin-bottom: 6px;
  }
  .gm-plan-profit {
    font-size: 0.85rem;
    font-weight: 700;
    color: #34D399;
    margin-bottom: 4px;
  }
  .gm-plan-meta {
    font-size: 0.74rem;
    color: #9FB1A6;
    margin-bottom: 12px;
    line-height: 1.4;
  }
  .gm-plan-btn {
    width: 100%;
    background: linear-gradient(180deg, #F7CE3E 0%, #E0AC18 100%);
    color: #080D0A;
    font-weight: 800;
    font-size: 0.85rem;
    border: none;
    border-radius: 10px;
    padding: 9px 12px;
    cursor: pointer;
    transition: filter 0.15s ease;
  }
  .gm-plan-btn:hover {
    filter: brightness(1.08);
  }
  .gm-confirm-modal-backdrop {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.82);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 16px;
  }
  .gm-confirm-modal {
    background: #101612;
    border: 1.5px solid #F5C518;
    border-radius: 20px;
    max-width: 440px;
    width: 100%;
    padding: 24px;
    box-shadow: 0 24px 60px rgba(0, 0, 0, 0.9);
  }
  @media (max-width: 480px) {
    .gm-wallet-amount { font-size: 1.8rem; }
    .gm-plan-amount { font-size: 1.25rem; }
  }
</style>

<div class="gm-invest-shell">
  <!-- Top Header matching GoldMine Invest screenshot -->
  <div class="gm-invest-header">
    <span class="gm-invest-brand">GoldMine Invest</span>
    <a href="profile.php" class="gm-invest-avatar" title="Account Profile">
      <?php echo escape(strtoupper(substr($user['full_name'] ?? 'U', 0, 1))); ?>
    </a>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.16); border: 1px solid #EF4444; border-radius: 12px; padding: 12px 16px; margin-bottom: 16px; color: #FCA5A5; font-size: 0.86rem;">
      <?php echo escape($error); ?>
      <?php if (strpos($error, 'Insufficient wallet balance') !== false): ?>
        <div style="margin-top: 8px;">
          <a href="deposit.php" style="color: #F5C518; font-weight: 700; text-decoration: underline;">Click here to Deposit Funds &rarr;</a>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- Wallet Balance Card -->
  <div class="gm-wallet-banner">
    <div class="gm-wallet-label">Wallet Balance</div>
    <div class="gm-wallet-amount tabular-nums">
      <?php echo format_money($user['balance'], $currency_symbol); ?>
    </div>
  </div>

  <!-- 4 Quick Action Buttons (Deposit, Withdraw, Invest, History) -->
  <div class="gm-action-grid">
    <a href="deposit.php" class="gm-action-btn">Deposit</a>
    <a href="withdraw.php" class="gm-action-btn">Withdraw</a>
    <a href="invest.php" class="gm-action-btn active">Invest</a>
    <a href="transactions.php" class="gm-action-btn">History</a>
  </div>

  <!-- Investment Plans Heading -->
  <div class="gm-section-title">
    <span>Investment Plans</span>
    <a href="my-investments.php" style="font-size: 0.78rem; color: #F5C518; font-weight: 600; text-decoration: none;">
      My Portfolio &rarr;
    </a>
  </div>

  <!-- 2-Column Grid of the 6 Official Plans -->
  <div class="gm-plans-grid">
    <?php foreach ($plans as $p):
      $amt = (float)$p['min_amount'];
      $rate = (float)$p['roi_percentage'] > 0 ? (float)$p['roi_percentage'] : $target_projection_rate;
      $calc = calculate_projected_returns($amt, $rate, $p['capital_returned']);
      $is_selected = ((int)$p['id'] === $selected_plan_id);
    ?>
      <div class="gm-plan-card <?php echo $is_selected ? 'selected-plan' : ''; ?>">
        <div>
          <div class="gm-plan-tier"><?php echo escape($p['name']); ?></div>
          <div class="gm-plan-amount tabular-nums">
            <?php echo $currency_symbol . number_format($amt, 0); ?>
          </div>
          <div class="gm-plan-profit tabular-nums">
            <?php echo number_format($rate, 0); ?>% Profit
          </div>
          <div class="gm-plan-meta tabular-nums">
            Est. Profit: <strong style="color: #34D399;">+<?php echo $currency_symbol . number_format($calc['projected_profit'], 0); ?></strong><br>
            Projected Total: <strong style="color: #F5C518;"><?php echo $currency_symbol . number_format($calc['projected_total'], 0); ?></strong><br>
            Duration: <?php echo (int)$p['duration_days']; ?> Days
          </div>
        </div>

        <button
          type="button"
          class="gm-plan-btn"
          onclick="openInvestConfirm(
            <?php echo (int)$p['id']; ?>,
            '<?php echo escape(addslashes($p['name'])); ?>',
            <?php echo $amt; ?>,
            <?php echo $rate; ?>,
            <?php echo $calc['projected_profit']; ?>,
            <?php echo $calc['projected_total']; ?>,
            <?php echo (int)$p['duration_days']; ?>
          )"
        >
          Invest Now
        </button>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Mandatory Projection Disclaimer -->
  <div style="background: rgba(245, 197, 24, 0.07); border: 1px solid rgba(245, 197, 24, 0.25); border-radius: 12px; padding: 12px 14px; font-size: 0.76rem; color: #A6B4AC; line-height: 1.5; text-align: center;">
    <strong style="color: #F5C518;">Projection Notice:</strong> Projected returns are estimates and depend on plan terms and actual platform performance.
  </div>
</div>

<!-- Investment Confirmation Modal -->
<div id="investConfirmBackdrop" class="gm-confirm-modal-backdrop" onclick="if(event.target === this) closeInvestConfirm()">
  <div class="gm-confirm-modal">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid rgba(245, 197, 24, 0.2);">
      <h3 style="font-size: 1.2rem; font-weight: 800; color: #F5C518; margin: 0;" id="modalPlanTitle">
        Confirm Investment
      </h3>
      <button type="button" onclick="closeInvestConfirm()" style="background: none; border: none; color: #9FB1A6; font-size: 1.5rem; cursor: pointer; line-height: 1;">&times;</button>
    </div>

    <form method="POST" action="invest.php" id="investConfirmForm">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="create_investment">
      <input type="hidden" name="plan_id" id="modalPlanId" value="">

      <div style="background: #080E0B; border: 1px solid rgba(245, 197, 24, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px; display: flex; flex-direction: column; gap: 10px; font-size: 0.88rem;">
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #9FB1A6;">Selected Plan:</span>
          <strong style="color: #FFF;" id="modalPlanName">-</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #9FB1A6;">Investment Amount:</span>
          <strong class="tabular-nums" style="color: #FFF;" id="modalInvestAmount">-</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #9FB1A6;">Target Projection Rate:</span>
          <strong class="tabular-nums" style="color: #F5C518;" id="modalProjectionRate">-</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #9FB1A6;">Projected Profit:</span>
          <strong class="tabular-nums" style="color: #34D399;" id="modalProjectedProfit">-</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #9FB1A6;">Duration:</span>
          <strong class="tabular-nums" style="color: #FFF;" id="modalDuration">-</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding-top: 10px; border-top: 1px solid rgba(245, 197, 24, 0.2); font-size: 1rem;">
          <span style="color: #F5C518; font-weight: 700;">Projected Total:</span>
          <strong class="tabular-nums" style="color: #F5C518; font-size: 1.12rem;" id="modalProjectedTotal">-</strong>
        </div>
      </div>

      <p style="font-size: 0.74rem; color: #8E9E94; margin-bottom: 16px; line-height: 1.4;">
        Projected returns are estimates and depend on plan terms and actual platform performance. The investment principal will be deducted from your available wallet balance (<strong style="color: #F5C518;"><?php echo format_money($user['balance'], $currency_symbol); ?></strong>).
      </p>

      <div style="display: flex; gap: 10px;">
        <button type="button" onclick="closeInvestConfirm()" class="btn-outline-gold" style="flex: 1; padding: 11px;">
          Cancel
        </button>
        <button type="submit" id="confirmSubmitBtn" class="gm-plan-btn" style="flex: 1.4; padding: 11px; font-size: 0.92rem;">
          Confirm &amp; Invest Now
        </button>
      </div>
    </form>
  </div>
</div>

<script>
const CURR_SYMBOL = <?php echo json_encode($currency_symbol); ?>;

function formatNaira(val) {
  return CURR_SYMBOL + Number(val).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function openInvestConfirm(planId, planName, amount, rate, projProfit, projTotal, durationDays) {
  document.getElementById('modalPlanId').value = planId;
  document.getElementById('modalPlanTitle').innerText = planName + ' Plan Allocation';
  document.getElementById('modalPlanName').innerText = planName + ' Plan';
  document.getElementById('modalInvestAmount').innerText = formatNaira(amount);
  document.getElementById('modalProjectionRate').innerText = rate + '%';
  document.getElementById('modalProjectedProfit').innerText = '+' + formatNaira(projProfit);
  document.getElementById('modalProjectedTotal').innerText = formatNaira(projTotal);
  document.getElementById('modalDuration').innerText = durationDays + ' Days';
  document.getElementById('investConfirmBackdrop').style.display = 'flex';
}

function closeInvestConfirm() {
  document.getElementById('investConfirmBackdrop').style.display = 'none';
}

document.getElementById('investConfirmForm').addEventListener('submit', function() {
  const btn = document.getElementById('confirmSubmitBtn');
  btn.disabled = true;
  btn.innerText = 'Processing...';
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
