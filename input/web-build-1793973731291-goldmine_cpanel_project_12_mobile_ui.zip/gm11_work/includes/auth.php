<?php
/**
 * Session & Authentication Guard
 * GoldMine Investment Platform
 */

// Ensure output buffering is started so header("Location: ...") redirects never fail on cPanel
if (!ob_get_level()) {
    ob_start();
}

if (session_status() === PHP_SESSION_NONE) {
    $is_secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    session_set_cookie_params([
        'lifetime' => 86400,
        'path'     => '/',
        'secure'   => $is_secure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

require_once __DIR__ . '/functions.php';

/**
 * Check if a regular investor user is logged in
 */
function is_user_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Enforce investor login, redirecting to login.php if unauthenticated
 */
function require_user_login() {
    if (!is_user_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'dashboard.php';
        header("Location: login.php");
        exit;
    }
}

/**
 * Universal authentication guard alias
 */
function require_login() {
    require_user_login();
}

/**
 * Fetch current logged-in user record fresh from MySQL database,
 * normalized for full compatibility with `lhzmylpw_goldmine` (`balance`, `password_hash`, `total_invested`).
 */
function get_current_user_data($pdo) {
    if (!is_user_logged_in()) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user = normalize_user_row($stmt->fetch(PDO::FETCH_ASSOC));

    if (!$user || in_array($user['status'], ['suspended', 'banned', 'blocked'], true)) {
        unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['full_name'], $_SESSION['email']);
        header("Location: login.php?error=account_suspended");
        exit;
    }

    return $user;
}

/**
 * Check if an administrator is logged in
 */
function is_admin_logged_in() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

/**
 * Enforce administrator login
 */
function require_admin_login() {
    if (!is_admin_logged_in()) {
        header("Location: login.php");
        exit;
    }
}

/**
 * Fetch current logged-in admin record from MySQL
 */
function get_current_admin_data($pdo) {
    if (!is_admin_logged_in()) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
    $stmt->execute([(int)$_SESSION['admin_id']]);
    $admin = normalize_admin_row($stmt->fetch(PDO::FETCH_ASSOC));

    if (!$admin) {
        unset($_SESSION['admin_id'], $_SESSION['admin_username'], $_SESSION['admin_name']);
        header("Location: login.php");
        exit;
    }

    return $admin;
}
