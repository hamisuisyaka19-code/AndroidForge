</main>

<footer style="border-top: 1px solid rgba(212, 175, 55, 0.15); background: #040806; padding: 40px 24px 30px; margin-top: 60px;">
  <div style="max-width: 1280px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px;">
    
    <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 20px;">
      <div>
        <span class="font-gold-serif text-gold-gradient" style="font-size: 1.25rem; font-weight: 700; display: block; margin-bottom: 6px;">GOLDMINE</span>
        <p style="color: #7D8F84; font-size: 0.85rem; max-width: 480px;">
          Institutional-grade wealth management, precious metal backed ventures, and diversified structured yield portfolios.
        </p>
      </div>
      <div style="display: flex; gap: 20px; font-size: 0.85rem; color: #94A3B8;">
        <a href="index.php#plans" class="nav-link">Plans</a>
        <a href="index.php#security" class="nav-link">Security Protocols</a>
        <a href="mailto:<?php echo escape(get_setting($pdo, 'contact_email', 'support@goldmineinvest.com')); ?>" class="nav-link">Support</a>
        <a href="admin/login.php" class="nav-link" style="color: #64748B;">Staff Portal</a>
      </div>
    </div>

    <!-- Mandatory Risk Disclosure -->
    <div style="padding-top: 16px; border-top: 1px solid rgba(27, 56, 40, 0.5); font-size: 0.78rem; color: #5F7366; line-height: 1.5;">
      <strong>Risk Disclosure:</strong> All investments are subject to market risks, including the potential loss of principal. Projected yields reflect algorithmic strategy targets and are not guaranteed. Past performance does not indicate future results. Verify your financial objectives before committing funds.
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.78rem; color: #4B5E52; padding-top: 10px;">
      <div>&copy; <?php echo date('Y'); ?> <?php echo escape(get_setting($pdo, 'site_name', 'GoldMine Investment Platform')); ?>. All rights reserved.</div>
      <div style="display: flex; gap: 12px;">
        <span>SSL 256-Bit Encrypted</span>
        <span>·</span>
        <span>cPanel Production Certified</span>
      </div>
    </div>
  </div>
</footer>

<!-- Mobile Bottom Navigation (Visible on screen <= 768px) -->
<?php if (is_user_logged_in()): ?>
<nav class="mobile-bottom-nav">
  <a href="dashboard.php" class="mobile-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
    <span>Home</span>
  </a>
  <a href="invest.php" class="mobile-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'invest.php' ? 'active' : ''; ?>">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
    <span>Invest</span>
  </a>
  <a href="deposit.php" class="mobile-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'deposit.php' ? 'active' : ''; ?>">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    <span>Deposit</span>
  </a>
  <a href="withdraw.php" class="mobile-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'withdraw.php' ? 'active' : ''; ?>">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
    <span>Withdraw</span>
  </a>
  <a href="profile.php" class="mobile-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
    <span>Profile</span>
  </a>
</nav>
<?php endif; ?>

</body>
</html>
