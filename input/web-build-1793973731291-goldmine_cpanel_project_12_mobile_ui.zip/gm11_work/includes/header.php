<?php
/**
 * Global Frontend & User Dashboard Header
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$site_name = get_setting($pdo, 'site_name', 'GoldMine Investment Platform');
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$user = get_current_user_data($pdo);

// Count unread notifications if user is logged in
$unread_notifications = 0;
if ($user) {
    try {
        $nStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
        $nStmt->execute([(int)$user['id']]);
        $unread_notifications = (int)$nStmt->fetchColumn();
    } catch (Exception $e) {
        $unread_notifications = 0;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? escape($page_title) . ' | ' : ''; ?><?php echo escape($site_name); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Top Navigation Header -->
<header class="gm-navbar">
  <div style="max-width: 1280px; margin: 0 auto; padding: 14px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
    
    <!-- Brand Logo -->
    <a href="<?php echo $user ? 'dashboard.php' : 'index.php'; ?>" style="display: flex; align-items: center; gap: 12px;">
      <div style="width: 38px; height: 38px; border-radius: 8px; background: linear-gradient(135deg, #D4AF37, #AA8010); display: flex; align-items: center; justify-content: center; color: #040906; font-weight: 800; font-family: 'Cinzel', serif; font-size: 1.2rem; box-shadow: 0 2px 10px rgba(212,175,55,0.4);">
        G
      </div>
      <div>
        <span class="font-gold-serif text-gold-gradient" style="font-size: 1.25rem; font-weight: 800; letter-spacing: 0.06em; display: block; line-height: 1.1;">
          GOLDMINE
        </span>
        <span style="font-size: 0.68rem; color: #8A9A90; letter-spacing: 0.14em; text-transform: uppercase; display: block;">
          Digital Gold Investment
        </span>
      </div>
    </a>

    <!-- Desktop Navigation Links -->
    <?php if ($user): ?>
      <nav style="display: flex; align-items: center; gap: 22px; flex-wrap: wrap;" class="desktop-nav">
        <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">Overview</a>
        <a href="invest.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'invest.php' ? 'active' : ''; ?>">Invest</a>
        <a href="my-investments.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'my-investments.php' ? 'active' : ''; ?>">My Portfolio</a>
        <a href="deposit.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'deposit.php' ? 'active' : ''; ?>">Deposit</a>
        <a href="withdraw.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'withdraw.php' ? 'active' : ''; ?>">Withdraw</a>
        <a href="transfer.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'transfer.php' ? 'active' : ''; ?>">Transfer</a>
        <a href="transactions.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'transactions.php' ? 'active' : ''; ?>">Transactions</a>
        <a href="referrals.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'referrals.php' ? 'active' : ''; ?>">Referrals</a>
        <a href="support.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'support.php' ? 'active' : ''; ?>">Support</a>
      </nav>

      <!-- Right Action Controls -->
      <div style="display: flex; align-items: center; gap: 14px;">
        <!-- Balance Pill -->
        <a href="deposit.php" style="background: rgba(212, 175, 55, 0.1); border: 1px solid rgba(212, 175, 55, 0.35); padding: 6px 14px; border-radius: 6px; display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 0.75rem; color: #9FB1A6;">Balance:</span>
          <strong class="tabular-nums text-gold-gradient" style="font-size: 0.92rem;">
            <?php echo format_money($user['balance'], $currency_symbol); ?>
          </strong>
        </a>

        <!-- Notifications Bell -->
        <a href="notifications.php" style="position: relative; padding: 8px; color: #D4AF37;" title="Notifications">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          <?php if ($unread_notifications > 0): ?>
            <span style="position: absolute; top: 2px; right: 2px; width: 16px; height: 16px; border-radius: 50%; background: #EF4444; color: #FFF; font-size: 0.65rem; font-weight: 700; display: flex; align-items: center; justify-content: center;">
              <?php echo $unread_notifications > 9 ? '9+' : $unread_notifications; ?>
            </span>
          <?php endif; ?>
        </a>

        <!-- Profile & Logout -->
        <a href="profile.php" class="btn-outline-gold" style="padding: 6px 12px; font-size: 0.8rem;">
          Profile
        </a>
        <a href="logout.php" style="font-size: 0.82rem; color: #F87171; font-weight: 600; padding: 6px 8px;">
          Logout
        </a>
      </div>
    <?php else: ?>
      <!-- Public Guest Navigation -->
      <nav style="display: flex; align-items: center; gap: 24px;">
        <a href="index.php#plans" class="nav-link">Investment Plans</a>
        <a href="index.php#calculator" class="nav-link">Profit Calculator</a>
        <a href="index.php#security" class="nav-link">Security</a>
        <a href="login.php" class="btn-outline-gold" style="padding: 8px 18px; font-size: 0.85rem;">Sign In</a>
        <a href="register.php" class="btn-gold" style="padding: 8px 18px; font-size: 0.85rem;">Create Account</a>
      </nav>
    <?php endif; ?>

  </div>
</header>

<main style="max-width: 1280px; margin: 0 auto; padding: 28px 24px;">
<?php if (!empty($_SESSION['flash_success'])): ?>
  <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; color: #6EE7B7; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
    <span><?php echo escape($_SESSION['flash_success']); unset($_SESSION['flash_success']); ?></span>
  </div>
<?php endif; ?>

<?php if (!empty($_SESSION['flash_error'])): ?>
  <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; color: #FCA5A5; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
    <span><?php echo escape($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?></span>
  </div>
<?php endif; ?>
