<?php
/**
 * Core Helper & Business Logic Functions
 * GoldMine Investment Platform
 * 
 * Authoritative compatibility with the `lhzmylpw_goldmine` MySQL schema:
 * - users: id, full_name, email, phone, password_hash, balance, total_invested, total_profit, status, email_verified, verification_token, remember_token, created_at, updated_at
 * - investments: id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 * - deposits: id, reference_code, user_id, amount, payment_method, gateway_ref, receipt_path, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 * - transactions: id, reference_code, user_id, type, amount, fee, balance_after, status, description, created_at
 * - settings: key_name, value, updated_at
 */

/**
 * Inspect and cache actual columns of a table in the connected MySQL database.
 */
function get_table_columns($pdo, $table) {
    static $cache = [];
    $table_key = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', $table));
    if (isset($cache[$table_key])) {
        return $cache[$table_key];
    }

    $cols = [];
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `{$table_key}`");
        if ($stmt) {
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (!empty($row['Field'])) {
                    $cols[strtolower($row['Field'])] = $row['Field'];
                }
            }
        }
    } catch (Exception $e) {
        // Table might not exist yet
    }

    $cache[$table_key] = $cols;
    return $cols;
}

/**
 * Check if a specific column exists on a table in the live database.
 */
function has_column($pdo, $table, $column) {
    $cols = get_table_columns($pdo, $table);
    return isset($cols[strtolower($column)]);
}

/**
 * Return the primary balance column name in `users` ('balance' in actual DB, fallback 'wallet_balance').
 */
function get_user_balance_col($pdo) {
    if (has_column($pdo, 'users', 'balance')) {
        return 'balance';
    }
    if (has_column($pdo, 'users', 'wallet_balance')) {
        return 'wallet_balance';
    }
    return 'balance';
}

/**
 * Return the primary password column name in `users` ('password_hash' in actual DB, fallback 'password').
 */
function get_user_password_col($pdo) {
    if (has_column($pdo, 'users', 'password_hash')) {
        return 'password_hash';
    }
    if (has_column($pdo, 'users', 'password')) {
        return 'password';
    }
    return 'password_hash';
}

/**
 * Normalize a user row from `users` so both actual columns (`balance`, `password_hash`, `total_invested`, `total_profit`)
 * and backward-compatible keys (`wallet_balance`, `password`, `username`, `referral_code`, `referred_by`)
 * are always populated without triggering Undefined array key warnings.
 */
function normalize_user_row($row) {
    if (!$row || !is_array($row)) {
        return null;
    }

    $balance = 0.00;
    if (array_key_exists('balance', $row) && $row['balance'] !== null) {
        $balance = (float)$row['balance'];
    } elseif (array_key_exists('wallet_balance', $row) && $row['wallet_balance'] !== null) {
        $balance = (float)$row['wallet_balance'];
    }

    $row['balance'] = $balance;
    $row['wallet_balance'] = $balance;

    $pwd = (string)($row['password_hash'] ?? $row['password'] ?? '');
    $row['password_hash'] = $pwd;
    $row['password'] = $pwd;

    $row['total_invested'] = (float)($row['total_invested'] ?? 0.00);
    $row['total_profit'] = (float)($row['total_profit'] ?? 0.00);
    $row['full_name'] = (string)($row['full_name'] ?? 'Investor');
    $row['email'] = (string)($row['email'] ?? '');
    $row['phone'] = (string)($row['phone'] ?? '');
    $row['status'] = !empty($row['status']) ? strtolower((string)$row['status']) : 'active';

    if (empty($row['username'])) {
        $email_prefix = !empty($row['email']) ? explode('@', $row['email'])[0] : '';
        $clean_prefix = preg_replace('/[^a-zA-Z0-9_]/', '', $email_prefix);
        $row['username'] = !empty($clean_prefix) ? strtolower($clean_prefix) : ('investor' . (int)($row['id'] ?? 0));
    }

    if (empty($row['referral_code'])) {
        $row['referral_code'] = 'GM' . str_pad((string)($row['id'] ?? 0), 5, '0', STR_PAD_LEFT);
    }

    if (!array_key_exists('referred_by', $row)) {
        $row['referred_by'] = null;
    }

    return $row;
}

/**
 * Normalize an admin row from `admins`.
 */
function normalize_admin_row($row) {
    if (!$row || !is_array($row)) {
        return null;
    }
    $pwd = (string)($row['password_hash'] ?? $row['password'] ?? '');
    $row['password'] = $pwd;
    $row['password_hash'] = $pwd;
    $row['name'] = (string)($row['name'] ?? $row['full_name'] ?? $row['username'] ?? 'Administrator');
    $row['full_name'] = $row['name'];
    $row['username'] = (string)($row['username'] ?? $row['email'] ?? 'admin');
    $row['role'] = (string)($row['role'] ?? 'superadmin');
    return $row;
}

/**
 * Normalize an investment row from `investments` so `reference_code`, `maturity_date`,
 * `plan_name`, `roi_percentage`, `duration_days`, and `expected_return` are always available.
 */
function normalize_investment_row($inv, $default_rate = 45.00) {
    if (!$inv || !is_array($inv)) {
        return $inv;
    }
    $inv_id = (int)($inv['id'] ?? 0);
    $ref = (string)($inv['reference_code'] ?? $inv['reference'] ?? ('INV-' . str_pad((string)$inv_id, 6, '0', STR_PAD_LEFT)));
    $inv['reference_code'] = $ref;
    $inv['reference'] = $ref;

    $maturity = (string)($inv['maturity_date'] ?? $inv['end_date'] ?? date('Y-m-d H:i:s'));
    $inv['maturity_date'] = $maturity;
    $inv['end_date'] = $maturity;

    $amt = (float)($inv['amount'] ?? 0.00);
    $rate = (float)($inv['roi_percentage'] ?? $default_rate);
    if ($rate <= 0) {
        $rate = $default_rate;
    }
    $inv['roi_percentage'] = $rate;
    $inv['duration_days'] = max(1, (int)($inv['duration_days'] ?? 7));
    $inv['plan_name'] = !empty($inv['plan_name']) ? (string)$inv['plan_name'] : 'GoldMine';

    $calc = calculate_projected_returns($amt, $rate, 1);
    $inv['expected_return'] = (float)($inv['expected_return'] ?? 0) > 0 ? (float)$inv['expected_return'] : $calc['projected_total'];
    $inv['projected_profit'] = $calc['projected_profit'];
    $inv['projected_total'] = $inv['expected_return'];

    return $inv;
}

/**
 * Normalize a deposit row from `deposits` so `reference_code` and `receipt_path` are always available.
 */
function normalize_deposit_row($dep) {
    if (!$dep || !is_array($dep)) {
        return $dep;
    }
    $ref = (string)($dep['reference_code'] ?? $dep['reference'] ?? '');
    $dep['reference_code'] = $ref;
    $dep['reference'] = $ref;

    $receipt = $dep['receipt_path'] ?? $dep['receipt_file'] ?? null;
    if ($receipt !== null && strpos($receipt, '/') !== false) {
        $receipt_basename = basename($receipt);
    } else {
        $receipt_basename = $receipt;
    }
    $dep['receipt_path'] = $receipt;
    $dep['receipt_file'] = $receipt_basename;

    return $dep;
}

/**
 * Normalize a transaction row from `transactions` so `reference_code` is always available.
 */
function normalize_transaction_row($tx) {
    if (!$tx || !is_array($tx)) {
        return $tx;
    }
    $ref = (string)($tx['reference_code'] ?? $tx['reference'] ?? '');
    $tx['reference_code'] = $ref;
    $tx['reference'] = $ref;
    $tx['fee'] = (float)($tx['fee'] ?? 0.00);
    $tx['balance_after'] = (float)($tx['balance_after'] ?? 0.00);
    return $tx;
}

/**
 * Find a user by email (or username if column exists) for login authentication.
 */
function find_user_for_login($pdo, $identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') {
        return null;
    }

    if (has_column($pdo, 'users', 'username')) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1");
        $stmt->execute([$identifier, $identifier]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$identifier]);
    }

    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return normalize_user_row($row);
}

/**
 * Find a user by recipient identifier (email, ID, or username/referral_code if present).
 */
function find_recipient_user($pdo, $recipient_input, $exclude_user_id = 0, $for_update = false) {
    $recipient_input = trim((string)$recipient_input);
    if ($recipient_input === '') {
        return null;
    }

    $conditions = ["email = ?"];
    $params = [$recipient_input];

    if (has_column($pdo, 'users', 'username')) {
        $conditions[] = "username = ?";
        $params[] = $recipient_input;
    }
    if (has_column($pdo, 'users', 'referral_code')) {
        $conditions[] = "referral_code = ?";
        $params[] = $recipient_input;
    }
    if (ctype_digit($recipient_input)) {
        $conditions[] = "id = ?";
        $params[] = (int)$recipient_input;
    }
    if (preg_match('/^GM0*(\d+)$/i', $recipient_input, $m)) {
        $conditions[] = "id = ?";
        $params[] = (int)$m[1];
    }

    $where = "(" . implode(" OR ", $conditions) . ")";
    if ($exclude_user_id > 0) {
        $where .= " AND id != ?";
        $params[] = (int)$exclude_user_id;
    }

    $sql = "SELECT * FROM users WHERE {$where} LIMIT 1" . ($for_update ? " FOR UPDATE" : "");
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row && !has_column($pdo, 'users', 'username') && strpos($recipient_input, '@') === false) {
        $clean = ltrim($recipient_input, '@');
        $sqlPrefix = "SELECT * FROM users WHERE SUBSTRING_INDEX(email, '@', 1) = ?" . ($exclude_user_id > 0 ? " AND id != ?" : "") . " LIMIT 1" . ($for_update ? " FOR UPDATE" : "");
        $p2 = [$clean];
        if ($exclude_user_id > 0) {
            $p2[] = (int)$exclude_user_id;
        }
        $st2 = $pdo->prepare($sqlPrefix);
        $st2->execute($p2);
        $row = $st2->fetch(PDO::FETCH_ASSOC);
    }

    return normalize_user_row($row);
}

/**
 * Lock a user row with FOR UPDATE and return the normalized user array.
 */
function lock_user_row($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1 FOR UPDATE");
    $stmt->execute([(int)$user_id]);
    return normalize_user_row($stmt->fetch(PDO::FETCH_ASSOC));
}

/**
 * Update a user's balance (and optionally increment total_invested / total_profit)
 * using the actual `users` schema (`balance`, `total_invested`, `total_profit`, `updated_at`).
 */
function update_user_balance($pdo, $user_id, $new_balance, $added_invested = 0.0, $added_profit = 0.0) {
    $sets = [];
    $params = [];

    if (has_column($pdo, 'users', 'balance')) {
        $sets[] = "`balance` = ?";
        $params[] = round((float)$new_balance, 2);
    }
    if (has_column($pdo, 'users', 'wallet_balance')) {
        $sets[] = "`wallet_balance` = ?";
        $params[] = round((float)$new_balance, 2);
    }
    if ($added_invested != 0 && has_column($pdo, 'users', 'total_invested')) {
        $sets[] = "`total_invested` = COALESCE(`total_invested`, 0) + ?";
        $params[] = round((float)$added_invested, 2);
    }
    if ($added_profit != 0 && has_column($pdo, 'users', 'total_profit')) {
        $sets[] = "`total_profit` = COALESCE(`total_profit`, 0) + ?";
        $params[] = round((float)$added_profit, 2);
    }
    if (has_column($pdo, 'users', 'updated_at')) {
        $sets[] = "`updated_at` = NOW()";
    }

    if (empty($sets)) {
        return false;
    }

    $params[] = (int)$user_id;
    $sql = "UPDATE `users` SET " . implode(", ", $sets) . " WHERE `id` = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

/**
 * Update a user's password hash by ID using `password_hash`.
 */
function update_user_password_by_id($pdo, $user_id, $new_hash) {
    $sets = [];
    $params = [];
    if (has_column($pdo, 'users', 'password_hash')) {
        $sets[] = "`password_hash` = ?";
        $params[] = $new_hash;
    }
    if (has_column($pdo, 'users', 'password')) {
        $sets[] = "`password` = ?";
        $params[] = $new_hash;
    }
    if (has_column($pdo, 'users', 'updated_at')) {
        $sets[] = "`updated_at` = NOW()";
    }
    if (empty($sets)) {
        return false;
    }
    $params[] = (int)$user_id;
    $stmt = $pdo->prepare("UPDATE `users` SET " . implode(", ", $sets) . " WHERE `id` = ?");
    return $stmt->execute($params);
}

/**
 * Update a user's password hash by email address (used in reset-password.php).
 */
function update_user_password_by_email($pdo, $email, $new_hash) {
    $sets = [];
    $params = [];
    if (has_column($pdo, 'users', 'password_hash')) {
        $sets[] = "`password_hash` = ?";
        $params[] = $new_hash;
    }
    if (has_column($pdo, 'users', 'password')) {
        $sets[] = "`password` = ?";
        $params[] = $new_hash;
    }
    if (has_column($pdo, 'users', 'updated_at')) {
        $sets[] = "`updated_at` = NOW()";
    }
    if (empty($sets)) {
        return false;
    }
    $params[] = trim((string)$email);
    $stmt = $pdo->prepare("UPDATE `users` SET " . implode(", ", $sets) . " WHERE `email` = ?");
    return $stmt->execute($params);
}

/**
 * Sum all user balances in the database using the actual `balance` column.
 */
function sum_all_user_balances($pdo) {
    $col = get_user_balance_col($pdo);
    try {
        return (float)$pdo->query("SELECT COALESCE(SUM(`{$col}`), 0) FROM `users`")->fetchColumn();
    } catch (Exception $e) {
        return 0.00;
    }
}

/**
 * Sanitize output for safe HTML rendering (prevents XSS)
 */
function escape($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/**
 * Format currency consistently across the platform
 */
function format_money($amount, $symbol = null) {
    global $pdo;
    if ($symbol === null) {
        $symbol = isset($pdo) ? get_setting($pdo, 'currency_symbol', '₦') : '₦';
    }
    return $symbol . number_format((float)$amount, 2);
}

/**
 * Official Six GoldMine Investment Plans Specification
 * 
 * Plan      | Investment Amount
 * Starter   | ₦1,000
 * Silver    | ₦5,000
 * Gold      | ₦50,000
 * Platinum  | ₦100,000
 * Elite     | ₦500,000
 * VIP       | ₦1,000,000
 */
function get_official_six_plans_spec() {
    return [
        'Starter'  => ['amount' => 1000.00,    'duration_days' => 7,  'tagline' => 'Starter Tier · 7-Day Cycle'],
        'Silver'   => ['amount' => 5000.00,    'duration_days' => 7,  'tagline' => 'Silver Tier · 7-Day Cycle'],
        'Gold'     => ['amount' => 50000.00,   'duration_days' => 14, 'tagline' => 'Gold Tier · 14-Day Cycle'],
        'Platinum' => ['amount' => 100000.00,  'duration_days' => 14, 'tagline' => 'Platinum Tier · 14-Day Cycle'],
        'Elite'    => ['amount' => 500000.00,  'duration_days' => 30, 'tagline' => 'Elite Tier · 30-Day Cycle'],
        'VIP'      => ['amount' => 1000000.00, 'duration_days' => 30, 'tagline' => 'VIP Tier · 30-Day Cycle'],
    ];
}

/**
 * Server-Side Projected Return Calculation
 * Default Target Projection Rate = 45%
 */
function calculate_projected_returns($investment_amount, $projection_rate = 45.00, $capital_returned = 1) {
    $amount = round((float)$investment_amount, 2);
    $rate   = (float)$projection_rate > 0 ? (float)$projection_rate : 45.00;
    $profit = round(($amount * $rate) / 100, 2);
    $total  = ((int)$capital_returned === 1) ? round($amount + $profit, 2) : $profit;

    return [
        'investment_amount' => $amount,
        'projection_rate'   => $rate,
        'projected_profit'  => $profit,
        'projected_total'   => $total,
        'disclaimer'        => 'Projected returns are estimates and depend on plan terms and actual platform performance.'
    ];
}

/**
 * Normalize a plan row from `investment_plans` so all keys (`payout_interval`,
 * `capital_returned`, `tagline`, `risk_level`, `min_amount`, `max_amount`,
 * `roi_percentage`, `duration_days`, `projected_profit`, `projected_total`)
 * are guaranteed to exist without triggering PHP undefined array key warnings.
 */
function normalize_plan_row($p, $default_rate = 45.00) {
    $specs = get_official_six_plans_spec();
    $name = (string)($p['name'] ?? 'Starter');
    $spec = $specs[$name] ?? ['amount' => 1000.00, 'duration_days' => 7, 'tagline' => 'Structured Gold Allocation'];

    $amt = (float)($p['min_amount'] ?? $p['amount'] ?? $p['investment_amount'] ?? $spec['amount']);
    if ($amt <= 0) {
        $amt = (float)$spec['amount'];
    }

    $rate = (float)($p['roi_percentage'] ?? $p['roi'] ?? $p['interest_rate'] ?? $default_rate);
    if ($rate <= 0) {
        $rate = $default_rate;
    }

    $days = (int)($p['duration_days'] ?? $p['duration'] ?? $spec['duration_days']);
    if ($days <= 0) {
        $days = (int)$spec['duration_days'];
    }

    $cap_ret = isset($p['capital_returned']) ? (int)$p['capital_returned'] : 1;
    $interval = !empty($p['payout_interval']) ? (string)$p['payout_interval'] : 'end_of_term';
    $tagline = !empty($p['tagline']) ? (string)$p['tagline'] : (!empty($p['description']) ? (string)$p['description'] : $spec['tagline']);
    $risk = !empty($p['risk_level']) ? (string)$p['risk_level'] : ($name . ' Tier');
    $status = !empty($p['status']) ? strtolower((string)$p['status']) : 'active';

    $calc = calculate_projected_returns($amt, $rate, $cap_ret);

    $p['id']                    = (int)($p['id'] ?? 0);
    $p['name']                  = $name;
    $p['tagline']               = $tagline;
    $p['min_amount']            = $amt;
    $p['max_amount']            = (float)($p['max_amount'] ?? $amt);
    $p['investment_amount']     = $amt;
    $p['roi_percentage']        = $rate;
    $p['projection_rate']       = $rate;
    $p['duration_days']         = $days;
    $p['payout_interval']       = $interval;
    $p['capital_returned']      = $cap_ret;
    $p['risk_level']            = $risk;
    $p['status']                = $status;
    $p['projected_profit']      = $calc['projected_profit'];
    $p['projected_total']       = $calc['projected_total'];
    $p['projection_disclaimer'] = $calc['disclaimer'];

    return $p;
}

/**
 * Synchronize & Retrieve the Six Official Investment Plans in MySQL.
 * Dynamically adapts to the actual columns of `investment_plans` in `lhzmylpw_goldmine`
 * and never deletes or truncates any existing rows.
 */
function ensure_six_investment_plans($pdo, $include_inactive = false) {
    $official_specs = get_official_six_plans_spec();
    $default_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
    if ($default_rate <= 0) {
        $default_rate = 45.00;
    }

    $plan_cols = get_table_columns($pdo, 'investment_plans');

    try {
        if (!empty($plan_cols)) {
            $stmt = $pdo->query("SELECT * FROM `investment_plans` ORDER BY `id` ASC");
            $existing_rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];

            $by_name = [];
            foreach ($existing_rows as $row) {
                $key = strtolower(trim($row['name'] ?? ''));
                if ($key !== '' && !isset($by_name[$key])) {
                    $by_name[$key] = $row;
                }
            }

            foreach ($official_specs as $plan_name => $spec) {
                $lookup_key = strtolower($plan_name);
                if (isset($by_name[$lookup_key])) {
                    $curr = $by_name[$lookup_key];
                    $curr_min = (float)($curr['min_amount'] ?? $curr['amount'] ?? 0);
                    $curr_max = (float)($curr['max_amount'] ?? $curr_min);
                    $curr_roi = (float)($curr['roi_percentage'] ?? $curr['roi'] ?? 0);

                    if ($curr_min != $spec['amount'] || $curr_max != $spec['amount'] || $curr_roi <= 0) {
                        $upd_sets = [];
                        $upd_params = [];
                        $target_roi = $curr_roi > 0 ? $curr_roi : $default_rate;

                        if (isset($plan_cols['min_amount'])) {
                            $upd_sets[] = "`min_amount` = ?";
                            $upd_params[] = $spec['amount'];
                        } elseif (isset($plan_cols['amount'])) {
                            $upd_sets[] = "`amount` = ?";
                            $upd_params[] = $spec['amount'];
                        }
                        if (isset($plan_cols['max_amount'])) {
                            $upd_sets[] = "`max_amount` = ?";
                            $upd_params[] = $spec['amount'];
                        }
                        if (isset($plan_cols['roi_percentage'])) {
                            $upd_sets[] = "`roi_percentage` = ?";
                            $upd_params[] = $target_roi;
                        }
                        if (isset($plan_cols['duration_days']) && empty($curr['duration_days'])) {
                            $upd_sets[] = "`duration_days` = ?";
                            $upd_params[] = $spec['duration_days'];
                        }
                        if (!empty($upd_sets)) {
                            $upd_params[] = (int)$curr['id'];
                            $pdo->prepare("UPDATE `investment_plans` SET " . implode(", ", $upd_sets) . " WHERE `id` = ?")
                                ->execute($upd_params);
                        }
                    }
                } else {
                    $ins_cols = [];
                    $ins_vals = [];
                    $ins_params = [];

                    $candidate_data = [
                        'name'             => $plan_name,
                        'tagline'          => $spec['tagline'],
                        'description'      => $spec['tagline'],
                        'min_amount'       => $spec['amount'],
                        'max_amount'       => $spec['amount'],
                        'amount'           => $spec['amount'],
                        'roi_percentage'   => $default_rate,
                        'roi'              => $default_rate,
                        'interest_rate'    => $default_rate,
                        'duration_days'    => $spec['duration_days'],
                        'duration'         => $spec['duration_days'],
                        'payout_interval'  => 'end_of_term',
                        'capital_returned' => 1,
                        'risk_level'       => $plan_name . ' Tier',
                        'status'           => 'active',
                    ];

                    foreach ($candidate_data as $c_name => $c_val) {
                        if (isset($plan_cols[$c_name])) {
                            $ins_cols[] = "`{$plan_cols[$c_name]}`";
                            $ins_vals[] = "?";
                            $ins_params[] = $c_val;
                        }
                    }

                    if (isset($plan_cols['created_at'])) {
                        $ins_cols[] = "`created_at`";
                        $ins_vals[] = "NOW()";
                    }

                    if (!empty($ins_cols)) {
                        $sqlIns = "INSERT INTO `investment_plans` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
                        $pdo->prepare($sqlIns)->execute($ins_params);
                    }
                }
            }

            if (isset($plan_cols['status'])) {
                $official_names = array_keys($official_specs);
                $placeholders = implode(',', array_fill(0, count($official_names), '?'));
                $pdo->prepare("UPDATE `investment_plans` SET `status` = 'inactive' WHERE `name` NOT IN ($placeholders)")
                    ->execute($official_names);
            }

            $official_names = array_keys($official_specs);
            $placeholders = implode(',', array_fill(0, count($official_names), '?'));
            $status_clause = (!$include_inactive && isset($plan_cols['status'])) ? "AND `status` = 'active'" : "";
            $min_col = isset($plan_cols['min_amount']) ? '`min_amount`' : (isset($plan_cols['amount']) ? '`amount`' : '`id`');

            $fetchStmt = $pdo->prepare("
                SELECT * FROM `investment_plans`
                WHERE `name` IN ($placeholders) {$status_clause}
                ORDER BY {$min_col} ASC
            ");
            $fetchStmt->execute($official_names);
            $plans = $fetchStmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($plans)) {
                $seen = [];
                $result = [];
                foreach ($plans as $p) {
                    $k = strtolower(trim($p['name'] ?? ''));
                    if (isset($seen[$k])) {
                        continue;
                    }
                    $seen[$k] = true;
                    $result[] = normalize_plan_row($p, $default_rate);
                }
                return $result;
            }
        }
    } catch (Exception $e) {
        error_log("GoldMine Plan Sync Notice: " . $e->getMessage());
    }

    $fallback = [];
    $idx = 1;
    foreach ($official_specs as $plan_name => $spec) {
        $fallback[] = normalize_plan_row([
            'id'               => $idx++,
            'name'             => $plan_name,
            'tagline'          => $spec['tagline'],
            'min_amount'       => $spec['amount'],
            'max_amount'       => $spec['amount'],
            'roi_percentage'   => $default_rate,
            'duration_days'    => $spec['duration_days'],
            'payout_interval'  => 'end_of_term',
            'capital_returned' => 1,
            'risk_level'       => $plan_name . ' Tier',
            'status'           => 'active',
        ], $default_rate);
    }
    return $fallback;
}

/**
 * Retrieve platform setting from `settings` table (`key_name`, `value`, `updated_at`) with caching.
 * Also supports legacy `setting_key` / `setting_value` if present.
 */
function get_setting($pdo, $key, $default = '', $force_reload = false) {
    static $settings_cache = null;

    if ($settings_cache === null || $force_reload) {
        $settings_cache = [];
        try {
            $stmt = $pdo->query("SELECT * FROM `settings`");
            if ($stmt) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $k = $row['key_name'] ?? $row['setting_key'] ?? null;
                    $v = $row['value'] ?? $row['setting_value'] ?? null;
                    if ($k !== null) {
                        $settings_cache[(string)$k] = (string)$v;
                    }
                }
            }
        } catch (Exception $e) {
            return $default;
        }
    }

    return isset($settings_cache[$key]) && $settings_cache[$key] !== '' ? $settings_cache[$key] : $default;
}

/**
 * Insert or update a platform setting in `settings` (`key_name`, `value`, `updated_at`).
 */
function save_setting($pdo, $key, $value) {
    try {
        $cols = get_table_columns($pdo, 'settings');
        $key_col = isset($cols['key_name']) ? 'key_name' : (isset($cols['setting_key']) ? 'setting_key' : 'key_name');
        $val_col = isset($cols['value']) ? 'value' : (isset($cols['setting_value']) ? 'setting_value' : 'value');
        $has_updated = isset($cols['updated_at']);

        $chk = $pdo->prepare("SELECT COUNT(*) FROM `settings` WHERE `{$key_col}` = ?");
        $chk->execute([(string)$key]);
        $exists = (int)$chk->fetchColumn() > 0;

        if ($exists) {
            $sql = $has_updated
                ? "UPDATE `settings` SET `{$val_col}` = ?, `updated_at` = NOW() WHERE `{$key_col}` = ?"
                : "UPDATE `settings` SET `{$val_col}` = ? WHERE `{$key_col}` = ?";
            $res = $pdo->prepare($sql)->execute([(string)$value, (string)$key]);
        } else {
            $sql = $has_updated
                ? "INSERT INTO `settings` (`{$key_col}`, `{$val_col}`, `updated_at`) VALUES (?, ?, NOW())"
                : "INSERT INTO `settings` (`{$key_col}`, `{$val_col}`) VALUES (?, ?)";
            $res = $pdo->prepare($sql)->execute([(string)$key, (string)$value]);
        }

        // Refresh static cache
        get_setting($pdo, $key, '', true);
        return $res;
    } catch (Exception $e) {
        error_log("Save Setting Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Generate a unique cryptographic reference code for transactions/deposits/investments
 */
function generate_reference($prefix = 'GM') {
    return strtoupper($prefix) . '-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4)));
}

/**
 * Check if a transaction with the given `reference_code` already exists in `transactions`.
 */
function transaction_reference_exists($pdo, $reference_code, $for_update = false) {
    $cols = get_table_columns($pdo, 'transactions');
    $ref_col = isset($cols['reference_code']) ? 'reference_code' : (isset($cols['reference']) ? 'reference' : 'reference_code');
    $sql = "SELECT id FROM `transactions` WHERE `{$ref_col}` = ? LIMIT 1" . ($for_update ? " FOR UPDATE" : "");
    $stmt = $pdo->prepare($sql);
    $stmt->execute([(string)$reference_code]);
    return (bool)$stmt->fetch();
}

/**
 * Record a financial transaction in the `transactions` ledger table
 * Actual schema: id, reference_code, user_id, type, amount, fee, balance_after, status, description, created_at
 */
function record_transaction($pdo, $user_id, $type, $amount, $balance_after, $reference_code, $description, $fee = 0.00, $status = 'completed') {
    try {
        $cols = get_table_columns($pdo, 'transactions');
        if (empty($cols)) {
            return false;
        }

        $ins_cols = [];
        $ins_vals = [];
        $params = [];

        $candidates = [
            'reference_code' => (string)$reference_code,
            'reference'      => (string)$reference_code,
            'user_id'        => (int)$user_id,
            'type'           => (string)$type,
            'amount'         => round((float)$amount, 2),
            'fee'            => round((float)$fee, 2),
            'balance_after'  => round((float)$balance_after, 2),
            'status'         => (string)$status,
            'description'    => (string)$description,
        ];

        foreach ($candidates as $k => $v) {
            if (isset($cols[$k])) {
                $ins_cols[] = "`{$cols[$k]}`";
                $ins_vals[] = "?";
                $params[] = $v;
            }
        }

        if (isset($cols['created_at'])) {
            $ins_cols[] = "`created_at`";
            $ins_vals[] = "NOW()";
        }

        $sql = "INSERT INTO `transactions` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    } catch (Exception $e) {
        error_log("Transaction Log Notice: " . $e->getMessage());
        return false;
    }
}

/**
 * Insert a new investment record into `investments`.
 * Actual schema: id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 */
function create_investment_record($pdo, $data) {
    $cols = get_table_columns($pdo, 'investments');
    $ins_cols = [];
    $ins_vals = [];
    $params = [];

    $candidates = [
        'reference_code'  => (string)($data['reference_code'] ?? generate_reference('INV')),
        'user_id'         => (int)$data['user_id'],
        'plan_id'         => (int)$data['plan_id'],
        'plan_name'       => (string)($data['plan_name'] ?? 'GoldMine'),
        'amount'          => round((float)$data['amount'], 2),
        'roi_percentage'  => round((float)($data['roi_percentage'] ?? 45.00), 2),
        'expected_return' => round((float)$data['expected_return'], 2),
        'duration_days'   => max(1, (int)($data['duration_days'] ?? 7)),
        'start_date'      => (string)$data['start_date'],
        'maturity_date'   => (string)$data['maturity_date'],
        'end_date'        => (string)$data['maturity_date'],
        'status'          => (string)($data['status'] ?? 'active'),
        'admin_notes'     => $data['admin_notes'] ?? null,
    ];

    foreach ($candidates as $k => $v) {
        if (isset($cols[$k])) {
            $ins_cols[] = "`{$cols[$k]}`";
            $ins_vals[] = "?";
            $params[] = $v;
        }
    }

    if (isset($cols['created_at'])) {
        $ins_cols[] = "`created_at`";
        $ins_vals[] = "NOW()";
    }
    if (isset($cols['updated_at'])) {
        $ins_cols[] = "`updated_at`";
        $ins_vals[] = "NOW()";
    }

    $sql = "INSERT INTO `investments` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$pdo->lastInsertId();
}

/**
 * Insert a new deposit record into `deposits`.
 * Actual schema: id, reference_code, user_id, amount, payment_method, gateway_ref, receipt_path, status, admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 */
function create_deposit_record($pdo, $data) {
    $cols = get_table_columns($pdo, 'deposits');
    $ins_cols = [];
    $ins_vals = [];
    $params = [];

    $candidates = [
        'reference_code' => (string)$data['reference_code'],
        'reference'      => (string)$data['reference_code'],
        'user_id'        => (int)$data['user_id'],
        'amount'         => round((float)$data['amount'], 2),
        'payment_method' => (string)($data['payment_method'] ?? 'bank_transfer'),
        'gateway_ref'    => $data['gateway_ref'] ?? null,
        'receipt_path'   => $data['receipt_path'] ?? null,
        'receipt_file'   => $data['receipt_path'] ?? null,
        'status'         => (string)($data['status'] ?? 'pending'),
        'admin_action_by'=> $data['admin_action_by'] ?? null,
        'admin_notes'    => $data['admin_notes'] ?? null,
    ];

    foreach ($candidates as $k => $v) {
        if (isset($cols[$k])) {
            $ins_cols[] = "`{$cols[$k]}`";
            $ins_vals[] = "?";
            $params[] = $v;
        }
    }

    if (!empty($data['admin_action_at']) && isset($cols['admin_action_at'])) {
        $ins_cols[] = "`admin_action_at`";
        $ins_vals[] = "NOW()";
    }
    if (isset($cols['created_at'])) {
        $ins_cols[] = "`created_at`";
        $ins_vals[] = "NOW()";
    }
    if (isset($cols['updated_at'])) {
        $ins_cols[] = "`updated_at`";
        $ins_vals[] = "NOW()";
    }

    $sql = "INSERT INTO `deposits` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$pdo->lastInsertId();
}

/**
 * Update a deposit record's status and audit columns (`admin_action_by`, `admin_action_at`, `admin_notes`, `gateway_ref`, `amount`).
 */
function update_deposit_status($pdo, $deposit_id, $status, $admin_notes = '', $admin_id = null, $verified_amount = null, $gateway_ref = null) {
    $cols = get_table_columns($pdo, 'deposits');
    $sets = ["`status` = ?"];
    $params = [(string)$status];

    if ($verified_amount !== null && isset($cols['amount'])) {
        $sets[] = "`amount` = ?";
        $params[] = round((float)$verified_amount, 2);
    }
    if ($gateway_ref !== null && isset($cols['gateway_ref'])) {
        $sets[] = "`gateway_ref` = ?";
        $params[] = (string)$gateway_ref;
    }
    if (isset($cols['admin_notes'])) {
        $sets[] = "`admin_notes` = ?";
        $params[] = (string)$admin_notes;
    }
    if ($admin_id !== null && isset($cols['admin_action_by'])) {
        $sets[] = "`admin_action_by` = ?";
        $params[] = (int)$admin_id;
    }
    if (isset($cols['admin_action_at'])) {
        $sets[] = "`admin_action_at` = NOW()";
    } elseif ($status === 'approved' && isset($cols['approved_at'])) {
        $sets[] = "`approved_at` = NOW()";
    }
    if (isset($cols['updated_at'])) {
        $sets[] = "`updated_at` = NOW()";
    }

    $params[] = (int)$deposit_id;
    $sql = "UPDATE `deposits` SET " . implode(", ", $sets) . " WHERE `id` = ?";
    return $pdo->prepare($sql)->execute($params);
}

/**
 * Insert a new withdrawal record into `withdrawals` safely across schemas.
 */
function create_withdrawal_record($pdo, $data) {
    $cols = get_table_columns($pdo, 'withdrawals');
    $ins_cols = [];
    $ins_vals = [];
    $params = [];

    $candidates = [
        'reference_code' => (string)($data['reference_code'] ?? generate_reference('WDR')),
        'user_id'        => (int)$data['user_id'],
        'amount'         => round((float)$data['amount'], 2),
        'fee'            => round((float)($data['fee'] ?? 0.00), 2),
        'net_amount'     => round((float)$data['net_amount'], 2),
        'bank_name'      => (string)$data['bank_name'],
        'account_number' => (string)$data['account_number'],
        'account_name'   => (string)$data['account_name'],
        'status'         => (string)($data['status'] ?? 'pending'),
    ];

    foreach ($candidates as $k => $v) {
        if (isset($cols[$k])) {
            $ins_cols[] = "`{$cols[$k]}`";
            $ins_vals[] = "?";
            $params[] = $v;
        }
    }

    if (isset($cols['created_at'])) {
        $ins_cols[] = "`created_at`";
        $ins_vals[] = "NOW()";
    }
    if (isset($cols['updated_at'])) {
        $ins_cols[] = "`updated_at`";
        $ins_vals[] = "NOW()";
    }

    $sql = "INSERT INTO `withdrawals` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$pdo->lastInsertId();
}

/**
 * Update a withdrawal record's status and audit columns (`admin_action_by`, `admin_action_at`, `admin_notes`).
 */
function update_withdrawal_status($pdo, $withdrawal_id, $status, $admin_notes = '', $admin_id = null) {
    $cols = get_table_columns($pdo, 'withdrawals');
    $sets = ["`status` = ?"];
    $params = [(string)$status];

    if (isset($cols['admin_notes'])) {
        $sets[] = "`admin_notes` = ?";
        $params[] = (string)$admin_notes;
    }
    if ($admin_id !== null && isset($cols['admin_action_by'])) {
        $sets[] = "`admin_action_by` = ?";
        $params[] = (int)$admin_id;
    }
    if (isset($cols['admin_action_at'])) {
        $sets[] = "`admin_action_at` = NOW()";
    } elseif ($status === 'approved' && isset($cols['processed_at'])) {
        $sets[] = "`processed_at` = NOW()";
    }
    if (isset($cols['updated_at'])) {
        $sets[] = "`updated_at` = NOW()";
    }

    $params[] = (int)$withdrawal_id;
    $sql = "UPDATE `withdrawals` SET " . implode(", ", $sets) . " WHERE `id` = ?";
    return $pdo->prepare($sql)->execute($params);
}

/**
 * Save or update a user's default payout bank coordinates in `user_bank_details`.
 */
function save_user_bank_details($pdo, $user_id, $bank_name, $account_number, $account_name, $routing_code = '') {
    try {
        $cols = get_table_columns($pdo, 'user_bank_details');
        if (empty($cols)) {
            return false;
        }

        $chk = $pdo->prepare("SELECT id FROM `user_bank_details` WHERE `user_id` = ? LIMIT 1");
        $chk->execute([(int)$user_id]);
        $existing = $chk->fetch();

        if ($existing) {
            $sets = ["`bank_name` = ?", "`account_number` = ?", "`account_name` = ?"];
            $params = [(string)$bank_name, (string)$account_number, (string)$account_name];
            if (isset($cols['routing_code'])) {
                $sets[] = "`routing_code` = ?";
                $params[] = (string)$routing_code;
            }
            if (isset($cols['updated_at'])) {
                $sets[] = "`updated_at` = NOW()";
            }
            $params[] = (int)$user_id;
            return $pdo->prepare("UPDATE `user_bank_details` SET " . implode(", ", $sets) . " WHERE `user_id` = ?")->execute($params);
        } else {
            $ins_cols = ["`user_id`", "`bank_name`", "`account_number`", "`account_name`"];
            $ins_vals = ["?", "?", "?", "?"];
            $params = [(int)$user_id, (string)$bank_name, (string)$account_number, (string)$account_name];
            if (isset($cols['routing_code'])) {
                $ins_cols[] = "`routing_code`";
                $ins_vals[] = "?";
                $params[] = (string)$routing_code;
            }
            if (isset($cols['created_at'])) {
                $ins_cols[] = "`created_at`";
                $ins_vals[] = "NOW()";
            }
            if (isset($cols['updated_at'])) {
                $ins_cols[] = "`updated_at`";
                $ins_vals[] = "NOW()";
            }
            return $pdo->prepare("INSERT INTO `user_bank_details` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")")->execute($params);
        }
    } catch (Exception $e) {
        error_log("Bank Details Save Notice: " . $e->getMessage());
        return false;
    }
}

/**
 * Create a user or global notification safely
 */
function create_notification($pdo, $user_id, $title, $message, $type = 'info') {
    try {
        $cols = get_table_columns($pdo, 'notifications');
        if (empty($cols)) {
            return false;
        }

        $ins_cols = [];
        $ins_vals = [];
        $params = [];

        $candidates = [
            'user_id' => $user_id !== null ? (int)$user_id : null,
            'title'   => (string)$title,
            'message' => (string)$message,
            'type'    => (string)$type,
            'is_read' => 0,
        ];

        foreach ($candidates as $k => $v) {
            if (isset($cols[$k])) {
                $ins_cols[] = "`{$cols[$k]}`";
                $ins_vals[] = "?";
                $params[] = $v;
            }
        }
        if (isset($cols['created_at'])) {
            $ins_cols[] = "`created_at`";
            $ins_vals[] = "NOW()";
        }

        $sql = "INSERT INTO `notifications` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
        return $pdo->prepare($sql)->execute($params);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Record an admin or security audit log safely
 */
function record_audit_log($pdo, $admin_id, $user_id, $action, $details = '') {
    try {
        $cols = get_table_columns($pdo, 'audit_logs');
        if (empty($cols)) {
            return false;
        }
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 250);

        $ins_cols = [];
        $ins_vals = [];
        $params = [];

        $candidates = [
            'admin_id'    => $admin_id !== null ? (int)$admin_id : null,
            'user_id'     => $user_id !== null ? (int)$user_id : null,
            'action'      => (string)$action,
            'details'     => (string)$details,
            'description' => (string)$details,
            'ip_address'  => $ip,
            'user_agent'  => $ua,
        ];

        foreach ($candidates as $k => $v) {
            if (isset($cols[$k])) {
                $ins_cols[] = "`{$cols[$k]}`";
                $ins_vals[] = "?";
                $params[] = $v;
            }
        }
        if (isset($cols['created_at'])) {
            $ins_cols[] = "`created_at`";
            $ins_vals[] = "NOW()";
        }

        $sql = "INSERT INTO `audit_logs` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")";
        return $pdo->prepare($sql)->execute($params);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Securely validate and upload a bank transfer receipt image or PDF
 */
function handle_receipt_upload($file_input) {
    if (!isset($file_input) || $file_input['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Please select a valid payment receipt file to upload.'];
    }

    $max_size = 5 * 1024 * 1024;
    if ($file_input['size'] > $max_size) {
        return ['success' => false, 'error' => 'Receipt file size must not exceed 5MB.'];
    }

    $allowed_mimes = [
        'image/jpeg'      => 'jpg',
        'image/png'       => 'png',
        'image/webp'      => 'webp',
        'application/pdf' => 'pdf'
    ];

    $mime = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file_input['tmp_name']);
    } elseif (function_exists('mime_content_type')) {
        $mime = mime_content_type($file_input['tmp_name']);
    }

    if (!isset($allowed_mimes[$mime])) {
        $ext_check = strtolower(pathinfo($file_input['name'] ?? '', PATHINFO_EXTENSION));
        $ext_map = ['jpg' => 'jpg', 'jpeg' => 'jpg', 'png' => 'png', 'webp' => 'webp', 'pdf' => 'pdf'];
        if (!isset($ext_map[$ext_check])) {
            return ['success' => false, 'error' => 'Invalid file format. Only JPG, PNG, WEBP, and PDF receipts are accepted.'];
        }
        $ext = $ext_map[$ext_check];
    } else {
        $ext = $allowed_mimes[$mime];
    }

    $filename = 'receipt_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $upload_dir = __DIR__ . '/../uploads/receipts/';

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $destination = $upload_dir . $filename;
    if (!move_uploaded_file($file_input['tmp_name'], $destination)) {
        return ['success' => false, 'error' => 'Failed to save uploaded receipt on server.'];
    }

    return ['success' => true, 'filename' => $filename];
}
