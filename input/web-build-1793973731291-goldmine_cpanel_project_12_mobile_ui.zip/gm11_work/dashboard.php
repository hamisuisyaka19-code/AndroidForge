<?php
/**
 * Main User Investment Dashboard
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` schema (`balance`, `total_invested`, `total_profit`).
 */
$page_title = "Portfolio Dashboard";
require_once __DIR__ . '/includes/header.php';
require_user_login();

$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$default_projection_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
if ($default_projection_rate <= 0) {
    $default_projection_rate = 45.00;
}

// 1. Total Approved Deposits
$stmtDep = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE user_id = ? AND status = 'approved'");
$stmtDep->execute([$user_id]);
$total_deposits = (float)$stmtDep->fetchColumn();

// 2. Active Investments Capital & Count
$stmtInv = $pdo->prepare("SELECT COALESCE(SUM(amount), 0), COUNT(*) FROM investments WHERE user_id = ? AND status = 'active'");
$stmtInv->execute([$user_id]);
list($active_investments_sum, $active_investments_count) = $stmtInv->fetch(PDO::FETCH_NUM);
$active_investments_sum = max((float)$active_investments_sum, (float)($user['total_invested'] ?? 0));

// 3. Total Earned Profits (from `users.total_profit` and verified `roi_profit` transactions)
$stmtProfit = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = ? AND type = 'roi_profit' AND status = 'completed'");
$stmtProfit->execute([$user_id]);
$earned_from_tx = (float)$stmtProfit->fetchColumn();
$total_profits = max((float)($user['total_profit'] ?? 0.00), $earned_from_tx);

// 4. Total Withdrawals (Approved + Pending)
$stmtWithApproved = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE user_id = ? AND status = 'approved'");
$stmtWithApproved->execute([$user_id]);
$total_withdrawals_approved = (float)$stmtWithApproved->fetchColumn();

$stmtWithPending = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE user_id = ? AND status = 'pending'");
$stmtWithPending->execute([$user_id]);
$total_withdrawals_pending = (float)$stmtWithPending->fetchColumn();

// 5. Total Referrals (Guarded so it only queries `referred_by` if the column exists)
$total_referrals = 0;
if (has_column($pdo, 'users', 'referred_by') && !empty($user['referral_code'])) {
    try {
        $stmtRef = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by = ?");
        $stmtRef->execute([$user['referral_code']]);
        $total_referrals = (int)$stmtRef->fetchColumn();
    } catch (Exception $e) {
        $total_referrals = 0;
    }
}

// 6. Active Investment Portfolio List using actual `investments` schema
$stmtActiveList = $pdo->prepare("
    SELECT i.*,
           COALESCE(NULLIF(i.plan_name, ''), p.name) AS resolved_plan_name,
           COALESCE(NULLIF(i.roi_percentage, 0), p.roi_percentage) AS resolved_roi_percentage,
           COALESCE(NULLIF(i.duration_days, 0), p.duration_days) AS resolved_duration_days
    FROM investments i
    LEFT JOIN investment_plans p ON i.plan_id = p.id
    WHERE i.user_id = ? AND i.status = 'active'
    ORDER BY i.created_at DESC
    LIMIT 5
");
$stmtActiveList->execute([$user_id]);
$raw_active_list = $stmtActiveList->fetchAll(PDO::FETCH_ASSOC);
$active_list = [];
foreach ($raw_active_list as $row) {
    $row['plan_name'] = $row['resolved_plan_name'] ?? $row['plan_name'] ?? 'GoldMine';
    $row['roi_percentage'] = $row['resolved_roi_percentage'] ?? $row['roi_percentage'] ?? $default_projection_rate;
    $row['duration_days'] = $row['resolved_duration_days'] ?? $row['duration_days'] ?? 7;
    $active_list[] = normalize_investment_row($row, $default_projection_rate);
}

// 7. Recent Transactions Ledger
$stmtTx = $pdo->prepare("
    SELECT * FROM transactions
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 6
");
$stmtTx->execute([$user_id]);
$raw_transactions = $stmtTx->fetchAll(PDO::FETCH_ASSOC);
$recent_transactions = array_map('normalize_transaction_row', $raw_transactions);
?>

<div style="display: flex; flex-direction: column; gap: 28px;">

  <!-- Welcome & Quick Actions Bar -->
  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        Investor Command Center
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Welcome back, <strong style="color: #FFF;"><?php echo escape($user['full_name']); ?></strong> (<span style="color: #D4AF37;"><?php echo escape($user['email']); ?></span>)
      </p>
    </div>

    <div style="display: flex; flex-wrap: wrap; gap: 12px;">
      <a href="deposit.php" class="btn-gold">
        + Fund Wallet
      </a>
      <a href="invest.php" class="btn-outline-gold">
        Allocate Plan
      </a>
      <a href="withdraw.php" class="btn-outline-gold">
        Withdraw
      </a>
      <a href="transfer.php" class="btn-outline-gold">
        Transfer Money
      </a>
    </div>
  </div>

  <!-- Primary 6-Card Financial KPI Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px;">
    <!-- 1. Available Wallet Balance -->
    <div class="gm-card" style="border-color: rgba(212, 175, 55, 0.45); background: linear-gradient(155deg, #0E2217 0%, #08130D 100%);">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Available Balance
      </div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 1.95rem; font-weight: 800; margin-bottom: 8px;">
        <?php echo format_money($user['balance'], $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #34D399;">
        Ready for immediate allocation or withdrawal
      </div>
    </div>

    <!-- 2. Active Investments -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Active Investments
      </div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.85rem; font-weight: 700; color: #FFF; margin-bottom: 8px;">
        <?php echo format_money($active_investments_sum, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #D4AF37;">
        <?php echo (int)$active_investments_count; ?> active portfolio <?php echo (int)$active_investments_count === 1 ? 'position' : 'positions'; ?>
      </div>
    </div>

    <!-- 3. Total Profit Earned -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Actual Earned Profits
      </div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.85rem; font-weight: 700; color: #34D399; margin-bottom: 8px;">
        +<?php echo format_money($total_profits, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #8E9E94;">
        Cumulative verified yield returns
      </div>
    </div>

    <!-- 4. Total Approved Deposits -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Total Deposits
      </div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.85rem; font-weight: 700; color: #FFF; margin-bottom: 8px;">
        <?php echo format_money($total_deposits, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #8E9E94;">
        Verified capital inflows
      </div>
    </div>

    <!-- 5. Total Withdrawals -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Total Withdrawals
      </div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.85rem; font-weight: 700; color: #FFF; margin-bottom: 8px;">
        <?php echo format_money($total_withdrawals_approved, $currency_symbol); ?>
      </div>
      <div style="font-size: 0.78rem; color: #FBBF24;">
        Pending: <?php echo format_money($total_withdrawals_pending, $currency_symbol); ?>
      </div>
    </div>

    <!-- 6. Referral Network -->
    <div class="gm-card">
      <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; color: #9FB1A6; margin-bottom: 8px;">
        Affiliate Partners
      </div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.85rem; font-weight: 700; color: #D4AF37; margin-bottom: 8px;">
        <?php echo $total_referrals; ?> Referred
      </div>
      <div style="font-size: 0.78rem; color: #8E9E94;">
        Code: <strong style="color: #FFF;"><?php echo escape($user['referral_code'] ?? 'Not available'); ?></strong>
      </div>
    </div>
  </div>

  <!-- Active Investments & Live Countdown Section -->
  <div class="gm-card" style="padding: 26px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <div>
        <h2 class="font-gold-serif" style="font-size: 1.3rem; color: #FFF;">Active Investment Positions</h2>
        <p style="font-size: 0.82rem; color: #8E9E94;">Real-time maturity progress &amp; projected vs. earned yield tracking</p>
      </div>
      <a href="my-investments.php" style="font-size: 0.85rem; color: #D4AF37; font-weight: 600;">View Full Portfolio &rarr;</a>
    </div>

    <?php if (empty($active_list)): ?>
      <div style="text-align: center; padding: 36px 20px; background: rgba(6, 14, 10, 0.6); border: 1px dashed rgba(212, 175, 55, 0.25); border-radius: 10px;">
        <p style="color: #9FB1A6; margin-bottom: 16px;">You do not have any active investment positions running right now.</p>
        <a href="invest.php" class="btn-gold">Explore 6 Investment Plans</a>
      </div>
    <?php else: ?>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px;">
        <?php foreach ($active_list as $inv): 
          $start_ts = strtotime($inv['start_date']);
          $maturity_ts = strtotime($inv['maturity_date']);
          $now_ts = time();
          $total_sec = max(1, $maturity_ts - $start_ts);
          $elapsed_sec = max(0, min($total_sec, $now_ts - $start_ts));
          $progress_pct = round(($elapsed_sec / $total_sec) * 100, 1);
          $amt = (float)$inv['amount'];
          $rate = (float)($inv['roi_percentage'] ?: $default_projection_rate);
          $proj_total = (float)$inv['expected_return'] > 0 ? (float)$inv['expected_return'] : ($amt + ($amt * $rate / 100));
          $proj_profit = max(0, $proj_total - $amt);
        ?>
          <div style="background: #07120C; border: 1px solid #1B3828; border-radius: 10px; padding: 18px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <strong class="font-gold-serif" style="color: #D4AF37; font-size: 1.05rem;">
                <?php echo escape($inv['plan_name'] ?: 'GoldMine Plan'); ?>
              </strong>
              <span class="badge-clean badge-active">Active</span>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 14px; font-size: 0.82rem;">
              <div>
                <div style="color: #7D8F84;">Principal</div>
                <strong class="tabular-nums" style="color: #FFF; font-size: 0.95rem;">
                  <?php echo format_money($amt, $currency_symbol); ?>
                </strong>
              </div>
              <div>
                <div style="color: #7D8F84;">Projected Profit</div>
                <strong class="tabular-nums" style="color: #D4AF37; font-size: 0.95rem;">
                  +<?php echo format_money($proj_profit, $currency_symbol); ?>
                </strong>
              </div>
              <div>
                <div style="color: #7D8F84;">Projected Total</div>
                <strong class="tabular-nums" style="color: #34D399; font-size: 0.95rem;">
                  <?php echo format_money($proj_total, $currency_symbol); ?>
                </strong>
              </div>
            </div>

            <!-- Progress Bar -->
            <div style="background: #040906; height: 7px; border-radius: 99px; overflow: hidden; margin-bottom: 10px;">
              <div style="width: <?php echo $progress_pct; ?>%; height: 100%; background: linear-gradient(90deg, #D4AF37, #34D399);"></div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.78rem; color: #9FB1A6;">
              <span>Progress: <strong class="tabular-nums"><?php echo $progress_pct; ?>%</strong></span>
              <span class="tabular-nums countdown-timer" data-end="<?php echo $maturity_ts; ?>" style="color: #F3E5AB; font-weight: 600;">
                Calculating...
              </span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Recent Transactions Ledger Table -->
  <div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
      <h2 class="font-gold-serif" style="font-size: 1.3rem; color: #FFF;">Recent Financial Ledger</h2>
      <a href="transactions.php" style="font-size: 0.85rem; color: #D4AF37; font-weight: 600;">All Transactions &rarr;</a>
    </div>

    <div class="gm-table-container">
      <table class="gm-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Reference</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent_transactions)): ?>
            <tr>
              <td colspan="6" style="text-align: center; color: #8E9E94; padding: 28px;">
                No transactions recorded yet. Make your first deposit to begin.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($recent_transactions as $tx): 
              $is_positive = in_array($tx['type'], ['deposit', 'roi_profit', 'referral_bonus', 'refund']);
            ?>
              <tr>
                <td class="tabular-nums" style="font-size: 0.82rem; color: #94A3B8;">
                  <?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?>
                </td>
                <td style="text-transform: capitalize; font-weight: 600; color: #FFF;">
                  <?php echo str_replace('_', ' ', escape($tx['type'])); ?>
                </td>
                <td class="tabular-nums" style="font-size: 0.8rem; color: #D4AF37;">
                  <?php echo escape($tx['reference_code']); ?>
                </td>
                <td style="font-size: 0.85rem; color: #C2D1C7;">
                  <?php echo escape($tx['description']); ?>
                </td>
                <td class="tabular-nums" style="font-weight: 700; color: <?php echo $is_positive ? '#34D399' : '#F87171'; ?>;">
                  <?php echo ($is_positive ? '+' : '-') . format_money($tx['amount'], $currency_symbol); ?>
                </td>
                <td>
                  <span class="badge-clean badge-<?php echo escape($tx['status']); ?>">
                    <?php echo escape($tx['status']); ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<script>
function updateCountdowns() {
  const now = Math.floor(Date.now() / 1000);
  document.querySelectorAll('.countdown-timer').forEach(el => {
    const end = parseInt(el.getAttribute('data-end'), 10);
    const diff = end - now;
    if (diff <= 0) {
      el.innerText = 'Matured (Awaiting Settlement)';
      el.style.color = '#34D399';
      return;
    }
    const d = Math.floor(diff / 86400);
    const h = Math.floor((diff % 86400) / 3600);
    const m = Math.floor((diff % 3600) / 60);
    const s = diff % 60;
    el.innerText = `${d}d ${h}h ${m}m ${s}s remaining`;
  });
}
setInterval(updateCountdowns, 1000);
updateCountdowns();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
