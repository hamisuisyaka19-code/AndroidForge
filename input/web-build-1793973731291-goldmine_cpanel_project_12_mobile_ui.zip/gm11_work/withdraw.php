<?php
/**
 * Request Funds Withdrawal
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Withdraw Funds";
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$min_withdrawal = (float)get_setting($pdo, 'min_withdrawal', '1000.00');
$withdrawal_fee_percent = (float)get_setting($pdo, 'withdrawal_fee_percent', '1.50');

// Fetch saved user bank details if any
$stmtBank = $pdo->prepare("SELECT * FROM user_bank_details WHERE user_id = ? LIMIT 1");
$stmtBank->execute([$user_id]);
$saved_bank = $stmtBank->fetch();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'request_withdrawal') {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $amount = round((float)($_POST['amount'] ?? 0), 2);
        $bank_name = trim($_POST['bank_name'] ?? '');
        $account_number = trim($_POST['account_number'] ?? '');
        $account_name = trim($_POST['account_name'] ?? '');

        if ($amount < $min_withdrawal) {
            $error = "Minimum withdrawal amount is " . format_money($min_withdrawal, $currency_symbol) . ".";
        } elseif (empty($bank_name) || empty($account_number) || empty($account_name)) {
            $error = "Please provide complete receiving bank account details.";
        } else {
            try {
                $pdo->beginTransaction();

                // Lock user row to prevent double-withdrawal race conditions
                $lockedUser = lock_user_row($pdo, $user_id);
                $current_balance = (float)($lockedUser['balance'] ?? 0.00);

                if ($current_balance < $amount) {
                    $pdo->rollBack();
                    $error = "Insufficient available balance (" . format_money($current_balance, $currency_symbol) . ") for this withdrawal.";
                } else {
                    $fee = round($amount * ($withdrawal_fee_percent / 100), 2);
                    $net_amount = round($amount - $fee, 2);
                    $new_balance = round($current_balance - $amount, 2);

                    // 1. Deduct from user balance immediately (held in escrow pending admin approval; refunded if rejected)
                    update_user_balance($pdo, $user_id, $new_balance);

                    // 2. Save or update user default bank details for convenience
                    save_user_bank_details($pdo, $user_id, $bank_name, $account_number, $account_name);

                    // 3. Create withdrawal request record
                    $refTx = generate_reference('WDR');
                    create_withdrawal_record($pdo, [
                        'reference_code' => $refTx,
                        'user_id'        => $user_id,
                        'amount'         => $amount,
                        'fee'            => $fee,
                        'net_amount'     => $net_amount,
                        'bank_name'      => $bank_name,
                        'account_number' => $account_number,
                        'account_name'   => $account_name,
                        'status'         => 'pending',
                    ]);

                    // 4. Record transaction in ledger
                    record_transaction(
                        $pdo,
                        $user_id,
                        'withdrawal',
                        $amount,
                        $new_balance,
                        $refTx,
                        "Withdrawal request to {$bank_name} ({$account_number})",
                        $fee,
                        'pending'
                    );

                    // 5. Notify user
                    create_notification(
                        $pdo,
                        $user_id,
                        "Withdrawal Request Submitted",
                        "Your withdrawal request for " . format_money($amount, $currency_symbol) . " (Net payout: " . format_money($net_amount, $currency_symbol) . ") is queued for disbursement.",
                        "info"
                    );

                    // 6. Audit log
                    record_audit_log($pdo, null, $user_id, 'WITHDRAWAL_REQUESTED', "Requested withdrawal of {$amount} to {$bank_name} - {$account_number}");

                    $pdo->commit();

                    $user['balance'] = $new_balance;
                    $user['wallet_balance'] = $new_balance;
                    $success = "Withdrawal request of " . format_money($amount, $currency_symbol) . " submitted! Net payout of " . format_money($net_amount, $currency_symbol) . " will be disbursed to your bank account upon verification.";
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log("Withdrawal Error: " . $e->getMessage());
                $error = "An error occurred while submitting your withdrawal. Please try again.";
            }
        }
    }
}

// Fetch user's withdrawal history
$wHistoryStmt = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 12");
$wHistoryStmt->execute([$user_id]);
$withdrawal_history = $wHistoryStmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 1100px; margin: 0 auto; padding-bottom: 50px;">

  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Withdraw Portfolio Funds
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Disburse matured capital and earned profits directly to your verified bank account.
    </p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 14px 18px; margin-bottom: 24px; color: #FCA5A5; font-size: 0.9rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 16px 20px; margin-bottom: 24px; color: #6EE7B7; font-size: 0.92rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 1.15fr; gap: 28px;" class="calc-grid">
    <!-- Left: Balance & Fee Breakdown -->
    <div>
      <div class="gm-card" style="margin-bottom: 20px; border-color: rgba(212,175,55,0.4);">
        <div style="font-size: 0.8rem; color: #8E9E94; text-transform: uppercase; letter-spacing: 0.05em;">Withdrawable Wallet Balance</div>
        <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 2.2rem; font-weight: 800; margin: 8px 0;">
          <?php echo format_money($user['balance'], $currency_symbol); ?>
        </div>
        <div style="font-size: 0.8rem; color: #9FB1A6;">
          Minimum Withdrawal: <strong><?php echo format_money($min_withdrawal, $currency_symbol); ?></strong> · Processing Fee: <strong><?php echo $withdrawal_fee_percent; ?>%</strong>
        </div>
      </div>

      <div class="gm-card" style="background: #06100B;">
        <h3 class="font-gold-serif" style="font-size: 1.05rem; color: #D4AF37; margin-bottom: 12px;">
          Disbursement &amp; Refund Policy
        </h3>
        <ul style="list-style: none; display: flex; flex-direction: column; gap: 10px; font-size: 0.84rem; color: #9FB1A6; line-height: 1.5;">
          <li>• Requested funds are deducted from your available balance and placed in settlement queue.</li>
          <li>• If a withdrawal request is declined by an administrator (e.g., due to incorrect bank details), <strong>100% of the requested amount is automatically refunded</strong> back to your wallet balance.</li>
          <li>• Bank transfers are typically settled within 1–24 hours following treasury review.</li>
        </ul>
      </div>
    </div>

    <!-- Right: Withdrawal Request Form -->
    <div class="gm-card" style="padding: 28px;">
      <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 20px;">
        Destination Bank Coordinates
      </h3>

      <form method="POST" action="withdraw.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="request_withdrawal">

        <div class="form-group">
          <label class="form-label">Withdrawal Amount (<?php echo escape($currency_symbol); ?>)</label>
          <input type="number" step="0.01" min="<?php echo $min_withdrawal; ?>" max="<?php echo (float)$user['balance']; ?>" id="wd_amount" name="amount" class="form-control tabular-nums" required placeholder="Enter amount" oninput="calcNetWithdrawal()">
        </div>

        <div style="background: #050C08; border: 1px solid #162E21; border-radius: 8px; padding: 12px 16px; margin-bottom: 18px; font-size: 0.84rem;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
            <span style="color: #8E9E94;">Fee (<?php echo $withdrawal_fee_percent; ?>%):</span>
            <span id="wd_fee_display" class="tabular-nums" style="color: #F87171;"><?php echo escape($currency_symbol); ?>0.00</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-weight: 700;">
            <span style="color: #D4AF37;">Net Bank Payout:</span>
            <span id="wd_net_display" class="tabular-nums" style="color: #34D399;"><?php echo escape($currency_symbol); ?>0.00</span>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Receiving Bank Name</label>
          <input type="text" name="bank_name" class="form-control" required value="<?php echo escape($saved_bank['bank_name'] ?? ''); ?>" placeholder="e.g. Zenith Bank, GTBank, Access Bank">
        </div>

        <div class="form-group">
          <label class="form-label">Account Number / IBAN</label>
          <input type="text" name="account_number" class="form-control tabular-nums" required value="<?php echo escape($saved_bank['account_number'] ?? ''); ?>" placeholder="Enter account number">
        </div>

        <div class="form-group">
          <label class="form-label">Account Holder Legal Name</label>
          <input type="text" name="account_name" class="form-control" required value="<?php echo escape($saved_bank['account_name'] ?? $user['full_name']); ?>" placeholder="Must match account beneficiary">
        </div>

        <button type="submit" class="btn-gold" style="width: 100%; padding: 13px; font-size: 1rem;">
          Submit Withdrawal Request
        </button>
      </form>
    </div>
  </div>

  <!-- Withdrawal History Table -->
  <div style="margin-top: 40px;">
    <h2 class="font-gold-serif" style="font-size: 1.3rem; color: #FFF; margin-bottom: 16px;">
      Withdrawal Request History
    </h2>

    <div class="gm-table-container">
      <table class="gm-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Gross Amount</th>
            <th>Fee</th>
            <th>Net Payout</th>
            <th>Bank Details</th>
            <th>Status</th>
            <th>Admin Remarks</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($withdrawal_history)): ?>
            <tr>
              <td colspan="7" style="text-align: center; color: #8E9E94; padding: 28px;">
                No withdrawal requests submitted yet.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($withdrawal_history as $wh): ?>
              <tr>
                <td class="tabular-nums" style="font-size: 0.82rem; color: #94A3B8;">
                  <?php echo date('M d, Y H:i', strtotime($wh['created_at'])); ?>
                </td>
                <td class="tabular-nums" style="font-weight: 700; color: #FFF;">
                  <?php echo format_money($wh['amount'], $currency_symbol); ?>
                </td>
                <td class="tabular-nums" style="font-size: 0.82rem; color: #F87171;">
                  <?php echo format_money($wh['fee'], $currency_symbol); ?>
                </td>
                <td class="tabular-nums" style="font-weight: 700; color: #34D399;">
                  <?php echo format_money($wh['net_amount'], $currency_symbol); ?>
                </td>
                <td style="font-size: 0.84rem; color: #C2D1C7;">
                  <strong><?php echo escape($wh['bank_name']); ?></strong> — <?php echo escape($wh['account_number']); ?><br>
                  <span style="font-size: 0.76rem; color: #8E9E94;"><?php echo escape($wh['account_name']); ?></span>
                </td>
                <td>
                  <span class="badge-clean badge-<?php echo escape($wh['status']); ?>">
                    <?php echo escape($wh['status']); ?>
                  </span>
                </td>
                <td style="font-size: 0.82rem; color: #9FB1A6;">
                  <?php echo escape($wh['admin_notes'] ?: '—'); ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const WD_FEE_PCT = <?php echo (float)$withdrawal_fee_percent; ?>;
const WD_SYM = <?php echo json_encode($currency_symbol); ?>;

function calcNetWithdrawal() {
  const val = parseFloat(document.getElementById('wd_amount').value) || 0;
  const fee = (val * WD_FEE_PCT) / 100;
  const net = Math.max(0, val - fee);
  document.getElementById('wd_fee_display').innerText = WD_SYM + fee.toFixed(2);
  document.getElementById('wd_net_display').innerText = WD_SYM + net.toFixed(2);
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
