<?php
/**
 * GoldMine Investment Platform - Configuration Template
 * 
 * Instructions for cPanel Shared Hosting:
 * 1. Copy or rename this file to "config.php" in the same root folder.
 * 2. Enter the MySQL user password you created in cPanel MySQL Databases.
 * 3. Configure optional CRON_SECRET or FLUTTERWAVE_SECRET_KEY as needed.
 * 4. Save the file. db.php will automatically load these credentials.
 */

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'lhzmylpw_goldmine');
define('DB_USER', 'lhzmylpw_goldmineapp');
define('DB_PASS', ''); // Enter your cPanel MySQL user password here
define('DB_CHARSET', 'utf8mb4');

// Security & Automation Keys
// Leave empty to disallow HTTP cron triggers (CLI-only mode), or set a 32+ character random secret.
define('CRON_SECRET', '');

// Automation Switch: Set to true once verified by treasury
define('CRON_SETTLEMENT_ENABLED', false);

// Payment Gateway (Flutterwave)
define('FLUTTERWAVE_SECRET_KEY', '');
define('FLUTTERWAVE_SECRET_HASH', '');

// Application Base URLs
define('APP_NAME', 'GoldMine Investment Platform');
define('API_BASE_URL', 'https://goalmindai.com.ng/api/v1/');
