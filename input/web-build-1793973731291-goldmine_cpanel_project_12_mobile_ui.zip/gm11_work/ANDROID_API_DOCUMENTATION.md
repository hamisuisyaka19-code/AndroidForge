# GoldMine Investment Platform — AndroidForce Integration Guide & REST API v1 Reference

**API Base URL**: `https://goalmindai.com.ng/api/v1/`  
**Database**: MySQL `lhzmylpw_goldmine` (User: `lhzmylpw_goldmineapp`)  
**Format**: `application/json` (UTF-8)  
**Authentication**: HTTP Bearer Token (`Authorization: Bearer <64_char_hex_token>`)  

---

## 1. Architectural Overview & Six Official Plans

The GoldMine Investment Platform provides a unified REST API (`v1`) shared by the web interface and AndroidForce mobile applications.

### Six Official Investment Plans (`GET /api/v1/plans`)
Only these six official plans are active and returned by the API:

| Plan Name | Investment Amount | Target Projection Rate | Projected Profit (45%) | Projected Total |
| :--- | :--- | :--- | :--- | :--- |
| **Starter** | ₦1,000 | 45% | ₦450 | ₦1,450 |
| **Silver** | ₦5,000 | 45% | ₦2,250 | ₦7,250 |
| **Gold** | ₦50,000 | 45% | ₦22,500 | ₦72,500 |
| **Platinum** | ₦100,000 | 45% | ₦45,000 | ₦145,000 |
| **Elite** | ₦500,000 | 45% | ₦225,000 | ₦725,000 |
| **VIP** | ₦1,000,000 | 45% | ₦450,000 | ₦1,450,000 |

- **Projection Separation**: All 45% returns are returned as `projected_profit` and `projected_total` with an explicit `projection_disclaimer`. Projected returns are estimates and are never automatically credited to user wallets upon investment creation (`earned_amount = 0.00`).
- **Atomic Server-Side Locking**: All financial mutations (`/investments`, `/deposits/create`, `/withdrawals`) execute inside database transactions with row-level locks (`FOR UPDATE`) and duplicate submission prevention.

---

## 2. Standard JSON Response Envelope

Every endpoint returns a consistent JSON structure:

```json
{
  "success": true,
  "message": "Operation completed successfully.",
  "timestamp": "2026-11-05T12:00:00+00:00",
  "version": "v1.0",
  "data": { ... },
  "errors": null
}
```

---

## 3. Complete Endpoint Reference (`https://goalmindai.com.ng/api/v1/`)

### 3.1 Authentication & Account
- **`POST /api/v1/auth/register`** (or `/api/v1/register`):
  - Body: `{"full_name": "...", "username": "...", "email": "...", "phone": "...", "password": "...", "referral_code": "..."}`
  - Returns: `token`, `expires_at`, and `user` profile object.
- **`POST /api/v1/auth/login`** (or `/api/v1/login`):
  - Body: `{"identifier": "username_or_email", "password": "..."}`
  - Returns: `token`, `expires_at`, and `user` profile object.
- **`POST /api/v1/auth/logout`** (or `/api/v1/logout`):
  - Headers: `Authorization: Bearer <token>`
  - Revokes the active Bearer token.
- **`POST /api/v1/auth/forgot-password`**:
  - Body: `{"email": "user@example.com"}`

### 3.2 User Profile, Wallet & Dashboard
- **`GET /api/v1/user/profile`** (or `/api/v1/profile`):
  - Returns authenticated user profile, `wallet_balance`, `total_profit`, `referral_code`, and `bank_details`.
- **`PUT /api/v1/user/profile`**:
  - Body: `{"full_name": "...", "phone": "..."}`
- **`PUT /api/v1/user/bank-details`**:
  - Body: `{"bank_name": "...", "account_number": "...", "account_name": "...", "routing_code": "..."}`
- **`GET /api/v1/dashboard/stats`** (or `/api/v1/wallet`):
  - Returns `wallet_balance`, `total_profit`, `active_invested`, `pending_deposits`, `pending_withdrawals`, `unread_notifications`, and `recent_transactions`.

### 3.3 Investment Plans, Creating Investments & My Investments
- **`GET /api/v1/plans`**:
  - Public or authenticated. Returns the **6 official plans** (`Starter`, `Silver`, `Gold`, `Platinum`, `Elite`, `VIP`) with `investment_amount`, `roi_percentage` (45%), `projected_profit`, `projected_total`, `duration_days`, and `projection_disclaimer`.
- **`POST /api/v1/investments`** (or `/api/v1/investments/create`):
  - Headers: `Authorization: Bearer <token>`
  - Body: `{"plan_id": 1, "amount": 1000}`
  - Validates the plan against the 6 official plans, prevents rapid duplicate submissions within 8 seconds, locks and deducts `wallet_balance`, sets `earned_amount = 0.00`, and returns `investment_reference`, `projected_profit`, `projected_total`, `start_date`, `end_date`, and `remaining_seconds`.
- **`GET /api/v1/investments`** (or `/api/v1/investments/my` or `/api/v1/my-investments`):
  - Headers: `Authorization: Bearer <token>`
  - Returns only the authenticated user's investments (`summary` + `investments` array) with `reference`, `plan_name`, `amount`, `projected_profit`, `projected_total`, `earned_amount`, `start_date`, `end_date`, `remaining_seconds`, `countdown` (`days`, `hours`, `minutes`, `seconds`, `formatted`), and `status` (`active` or `matured`).

### 3.4 Deposits, Withdrawals, Transfers, Transactions & Notifications
- **`GET /api/v1/deposits`**: Lists the user's deposit history and official bank transfer coordinates.
- **`POST /api/v1/deposits/create`** (or `/api/v1/deposits/upload-receipt`): Creates a pending bank transfer deposit with optional `receipt` image/PDF upload (`multipart/form-data`).
- **`POST /api/v1/deposits/gateway`**: Initiates or verifies a server-side Flutterwave deposit against `https://api.flutterwave.com/v3/transactions/{id}/verify`.
- **`GET /api/v1/withdrawals`**: Lists the user's withdrawal requests.
- **`POST /api/v1/withdrawals`** (or `/api/v1/withdrawals/create`): Submits a withdrawal request with atomic wallet deduction and transaction logging.
- **`GET /api/v1/transactions`**: Returns the user's auditable wallet ledger (`deposit`, `withdrawal`, `investment`, `roi_profit`, `referral_bonus`, `refund`).
- **`GET /api/v1/notifications`**: Returns user and broadcast notifications.
- **`GET /api/v1/support/tickets` & `POST /api/v1/support/tickets`**: Lists and creates customer support tickets.
