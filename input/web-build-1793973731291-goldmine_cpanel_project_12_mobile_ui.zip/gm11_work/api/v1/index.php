<?php
/**
 * GoldMine Investment Platform - REST API v1
 * Base URL: https://goalmindai.com.ng/api/v1/
 * Compatible with AndroidForce, Android (Kotlin/Java/Flutter), iOS & Web
 * 
 * Fully compatible with live `lhzmylpw_goldmine` MySQL schema:
 * (`id`, `full_name`, `email`, `phone`, `password_hash`, `balance`, `total_invested`, `total_profit`, `status`, `created_at`, `updated_at`)
 */

// 1. Headers & Domain-Aware CORS Configuration
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed_hosts = ['goalmindai.com.ng', 'www.goalmindai.com.ng', 'localhost'];

if (!empty($origin)) {
    $parsed_host = parse_url($origin, PHP_URL_HOST);
    if ($parsed_host && (in_array($parsed_host, $allowed_hosts) || str_ends_with($parsed_host, 'goalmindai.com.ng'))) {
        header("Access-Control-Allow-Origin: " . $origin);
        header("Access-Control-Allow-Credentials: true");
    } else {
        header("Access-Control-Allow-Origin: https://goalmindai.com.ng");
    }
} else {
    header("Access-Control-Allow-Origin: *");
}

header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Ensure `api_tokens` and `support_tickets` tables exist safely
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `api_tokens` (
          `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          `user_id` INT UNSIGNED DEFAULT NULL,
          `admin_id` INT UNSIGNED DEFAULT NULL,
          `token` VARCHAR(128) NOT NULL UNIQUE,
          `device_name` VARCHAR(100) DEFAULT 'Android Client',
          `expires_at` DATETIME NOT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          INDEX `idx_api_token` (`token`),
          INDEX `idx_api_user` (`user_id`),
          INDEX `idx_api_admin` (`admin_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
} catch (Exception $e) {
    // Ignore if already created
}

// 2. Standardized JSON Response Formatter
function json_response($status_code, $success, $message, $data = null, $errors = null) {
    http_response_code($status_code);
    $response = [
        'success'   => $success,
        'message'   => $message,
        'timestamp' => date('c'),
        'version'   => 'v1.0'
    ];
    if ($data !== null) {
        $response['data'] = $data;
    }
    if ($errors !== null) {
        $response['errors'] = $errors;
    }
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit();
}

// 3. Extract JSON payload or POST fields
$input_json = file_get_contents('php://input');
$request_data = json_decode($input_json, true) ?? [];
if (!empty($_POST)) {
    $request_data = array_merge($request_data, $_POST);
}

// 4. Extract Bearer Token from Authorization Header
function get_bearer_token() {
    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER['Authorization']);
    } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } elseif (function_exists('apache_request_headers')) {
        $req_headers = apache_request_headers();
        if (isset($req_headers['Authorization'])) {
            $headers = trim($req_headers['Authorization']);
        } elseif (isset($req_headers['authorization'])) {
            $headers = trim($req_headers['authorization']);
        }
    }
    if (!empty($headers) && preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
        return $matches[1];
    }
    return null;
}

// 5. Authenticate API User via Bearer Token
function authenticate_api_user($pdo) {
    $token = get_bearer_token();
    if (!$token) {
        json_response(401, false, "Unauthorized. Bearer token missing in Authorization header.", null, ["auth" => "Missing Bearer token."]);
    }
    try {
        $stmt = $pdo->prepare("
            SELECT u.*, t.token AS active_token, t.expires_at AS token_expires_at
            FROM api_tokens t
            JOIN users u ON t.user_id = u.id
            WHERE t.token = ? AND t.expires_at > NOW()
            LIMIT 1
        ");
        $stmt->execute([$token]);
        $raw = $stmt->fetch(PDO::FETCH_ASSOC);
        $user = normalize_user_row($raw);
        if (!$user) {
            json_response(401, false, "Unauthorized. Invalid or expired token.", null, ["auth" => "Token is invalid or expired."]);
        }
        if (in_array($user['status'], ['suspended', 'banned', 'blocked'], true)) {
            json_response(403, false, "Account suspended. Please contact platform compliance.", null, ["status" => "Account suspended."]);
        }
        unset($user['password'], $user['password_hash']);
        return $user;
    } catch (PDOException $e) {
        json_response(500, false, "Authentication query error.", null, $e->getMessage());
    }
}

// 6. Authenticate Admin via Bearer Token
function authenticate_api_admin($pdo) {
    $token = get_bearer_token();
    if (!$token) {
        json_response(401, false, "Unauthorized. Admin token missing.", null, ["auth" => "Missing Bearer token."]);
    }
    try {
        $stmt = $pdo->prepare("
            SELECT a.*, t.token AS active_token
            FROM api_tokens t
            JOIN admins a ON t.admin_id = a.id
            WHERE t.token = ? AND t.expires_at > NOW()
            LIMIT 1
        ");
        $stmt->execute([$token]);
        $admin = normalize_admin_row($stmt->fetch(PDO::FETCH_ASSOC));
        if (!$admin) {
            json_response(403, false, "Access denied. Administrative authorization required.", null, ["auth" => "Invalid admin token."]);
        }
        unset($admin['password'], $admin['password_hash']);
        return $admin;
    } catch (PDOException $e) {
        json_response(500, false, "Database error during admin auth.", null, $e->getMessage());
    }
}

// 7. Generate and Store API Token
function create_api_token($pdo, $user_id = null, $admin_id = null, $device_name = 'Android Client') {
    $token = bin2hex(random_bytes(32));
    $expires_at = date('Y-m-d H:i:s', strtotime('+30 days'));
    $stmt = $pdo->prepare("
        INSERT INTO api_tokens (user_id, admin_id, token, device_name, expires_at, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$user_id, $admin_id, $token, $device_name, $expires_at]);
    return [
        'token'      => $token,
        'type'       => 'Bearer',
        'expires_at' => $expires_at
    ];
}

// 8. Router: Parse requested path
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$script_name = $_SERVER['SCRIPT_NAME'] ?? '';
$api_base = dirname($script_name);

$path = parse_url($request_uri, PHP_URL_PATH) ?: '';
$rel_path = trim(str_replace($api_base, '', $path), '/');
$segments = $rel_path !== '' ? explode('/', $rel_path) : [];
$method = $_SERVER['REQUEST_METHOD'];

$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');

try {
    // -------------------------------------------------------------
    // Route: Root API Info & Health Check
    // -------------------------------------------------------------
    if (empty($rel_path) || $rel_path === 'index.php') {
        json_response(200, true, "GoldMine REST API v1 is active and operational.", [
            'platform'           => 'GoldMine Investment Platform',
            'base_url'           => 'https://goalmindai.com.ng/api/v1/',
            'database'           => 'lhzmylpw_goldmine',
            'android_compatible' => true,
            'auth_mode'          => 'Bearer Token',
            'server_time'        => date('c')
        ]);
    }

    // -------------------------------------------------------------
    // Route: /auth/register
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'auth' && ($segments[1] ?? '') === 'register' && $method === 'POST') {
        $full_name = trim($request_data['full_name'] ?? '');
        $email = strtolower(trim($request_data['email'] ?? ''));
        $username = trim($request_data['username'] ?? '');
        $phone = trim($request_data['phone'] ?? '');
        $password = $request_data['password'] ?? '';
        $referred_by = trim($request_data['referred_by'] ?? '');
        $device_name = trim($request_data['device_name'] ?? 'Android App');

        if (empty($username) && !empty($email)) {
            $email_prefix = explode('@', $email)[0] ?? 'investor';
            $username = preg_replace('/[^a-zA-Z0-9_]/', '', $email_prefix) ?: ('investor' . rand(100, 999));
        }

        $errors = [];
        if (empty($full_name)) $errors['full_name'] = "Full name is required.";
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = "Valid email is required.";
        if (empty($password) || strlen($password) < 6) $errors['password'] = "Password must be at least 6 characters.";

        if (!empty($errors)) {
            json_response(422, false, "Validation failed.", null, $errors);
        }

        // Check uniqueness compatible with actual `users` schema
        if (has_column($pdo, 'users', 'username')) {
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
            $chk->execute([$email, $username]);
        } else {
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $chk->execute([$email]);
        }
        if ($chk->fetch()) {
            json_response(409, false, "Email address is already registered.", null, ["account" => "Account already exists."]);
        }

        // Validate referrer if column exists
        $valid_ref = null;
        if (!empty($referred_by) && has_column($pdo, 'users', 'referral_code')) {
            $refStmt = $pdo->prepare("SELECT referral_code FROM users WHERE referral_code = ? LIMIT 1");
            $refStmt->execute([$referred_by]);
            if ($row = $refStmt->fetch()) {
                $valid_ref = $row['referral_code'];
            }
        }

        $my_ref_code = 'GM' . strtoupper(bin2hex(random_bytes(3))) . rand(10, 99);
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $user_cols = get_table_columns($pdo, 'users');
        $ins_cols = [];
        $ins_vals = [];
        $ins_params = [];

        $candidates = [
            'full_name'      => $full_name,
            'username'       => $username,
            'email'          => $email,
            'phone'          => $phone,
            'password_hash'  => $hash,
            'password'       => $hash,
            'balance'        => 0.00,
            'wallet_balance' => 0.00,
            'total_invested' => 0.00,
            'total_profit'   => 0.00,
            'referral_code'  => $my_ref_code,
            'referred_by'    => $valid_ref,
            'status'         => 'active',
            'email_verified' => 1,
        ];

        foreach ($candidates as $k => $v) {
            if (isset($user_cols[$k])) {
                $ins_cols[] = "`{$user_cols[$k]}`";
                $ins_vals[] = "?";
                $ins_params[] = $v;
            }
        }
        if (isset($user_cols['created_at'])) {
            $ins_cols[] = "`created_at`";
            $ins_vals[] = "NOW()";
        }
        if (isset($user_cols['updated_at'])) {
            $ins_cols[] = "`updated_at`";
            $ins_vals[] = "NOW()";
        }

        $ins = $pdo->prepare("INSERT INTO `users` (" . implode(", ", $ins_cols) . ") VALUES (" . implode(", ", $ins_vals) . ")");
        $ins->execute($ins_params);
        $new_user_id = (int)$pdo->lastInsertId();

        create_notification($pdo, $new_user_id, "Welcome to GoldMine", "Account created successfully via Android API.", "success");
        record_audit_log($pdo, null, $new_user_id, 'API_REGISTER', "User registered via Android API ({$device_name})");

        $token_data = create_api_token($pdo, $new_user_id, null, $device_name);

        json_response(201, true, "Account created successfully.", [
            'user' => [
                'id'             => $new_user_id,
                'full_name'      => $full_name,
                'username'       => $username,
                'email'          => $email,
                'phone'          => $phone,
                'balance'        => 0.00,
                'wallet_balance' => 0.00,
                'total_invested' => 0.00,
                'total_profit'   => 0.00,
                'referral_code'  => 'GM' . str_pad((string)$new_user_id, 5, '0', STR_PAD_LEFT)
            ],
            'auth' => $token_data
        ]);
    }

    // -------------------------------------------------------------
    // Route: /auth/login
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'auth' && ($segments[1] ?? '') === 'login' && $method === 'POST') {
        $identifier = trim($request_data['identifier'] ?? $request_data['email'] ?? $request_data['username'] ?? '');
        $password = $request_data['password'] ?? '';
        $device_name = trim($request_data['device_name'] ?? 'Android Device');

        if (empty($identifier) || empty($password)) {
            json_response(422, false, "Email and password are required.", null, ["credentials" => "Missing credentials."]);
        }

        $user = find_user_for_login($pdo, $identifier);

        if ($user && !empty($user['password_hash']) && password_verify($password, $user['password_hash'])) {
            if (in_array($user['status'], ['suspended', 'banned', 'blocked'], true)) {
                json_response(403, false, "Your account has been suspended.", null, ["status" => "Suspended"]);
            }

            $token_data = create_api_token($pdo, (int)$user['id'], null, $device_name);
            record_audit_log($pdo, null, (int)$user['id'], 'API_LOGIN', "User logged in via Android API ({$device_name})");

            json_response(200, true, "Login successful.", [
                'user' => [
                    'id'             => (int)$user['id'],
                    'full_name'      => $user['full_name'],
                    'username'       => $user['username'],
                    'email'          => $user['email'],
                    'phone'          => $user['phone'],
                    'balance'        => (float)$user['balance'],
                    'wallet_balance' => (float)$user['wallet_balance'],
                    'total_invested' => (float)$user['total_invested'],
                    'total_profit'   => (float)$user['total_profit'],
                    'referral_code'  => $user['referral_code'],
                    'status'         => $user['status']
                ],
                'auth' => $token_data
            ]);
        } else {
            json_response(401, false, "Invalid email or password.", null, ["credentials" => "Invalid credentials."]);
        }
    }

    // -------------------------------------------------------------
    // Route: /auth/logout
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'auth' && ($segments[1] ?? '') === 'logout' && $method === 'POST') {
        $token = get_bearer_token();
        if ($token) {
            $pdo->prepare("DELETE FROM api_tokens WHERE token = ?")->execute([$token]);
        }
        json_response(200, true, "Logged out successfully. Token revoked.");
    }

    // -------------------------------------------------------------
    // Route: /dashboard/stats
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'dashboard' && ($segments[1] ?? '') === 'stats' && $method === 'GET') {
        $user = authenticate_api_user($pdo);
        $user_id = (int)$user['id'];

        $stmtDep = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE user_id = ? AND status = 'approved'");
        $stmtDep->execute([$user_id]);
        $total_deposits = (float)$stmtDep->fetchColumn();

        $stmtInv = $pdo->prepare("SELECT COALESCE(SUM(amount), 0), COUNT(*) FROM investments WHERE user_id = ? AND status = 'active'");
        $stmtInv->execute([$user_id]);
        list($active_inv_amount, $active_inv_count) = $stmtInv->fetch(PDO::FETCH_NUM);
        $active_inv_amount = max((float)$active_inv_amount, (float)$user['total_invested']);

        $stmtProf = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = ? AND type = 'roi_profit' AND status = 'completed'");
        $stmtProf->execute([$user_id]);
        $total_profits = max((float)$user['total_profit'], (float)$stmtProf->fetchColumn());

        $stmtWd = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE user_id = ? AND status = 'approved'");
        $stmtWd->execute([$user_id]);
        $total_withdrawals = (float)$stmtWd->fetchColumn();

        $stmtWdPending = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE user_id = ? AND status = 'pending'");
        $stmtWdPending->execute([$user_id]);
        $pending_withdrawals = (float)$stmtWdPending->fetchColumn();

        $total_referrals = 0;
        if (has_column($pdo, 'users', 'referred_by') && !empty($user['referral_code'])) {
            $stmtRef = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by = ?");
            $stmtRef->execute([$user['referral_code']]);
            $total_referrals = (int)$stmtRef->fetchColumn();
        }

        $stmtNotif = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
        $stmtNotif->execute([$user_id]);
        $unread_notifs = (int)$stmtNotif->fetchColumn();

        $stmtTx = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
        $stmtTx->execute([$user_id]);
        $recent_tx = array_map('normalize_transaction_row', $stmtTx->fetchAll(PDO::FETCH_ASSOC));

        json_response(200, true, "Dashboard stats fetched successfully.", [
            'balance'              => (float)$user['balance'],
            'wallet_balance'       => (float)$user['wallet_balance'],
            'total_deposits'       => $total_deposits,
            'active_investments'   => $active_inv_amount,
            'total_invested'       => $active_inv_amount,
            'active_count'         => (int)$active_inv_count,
            'investment_profits'   => $total_profits,
            'total_profit'         => $total_profits,
            'total_withdrawals'    => $total_withdrawals,
            'pending_withdrawals'  => $pending_withdrawals,
            'referral_count'       => $total_referrals,
            'unread_notifications' => $unread_notifs,
            'currency_symbol'      => $currency_symbol,
            'recent_transactions'  => $recent_tx
        ]);
    }

    // -------------------------------------------------------------
    // Route: /plans (Returns ONLY the 6 official GoldMine plans)
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'plans' && $method === 'GET') {
        $official_plans = ensure_six_investment_plans($pdo, false);
        if (isset($segments[1]) && is_numeric($segments[1])) {
            $req_id = (int)$segments[1];
            $found = null;
            foreach ($official_plans as $op) {
                if ((int)$op['id'] === $req_id) {
                    $found = $op;
                    break;
                }
            }
            if (!$found) json_response(404, false, "Plan not found or inactive.");
            json_response(200, true, "Official investment plan details retrieved.", $found);
        } else {
            json_response(200, true, "Official 6 investment plans retrieved.", $official_plans);
        }
    }

    // -------------------------------------------------------------
    // Route: /investments
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'investments') {
        $user = authenticate_api_user($pdo);
        $user_id = (int)$user['id'];

        if ($method === 'GET') {
            $status_filter = trim($_GET['status'] ?? 'all');
            $sql = "
                SELECT i.*,
                       COALESCE(NULLIF(i.plan_name, ''), p.name) AS resolved_plan_name,
                       COALESCE(NULLIF(i.roi_percentage, 0), p.roi_percentage) AS resolved_roi_percentage,
                       COALESCE(NULLIF(i.duration_days, 0), p.duration_days) AS resolved_duration_days
                FROM investments i
                LEFT JOIN investment_plans p ON i.plan_id = p.id
                WHERE i.user_id = ?
            ";
            $params = [$user_id];
            if ($status_filter !== 'all' && in_array($status_filter, ['active', 'completed', 'cancelled'])) {
                $sql .= " AND i.status = ?";
                $params[] = $status_filter;
            }
            $sql .= " ORDER BY i.created_at DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $investments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $now_ts = time();
            $formatted = array_map(function($rawInv) use ($now_ts) {
                $rawInv['plan_name'] = $rawInv['resolved_plan_name'] ?? $rawInv['plan_name'] ?? 'GoldMine';
                $rawInv['roi_percentage'] = $rawInv['resolved_roi_percentage'] ?? $rawInv['roi_percentage'] ?? 45.00;
                $rawInv['duration_days'] = $rawInv['resolved_duration_days'] ?? $rawInv['duration_days'] ?? 7;
                $inv = normalize_investment_row($rawInv);

                $start_ts = strtotime($inv['start_date']);
                $maturity_ts = strtotime($inv['maturity_date']);
                $total_duration = max(1, $maturity_ts - $start_ts);
                $elapsed = max(0, min($total_duration, $now_ts - $start_ts));
                $progress_pct = min(100, round(($elapsed / $total_duration) * 100, 2));

                $remaining_secs = max(0, $maturity_ts - $now_ts);
                $days = floor($remaining_secs / 86400);
                $hours = floor(($remaining_secs % 86400) / 3600);
                $minutes = floor(($remaining_secs % 3600) / 60);
                $seconds = $remaining_secs % 60;

                $calc = calculate_projected_returns((float)$inv['amount'], (float)$inv['roi_percentage'], 1);
                $inv['payout_interval'] = 'end_of_term';
                $inv['capital_returned'] = 1;
                $inv['projected_profit'] = $calc['projected_profit'];
                $inv['projected_total']  = (float)$inv['expected_return'] > 0 ? (float)$inv['expected_return'] : $calc['projected_total'];
                $inv['projection_disclaimer'] = $calc['disclaimer'];

                $inv['countdown'] = [
                    'days'              => $days,
                    'hours'             => $hours,
                    'minutes'           => $minutes,
                    'seconds'           => $seconds,
                    'formatted'         => sprintf('%02dd : %02dh : %02dm : %02ds', $days, $hours, $minutes, $seconds),
                    'remaining_seconds' => $remaining_secs,
                    'progress_percent'  => $progress_pct,
                    'is_matured'        => ($now_ts >= $maturity_ts)
                ];
                return $inv;
            }, $investments);

            json_response(200, true, "User investments retrieved successfully.", $formatted);
        }

        if ($method === 'POST') {
            ensure_six_investment_plans($pdo, false);
            $plan_id = (int)($request_data['plan_id'] ?? 0);
            $official_names = array_keys(get_official_six_plans_spec());
            $placeholders = implode(',', array_fill(0, count($official_names), '?'));

            $pStmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND name IN ($placeholders) LIMIT 1");
            $pStmt->execute(array_merge([$plan_id], $official_names));
            $rawPlan = $pStmt->fetch(PDO::FETCH_ASSOC);
            $plan = $rawPlan ? normalize_plan_row($rawPlan) : null;

            if (!$plan || $plan['status'] !== 'active') {
                json_response(404, false, "Selected plan not found or inactive. Choose one of the 6 official plans.");
            }

            $amount = (float)$plan['min_amount'];
            if (isset($request_data['amount']) && (float)$request_data['amount'] > 0 && abs((float)$request_data['amount'] - $amount) > 0.01) {
                json_response(422, false, "The {$plan['name']} Plan requires an exact investment amount of {$currency_symbol}" . number_format($amount, 2) . ".");
            }

            try {
                $pdo->beginTransaction();
                $lockedUser = lock_user_row($pdo, $user_id);
                $curr_bal = (float)($lockedUser['balance'] ?? 0.00);

                $dupStmt = $pdo->prepare("
                    SELECT id FROM investments
                    WHERE user_id = ? AND plan_id = ? AND amount = ? AND created_at >= (NOW() - INTERVAL 8 SECOND)
                    LIMIT 1
                ");
                $dupStmt->execute([$user_id, $plan_id, $amount]);
                if ($dupStmt->fetch()) {
                    $pdo->rollBack();
                    json_response(409, false, "Duplicate investment submission detected. Please wait a few seconds.");
                }

                if ($curr_bal < $amount) {
                    $pdo->rollBack();
                    json_response(400, false, "Insufficient wallet balance. Available: {$currency_symbol}" . number_format($curr_bal, 2) . ". Required: {$currency_symbol}" . number_format($amount, 2) . ".");
                }

                $new_bal = round($curr_bal - $amount, 2);
                $roi_pct = (float)$plan['roi_percentage'];
                $duration = max(1, (int)$plan['duration_days']);
                $calc = calculate_projected_returns($amount, $roi_pct, $plan['capital_returned']);
                $projected_profit = $calc['projected_profit'];
                $projected_total  = $calc['projected_total'];

                $start_date = date('Y-m-d H:i:s');
                $maturity_date = date('Y-m-d H:i:s', strtotime("+{$duration} days"));
                $txRef = generate_reference('INV-' . strtoupper(substr($plan['name'], 0, 3)));

                // 1. Deduct principal balance and increment total_invested
                update_user_balance($pdo, $user_id, $new_bal, $amount, 0.00);

                // 2. Insert investment using actual `investments` schema
                $new_inv_id = create_investment_record($pdo, [
                    'reference_code'  => $txRef,
                    'user_id'         => $user_id,
                    'plan_id'         => $plan_id,
                    'plan_name'       => $plan['name'],
                    'amount'          => $amount,
                    'roi_percentage'  => $roi_pct,
                    'expected_return' => $projected_total,
                    'duration_days'   => $duration,
                    'start_date'      => $start_date,
                    'maturity_date'   => $maturity_date,
                    'status'          => 'active',
                ]);

                // 3. Record transaction (`reference_code`)
                record_transaction(
                    $pdo,
                    $user_id,
                    'investment',
                    $amount,
                    $new_bal,
                    $txRef,
                    "Activated {$plan['name']} Plan ({$duration} Days) - Projected Total: {$currency_symbol}" . number_format($projected_total, 2),
                    0.00,
                    'completed'
                );

                create_notification($pdo, $user_id, "{$plan['name']} Plan Activated", "Committed {$currency_symbol}" . number_format($amount, 2) . " into {$plan['name']} Plan (Ref: {$txRef}). Projected Total: {$currency_symbol}" . number_format($projected_total, 2) . ".", "success");
                record_audit_log($pdo, null, $user_id, 'API_INVESTMENT', "Allocated {$amount} into {$plan['name']} Plan (#{$plan_id}) via REST API. Ref: {$txRef}");

                $pdo->commit();

                json_response(201, true, "Investment position activated successfully.", [
                    'investment_id'         => $new_inv_id,
                    'reference_code'        => $txRef,
                    'reference'             => $txRef,
                    'plan_name'             => $plan['name'],
                    'amount'                => $amount,
                    'roi_percentage'        => $roi_pct,
                    'projection_rate'       => $roi_pct,
                    'projected_profit'      => $projected_profit,
                    'projected_total'       => $projected_total,
                    'expected_return'       => $projected_total,
                    'duration_days'         => $duration,
                    'projection_disclaimer' => $calc['disclaimer'],
                    'wallet_balance_after'  => $new_bal,
                    'balance_after'         => $new_bal,
                    'start_date'            => $start_date,
                    'maturity_date'         => $maturity_date,
                    'end_date'              => $maturity_date
                ]);
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                json_response(500, false, "Failed to commit investment: " . $e->getMessage());
            }
        }
    }

    // -------------------------------------------------------------
    // Route: /deposits
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'deposits') {
        $user = authenticate_api_user($pdo);
        $user_id = (int)$user['id'];

        if ($method === 'GET') {
            $stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$user_id]);
            $deps = array_map('normalize_deposit_row', $stmt->fetchAll(PDO::FETCH_ASSOC));
            json_response(200, true, "Deposit history retrieved.", $deps);
        }

        if ($method === 'POST' && ($segments[1] ?? '') === 'bank') {
            $amount = round((float)($request_data['amount'] ?? 0), 2);
            $reference = trim($request_data['reference'] ?? $request_data['reference_code'] ?? '');
            $min_dep = (float)get_setting($pdo, 'min_deposit', '1000.00');

            if ($amount < $min_dep) {
                json_response(422, false, "Minimum deposit amount is {$currency_symbol}{$min_dep}.");
            }
            if (empty($reference)) {
                json_response(422, false, "Bank reference or sender name is required.");
            }

            $receipt_file = null;
            if (isset($_FILES['receipt_file'])) {
                $upload_res = handle_receipt_upload($_FILES['receipt_file']);
                if (!$upload_res['success']) {
                    json_response(400, false, $upload_res['error']);
                }
                $receipt_file = $upload_res['filename'];
            }

            $sysRef = generate_reference('DEP-BNK');
            create_deposit_record($pdo, [
                'reference_code' => $sysRef,
                'user_id'        => $user_id,
                'amount'         => $amount,
                'payment_method' => 'bank_transfer',
                'gateway_ref'    => $reference,
                'receipt_path'   => $receipt_file,
                'status'         => 'pending',
                'admin_notes'    => "User ref: " . $reference,
            ]);

            create_notification($pdo, $user_id, "Deposit Proof Submitted", "Wire deposit of {$currency_symbol}{$amount} (Ref: {$sysRef}) received and pending approval.", "info");
            record_audit_log($pdo, null, $user_id, 'API_DEPOSIT_BANK', "Submitted wire receipt for {$amount}. Sys Ref: {$sysRef}");

            json_response(201, true, "Deposit proof received. Staff will verify your receipt.", [
                'reference_code' => $sysRef,
                'reference'      => $sysRef,
                'amount'         => $amount,
                'status'         => 'pending'
            ]);
        }

        if ($method === 'POST' && ($segments[1] ?? '') === 'gateway') {
            $flw_secret_key = trim(get_setting($pdo, 'flutterwave_secret_key', ''));
            if (empty($flw_secret_key) && defined('FLUTTERWAVE_SECRET_KEY')) {
                $flw_secret_key = trim(FLUTTERWAVE_SECRET_KEY);
            }

            if (empty($flw_secret_key)) {
                json_response(503, false, "Online gateway payments are currently disabled. Flutterwave API keys not configured.");
            }

            $flw_transaction_id = trim($request_data['transaction_id'] ?? '');
            if (empty($flw_transaction_id) || !is_numeric($flw_transaction_id)) {
                json_response(422, false, "Valid numeric Flutterwave transaction_id is required.", null, ["transaction_id" => "Missing or invalid transaction ID."]);
            }

            $ch = curl_init("https://api.flutterwave.com/v3/transactions/" . urlencode($flw_transaction_id) . "/verify");
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER     => [
                    "Authorization: Bearer {$flw_secret_key}",
                    "Content-Type: application/json"
                ],
                CURLOPT_TIMEOUT        => 25,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            $flw_raw = curl_exec($ch);
            $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_err = curl_error($ch);
            curl_close($ch);

            if ($curl_err || $http_status !== 200 || empty($flw_raw)) {
                json_response(502, false, "Failed to communicate with Flutterwave verification service.", null, ["gateway" => $curl_err ?: "HTTP {$http_status}"]);
            }

            $flw_json = json_decode($flw_raw, true);
            if (
                empty($flw_json) ||
                ($flw_json['status'] ?? '') !== 'success' ||
                ($flw_json['data']['status'] ?? '') !== 'successful'
            ) {
                json_response(400, false, "Payment verification rejected by Flutterwave: " . ($flw_json['message'] ?? 'Unsuccessful payment status.'));
            }

            $verified_amount = (float)($flw_json['data']['amount'] ?? 0);
            $tx_ref = trim($flw_json['data']['tx_ref'] ?? '');
            $verified_currency = strtoupper($flw_json['data']['currency'] ?? '');
            $gateway_id = (string)($flw_json['data']['id'] ?? $flw_transaction_id);

            if ($verified_amount <= 0 || empty($tx_ref)) {
                json_response(422, false, "Invalid verified financial payload returned from gateway.");
            }

            try {
                $pdo->beginTransaction();

                $dep_cols = get_table_columns($pdo, 'deposits');
                $ref_col = isset($dep_cols['reference_code']) ? 'reference_code' : 'reference';
                if (isset($dep_cols['gateway_ref'])) {
                    $chk = $pdo->prepare("SELECT id, status FROM `deposits` WHERE `{$ref_col}` = ? OR `gateway_ref` = ? OR `admin_notes` LIKE ? LIMIT 1 FOR UPDATE");
                    $chk->execute([$tx_ref, $gateway_id, "%FLW-ID: {$gateway_id}%"]);
                } else {
                    $chk = $pdo->prepare("SELECT id, status FROM `deposits` WHERE `{$ref_col}` = ? OR `admin_notes` LIKE ? LIMIT 1 FOR UPDATE");
                    $chk->execute([$tx_ref, "%FLW-ID: {$gateway_id}%"]);
                }
                $existing = $chk->fetch(PDO::FETCH_ASSOC);

                if ($existing && $existing['status'] === 'approved') {
                    $pdo->rollBack();
                    json_response(409, false, "This transaction has already been processed and credited.");
                }

                $uData = lock_user_row($pdo, $user_id);
                $new_bal = round((float)($uData['balance'] ?? 0.00) + $verified_amount, 2);
                $admin_notes = "Verified FLW-ID: {$gateway_id} | Currency: {$verified_currency}";

                if ($existing) {
                    update_deposit_status($pdo, (int)$existing['id'], 'approved', $admin_notes, null, $verified_amount, $gateway_id);
                    $deposit_id = (int)$existing['id'];
                } else {
                    $deposit_id = create_deposit_record($pdo, [
                        'reference_code'  => $tx_ref,
                        'user_id'         => $user_id,
                        'amount'          => $verified_amount,
                        'payment_method'  => 'flutterwave',
                        'gateway_ref'     => $gateway_id,
                        'status'          => 'approved',
                        'admin_action_at' => true,
                        'admin_notes'     => $admin_notes,
                    ]);
                }

                update_user_balance($pdo, $user_id, $new_bal);

                record_transaction(
                    $pdo,
                    $user_id,
                    'deposit',
                    $verified_amount,
                    $new_bal,
                    $tx_ref,
                    "Flutterwave verified online deposit (FLW: {$gateway_id})",
                    0.00,
                    'completed'
                );

                if (!empty($uData['referred_by']) && has_column($pdo, 'users', 'referral_code')) {
                    $bonusPct = (float)get_setting($pdo, 'referral_bonus_percent', '10.00');
                    if ($bonusPct > 0) {
                        $refBonusCode = 'REF-BONUS-DEP' . $deposit_id;
                        if (!transaction_reference_exists($pdo, $refBonusCode, true)) {
                            $refUserStmt = $pdo->prepare("SELECT * FROM users WHERE referral_code = ? LIMIT 1 FOR UPDATE");
                            $refUserStmt->execute([$uData['referred_by']]);
                            if ($refUser = normalize_user_row($refUserStmt->fetch(PDO::FETCH_ASSOC))) {
                                $comm = round($verified_amount * ($bonusPct / 100), 2);
                                if ($comm > 0) {
                                    $refNew = round((float)$refUser['balance'] + $comm, 2);
                                    update_user_balance($pdo, (int)$refUser['id'], $refNew);
                                    record_transaction($pdo, (int)$refUser['id'], 'referral_bonus', $comm, $refNew, $refBonusCode, "Referral commission on deposit #{$deposit_id}", 0, 'completed');
                                }
                            }
                        }
                    }
                }

                create_notification($pdo, $user_id, "Deposit Verified", "Flutterwave deposit of {$currency_symbol}{$verified_amount} verified and settled.", "success");
                record_audit_log($pdo, null, $user_id, 'API_FLW_VERIFIED', "Verified FLW payment: {$verified_amount} {$verified_currency}. Ref: {$tx_ref}");

                $pdo->commit();

                json_response(200, true, "Payment verified and credited successfully.", [
                    'reference'       => $tx_ref,
                    'verified_amount' => $verified_amount,
                    'currency'        => $verified_currency,
                    'current_balance' => $new_bal
                ]);
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                json_response(500, false, "Database error during gateway credit.", null, $e->getMessage());
            }
        }
    }

    // -------------------------------------------------------------
    // Route: /withdrawals
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'withdrawals') {
        $user = authenticate_api_user($pdo);
        $user_id = (int)$user['id'];

        if ($method === 'GET') {
            $stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$user_id]);
            json_response(200, true, "Withdrawals history retrieved.", $stmt->fetchAll());
        }

        if ($method === 'POST') {
            $amount = round((float)($request_data['amount'] ?? 0), 2);
            $bank_name = trim($request_data['bank_name'] ?? '');
            $account_number = trim($request_data['account_number'] ?? '');
            $account_name = trim($request_data['account_name'] ?? '');

            $min_wd = (float)get_setting($pdo, 'min_withdrawal', '1000.00');
            $fee_pct = (float)get_setting($pdo, 'withdrawal_fee_percent', '1.50');

            if ($amount < $min_wd) {
                json_response(422, false, "Minimum withdrawal is {$currency_symbol}{$min_wd}.");
            }
            if (empty($bank_name) || empty($account_number) || empty($account_name)) {
                json_response(422, false, "Bank name, account number, and account name are required.");
            }

            try {
                $pdo->beginTransaction();
                $lockedUser = lock_user_row($pdo, $user_id);
                $curr_bal = (float)($lockedUser['balance'] ?? 0.00);

                if ($curr_bal < $amount) {
                    $pdo->rollBack();
                    json_response(400, false, "Insufficient wallet balance. You have {$currency_symbol}{$curr_bal}.");
                }

                $fee = round($amount * ($fee_pct / 100), 2);
                $net_amount = round($amount - $fee, 2);
                $new_bal = round($curr_bal - $amount, 2);

                // 1. Deduct immediately
                update_user_balance($pdo, $user_id, $new_bal);

                // 2. Insert withdrawal using schema-safe helper
                $txRef = generate_reference('WD');
                $new_wd_id = create_withdrawal_record($pdo, [
                    'reference_code' => $txRef,
                    'user_id'        => $user_id,
                    'amount'         => $amount,
                    'fee'            => $fee,
                    'net_amount'     => $net_amount,
                    'bank_name'      => $bank_name,
                    'account_number' => $account_number,
                    'account_name'   => $account_name,
                    'status'         => 'pending',
                ]);

                // 3. Record pending transaction (`reference_code`)
                record_transaction(
                    $pdo,
                    $user_id,
                    'withdrawal',
                    $amount,
                    $new_bal,
                    $txRef,
                    "Disbursement request to {$bank_name} ({$account_number})",
                    $fee,
                    'pending'
                );

                create_notification($pdo, $user_id, "Withdrawal Requested", "Requested {$currency_symbol}{$amount} (Net: {$currency_symbol}{$net_amount}).", "info");
                record_audit_log($pdo, null, $user_id, 'API_WITHDRAWAL_REQUESTED', "Withdrawal of {$amount} submitted via Android API");

                $pdo->commit();

                json_response(201, true, "Withdrawal request submitted successfully.", [
                    'withdrawal_id'        => $new_wd_id,
                    'amount'               => $amount,
                    'fee'                  => $fee,
                    'net_amount'           => $net_amount,
                    'wallet_balance_after' => $new_bal,
                    'balance_after'        => $new_bal,
                    'status'               => 'pending'
                ]);
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                json_response(500, false, "Withdrawal processing error: " . $e->getMessage());
            }
        }
    }

    // -------------------------------------------------------------
    // Route: /transactions
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'transactions' && $method === 'GET') {
        $user = authenticate_api_user($pdo);
        $user_id = (int)$user['id'];
        $type = trim($_GET['type'] ?? 'all');
        $status = trim($_GET['status'] ?? 'all');
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = min(100, max(5, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;

        $sql = "SELECT * FROM transactions WHERE user_id = ?";
        $params = [$user_id];
        if ($type !== 'all') {
            $sql .= " AND type = ?";
            $params[] = $type;
        }
        if ($status !== 'all') {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $txList = array_map('normalize_transaction_row', $stmt->fetchAll(PDO::FETCH_ASSOC));

        json_response(200, true, "Transactions retrieved.", [
            'page'    => $page,
            'limit'   => $limit,
            'records' => $txList
        ]);
    }

    // -------------------------------------------------------------
    // Route: /referrals
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'referrals' && $method === 'GET') {
        $user = authenticate_api_user($pdo);
        $partners = [];
        if (has_column($pdo, 'users', 'referred_by') && !empty($user['referral_code'])) {
            $stmtRef = $pdo->prepare("SELECT * FROM users WHERE referred_by = ? ORDER BY created_at DESC");
            $stmtRef->execute([$user['referral_code']]);
            foreach ($stmtRef->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $nr = normalize_user_row($r);
                $partners[] = [
                    'id'         => (int)$nr['id'],
                    'full_name'  => $nr['full_name'],
                    'username'   => $nr['username'],
                    'email'      => $nr['email'],
                    'created_at' => $nr['created_at'] ?? null,
                    'status'     => $nr['status']
                ];
            }
        }

        $stmtComm = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = ? AND type = 'referral_bonus'");
        $stmtComm->execute([$user['id']]);
        $total_bonus = (float)$stmtComm->fetchColumn();

        json_response(200, true, "Referral information retrieved.", [
            'referral_code'      => $user['referral_code'],
            'referral_link'      => "https://goalmindai.com.ng/register.php?ref=" . urlencode($user['referral_code']),
            'commission_percent' => (float)get_setting($pdo, 'referral_bonus_percent', '10.00'),
            'total_earned'       => $total_bonus,
            'partners_count'     => count($partners),
            'partners'           => $partners
        ]);
    }

    // -------------------------------------------------------------
    // Route: /user/profile
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'user' && ($segments[1] ?? '') === 'profile') {
        $user = authenticate_api_user($pdo);
        if ($method === 'GET') {
            $bStmt = $pdo->prepare("SELECT * FROM user_bank_details WHERE user_id = ? LIMIT 1");
            $bStmt->execute([$user['id']]);
            $bank = $bStmt->fetch();
            json_response(200, true, "Profile retrieved.", [
                'user' => $user,
                'bank' => $bank
            ]);
        }
        if ($method === 'PUT' || $method === 'POST') {
            $full_name = trim($request_data['full_name'] ?? $user['full_name']);
            $phone = trim($request_data['phone'] ?? $user['phone']);
            $upd_sql = has_column($pdo, 'users', 'updated_at')
                ? "UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE id = ?"
                : "UPDATE users SET full_name = ?, phone = ? WHERE id = ?";
            $pdo->prepare($upd_sql)->execute([$full_name, $phone, $user['id']]);
            json_response(200, true, "Profile updated successfully.");
        }
    }

    // -------------------------------------------------------------
    // Route: /transfer (Peer-to-Peer Wallet Transfer)
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'transfer' && $method === 'POST') {
        $user = authenticate_api_user($pdo);
        $recipient_input = trim($request_data['recipient'] ?? '');
        $amount = round((float)($request_data['amount'] ?? 0), 2);

        if (empty($recipient_input)) {
            json_response(422, false, "Receiver email or user ID is required.", null, ["recipient" => "Missing recipient"]);
        }
        if ($amount <= 0) {
            json_response(422, false, "Transfer amount must be greater than zero.", null, ["amount" => "Invalid amount"]);
        }

        try {
            $pdo->beginTransaction();

            $lockedSender = lock_user_row($pdo, (int)$user['id']);
            $current_balance = (float)($lockedSender['balance'] ?? 0.00);

            if ($amount > $current_balance) {
                $pdo->rollBack();
                json_response(400, false, "Insufficient funds. Available balance: " . $currency_symbol . number_format($current_balance, 2));
            }

            $recipient = find_recipient_user($pdo, $recipient_input, (int)$user['id'], true);

            if (!$recipient) {
                $pdo->rollBack();
                json_response(404, false, "Recipient user not found. Please verify their email address.");
            }

            $sender_new_bal = round($current_balance - $amount, 2);
            $recip_new_bal = round((float)$recipient['balance'] + $amount, 2);

            update_user_balance($pdo, (int)$user['id'], $sender_new_bal);
            update_user_balance($pdo, (int)$recipient['id'], $recip_new_bal);

            $refSend = generate_reference('TRF-OUT');
            record_transaction($pdo, (int)$user['id'], 'withdrawal', $amount, $sender_new_bal, $refSend, "Transfer sent to {$recipient['full_name']} ({$recipient['email']})", 0.00, 'completed');

            $refRecv = generate_reference('TRF-IN');
            record_transaction($pdo, (int)$recipient['id'], 'deposit', $amount, $recip_new_bal, $refRecv, "Transfer received from {$user['full_name']} ({$user['email']})", 0.00, 'completed');

            create_notification($pdo, (int)$user['id'], "Transfer Sent", "Transferred {$currency_symbol}" . number_format($amount, 2) . " to {$recipient['full_name']}.", 'info');
            create_notification($pdo, (int)$recipient['id'], "Transfer Received", "Received {$currency_symbol}" . number_format($amount, 2) . " from {$user['full_name']}.", 'success');

            $pdo->commit();

            json_response(200, true, "Transferred {$currency_symbol}" . number_format($amount, 2) . " to {$recipient['full_name']} successfully.", [
                'reference'       => $refSend,
                'recipient'       => $recipient['email'],
                'amount'          => $amount,
                'current_balance' => $sender_new_bal
            ]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            json_response(500, false, "Transfer execution failed.", null, $e->getMessage());
        }
    }

    // -------------------------------------------------------------
    // Route: /notifications
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'notifications') {
        $user = authenticate_api_user($pdo);
        if ($method === 'GET') {
            $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC LIMIT 50");
            $stmt->execute([$user['id']]);
            json_response(200, true, "Notifications retrieved.", $stmt->fetchAll());
        }
        if ($method === 'POST' && ($segments[1] ?? '') === 'read') {
            $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? OR user_id IS NULL")->execute([$user['id']]);
            json_response(200, true, "All notifications marked as read.");
        }
    }

    // -------------------------------------------------------------
    // Route: /support/tickets
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'support' && ($segments[1] ?? '') === 'tickets') {
        $user = authenticate_api_user($pdo);
        if ($method === 'GET') {
            $stmt = $pdo->prepare("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$user['id']]);
            json_response(200, true, "Support tickets retrieved.", $stmt->fetchAll());
        }
        if ($method === 'POST') {
            $subject = trim($request_data['subject'] ?? '');
            $message = trim($request_data['message'] ?? '');
            $priority = in_array($request_data['priority'] ?? '', ['low', 'normal', 'high', 'urgent']) ? $request_data['priority'] : 'normal';

            if (empty($subject) || empty($message)) {
                json_response(422, false, "Subject and message are required.");
            }

            $ticket_code = 'TKT-' . strtoupper(substr(uniqid(), -6));
            $ins = $pdo->prepare("
                INSERT INTO support_tickets (user_id, ticket_code, subject, priority, message, status, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, 'open', NOW(), NOW())
            ");
            $ins->execute([$user['id'], $ticket_code, $subject, $priority, $message]);
            json_response(201, true, "Support ticket submitted.", [
                'ticket_id'   => (int)$pdo->lastInsertId(),
                'ticket_code' => $ticket_code,
                'priority'    => $priority
            ]);
        }
    }

    // -------------------------------------------------------------
    // Route: /admin/* (Administrative Endpoints)
    // -------------------------------------------------------------
    if (($segments[0] ?? '') === 'admin') {
        if (($segments[1] ?? '') === 'login' && $method === 'POST') {
            $u = trim($request_data['username'] ?? $request_data['email'] ?? '');
            $p = $request_data['password'] ?? '';

            if (has_column($pdo, 'admins', 'username') && has_column($pdo, 'admins', 'email')) {
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
                $stmt->execute([$u, $u]);
            } elseif (has_column($pdo, 'admins', 'username')) {
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? LIMIT 1");
                $stmt->execute([$u]);
            } else {
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
                $stmt->execute([$u]);
            }

            $adm = normalize_admin_row($stmt->fetch(PDO::FETCH_ASSOC));
            if ($adm && !empty($adm['password']) && password_verify($p, $adm['password'])) {
                $token_data = create_api_token($pdo, null, (int)$adm['id'], 'Android Admin Console');
                record_audit_log($pdo, (int)$adm['id'], null, 'API_ADMIN_LOGIN', "Admin authenticated via REST API");
                unset($adm['password'], $adm['password_hash']);
                json_response(200, true, "Admin authenticated.", [
                    'admin' => $adm,
                    'auth'  => $token_data
                ]);
            } else {
                json_response(401, false, "Invalid admin credentials.");
            }
        }

        $admin = authenticate_api_admin($pdo);

        if (($segments[1] ?? '') === 'overview' && $method === 'GET') {
            $totDep = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE status = 'approved'")->fetchColumn();
            $pendDep = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")->fetchColumn();
            $totWd = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE status = 'approved'")->fetchColumn();
            $pendWd = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")->fetchColumn();
            $totUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $totInv = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM investments WHERE status = 'active'")->fetchColumn();

            json_response(200, true, "Admin overview metrics.", [
                'total_approved_deposits'    => $totDep,
                'pending_deposits_count'     => $pendDep,
                'total_approved_withdrawals' => $totWd,
                'pending_withdrawals_count'  => $pendWd,
                'total_users'                => $totUsers,
                'active_portfolio_capital'   => $totInv,
                'total_user_balances'        => sum_all_user_balances($pdo)
            ]);
        }

        if (($segments[1] ?? '') === 'deposits' && isset($segments[2]) && ($segments[3] ?? '') === 'approve' && $method === 'POST') {
            $dep_id = (int)$segments[2];
            $notes = trim($request_data['notes'] ?? 'Approved via Admin API');

            $pdo->beginTransaction();
            $dStmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
            $dStmt->execute([$dep_id]);
            $dep = normalize_deposit_row($dStmt->fetch(PDO::FETCH_ASSOC));

            if (!$dep || $dep['status'] !== 'pending') {
                $pdo->rollBack();
                json_response(400, false, "Deposit not found or already processed.");
            }

            $targetUser = lock_user_row($pdo, (int)$dep['user_id']);
            $newBal = round((float)($targetUser['balance'] ?? 0.00) + (float)$dep['amount'], 2);
            $dep_ref = $dep['reference_code'] ?: ('DEP-' . $dep_id);

            update_deposit_status($pdo, $dep_id, 'approved', $notes, (int)$admin['id']);
            update_user_balance($pdo, (int)$dep['user_id'], $newBal);

            record_transaction($pdo, (int)$dep['user_id'], 'deposit', $dep['amount'], $newBal, $dep_ref, "Approved via Admin API", 0, 'completed');
            create_notification($pdo, (int)$dep['user_id'], "Deposit Approved", "Your deposit of {$currency_symbol}{$dep['amount']} (Ref: {$dep_ref}) was approved.", "success");
            record_audit_log($pdo, $admin['id'], (int)$dep['user_id'], 'API_DEPOSIT_APPROVED', "Approved deposit #{$dep_id} ({$dep_ref})");

            $pdo->commit();
            json_response(200, true, "Deposit approved and user credited.");
        }

        if (($segments[1] ?? '') === 'withdrawals' && isset($segments[2]) && ($segments[3] ?? '') === 'reject' && $method === 'POST') {
            $wd_id = (int)$segments[2];
            $notes = trim($request_data['notes'] ?? 'Declined via Admin API');

            $pdo->beginTransaction();
            $wStmt = $pdo->prepare("SELECT * FROM withdrawals WHERE id = ? FOR UPDATE");
            $wStmt->execute([$wd_id]);
            $wd = $wStmt->fetch();

            if (!$wd || $wd['status'] !== 'pending') {
                $pdo->rollBack();
                json_response(400, false, "Withdrawal not found or already processed.");
            }

            $lockedUser = lock_user_row($pdo, (int)$wd['user_id']);
            $currBal = (float)($lockedUser['balance'] ?? 0.00);
            $refundBal = round($currBal + (float)$wd['amount'], 2);

            update_withdrawal_status($pdo, $wd_id, 'rejected', $notes, (int)$admin['id']);
            update_user_balance($pdo, (int)$wd['user_id'], $refundBal);

            record_transaction($pdo, (int)$wd['user_id'], 'refund', $wd['amount'], $refundBal, generate_reference('REFUND'), "Withdrawal refund: {$notes}", 0, 'completed');
            create_notification($pdo, (int)$wd['user_id'], "Withdrawal Declined", "Withdrawal of {$currency_symbol}{$wd['amount']} was declined and refunded.", "warning");
            record_audit_log($pdo, $admin['id'], (int)$wd['user_id'], 'API_WITHDRAWAL_REJECTED', "Rejected withdrawal #{$wd_id}. Refunded to wallet.");

            $pdo->commit();
            json_response(200, true, "Withdrawal rejected and amount refunded.");
        }
    }

    // 404 Route Not Found
    json_response(404, false, "Endpoint not found: {$method} /api/v1/{$rel_path}", null, [
        'available_routes' => [
            'POST /api/v1/auth/register',
            'POST /api/v1/auth/login',
            'POST /api/v1/auth/logout',
            'GET /api/v1/dashboard/stats',
            'GET /api/v1/plans',
            'GET /api/v1/investments',
            'POST /api/v1/investments',
            'GET /api/v1/deposits',
            'POST /api/v1/deposits/bank',
            'POST /api/v1/deposits/gateway',
            'GET /api/v1/withdrawals',
            'POST /api/v1/withdrawals',
            'GET /api/v1/transactions',
            'GET /api/v1/referrals',
            'GET /api/v1/user/profile',
            'PUT /api/v1/user/profile',
            'POST /api/v1/transfer',
            'GET /api/v1/notifications',
            'GET /api/v1/support/tickets',
            'POST /api/v1/support/tickets',
            'POST /api/v1/admin/login'
        ]
    ]);

} catch (Exception $e) {
    json_response(500, false, "Internal API error.", null, $e->getMessage());
}
