<?php
/**
 * Official Flutterwave Server-Side Payment Verification & Webhook Endpoint
 * GoldMine Investment Platform
 * 
 * Strict Security Architecture:
 * 1. Never accepts webhooks when configured webhook secret hash is empty.
 * 2. Rejects invalid or missing webhook signatures (HTTP_VERIF_HASH).
 * 3. Verifies payment status directly through Flutterwave's official API.
 * 4. Verifies transaction ID, transaction reference, amount, currency, and customer identity.
 * 5. Matches the verified payment to the original pending deposit record.
 * 6. Never credits a logged-in user merely because a browser callback contains a transaction ID.
 * 7. Prevents duplicate credits for the same Flutterwave transaction (idempotency).
 * 8. Uses atomic database transactions and row locking (FOR UPDATE) compatible with `balance` and `wallet_balance`.
 * 9. Ensures one deposit generates at most one referral commission using a deterministic reference.
 * 10. Does not trust browser-supplied amounts or customer IDs.
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$is_post = ($_SERVER['REQUEST_METHOD'] === 'POST');

// 1. Retrieve configured Flutterwave credentials
$flw_secret_key = trim(get_setting($pdo, 'flutterwave_secret_key', ''));
if (empty($flw_secret_key) && defined('FLUTTERWAVE_SECRET_KEY')) {
    $flw_secret_key = trim(FLUTTERWAVE_SECRET_KEY);
}

$flw_secret_hash = trim(get_setting($pdo, 'flutterwave_secret_hash', ''));
if (empty($flw_secret_hash) && defined('FLUTTERWAVE_SECRET_HASH')) {
    $flw_secret_hash = trim(FLUTTERWAVE_SECRET_HASH);
}

$site_currency = strtoupper(get_setting($pdo, 'site_currency', 'NGN'));
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');

// 2. Reject if secret key is unconfigured
if (empty($flw_secret_key)) {
    if ($is_post) {
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Flutterwave payment gateway is unconfigured on platform. Secret API key missing.'
        ]);
        exit;
    }
    $_SESSION['flash_error'] = "Online card & Flutterwave payments are currently disabled. Please use manual Bank Transfer with receipt upload.";
    header("Location: ../deposit.php");
    exit;
}

// 3. Webhook Signature Verification (HTTP POST)
$transaction_id = null;
$is_webhook = false;

if ($is_post) {
    $is_webhook = true;
    $received_hash = $_SERVER['HTTP_VERIF_HASH'] ?? '';

    // CRITICAL: Never accept a webhook when the configured secret hash is empty. Reject invalid or missing signatures.
    if (empty($flw_secret_hash) || empty($received_hash) || !hash_equals($flw_secret_hash, $received_hash)) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'error',
            'message' => 'Unauthorized: Missing, invalid, or unconfigured webhook signature hash.'
        ]);
        exit;
    }

    $raw_input = file_get_contents('php://input');
    $payload = json_decode($raw_input, true);

    if (empty($payload) || empty($payload['data']['id'])) {
        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Malformed webhook payload or missing transaction ID.']);
        exit;
    }

    $transaction_id = (string)$payload['data']['id'];
} else {
    // Browser Redirect Callback
    $status_param = $_GET['status'] ?? '';
    $transaction_id = $_GET['transaction_id'] ?? $_GET['tx_id'] ?? null;

    if ($status_param === 'cancelled') {
        $_SESSION['flash_error'] = "Payment transaction was cancelled.";
        header("Location: ../deposit.php");
        exit;
    }

    if (empty($transaction_id) || !is_numeric($transaction_id)) {
        $_SESSION['flash_error'] = "Invalid payment transaction reference returned by gateway.";
        header("Location: ../deposit.php");
        exit;
    }
}

// 4. Query Flutterwave's Official Server-Side API for Authentic Transaction Data
$verify_url = "https://api.flutterwave.com/v3/transactions/" . urlencode($transaction_id) . "/verify";

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $verify_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        "Authorization: Bearer {$flw_secret_key}",
        "Content-Type: application/json"
    ],
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => true
]);

$response_body = curl_exec($ch);
$curl_err = curl_error($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curl_err || $http_status !== 200 || empty($response_body)) {
    error_log("Flutterwave API Query Failure [HTTP {$http_status}]: " . ($curl_err ?: 'Empty response body'));
    if ($is_webhook) {
        http_response_code(502);
        echo json_encode(['status' => 'error', 'message' => 'Failed to reach Flutterwave verification service.']);
        exit;
    }
    $_SESSION['flash_error'] = "Unable to verify payment with Flutterwave gateway. Please contact support with transaction ID: {$transaction_id}";
    header("Location: ../deposit.php");
    exit;
}

$flw_response = json_decode($response_body, true);

// 5. Strict Verification of Payment Status
if (
    empty($flw_response) ||
    ($flw_response['status'] ?? '') !== 'success' ||
    ($flw_response['data']['status'] ?? '') !== 'successful'
) {
    $failure_msg = $flw_response['data']['processor_response'] ?? ($flw_response['message'] ?? 'Transaction was not successful.');
    error_log("Payment Gateway Refusal for FLW ID {$transaction_id}: " . $failure_msg);

    if ($is_webhook) {
        http_response_code(200);
        echo json_encode(['status' => 'ignored', 'message' => 'Transaction was not successful.']);
        exit;
    }
    $_SESSION['flash_error'] = "Payment verification failed: " . escape($failure_msg);
    header("Location: ../deposit.php");
    exit;
}

// Extract verified financial attributes
$verified_data = $flw_response['data'];
$verified_amount = (float)($verified_data['amount'] ?? 0);
$verified_currency = strtoupper($verified_data['currency'] ?? '');
$tx_ref = trim($verified_data['tx_ref'] ?? '');
$flw_id = (string)($verified_data['id'] ?? $transaction_id);
$customer_email = strtolower(trim($verified_data['customer']['email'] ?? ''));

if ($verified_amount <= 0 || empty($tx_ref)) {
    if ($is_webhook) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid verified amount or tx_ref returned by gateway.']);
        exit;
    }
    $_SESSION['flash_error'] = "Invalid payment data received from gateway verification.";
    header("Location: ../deposit.php");
    exit;
}

// 6. Database Settlement with Strict Matching to Pending Deposit Record
try {
    $pdo->beginTransaction();

    // CRITICAL: Match the verified payment to the original pending deposit record using `reference_code` or `gateway_ref`.
    // Never credit a logged-in user merely because a browser callback contains a transaction ID.
    $dep_cols = get_table_columns($pdo, 'deposits');
    $ref_col = isset($dep_cols['reference_code']) ? 'reference_code' : 'reference';
    if (isset($dep_cols['gateway_ref'])) {
        $stmtPending = $pdo->prepare("SELECT * FROM `deposits` WHERE `{$ref_col}` = ? OR `gateway_ref` = ? LIMIT 1 FOR UPDATE");
        $stmtPending->execute([$tx_ref, $flw_id]);
    } else {
        $stmtPending = $pdo->prepare("SELECT * FROM `deposits` WHERE `{$ref_col}` = ? LIMIT 1 FOR UPDATE");
        $stmtPending->execute([$tx_ref]);
    }
    $pendingDeposit = normalize_deposit_row($stmtPending->fetch(PDO::FETCH_ASSOC));

    if (!$pendingDeposit) {
        $pdo->rollBack();
        error_log("Payment Verification Rejected: No pending deposit record matched reference {$tx_ref}");
        if ($is_webhook) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'No matching pending deposit record found for reference: ' . $tx_ref]);
            exit;
        }
        $_SESSION['flash_error'] = "The payment reference was not recognized as an authorized deposit on this platform.";
        header("Location: ../deposit.php");
        exit;
    }

    $deposit_id = (int)$pendingDeposit['id'];
    $target_user_id = (int)$pendingDeposit['user_id'];

    // Prevent duplicate credits for the same Flutterwave transaction
    if ($pendingDeposit['status'] === 'approved') {
        $pdo->rollBack();
        if ($is_webhook) {
            http_response_code(200);
            echo json_encode(['status' => 'success', 'message' => 'Deposit #' . $deposit_id . ' already settled.']);
            exit;
        }
        $_SESSION['flash_success'] = "This deposit has already been verified and credited to your investment wallet.";
        header("Location: ../dashboard.php");
        exit;
    }

    // Lock target investor user record compatible with `balance` / `wallet_balance`
    $userRow = lock_user_row($pdo, $target_user_id);

    if (!$userRow) {
        $pdo->rollBack();
        error_log("Payment Verification Failed: Investor user #{$target_user_id} not found.");
        if ($is_webhook) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Investor account associated with deposit not found.']);
            exit;
        }
        $_SESSION['flash_error'] = "The investor account associated with this deposit could not be located.";
        header("Location: ../deposit.php");
        exit;
    }

    // Verify Customer Identity: Flutterwave customer email must match the account email
    if (!empty($customer_email) && strcasecmp($userRow['email'], $customer_email) !== 0) {
        $pdo->rollBack();
        error_log("Payment Identity Mismatch: Gateway customer {$customer_email} does not match investor account {$userRow['email']} (Deposit #{$deposit_id})");
        if ($is_webhook) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Payment customer identity does not match deposit account owner.']);
            exit;
        }
        $_SESSION['flash_error'] = "Customer payment identity does not match your registered account email.";
        header("Location: ../deposit.php");
        exit;
    }

    // Verify Deposit Amount: Verified amount must not be less than the initiated deposit
    if ($verified_amount < (float)$pendingDeposit['amount']) {
        $pdo->rollBack();
        error_log("Payment Amount Underpaid: Verified {$verified_amount} is less than deposit record {$pendingDeposit['amount']} (Deposit #{$deposit_id})");
        if ($is_webhook) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Verified gateway amount is less than expected deposit amount.']);
            exit;
        }
        $_SESSION['flash_error'] = "Paid amount is less than initiated deposit value. Please contact support.";
        header("Location: ../deposit.php");
        exit;
    }

    // 7. Atomic Wallet Settlement
    $current_balance = (float)$userRow['balance'];
    $new_balance = round($current_balance + $verified_amount, 2);

    $admin_notes = "Verified FLW-ID: {$flw_id} | Ref: {$tx_ref} | Customer: {$customer_email} | Amount: {$verified_amount} {$verified_currency}";

    // Update deposit record to approved using actual `deposits` columns (`admin_action_at`, `gateway_ref`, `admin_notes`, `updated_at`)
    update_deposit_status($pdo, $deposit_id, 'approved', $admin_notes, null, $verified_amount, $flw_id);

    // Update user balance compatible with `balance`
    update_user_balance($pdo, $target_user_id, $new_balance);

    // Record verified transaction in ledger (`reference_code`)
    record_transaction(
        $pdo,
        $target_user_id,
        'deposit',
        $verified_amount,
        $new_balance,
        $tx_ref,
        "Flutterwave verified online deposit (FLW: {$flw_id})",
        0.00,
        'completed'
    );

    // 8. Referral Commission Protection (if `referred_by` and `referral_code` exist)
    if (!empty($userRow['referred_by']) && has_column($pdo, 'users', 'referral_code')) {
        $refBonusPct = (float)get_setting($pdo, 'referral_bonus_percent', '10.00');
        if ($refBonusPct > 0) {
            $refBonusCode = 'REF-BONUS-DEP' . $deposit_id;

            // Check if referral commission has already been issued for this specific deposit using `reference_code`
            $alreadyRewarded = transaction_reference_exists($pdo, $refBonusCode, true);

            if (!$alreadyRewarded) {
                $stmtRefUser = $pdo->prepare("SELECT * FROM users WHERE referral_code = ? LIMIT 1 FOR UPDATE");
                $stmtRefUser->execute([$userRow['referred_by']]);
                $referrer = normalize_user_row($stmtRefUser->fetch(PDO::FETCH_ASSOC));

                if ($referrer) {
                    $refBonusAmount = round($verified_amount * ($refBonusPct / 100), 2);
                    if ($refBonusAmount > 0) {
                        $refNewBal = round((float)$referrer['balance'] + $refBonusAmount, 2);

                        // Atomically update referrer wallet
                        update_user_balance($pdo, (int)$referrer['id'], $refNewBal);

                        // Record in ledger with unique reference tied to the deposit
                        record_transaction(
                            $pdo,
                            (int)$referrer['id'],
                            'referral_bonus',
                            $refBonusAmount,
                            $refNewBal,
                            $refBonusCode,
                            "Referral commission ({$refBonusPct}%) on verified deposit #{$deposit_id}",
                            0.00,
                            'completed'
                        );

                        create_notification(
                            $pdo,
                            (int)$referrer['id'],
                            "Referral Commission Earned",
                            "Earned " . format_money($refBonusAmount, $currency_symbol) . " commission from partner referral on deposit #{$deposit_id}.",
                            "success"
                        );
                    }
                }
            }
        }
    }

    // User notification & security audit trail
    create_notification(
        $pdo,
        $target_user_id,
        "Deposit Verified & Credited",
        "Your Flutterwave payment of " . format_money($verified_amount, $currency_symbol) . " has been verified and settled to your wallet.",
        "success"
    );

    record_audit_log(
        $pdo,
        null,
        $target_user_id,
        'GATEWAY_DEPOSIT_VERIFIED',
        "Verified Flutterwave payment. FLW-ID: {$flw_id}, Ref: {$tx_ref}, Amount: {$verified_amount} {$verified_currency}"
    );

    $pdo->commit();

    if ($is_webhook) {
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => 'success',
            'message' => 'Deposit verified and credited successfully.',
            'ref'     => $tx_ref,
            'amount'  => $verified_amount
        ]);
        exit;
    }

    $_SESSION['flash_success'] = "Payment verified successfully! " . format_money($verified_amount, $currency_symbol) . " has been credited to your investment wallet.";
    header("Location: ../dashboard.php");
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Database Exception in Payment Verification: " . $e->getMessage());

    if ($is_webhook) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Database error during wallet settlement.']);
        exit;
    }
    $_SESSION['flash_error'] = "A database error occurred during wallet settlement. Please contact platform support.";
    header("Location: ../deposit.php");
    exit;
}
