<?php
/**
 * GoldMine Investment Platform - Master Environment Configuration
 * 
 * Hosting Environment: cPanel Shared Hosting (MySQL PDO)
 * Target Database: lhzmylpw_goldmine
 * Target User: lhzmylpw_goldmineapp
 */

// Database Host (default on cPanel is localhost)
if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
}

// Database Name
if (!defined('DB_NAME')) {
    define('DB_NAME', getenv('DB_NAME') ?: 'lhzmylpw_goldmine');
}

// Database Username
if (!defined('DB_USER')) {
    define('DB_USER', getenv('DB_USER') ?: 'lhzmylpw_goldmineapp');
}

// Database Password
// Set your cPanel MySQL user password below or configure via server environment variable DB_PASS
if (!defined('DB_PASS')) {
    define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
}

// Database Charset
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

// Automation Cron Secret:
// No hardcoded default token. If left empty (''), HTTP cron execution is strictly blocked,
// allowing only secure CLI execution via the cPanel server terminal/crontab.
if (!defined('CRON_SECRET')) {
    define('CRON_SECRET', getenv('CRON_SECRET') !== false ? getenv('CRON_SECRET') : '');
}

// Automation Switch:
// Keep automated payout execution disabled until accounting rules and authorizations are reviewed.
// Set to true in production once daily/term schedule is approved.
if (!defined('CRON_SETTLEMENT_ENABLED')) {
    define('CRON_SETTLEMENT_ENABLED', getenv('CRON_SETTLEMENT_ENABLED') === 'true' || getenv('CRON_SETTLEMENT_ENABLED') === '1');
}

// Payment Gateway (Flutterwave) Server-side Credentials:
// Keep disabled until live keys are configured in admin settings or here.
if (!defined('FLUTTERWAVE_SECRET_KEY')) {
    define('FLUTTERWAVE_SECRET_KEY', getenv('FLUTTERWAVE_SECRET_KEY') ?: '');
}

if (!defined('FLUTTERWAVE_SECRET_HASH')) {
    define('FLUTTERWAVE_SECRET_HASH', getenv('FLUTTERWAVE_SECRET_HASH') ?: '');
}

// Application & API Settings
if (!defined('APP_NAME')) {
    define('APP_NAME', 'GoldMine Investment Platform');
}

if (!defined('API_BASE_URL')) {
    define('API_BASE_URL', 'https://goalmindai.com.ng/api/v1/');
}
