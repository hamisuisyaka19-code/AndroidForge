<?php
/**
 * My Investments Portfolio & Maturity Tracker
 * GoldMine Investment Platform
 * 
 * Uses the authoritative `investments` table schema:
 * id, reference_code, user_id, plan_id, plan_name, amount, roi_percentage,
 * expected_return, duration_days, start_date, maturity_date, status,
 * admin_action_by, admin_action_at, admin_notes, created_at, updated_at
 */
$page_title = "My Investment Portfolio";
require_once __DIR__ . '/includes/header.php';
require_user_login();

$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$default_rate = (float)get_setting($pdo, 'target_projection_rate', '45.00');
if ($default_rate <= 0) {
    $default_rate = 45.00;
}

// Filter status
$status_filter = $_GET['status'] ?? 'all';
$where_clause = "WHERE i.user_id = ?";
$params = [$user_id];

if (in_array($status_filter, ['active', 'completed', 'cancelled'])) {
    $where_clause .= " AND i.status = ?";
    $params[] = $status_filter;
}

// Fetch user's investments using actual `investments` and `investment_plans` columns
$stmt = $pdo->prepare("
    SELECT i.*,
           COALESCE(NULLIF(i.plan_name, ''), p.name) AS resolved_plan_name,
           COALESCE(NULLIF(i.roi_percentage, 0), p.roi_percentage) AS resolved_roi_percentage,
           COALESCE(NULLIF(i.duration_days, 0), p.duration_days) AS resolved_duration_days
    FROM investments i
    LEFT JOIN investment_plans p ON i.plan_id = p.id
    {$where_clause}
    ORDER BY i.created_at DESC
");
$stmt->execute($params);
$raw_investments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$investments = [];
$total_active_principal = 0.00;
$total_projected_profit = 0.00;

foreach ($raw_investments as $item) {
    $item['plan_name'] = $item['resolved_plan_name'] ?? $item['plan_name'] ?? 'GoldMine';
    $item['roi_percentage'] = $item['resolved_roi_percentage'] ?? $item['roi_percentage'] ?? $default_rate;
    $item['duration_days'] = $item['resolved_duration_days'] ?? $item['duration_days'] ?? 7;
    $norm = normalize_investment_row($item, $default_rate);

    if ($norm['status'] === 'active') {
        $total_active_principal += (float)$norm['amount'];
        $total_projected_profit += (float)$norm['projected_profit'];
    }
    $investments[] = $norm;
}

// Actual earned profit comes from `users.total_profit` (never from a nonexistent column on `investments`)
$total_earned_profits = (float)($user['total_profit'] ?? 0.00);
?>

<div style="max-width: 1200px; margin: 0 auto; padding-bottom: 50px;">

  <!-- Header & Filter Tabs -->
  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: flex-end; gap: 16px; margin-bottom: 28px;">
    <div>
      <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
        My Investment Portfolio
      </h1>
      <p style="color: #8E9E94; font-size: 0.9rem;">
        Track your active plans, projected returns, actual earned profits, and maturity dates.
      </p>
    </div>

    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="my-investments.php?status=all" class="<?php echo $status_filter === 'all' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 8px 16px; font-size: 0.82rem;">All Positions</a>
      <a href="my-investments.php?status=active" class="<?php echo $status_filter === 'active' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 8px 16px; font-size: 0.82rem;">Active</a>
      <a href="my-investments.php?status=completed" class="<?php echo $status_filter === 'completed' ? 'btn-gold' : 'btn-outline-gold'; ?>" style="padding: 8px 16px; font-size: 0.82rem;">Matured</a>
      <a href="invest.php" class="btn-gold" style="padding: 8px 18px; font-size: 0.82rem;">+ New Investment</a>
    </div>
  </div>

  <!-- Summary Banner -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 18px; margin-bottom: 28px;">
    <div class="gm-card">
      <div style="font-size: 0.78rem; color: #8E9E94; text-transform: uppercase;">Active Principal Committed</div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.75rem; font-weight: 700; color: #FFF; margin-top: 6px;">
        <?php echo format_money($total_active_principal, $currency_symbol); ?>
      </div>
    </div>
    <div class="gm-card">
      <div style="font-size: 0.78rem; color: #8E9E94; text-transform: uppercase;">Projected Profit (Active Est.)</div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 1.75rem; font-weight: 700; margin-top: 6px;">
        +<?php echo format_money($total_projected_profit, $currency_symbol); ?>
      </div>
    </div>
    <div class="gm-card">
      <div style="font-size: 0.78rem; color: #8E9E94; text-transform: uppercase;">Actual Earned Profit (Account)</div>
      <div class="tabular-nums font-gold-serif" style="font-size: 1.75rem; font-weight: 700; color: #34D399; margin-top: 6px;">
        +<?php echo format_money($total_earned_profits, $currency_symbol); ?>
      </div>
    </div>
    <div class="gm-card">
      <div style="font-size: 0.78rem; color: #8E9E94; text-transform: uppercase;">Total Positions</div>
      <div class="tabular-nums font-gold-serif text-gold-gradient" style="font-size: 1.75rem; font-weight: 700; margin-top: 6px;">
        <?php echo count($investments); ?> Contracts
      </div>
    </div>
  </div>

  <!-- Investments List -->
  <?php if (empty($investments)): ?>
    <div class="gm-card" style="text-align: center; padding: 48px 24px;">
      <h3 class="font-gold-serif" style="font-size: 1.3rem; color: #FFF; margin-bottom: 10px;">No Investment Records Found</h3>
      <p style="color: #8E9E94; margin-bottom: 22px; font-size: 0.92rem;">
        You have no investment positions matching this filter. Start growing your portfolio with one of our 6 official plans.
      </p>
      <a href="invest.php" class="btn-gold">Select an Investment Plan</a>
    </div>
  <?php else: ?>
    <div style="display: flex; flex-direction: column; gap: 18px;">
      <?php foreach ($investments as $inv): 
        $start_ts = strtotime($inv['start_date']);
        $maturity_ts = strtotime($inv['maturity_date']);
        $now_ts = time();
        $total_duration = max(1, $maturity_ts - $start_ts);
        $elapsed = max(0, min($total_duration, $now_ts - $start_ts));
        $progress_pct = min(100, round(($elapsed / $total_duration) * 100, 1));

        $amt = (float)$inv['amount'];
        $rate = (float)$inv['roi_percentage'];
        $projected_profit = (float)$inv['projected_profit'];
        $projected_total  = (float)$inv['expected_return'];
        $ref_code = $inv['reference_code'];
        $plan_name = $inv['plan_name'];
        $is_matured = ($inv['status'] === 'completed' || $now_ts >= $maturity_ts);
      ?>
        <div class="gm-card" style="padding: 24px;">
          <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 18px; padding-bottom: 14px; border-bottom: 1px solid rgba(27,56,40,0.6);">
            <div>
              <span style="font-size: 0.75rem; color: #D4AF37; font-family: 'JetBrains Mono', monospace;">
                Ref: <?php echo escape($ref_code); ?>
              </span>
              <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF;">
                <?php echo escape($plan_name); ?> Plan
              </h3>
            </div>

            <div style="display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 0.82rem; color: #9FB1A6;">
                ROI Rate: <strong style="color: #D4AF37;"><?php echo number_format($rate, 0); ?>%</strong> (<?php echo (int)$inv['duration_days']; ?> Days)
              </span>
              <span class="badge-clean badge-<?php echo (!$is_matured && $inv['status'] === 'active') ? 'active' : 'completed'; ?>">
                <?php echo (!$is_matured && $inv['status'] === 'active') ? 'Active' : 'Matured'; ?>
              </span>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(175px, 1fr)); gap: 16px; margin-bottom: 18px;">
            <div>
              <div style="font-size: 0.75rem; color: #7D8F84;">Investment Amount</div>
              <div class="tabular-nums" style="font-size: 1.1rem; font-weight: 700; color: #FFF; margin-top: 2px;">
                <?php echo format_money($amt, $currency_symbol); ?>
              </div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: #7D8F84;">Projected Profit (<?php echo number_format($rate, 0); ?>%)</div>
              <div class="tabular-nums" style="font-size: 1.1rem; font-weight: 700; color: #D4AF37; margin-top: 2px;">
                +<?php echo format_money($projected_profit, $currency_symbol); ?>
              </div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: #7D8F84;">Expected Return (Projected Total)</div>
              <div class="tabular-nums" style="font-size: 1.1rem; font-weight: 700; color: #F5C518; margin-top: 2px;">
                <?php echo format_money($projected_total, $currency_symbol); ?>
              </div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: #7D8F84;">Start Date</div>
              <div class="tabular-nums" style="font-size: 0.9rem; color: #C2D1C7; margin-top: 4px;">
                <?php echo date('M d, Y H:i', $start_ts); ?>
              </div>
            </div>
            <div>
              <div style="font-size: 0.75rem; color: #7D8F84;">Maturity Date</div>
              <div class="tabular-nums" style="font-size: 0.9rem; color: #C2D1C7; margin-top: 4px;">
                <?php echo date('M d, Y H:i', $maturity_ts); ?>
              </div>
            </div>
          </div>

          <!-- Progress & Countdown Bar -->
          <div style="background: #06100B; border: 1px solid #162E21; border-radius: 8px; padding: 12px 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 0.8rem;">
              <span style="color: #9FB1A6;">Term Progress: <strong class="tabular-nums" style="color: #FFF;"><?php echo $progress_pct; ?>%</strong></span>
              <?php if (!$is_matured && $inv['status'] === 'active'): ?>
                <span class="tabular-nums inv-countdown" data-end="<?php echo $maturity_ts; ?>" style="color: #D4AF37; font-weight: 600;">
                  Calculating remaining time...
                </span>
              <?php else: ?>
                <span style="color: #34D399; font-weight: 600;">✓ Contract Cycle Completed</span>
              <?php endif; ?>
            </div>
            <div style="background: #030705; height: 8px; border-radius: 99px; overflow: hidden;">
              <div style="width: <?php echo $progress_pct; ?>%; height: 100%; background: linear-gradient(90deg, #D4AF37, #10B981);"></div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div style="margin-top: 24px; font-size: 0.78rem; color: #7D8F84; text-align: center;">
    * Projected returns are estimates and depend on plan terms and actual platform performance.
  </div>
</div>

<script>
function tickPortfolioCountdowns() {
  const now = Math.floor(Date.now() / 1000);
  document.querySelectorAll('.inv-countdown').forEach(el => {
    const end = parseInt(el.getAttribute('data-end'), 10);
    const diff = end - now;
    if (diff <= 0) {
      el.innerText = 'Matured — Pending Final Settlement';
      el.style.color = '#34D399';
      return;
    }
    const d = Math.floor(diff / 86400);
    const h = Math.floor((diff % 86400) / 3600);
    const m = Math.floor((diff % 3600) / 60);
    const s = diff % 60;
    el.innerText = `Time Left: ${d}d : ${h}h : ${m}m : ${s}s`;
  });
}
setInterval(tickPortfolioCountdowns, 1000);
tickPortfolioCountdowns();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
