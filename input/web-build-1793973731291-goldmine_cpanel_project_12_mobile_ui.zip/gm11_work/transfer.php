<?php
/**
 * Transfer Money to Investor
 * GoldMine Investment Platform
 * 
 * Fully compatible with live `lhzmylpw_goldmine` `users` schema (`balance`, `email`, `full_name`).
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Transfer Money";
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'transfer') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Invalid security token. Please try again.";
    } else {
        $recipient_input = trim($_POST['recipient'] ?? '');
        $amount = round((float)($_POST['amount'] ?? 0), 2);

        if (empty($recipient_input)) {
            $error = "Please enter the receiver email address or user ID.";
        } elseif ($amount <= 0) {
            $error = "Transfer amount must be greater than zero.";
        } elseif ($amount > (float)$user['balance']) {
            $error = "Insufficient funds. Your available balance is " . format_money($user['balance'], $currency_symbol);
        } else {
            // Find recipient safely using actual table columns
            $recipient = find_recipient_user($pdo, $recipient_input, $user_id, false);

            if (!$recipient) {
                $error = "Recipient user was not found. Please verify their registered email address.";
            } else {
                try {
                    $pdo->beginTransaction();

                    // Lock sender and recipient balances
                    $lockedSender = lock_user_row($pdo, $user_id);
                    $lockedRecip = lock_user_row($pdo, (int)$recipient['id']);

                    $sender_current = (float)($lockedSender['balance'] ?? 0.00);
                    $recip_current = (float)($lockedRecip['balance'] ?? 0.00);

                    if ($amount > $sender_current) {
                        $pdo->rollBack();
                        $error = "Insufficient funds. Your available balance is " . format_money($sender_current, $currency_symbol);
                    } else {
                        $sender_new = round($sender_current - $amount, 2);
                        $recip_new = round($recip_current + $amount, 2);

                        // 1. Deduct sender
                        update_user_balance($pdo, $user_id, $sender_new);

                        // 2. Credit receiver
                        update_user_balance($pdo, (int)$lockedRecip['id'], $recip_new);

                        // 3. Sender transaction
                        $refSender = generate_reference('TRF-OUT');
                        record_transaction($pdo, $user_id, 'withdrawal', $amount, $sender_new, $refSender, "Transfer sent to {$lockedRecip['full_name']} ({$lockedRecip['email']})", 0.00, 'completed');

                        // 4. Receiver transaction
                        $refReceiver = generate_reference('TRF-IN');
                        record_transaction($pdo, (int)$lockedRecip['id'], 'deposit', $amount, $recip_new, $refReceiver, "Transfer received from {$user['full_name']} ({$user['email']})", 0.00, 'completed');

                        // 5. Notifications
                        create_notification($pdo, $user_id, "Transfer Sent", "Transferred " . format_money($amount, $currency_symbol) . " to {$lockedRecip['full_name']}.", 'info');
                        create_notification($pdo, (int)$lockedRecip['id'], "Transfer Received", "Received " . format_money($amount, $currency_symbol) . " from {$user['full_name']}.", 'success');

                        $pdo->commit();
                        $success = "Successfully transferred " . format_money($amount, $currency_symbol) . " to {$lockedRecip['full_name']} ({$lockedRecip['email']})!";
                        $user['balance'] = $sender_new;
                        $user['wallet_balance'] = $sender_new;
                    }
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    error_log("Transfer Error: " . $e->getMessage());
                    $error = "Transfer transaction could not be completed. Please try again.";
                }
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 480px; margin: 20px auto; display: flex; flex-direction: column; gap: 20px;">
    <!-- Top Back & Title -->
    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(245, 197, 24, 0.25); padding-bottom: 16px;">
        <a href="dashboard.php" style="color: #F5C518; font-weight: 700; font-size: 0.9rem;">&larr; Back to Dashboard</a>
        <h1 style="font-size: 1.25rem; font-weight: 800; color: #FFF;">Transfer Money</h1>
        <div style="width: 40px;"></div>
    </div>

    <!-- Mode Pill -->
    <div style="background: #141414; border: 1px solid rgba(245, 197, 24, 0.35); border-radius: 12px; padding: 10px; text-align: center; color: #F5C518; font-weight: 700; font-size: 0.85rem;">
        Transfer to Investor Wallet
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-msg flash-error"><?php echo escape($error); ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="flash-msg flash-success"><?php echo escape($success); ?></div>
    <?php endif; ?>

    <!-- Transfer Form Card -->
    <div class="card" style="padding: 24px;">
        <form method="POST" action="transfer.php" style="display: flex; flex-direction: column; gap: 16px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="transfer">

            <div>
                <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #CCCCCC; margin-bottom: 6px;">
                    Enter Receiver Email or User ID *
                </label>
                <input 
                    type="text" 
                    name="recipient" 
                    required 
                    placeholder="investor@example.com"
                    class="form-control"
                    style="width: 100%; padding: 12px 14px; background: #0A0A0A; border: 1px solid rgba(245, 197, 24, 0.35); border-radius: 10px; color: #FFF;"
                >
            </div>

            <div>
                <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #CCCCCC; margin-bottom: 6px;">
                    Amount (<?php echo escape($currency_symbol); ?>) *
                </label>
                <input 
                    type="number" 
                    name="amount" 
                    step="100" 
                    min="100" 
                    required 
                    value="1000"
                    class="form-control"
                    style="width: 100%; padding: 12px 14px; background: #0A0A0A; border: 1px solid rgba(245, 197, 24, 0.35); border-radius: 10px; color: #FFF; font-weight: 700; font-size: 1.1rem;"
                >
                <div style="font-size: 0.75rem; color: #8E8E8E; margin-top: 4px;">
                    Available Balance: <strong style="color: #F5C518;"><?php echo format_money($user['balance'], $currency_symbol); ?></strong>
                </div>
            </div>

            <button type="submit" class="btn-gold" style="padding: 13px; font-weight: 800; font-size: 0.92rem; width: 100%; margin-top: 8px;">
                Transfer Now &rarr;
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
