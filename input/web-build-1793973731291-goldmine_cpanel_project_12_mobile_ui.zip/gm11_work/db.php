<?php
/**
 * Database Connection & PDO Bootstrap
 * GoldMine Investment Platform - cPanel Production Ready
 * 
 * Target Database: lhzmylpw_goldmine
 * Target User: lhzmylpw_goldmineapp
 */

// Ensure output buffering is active before any output to prevent "headers already sent" blank pages on redirects
if (!ob_get_level()) {
    ob_start();
}

// 1. Load Master Configuration if present
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}

// 2. Fallback constants if config.php was not loaded
if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', getenv('DB_NAME') ?: 'lhzmylpw_goldmine');
}
if (!defined('DB_USER')) {
    define('DB_USER', getenv('DB_USER') ?: 'lhzmylpw_goldmineapp');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
}
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

// 3. Establish Singleton PDO Connection
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    error_log("GoldMine Database Connection Failed: " . $e->getMessage());

    if (
        (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '/api/') !== false) ||
        (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
    ) {
        http_response_code(503);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'success' => false,
            'message' => 'Database connection error. Verify DB_PASS in config.php for user ' . DB_USER . '.',
            'database' => DB_NAME
        ]);
        exit;
    }

    http_response_code(503);
    die('
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Database Configuration Required | GoldMine</title>
        <style>
            body { background: #050B08; color: #E2ECE5; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .box { background: #0B1811; border: 1px solid #D4AF37; padding: 36px; border-radius: 12px; max-width: 540px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.7); }
            h2 { color: #D4AF37; margin-top: 0; font-size: 1.5rem; }
            p { color: #9FB1A6; line-height: 1.6; font-size: 0.95rem; }
            code { background: #060D09; color: #F3E5AB; padding: 3px 7px; border-radius: 4px; font-size: 0.88rem; }
        </style>
    </head>
    <body>
        <div class="box">
            <h2>Database Connection Setup</h2>
            <p>Unable to connect to MySQL database <code>' . htmlspecialchars(DB_NAME) . '</code> as user <code>' . htmlspecialchars(DB_USER) . '</code> on <code>' . htmlspecialchars(DB_HOST) . '</code>.</p>
            <p>Please open <code>config.php</code> in your cPanel File Manager, enter your MySQL password in <code>DB_PASS</code>, and ensure the user is assigned to the database with <strong>ALL PRIVILEGES</strong>.</p>
        </div>
    </body>
    </html>
    ');
}
