<?php
/**
 * Deposit & Funding Channels
 * GoldMine Investment Platform
 */
$page_title = "Fund Investment Wallet";
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_user_login();

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$currency_symbol = get_setting($pdo, 'currency_symbol', '₦');
$min_deposit = (float)get_setting($pdo, 'min_deposit', '50.00');

// Company bank settings for wire transfer
$bank_name = get_setting($pdo, 'company_bank_name', 'JPMorgan Chase Bank, N.A.');
$account_name = get_setting($pdo, 'company_account_name', 'GoldMine Global Asset Management LLC');
$account_number = get_setting($pdo, 'company_account_number', '48291048201');
$routing_number = get_setting($pdo, 'company_routing_number', '021000021');
$swift_code = get_setting($pdo, 'company_swift_code', 'CHASUS33');

// Flutterwave settings
$flw_pub_key = get_setting($pdo, 'flutterwave_public_key', '');

$error = '';
$success = '';
$initiated_flw_ref = '';
$initiated_flw_amount = 0;

// Handle Online Gateway Pending Deposit Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && in_array($_POST['action'], ['init_flutterwave', 'init_card'])) {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        if ($amount < $min_deposit) {
            $error = "Minimum deposit amount is " . format_money($min_deposit, $currency_symbol) . ".";
        } elseif (empty($flw_pub_key)) {
            $error = "Flutterwave payment gateway is currently disabled pending treasury API configuration in Settings. Please use Direct Bank Wire with receipt upload.";
        } else {
            $flw_tx_ref = generate_reference('FLW-DEP');
            create_deposit_record($pdo, [
                'reference_code' => $flw_tx_ref,
                'user_id'        => $user_id,
                'amount'         => $amount,
                'payment_method' => 'flutterwave',
                'gateway_ref'    => null,
                'receipt_path'   => null,
                'status'         => 'pending',
                'admin_notes'    => 'Pending Flutterwave gateway verification',
            ]);

            $initiated_flw_ref = $flw_tx_ref;
            $initiated_flw_amount = $amount;
        }
    }
}

// Handle Bank Transfer Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bank_deposit') {
    if (!validate_csrf_token()) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        $user_reference = trim($_POST['reference'] ?? '');

        if ($amount < $min_deposit) {
            $error = "Minimum deposit amount is " . format_money($min_deposit, $currency_symbol) . ".";
        } elseif (empty($user_reference)) {
            $error = "Please provide your bank transaction reference or sender name.";
        } else {
            // Upload receipt
            $receipt_filename = null;
            if (isset($_FILES['receipt_file']) && $_FILES['receipt_file']['error'] !== UPLOAD_ERR_NO_FILE) {
                $upload_res = handle_receipt_upload($_FILES['receipt_file']);
                if (!$upload_res['success']) {
                    $error = $upload_res['error'];
                } else {
                    $receipt_filename = $upload_res['filename'];
                }
            }

            if (empty($error)) {
                $system_reference = generate_reference('DEP-BNK');
                $ref_col = has_column($pdo, 'deposits', 'reference_code') ? 'reference_code' : 'reference';

                // Check duplicate reference
                $dup = $pdo->prepare("SELECT id FROM `deposits` WHERE `{$ref_col}` = ? LIMIT 1");
                $dup->execute([$system_reference]);
                if ($dup->fetch()) {
                    $system_reference = generate_reference('DEP-BNK2');
                }

                $admin_notes = "User Ref: " . $user_reference;

                $dep_id = create_deposit_record($pdo, [
                    'reference_code' => $system_reference,
                    'user_id'        => $user_id,
                    'amount'         => $amount,
                    'payment_method' => 'bank_transfer',
                    'gateway_ref'    => $user_reference,
                    'receipt_path'   => $receipt_filename,
                    'status'         => 'pending',
                    'admin_notes'    => $admin_notes,
                ]);

                if ($dep_id > 0) {
                    // Create notification
                    create_notification(
                        $pdo,
                        $user_id,
                        "Deposit Submitted (Pending Review)",
                        "Your bank transfer deposit of " . format_money($amount, $currency_symbol) . " (Ref: {$system_reference}) has been received and is pending administrator verification.",
                        "info"
                    );

                    record_audit_log($pdo, null, $user_id, 'DEPOSIT_SUBMITTED', "Bank transfer deposit of {$amount} submitted. Ref: {$system_reference}");

                    $success = "Your deposit proof has been submitted successfully! The funds will be credited to your wallet as soon as staff verifies the transaction.";
                } else {
                    $error = "Unable to record deposit. Please contact support.";
                }
            }
        }
    }
}

// Fetch user's deposit history
$depStmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$depStmt->execute([$user_id]);
$deposits = array_map('normalize_deposit_row', $depStmt->fetchAll(PDO::FETCH_ASSOC));

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 1050px; margin: 0 auto; padding-bottom: 50px;">
  <div style="margin-bottom: 28px;">
    <h1 class="font-gold-serif text-gold-gradient" style="font-size: 1.85rem; margin-bottom: 4px;">
      Fund Your Investment Account
    </h1>
    <p style="color: #8E9E94; font-size: 0.9rem;">
      Select your preferred funding channel below. Verified funds are immediately available for plan allocations.
    </p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #EF4444; border-radius: 8px; padding: 12px 18px; margin-bottom: 20px; color: #FCA5A5; font-size: 0.88rem;">
      <?php echo escape($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; color: #6EE7B7; font-size: 0.9rem;">
      <?php echo escape($success); ?>
    </div>
  <?php endif; ?>

  <!-- Deposit Method Selection Tabs -->
  <div style="display: flex; gap: 8px; margin-bottom: 24px; border-bottom: 1px solid rgba(212,175,55,0.2); padding-bottom: 12px;">
    <button onclick="switchTab('bank')" id="tab-btn-bank" class="btn-gold" style="padding: 9px 20px; font-size: 0.88rem;">
      Bank Transfer (Manual Wire)
    </button>
    <button onclick="switchTab('flutterwave')" id="tab-btn-flw" class="btn-outline-gold" style="padding: 9px 20px; font-size: 0.88rem;">
      Flutterwave Gateway
    </button>
    <button onclick="switchTab('card')" id="tab-btn-card" class="btn-outline-gold" style="padding: 9px 20px; font-size: 0.88rem;">
      Credit / Debit Card
    </button>
  </div>

  <!-- Channel 1: Bank Transfer Form -->
  <div id="channel-bank">
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;" class="calc-grid">
      <!-- Bank Details Card -->
      <div class="gm-card">
        <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 16px;">
          Official Company Bank Details
        </h3>
        <p style="color: #8E9E94; font-size: 0.85rem; margin-bottom: 20px;">
          Execute your wire or domestic transfer to the designated vault account below. Include your username in the payment narration.
        </p>

        <div style="display: flex; flex-direction: column; gap: 14px; font-size: 0.88rem; background: #07120B; padding: 18px; border-radius: 10px; border: 1px solid rgba(27,56,40,0.6);">
          <div>
            <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase;">Bank Institution</span>
            <div style="font-weight: 700; color: #FFF;"><?php echo escape($bank_name); ?></div>
          </div>
          <div>
            <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase;">Account Beneficiary</span>
            <div style="font-weight: 700; color: #FFF;"><?php echo escape($account_name); ?></div>
          </div>
          <div>
            <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase;">Account / IBAN Number</span>
            <div class="tabular-nums" style="font-weight: 700; color: #D4AF37; font-size: 1.05rem;">
              <?php echo escape($account_number); ?>
            </div>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <div>
              <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase;">Routing / ACH</span>
              <div class="tabular-nums" style="color: #FFF;"><?php echo escape($routing_number); ?></div>
            </div>
            <div>
              <span style="font-size: 0.75rem; color: #7D8F84; text-transform: uppercase;">SWIFT / BIC Code</span>
              <div class="tabular-nums" style="color: #FFF;"><?php echo escape($swift_code); ?></div>
            </div>
          </div>
        </div>

        <div style="margin-top: 18px; font-size: 0.8rem; color: #A3B5AA;">
          <strong>Tip:</strong> Deposits are confirmed by our treasury within 15–45 minutes of receipt verification.
        </div>
      </div>

      <!-- Submit Proof Form -->
      <div class="gm-card">
        <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 16px;">
          Submit Deposit Proof
        </h3>

        <form method="POST" action="deposit.php" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="action" value="bank_deposit">

          <div class="form-group">
            <label class="form-label">Deposit Amount (<?php echo escape($currency_symbol); ?>) *</label>
            <input type="number" name="amount" step="0.01" min="<?php echo $min_deposit; ?>" class="form-control" required placeholder="Minimum <?php echo $min_deposit; ?>">
          </div>

          <div class="form-group">
            <label class="form-label">Your Transaction Reference or Sender Name *</label>
            <input type="text" name="reference" class="form-control" required placeholder="e.g. Wire #90241 or John Doe">
          </div>

          <div class="form-group">
            <label class="form-label">Payment Receipt / Screenshot *</label>
            <input type="file" name="receipt_file" accept="image/png,image/jpeg,image/webp,application/pdf" class="form-control" required>
            <div style="font-size: 0.75rem; color: #7D8F84; margin-top: 5px;">
              Accepted: JPG, PNG, WEBP, PDF (Max 5MB).
            </div>
          </div>

          <button type="submit" class="btn-gold" style="width: 100%; padding: 12px; margin-top: 8px;">
            Submit Payment Proof for Verification
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Channel 2: Flutterwave Online -->
  <div id="channel-flutterwave" style="display: none;">
    <div class="gm-card" style="max-width: 600px; margin: 0 auto; text-align: center; padding: 40px 30px;">
      <h3 class="font-gold-serif text-gold-gradient" style="font-size: 1.6rem; margin-bottom: 8px;">
        Instant Flutterwave Gateway
      </h3>
      <p style="color: #8E9E94; font-size: 0.88rem; margin-bottom: 24px;">
        Pay instantly via Mobile Money, Bank Transfer, USSD, or African cards with instant automated wallet credit.
      </p>

      <form method="POST" action="deposit.php" style="max-width: 400px; margin: 0 auto; text-align: left;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="init_flutterwave">

        <div class="form-group">
          <label class="form-label">Amount (<?php echo escape($currency_symbol); ?>)</label>
          <input type="number" name="amount" class="form-control" min="<?php echo $min_deposit; ?>" value="100" required>
        </div>

        <button type="submit" class="btn-gold" style="width: 100%; padding: 13px;">
          Authorize & Launch Flutterwave
        </button>
      </form>

      <div style="margin-top: 24px; font-size: 0.78rem; color: #7D8F84;">
        Secured with TLS 1.3 256-bit encryption. Handled through Flutterwave API callback verification.
      </div>
    </div>
  </div>

  <!-- Channel 3: Debit / Credit Card -->
  <div id="channel-card" style="display: none;">
    <div class="gm-card" style="max-width: 600px; margin: 0 auto; padding: 36px 30px;">
      <h3 class="font-gold-serif text-gold-gradient" style="font-size: 1.6rem; margin-bottom: 8px; text-align: center;">
        Debit & Credit Card Gateway
      </h3>
      <p style="color: #8E9E94; font-size: 0.88rem; margin-bottom: 24px; text-align: center;">
        Global Visa, Mastercard, and American Express gateway. Zero sensitive card credentials stored on platform servers.
      </p>

      <form method="POST" action="deposit.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="init_card">

        <div class="form-group">
          <label class="form-label">Funding Amount (<?php echo escape($currency_symbol); ?>)</label>
          <input type="number" name="amount" class="form-control" min="<?php echo $min_deposit; ?>" value="250" required>
        </div>

        <div class="form-group">
          <label class="form-label">Name on Card</label>
          <input type="text" class="form-control" required placeholder="Cardholder Name">
        </div>

        <div class="form-group">
          <label class="form-label">Card Number</label>
          <input type="text" class="form-control" placeholder="•••• •••• •••• 4242" maxlength="19">
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div class="form-group">
            <label class="form-label">Expiry (MM/YY)</label>
            <input type="text" class="form-control" placeholder="12/28" maxlength="5">
          </div>
          <div class="form-group">
            <label class="form-label">CVV / CVC</label>
            <input type="password" class="form-control" placeholder="•••" maxlength="4">
          </div>
        </div>

        <button type="submit" id="card_pay_btn" class="btn-gold" style="width: 100%; padding: 13px; margin-top: 10px;">
          Authorize Card Payment
        </button>
      </form>
    </div>
  </div>

  <!-- User's Deposit History Table -->
  <div style="margin-top: 50px;">
    <h3 class="font-gold-serif" style="font-size: 1.25rem; color: #FFF; margin-bottom: 16px;">
      Deposit History & Status
    </h3>

    <div class="gm-table-container">
      <table class="gm-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Method</th>
            <th>Reference</th>
            <th>Amount</th>
            <th>Receipt</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($deposits)): ?>
            <tr>
              <td colspan="6" style="text-align: center; color: #8E9E94; padding: 24px;">
                You haven't initiated any deposits yet.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($deposits as $dep): ?>
              <tr>
                <td class="tabular-nums" style="font-size: 0.82rem; color: #94A3B8;">
                  <?php echo date('M d, Y H:i', strtotime($dep['created_at'])); ?>
                </td>
                <td style="text-transform: capitalize;">
                  <?php echo str_replace('_', ' ', escape($dep['payment_method'])); ?>
                </td>
                <td class="tabular-nums" style="font-size: 0.8rem; color: #D4AF37;">
                  <?php echo escape($dep['reference_code']); ?>
                </td>
                <td class="tabular-nums" style="font-weight: 700; color: #FFF;">
                  <?php echo format_money($dep['amount'], $currency_symbol); ?>
                </td>
                <td>
                  <?php if (!empty($dep['receipt_path'])): ?>
                    <a href="uploads/receipts/<?php echo escape(basename((string)$dep['receipt_path'])); ?>" target="_blank" style="color: #D4AF37; font-size: 0.8rem; text-decoration: underline;">
                      View Proof
                    </a>
                  <?php else: ?>
                    <span style="color: #64748B; font-size: 0.78rem;">Automated</span>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge-clean badge-<?php echo escape($dep['status']); ?>">
                    <?php echo escape($dep['status']); ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script src="https://checkout.flutterwave.com/v3.js"></script>
<script>
const FLW_PUB_KEY = <?php echo json_encode($flw_pub_key); ?>;
const USER_EMAIL = <?php echo json_encode($user['email'] ?? ''); ?>;
const USER_NAME = <?php echo json_encode($user['full_name'] ?? ''); ?>;
const SITE_CURRENCY = <?php echo json_encode(get_setting($pdo, 'site_currency', 'USD')); ?>;
const INITIATED_FLW_REF = <?php echo json_encode($initiated_flw_ref); ?>;
const INITIATED_FLW_AMOUNT = <?php echo (float)$initiated_flw_amount; ?>;

function switchTab(type) {
  document.getElementById('channel-bank').style.display = type === 'bank' ? 'block' : 'none';
  document.getElementById('channel-flutterwave').style.display = type === 'flutterwave' ? 'block' : 'none';
  document.getElementById('channel-card').style.display = type === 'card' ? 'block' : 'none';

  document.getElementById('tab-btn-bank').className = type === 'bank' ? 'btn-gold' : 'btn-outline-gold';
  document.getElementById('tab-btn-flw').className = type === 'flutterwave' ? 'btn-gold' : 'btn-outline-gold';
  document.getElementById('tab-btn-card').className = type === 'card' ? 'btn-gold' : 'btn-outline-gold';
}

function launchFlutterwaveModal(tx_ref, amount) {
  if (!FLW_PUB_KEY || FLW_PUB_KEY.trim() === '') {
    alert('Flutterwave payment gateway is currently disabled pending treasury API configuration in Settings. Please use the "Direct Bank Wire" tab with receipt upload.');
    return;
  }

  FlutterwaveCheckout({
    public_key: FLW_PUB_KEY,
    tx_ref: tx_ref,
    amount: amount,
    currency: SITE_CURRENCY,
    payment_options: "card,banktransfer,ussd",
    customer: {
      email: USER_EMAIL,
      name: USER_NAME,
    },
    callback: function (data) {
      if (data && data.transaction_id) {
        window.location.href = 'api/verify_payment.php?transaction_id=' + encodeURIComponent(data.transaction_id);
      } else {
        alert('Transaction completed but no transaction ID was returned. Contact support.');
      }
    },
    onclose: function() {
      // User cancelled modal
    },
    customizations: {
      title: "GoldMine Investment Platform",
      description: "Wallet Funding Deposit",
      logo: "https://goalmindai.com.ng/assets/logo.png",
    },
  });
}

// Auto-launch modal if server registered a pending deposit reference
if (INITIATED_FLW_REF && INITIATED_FLW_REF.length > 0 && INITIATED_FLW_AMOUNT > 0) {
  window.addEventListener('DOMContentLoaded', function() {
    launchFlutterwaveModal(INITIATED_FLW_REF, INITIATED_FLW_AMOUNT);
  });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
