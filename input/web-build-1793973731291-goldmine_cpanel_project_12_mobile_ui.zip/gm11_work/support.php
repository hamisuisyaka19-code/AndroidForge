<?php
/**
 * Customer Support Ticket Desk
 * GoldMine Investment Platform
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$page_title = "Customer Support Desk";
require_login();

// Ensure support_tickets table exists safely without affecting any existing records
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `support_tickets` (
          `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          `user_id` INT UNSIGNED NOT NULL,
          `ticket_code` VARCHAR(30) DEFAULT NULL,
          `subject` VARCHAR(200) NOT NULL,
          `priority` ENUM('low', 'normal', 'high', 'urgent') NOT NULL DEFAULT 'normal',
          `message` TEXT NOT NULL,
          `status` ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
          `admin_reply` TEXT DEFAULT NULL,
          `replied_at` DATETIME DEFAULT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX `idx_support_user` (`user_id`),
          INDEX `idx_support_status` (`status`),
          INDEX `idx_support_code` (`ticket_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
} catch (Exception $e) {
    // Ignore if table already exists
}

$user = get_current_user_data($pdo);
$user_id = (int)$user['id'];
$error = '';
$success = '';

// Handle New Ticket Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_ticket') {
    if (!validate_csrf_token()) {
        $error = "Invalid security token. Please try again.";
    } else {
        $subject = trim($_POST['subject'] ?? '');
        $priority = in_array($_POST['priority'] ?? '', ['low', 'normal', 'high', 'urgent']) ? $_POST['priority'] : 'normal';
        $message = trim($_POST['message'] ?? '');

        if (empty($subject) || empty($message)) {
            $error = "Please provide both a ticket subject and a detailed message.";
        } else {
            $ticket_code = 'TKT-' . strtoupper(substr(uniqid(), -6));
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO support_tickets (user_id, ticket_code, subject, priority, status, message, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 'open', ?, NOW(), NOW())
                ");
                $stmt->execute([$user_id, $ticket_code, $subject, $priority, $message]);
                $success = "Support ticket #{$ticket_code} submitted. A Treasury officer will respond shortly.";
            } catch (PDOException $e) {
                $error = "Failed to submit ticket. Please try again.";
            }
        }
    }
}

// Fetch user's tickets
$tickets = [];
try {
    $tickets_stmt = $pdo->prepare("
        SELECT * FROM support_tickets 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    $tickets_stmt->execute([$user_id]);
    $tickets = $tickets_stmt->fetchAll();
} catch (Exception $e) {
    $tickets = [];
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 32px;">
    <!-- Page Header -->
    <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 20px; border-bottom: 1px solid rgba(212, 175, 55, 0.2); padding-bottom: 24px;">
        <div>
            <h1 style="font-family: 'Cinzel', serif; font-size: 2rem; color: #FFF; margin-bottom: 6px;">
                Client Support &amp; Treasury Helpdesk
            </h1>
            <p style="color: #94A3B8; font-size: 0.9rem;">
                Submit inquiries regarding deposit verifications, withdrawal disbursements, or portfolio queries.
            </p>
        </div>
        <div>
            <a href="#new-ticket" class="btn-gold" style="padding: 10px 22px; font-size: 0.85rem; font-weight: 700;">
                + Open New Ticket
            </a>
        </div>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-msg flash-error"><?php echo escape($error); ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="flash-msg flash-success"><?php echo escape($success); ?></div>
    <?php endif; ?>

    <!-- Two-column layout: Tickets List & Create Form -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 32px; align-items: start;">
        
        <!-- Tickets History Column -->
        <div>
            <h2 style="font-family: 'Cinzel', serif; font-size: 1.25rem; color: #FFF; margin-bottom: 16px;">
                Your Support Tickets (<?php echo count($tickets); ?>)
            </h2>

            <?php if (empty($tickets)): ?>
                <div class="card" style="padding: 40px 20px; text-align: center; color: #94A3B8;">
                    <p style="font-size: 0.95rem; color: #FFF; margin-bottom: 6px;">No support tickets opened.</p>
                    <p style="font-size: 0.8rem;">Have an issue or inquiry? Create a ticket using the form on the right.</p>
                </div>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: 16px;">
                    <?php foreach ($tickets as $t): 
                        $badge_bg = 'rgba(234, 179, 8, 0.15)';
                        $badge_border = '#EAB308';
                        $badge_color = '#FDE047';
                        if ($t['status'] === 'answered') {
                            $badge_bg = 'rgba(16, 185, 129, 0.15)';
                            $badge_border = '#10B981';
                            $badge_color = '#34D399';
                        } elseif ($t['status'] === 'closed') {
                            $badge_bg = 'rgba(100, 116, 139, 0.15)';
                            $badge_border = '#64748B';
                            $badge_color = '#94A3B8';
                        }
                    ?>
                        <div class="card" style="padding: 20px;">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                                <div>
                                    <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; color: #D4AF37; font-weight: 600;">
                                        #<?php echo escape($t['ticket_code']); ?>
                                    </span>
                                    <h3 style="font-size: 1.05rem; font-weight: 700; color: #FFF; margin-top: 2px;">
                                        <?php echo escape($t['subject']); ?>
                                    </h3>
                                </div>
                                <span style="background: <?php echo $badge_bg; ?>; border: 1px solid <?php echo $badge_border; ?>; color: <?php echo $badge_color; ?>; font-size: 0.68rem; font-weight: 700; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">
                                    <?php echo ucfirst($t['status']); ?>
                                </span>
                            </div>

                            <div style="font-size: 0.85rem; color: #C2D1C7; line-height: 1.5; background: #040906; border: 1px solid #1B3828; border-radius: 6px; padding: 12px; margin-bottom: 12px;">
                                <?php echo nl2br(escape($t['message'])); ?>
                            </div>

                            <?php if (!empty($t['admin_reply'])): ?>
                                <div style="background: rgba(16, 185, 129, 0.08); border-left: 3px solid #10B981; border-radius: 4px; padding: 12px; margin-bottom: 12px;">
                                    <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: #34D399; font-weight: 700; margin-bottom: 4px;">
                                        <span>Treasury Compliance Officer</span>
                                        <span><?php echo !empty($t['replied_at']) ? date('M d, Y H:i', strtotime($t['replied_at'])) : ''; ?></span>
                                    </div>
                                    <div style="font-size: 0.85rem; color: #FFF; line-height: 1.5;">
                                        <?php echo nl2br(escape($t['admin_reply'])); ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div style="font-size: 0.75rem; color: #D4AF37; display: flex; align-items: center; gap: 6px; margin-bottom: 10px;">
                                    <span>⏳ Awaiting Treasury staff review...</span>
                                </div>
                            <?php endif; ?>

                            <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: #64748B; border-top: 1px solid rgba(27, 56, 40, 0.4); padding-top: 8px;">
                                <span>Priority: <strong style="text-transform: capitalize; color: #94A3B8;"><?php echo escape($t['priority']); ?></strong></span>
                                <span>Created: <?php echo date('M d, Y H:i', strtotime($t['created_at'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Create New Ticket Form Column -->
        <div id="new-ticket" class="card" style="padding: 28px;">
            <h2 style="font-family: 'Cinzel', serif; font-size: 1.25rem; color: #FFF; margin-bottom: 8px;">
                Open Support Request
            </h2>
            <p style="font-size: 0.82rem; color: #94A3B8; margin-bottom: 24px;">
                Our financial operations desk typically responds within 2-4 business hours.
            </p>

            <form method="POST" action="support.php" style="display: flex; flex-direction: column; gap: 18px;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="create_ticket">

                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 600; color: #C2D1C7; margin-bottom: 6px;">
                        Subject / Issue Category *
                    </label>
                    <input 
                        type="text" 
                        name="subject" 
                        required 
                        placeholder="e.g. Wire Deposit Receipt Verification #102"
                        class="form-control"
                        style="width: 100%; padding: 10px 14px; background: #07120C; border: 1px solid rgba(212, 175, 55, 0.3); border-radius: 6px; color: #FFF; font-size: 0.9rem;"
                    >
                </div>

                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 600; color: #C2D1C7; margin-bottom: 6px;">
                        Urgency Priority
                    </label>
                    <select 
                        name="priority"
                        style="width: 100%; padding: 10px 14px; background: #07120C; border: 1px solid rgba(212, 175, 55, 0.3); border-radius: 6px; color: #FFF; font-size: 0.9rem;"
                    >
                        <option value="low">Low - General Platform Inquiry</option>
                        <option value="normal" selected>Normal - Account or Plan Question</option>
                        <option value="high">High - Deposit or Withdrawal Delay</option>
                        <option value="urgent">Urgent - Security / Urgent Settlement</option>
                    </select>
                </div>

                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 600; color: #C2D1C7; margin-bottom: 6px;">
                        Detailed Description *
                    </label>
                    <textarea 
                        name="message" 
                        rows="6" 
                        required 
                        placeholder="Please include transaction reference numbers, dates, and full details to help us expedite your request..."
                        style="width: 100%; padding: 12px 14px; background: #07120C; border: 1px solid rgba(212, 175, 55, 0.3); border-radius: 6px; color: #FFF; font-size: 0.88rem; resize: vertical;"
                    ></textarea>
                </div>

                <button type="submit" class="btn-gold" style="padding: 12px; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    Dispatch Support Ticket
                </button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
