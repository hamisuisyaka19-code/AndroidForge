<?php
/**
 * GoldMine Investment Platform - Mobile Android & Website Synchronized API Controller (/api/index.php)
 * Mirror of root api.php so requests to /api/index.php?action=... and /api.php?action=... behave identically.
 */
require_once dirname(__DIR__) . '/api.php';
