<?php
/**
 * GoldMine Investment Platform - Official Investment Packages Page (invest.php)
 * Ensures all 5 investment packages (Starter Gold, Classic Gold, Premium Gold, VIP Gold, Diamond Gold)
 * are synchronized in the database and displayed with the reference horizontal card layout:
 * - Package image on the left, financial details on the right
 * - ROI badge at the top right
 * - Daily Profit, Duration, Minimum Investment, Maximum Investment, Total Return
 * - Separate green Invest Now button for every package
 */
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

require_user_login();

$pdo = get_db_connection();
$user_id = (int)$_SESSION['user_id'];

// Ensure all 5 official investment packages exist and are active in `investment_plans`
$official_packages = [
    [
        'name' => 'Starter Gold',
        'slug' => 'starter-gold',
        'match' => '%Starter%',
        'min_amount' => 1000.00,
        'max_amount' => 5000.00,
        'roi_percentage' => 35.00,
        'duration_days' => 3,
        'description' => 'Capital + 35% profit (₦1,350 – ₦6,750 total return in 3 Days)'
    ],
    [
        'name' => 'Classic Gold',
        'slug' => 'classic-gold',
        'match' => '%Classic%',
        'min_amount' => 10000.00,
        'max_amount' => 20000.00,
        'roi_percentage' => 45.00,
        'duration_days' => 7,
        'description' => 'Capital + 45% profit (₦14,500 – ₦29,000 total return in 7 Days)'
    ],
    [
        'name' => 'Premium Gold',
        'slug' => 'premium-gold',
        'match' => '%Premium%',
        'min_amount' => 30000.00,
        'max_amount' => 50000.00,
        'roi_percentage' => 45.00,
        'duration_days' => 15,
        'description' => 'Capital + 45% profit (₦43,500 – ₦72,500 total return in 15 Days)'
    ],
    [
        'name' => 'VIP Gold',
        'slug' => 'vip-gold',
        'match' => '%VIP%',
        'min_amount' => 100000.00,
        'max_amount' => 120000.00,
        'roi_percentage' => 45.00,
        'duration_days' => 30,
        'description' => 'Capital + 45% profit (₦145,000 – ₦174,000 total return in 30 Days)'
    ],
    [
        'name' => 'Diamond Gold',
        'slug' => 'diamond-gold',
        'match' => '%Diamond%',
        'min_amount' => 200000.00,
        'max_amount' => 1000000.00,
        'roi_percentage' => 45.00,
        'duration_days' => 60,
        'description' => 'Capital + 45% profit (₦290,000 – ₦1,450,000 total return in 60 Days)'
    ]
];

try {
    foreach ($official_packages as $op) {
        $chk = $pdo->prepare("SELECT id FROM investment_plans WHERE slug = ? OR name LIKE ? LIMIT 1");
        $chk->execute([$op['slug'], $op['match']]);
        $existing_id = $chk->fetchColumn();
        if ($existing_id) {
            $upd = $pdo->prepare("UPDATE investment_plans SET name = ?, slug = ?, min_amount = ?, max_amount = ?, duration_days = ?, roi_percentage = ?, description = ?, status = 'active' WHERE id = ?");
            $upd->execute([$op['name'], $op['slug'], $op['min_amount'], $op['max_amount'], $op['duration_days'], $op['roi_percentage'], $op['description'], $existing_id]);
        } else {
            $ins = $pdo->prepare("INSERT INTO investment_plans (name, slug, min_amount, max_amount, roi_percentage, duration_days, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
            $ins->execute([$op['name'], $op['slug'], $op['min_amount'], $op['max_amount'], $op['roi_percentage'], $op['duration_days'], $op['description']]);
        }
    }
} catch (Exception $ignored) {}

// Fetch current user
$u_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$u_stmt->execute([$user_id]);
$user = $u_stmt->fetch();

// Handle investment submission
$error_msg = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['plan_id'], $_POST['amount'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_msg = 'Security token mismatch. Please try again.';
    } else {
        $plan_id = (int)$_POST['plan_id'];
        $amount = (float)$_POST['amount'];

        $p_stmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND status = 'active' LIMIT 1");
        $p_stmt->execute([$plan_id]);
        $plan = $p_stmt->fetch();

        if (!$plan) {
            $error_msg = 'Selected investment package was not found.';
        } elseif ($amount < (float)$plan['min_amount']) {
            $error_msg = 'Minimum investment for ' . htmlspecialchars($plan['name']) . ' is ' . format_currency((float)$plan['min_amount']);
        } elseif ($amount > (float)$plan['max_amount']) {
            $error_msg = 'Maximum investment for ' . htmlspecialchars($plan['name']) . ' is ' . format_currency((float)$plan['max_amount']);
        } elseif ((float)$user['balance'] < $amount) {
            $error_msg = 'Insufficient balance (' . format_currency((float)$user['balance']) . '). Please deposit funds first.';
        } else {
            try {
                $pdo->beginTransaction();
                $ref = generate_reference('INV');
                $roi = (float)$plan['roi_percentage'];
                $duration_days = (int)$plan['duration_days'];
                $profit = round(($amount * $roi) / 100.0, 2);
                $expected_return = round($amount + $profit, 2);

                $now_ts = time();
                $start_date = date('Y-m-d H:i:s', $now_ts);
                $maturity_date = date('Y-m-d H:i:s', $now_ts + ($duration_days * 86400));

                $pdo->prepare("UPDATE users SET balance = balance - ?, total_invested = total_invested + ? WHERE id = ?")
                    ->execute([$amount, $amount, $user_id]);

                $pdo->prepare("INSERT INTO investments (reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')")
                    ->execute([$ref, $user_id, $plan['id'], $plan['name'], $amount, $roi, $expected_return, $duration_days, $start_date, $maturity_date]);

                $new_bal = (float)$user['balance'] - $amount;
                $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'investment', ?, ?, 'pending', ?)")
                    ->execute([$ref, $user_id, $amount, $new_bal, "Invested in " . $plan['name'] . " ($ref)"]);

                $pdo->commit();
                $user['balance'] = $new_bal;
                $success_msg = "Investment order $ref submitted successfully!";
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error_msg = 'Failed to submit investment. Please try again.';
            }
        }
    }
}

// Fetch all 5 active packages ordered by min_amount
$plans_stmt = $pdo->query("SELECT * FROM investment_plans WHERE status = 'active' ORDER BY min_amount ASC");
$plans = $plans_stmt ? $plans_stmt->fetchAll() : [];
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investment Packages - <?php echo htmlspecialchars(APP_NAME); ?></title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #080d0a; color: #ffffff; padding: 16px 16px 90px; }
        .container { max-width: 520px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .header h1 { font-size: 1.25rem; font-weight: 800; color: #fff; }
        .bal-pill { background: #121814; border: 1px solid #27342a; color: #eab308; padding: 6px 12px; border-radius: 999px; font-size: 0.8rem; font-weight: 700; }
        .alert { padding: 12px; border-radius: 12px; margin-bottom: 14px; font-size: 0.85rem; }
        .alert-error { background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #fca5a5; }
        .alert-success { background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); color: #6ee7b7; }
        .pkg-card { background: #121814; border: 1px solid #222e25; border-radius: 16px; padding: 14px; margin-bottom: 14px; display: flex; gap: 14px; align-items: stretch; }
        .pkg-left { width: 105px; flex-shrink: 0; background: linear-gradient(145deg, #1d1808, #0c130e); border: 1px solid rgba(234,179,8,0.35); border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 10px 6px; text-align: center; }
        .pkg-tier-tag { background: rgba(234,179,8,0.18); color: #eab308; font-size: 0.62rem; font-weight: 800; padding: 2px 7px; border-radius: 99px; text-transform: uppercase; }
        .pkg-icon { width: 48px; height: 48px; border-radius: 12px; background: linear-gradient(135deg, #facc15, #ca8a04); color: #000; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; justify-content: center; margin: 10px 0 8px; box-shadow: 0 4px 14px rgba(234,179,8,0.3); }
        .pkg-left-title { font-size: 0.72rem; font-weight: 800; color: #fff; text-transform: uppercase; }
        .pkg-left-dur { font-size: 0.68rem; color: #10b981; font-weight: 700; margin-top: 2px; }
        .pkg-right { flex: 1; display: flex; flex-direction: column; justify-content: space-between; min-width: 0; }
        .pkg-top { display: flex; justify-content: space-between; align-items: center; gap: 6px; padding-bottom: 6px; border-bottom: 1px solid #1f2922; margin-bottom: 6px; }
        .pkg-name { font-size: 0.98rem; font-weight: 800; color: #fff; }
        .roi-badge { background: #eab308; color: #090d0a; font-size: 0.7rem; font-weight: 900; padding: 3px 9px; border-radius: 99px; white-space: nowrap; }
        .pkg-rows { display: flex; flex-direction: column; gap: 3px; font-size: 0.75rem; margin-bottom: 8px; }
        .pkg-row { display: flex; justify-content: space-between; gap: 6px; }
        .pkg-row span:first-child { color: #9ca3af; }
        .pkg-row strong { color: #fff; text-align: right; }
        .pkg-row strong.green { color: #10b981; }
        .pkg-row strong.gold { color: #eab308; }
        .invest-form { display: flex; gap: 6px; margin-top: 4px; }
        .invest-input { flex: 1; min-width: 0; background: #090d0a; border: 1px solid #27342a; border-radius: 9px; padding: 8px 10px; color: #fff; font-size: 0.8rem; font-weight: 700; }
        .btn-invest-green { background: linear-gradient(135deg, #10b981, #059669); color: #fff; border: none; border-radius: 9px; padding: 8px 14px; font-size: 0.78rem; font-weight: 800; cursor: pointer; white-space: nowrap; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div>
            <h1>Investment Packages</h1>
            <p style="font-size:0.75rem;color:#9ca3af;margin-top:2px;">All 5 official GoldMine packages</p>
        </div>
        <div class="bal-pill">Bal: <?php echo format_currency((float)($user['balance'] ?? 0)); ?></div>
    </div>

    <?php if ($error_msg): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>
    <?php if ($success_msg): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>

    <?php foreach ($plans as $idx => $p):
        $roi = (float)$p['roi_percentage'];
        $dur = (int)$p['duration_days'];
        $min_amt = (float)$p['min_amount'];
        $max_amt = (float)$p['max_amount'];
        $min_daily = (($min_amt * $roi) / 100.0) / max(1, $dur);
        $max_daily = (($max_amt * $roi) / 100.0) / max(1, $dur);
        $min_total = $min_amt + (($min_amt * $roi) / 100.0);
        $max_total = $max_amt + (($max_amt * $roi) / 100.0);
    ?>
    <div class="pkg-card">
        <div class="pkg-left">
            <span class="pkg-tier-tag">Tier <?php echo $idx + 1; ?></span>
            <div class="pkg-icon">GM</div>
            <div class="pkg-left-title"><?php echo htmlspecialchars(str_replace('Gold', '', $p['name'])); ?></div>
            <div class="pkg-left-dur"><?php echo $dur; ?> Days</div>
        </div>
        <div class="pkg-right">
            <div>
                <div class="pkg-top">
                    <span class="pkg-name"><?php echo htmlspecialchars($p['name']); ?></span>
                    <span class="roi-badge"><?php echo (int)$roi; ?>% ROI</span>
                </div>
                <div class="pkg-rows">
                    <div class="pkg-row">
                        <span>Daily Profit:</span>
                        <strong class="green">+<?php echo format_currency($min_daily); ?> – <?php echo format_currency($max_daily); ?>/d</strong>
                    </div>
                    <div class="pkg-row">
                        <span>Duration:</span>
                        <strong><?php echo $dur; ?> Days</strong>
                    </div>
                    <div class="pkg-row">
                        <span>Min Investment:</span>
                        <strong><?php echo format_currency($min_amt); ?></strong>
                    </div>
                    <div class="pkg-row">
                        <span>Max Investment:</span>
                        <strong><?php echo format_currency($max_amt); ?></strong>
                    </div>
                    <div class="pkg-row">
                        <span>Total Return:</span>
                        <strong class="gold">Capital + <?php echo (int)$roi; ?>% profit</strong>
                    </div>
                    <div class="pkg-row">
                        <span>Payout Range:</span>
                        <strong class="gold"><?php echo format_currency($min_total); ?> – <?php echo format_currency($max_total); ?></strong>
                    </div>
                </div>
            </div>
            <form method="POST" class="invest-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                <input type="hidden" name="plan_id" value="<?php echo (int)$p['id']; ?>">
                <input type="number" name="amount" class="invest-input" min="<?php echo (int)$min_amt; ?>" max="<?php echo (int)$max_amt; ?>" step="100" value="<?php echo (int)$min_amt; ?>" required>
                <button type="submit" class="btn-invest-green">Invest Now</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>
