<?php
/**
 * GoldMine Investment Platform - Admin Dashboard Pending Deposits & Approval Manager (admin/deposits.php)
 * Displays all Pending, Approved, and Rejected deposits submitted from both the Android Application and Website.
 * Shows:
 * - User's Full Name & Email/Phone
 * - User ID
 * - Deposit Amount
 * - Transaction Reference
 * - Submission Date & Time
 * - Uploaded Payment Receipt (clickable preview modal + open full image/PDF)
 * - Functional Approve (atomic single-credit to user wallet) & Reject (with rejection reason) buttons
 */
$base_dir = dirname(__DIR__);
require_once $base_dir . '/config/app.php';
require_once $base_dir . '/config/database.php';
require_once $base_dir . '/includes/functions.php';
if (file_exists($base_dir . '/includes/auth.php')) {
    require_once $base_dir . '/includes/auth.php';
}

if (function_exists('require_admin_login')) {
    require_admin_login();
}

$pdo = get_db_connection();

// Ensure deposit table columns exist
try {
    $cols = [];
    $col_stmt = $pdo->query("SHOW COLUMNS FROM deposits");
    if ($col_stmt) {
        foreach ($col_stmt->fetchAll() as $c) {
            $cols[strtolower((string)$c['Field'])] = true;
        }
    }
    if (!isset($cols['receipt_path'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN receipt_path VARCHAR(255) DEFAULT NULL");
    }
    if (!isset($cols['proof_image'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN proof_image VARCHAR(255) DEFAULT NULL");
    }
    if (!isset($cols['admin_note'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN admin_note TEXT DEFAULT NULL");
    }
    if (!isset($cols['reviewed_at'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN reviewed_at DATETIME DEFAULT NULL");
    }
} catch (Exception $ignored) {}

$action_feedback = '';
$action_error = '';

// Handle Admin Approve or Reject POST Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deposit_id'], $_POST['admin_action'])) {
    $deposit_id = (int)$_POST['deposit_id'];
    $admin_action = strtolower(trim((string)$_POST['admin_action']));
    $admin_note = trim((string)($_POST['admin_note'] ?? ''));

    if ($deposit_id > 0 && $admin_action === 'approve') {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
            $stmt->execute([$deposit_id]);
            $dep = $stmt->fetch();

            if (!$dep) {
                $pdo->rollBack();
                $action_error = 'Deposit record not found.';
            } elseif (strtolower((string)$dep['status']) !== 'pending') {
                $pdo->rollBack();
                $action_error = 'Deposit ' . htmlspecialchars((string)$dep['reference_code']) . ' has already been processed (' . strtoupper((string)$dep['status']) . ').';
            } else {
                $uid = (int)$dep['user_id'];
                $amt = round((float)$dep['amount'], 2);
                $ref = (string)$dep['reference_code'];
                $note = $admin_note !== '' ? $admin_note : 'Payment receipt verified and approved by Admin';
                $now_str = date('Y-m-d H:i:s');

                // 1. Update deposit status to approved
                $upd = $pdo->prepare("UPDATE deposits SET status = 'approved', admin_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'");
                $upd->execute([$note, $now_str, $deposit_id]);

                if ($upd->rowCount() === 1) {
                    // 2. Credit user wallet ONCE ONLY
                    $u_lock = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
                    $u_lock->execute([$uid]);
                    $old_bal = (float)$u_lock->fetchColumn();
                    $new_bal = round($old_bal + $amt, 2);

                    $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?")->execute([$new_bal, $uid]);

                    // 3. Update transaction history
                    $tx_upd = $pdo->prepare("UPDATE transactions SET status = 'approved', balance_after = ?, description = ? WHERE reference_code = ? AND user_id = ?");
                    $tx_upd->execute([$new_bal, "Deposit Approved ($ref)", $ref, $uid]);
                    if ($tx_upd->rowCount() === 0) {
                        $tx_ins = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'deposit', ?, ?, 'approved', ?)");
                        $tx_ins->execute([$ref, $uid, $amt, $new_bal, "Deposit Approved ($ref)"]);
                    }

                    // 4. Notify user
                    if (function_exists('add_user_notification')) {
                        add_user_notification(
                            $uid,
                            "Deposit Approved & Credited",
                            "Your deposit of " . format_currency($amt) . " (Ref: $ref) has been approved by Admin and credited to your wallet.",
                            "success",
                            "/deposit.php"
                        );
                    }

                    $pdo->commit();
                    $action_feedback = "Deposit $ref (" . format_currency($amt) . ") APPROVED! User #$uid wallet credited once (New Balance: " . format_currency($new_bal) . ").";
                } else {
                    $pdo->rollBack();
                    $action_error = 'Deposit was already processed.';
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $action_error = 'Error approving deposit: ' . $e->getMessage();
        }
    } elseif ($deposit_id > 0 && $admin_action === 'reject') {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
            $stmt->execute([$deposit_id]);
            $dep = $stmt->fetch();

            if (!$dep) {
                $pdo->rollBack();
                $action_error = 'Deposit record not found.';
            } elseif (strtolower((string)$dep['status']) !== 'pending') {
                $pdo->rollBack();
                $action_error = 'Only pending deposits can be rejected.';
            } else {
                $uid = (int)$dep['user_id'];
                $amt = round((float)$dep['amount'], 2);
                $ref = (string)$dep['reference_code'];
                $reason = $admin_note !== '' ? $admin_note : 'Payment receipt could not be verified';
                $now_str = date('Y-m-d H:i:s');

                // 1. Update deposit status to rejected (do NOT credit wallet)
                $pdo->prepare("UPDATE deposits SET status = 'rejected', admin_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'")
                    ->execute([$reason, $now_str, $deposit_id]);

                // 2. Update transaction status to rejected
                $pdo->prepare("UPDATE transactions SET status = 'rejected', description = ? WHERE reference_code = ? AND user_id = ?")
                    ->execute(["Deposit Rejected ($ref): $reason", $ref, $uid]);

                // 3. Notify user
                if (function_exists('add_user_notification')) {
                    add_user_notification(
                        $uid,
                        "Deposit Rejected",
                        "Your deposit request of " . format_currency($amt) . " ($ref) was rejected by Admin. Reason: $reason.",
                        "error",
                        "/deposit.php"
                    );
                }

                $pdo->commit();
                $action_feedback = "Deposit $ref REJECTED. User wallet was not credited.";
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $action_error = 'Error rejecting deposit: ' . $e->getMessage();
        }
    }
}

$filter = strtolower(trim($_GET['status'] ?? 'all'));
$sql = "
    SELECT d.*, u.full_name, u.email, u.phone, u.balance AS user_balance
    FROM deposits d
    LEFT JOIN users u ON d.user_id = u.id
";
$params = [];
if (in_array($filter, ['pending', 'approved', 'rejected'], true)) {
    $sql .= " WHERE d.status = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY CASE WHEN d.status = 'pending' THEN 0 ELSE 1 END, d.id DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$deposits = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard — Pending Deposits &amp; Verification</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #070b08; color: #fff; padding: 24px; }
        .wrap { max-width: 1200px; margin: 0 auto; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 12px; }
        .top-bar h1 { font-size: 1.4rem; font-weight: 900; color: #eab308; }
        .filters { display: flex; gap: 8px; }
        .filter-btn { padding: 7px 14px; border-radius: 99px; font-size: 0.78rem; font-weight: 800; text-decoration: none; color: #9ca3af; background: #121814; border: 1px solid #263128; }
        .filter-btn.active { background: #eab308; color: #000; border-color: #eab308; }
        .alert { padding: 12px 16px; border-radius: 12px; margin-bottom: 16px; font-size: 0.85rem; font-weight: 700; }
        .alert-ok { background: rgba(16,185,129,0.18); border: 1px solid #10b981; color: #6ee7b7; }
        .alert-err { background: rgba(239,68,68,0.18); border: 1px solid #ef4444; color: #fca5a5; }
        table { width: 100%; border-collapse: collapse; background: #111713; border-radius: 16px; overflow: hidden; border: 1px solid #222d24; }
        th, td { padding: 12px 14px; text-align: left; border-bottom: 1px solid #1d261f; font-size: 0.82rem; vertical-align: middle; }
        th { background: #161f19; color: #9ca3af; font-weight: 800; text-transform: uppercase; font-size: 0.72rem; }
        .badge { padding: 3px 9px; border-radius: 99px; font-size: 0.68rem; font-weight: 900; text-transform: uppercase; }
        .badge-pending { background: rgba(234,179,8,0.2); color: #eab308; }
        .badge-approved { background: rgba(16,185,129,0.2); color: #10b981; }
        .badge-rejected { background: rgba(239,68,68,0.2); color: #ef4444; }
        .btn-approve { background: #10b981; color: #fff; border: none; padding: 7px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; cursor: pointer; }
        .btn-reject { background: #ef4444; color: #fff; border: none; padding: 7px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; cursor: pointer; }
        .receipt-link { color: #eab308; font-weight: 700; text-decoration: underline; }
        .note-input { background: #090d0a; border: 1px solid #2a362d; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 0.75rem; width: 150px; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="top-bar">
        <div>
            <h1>Admin Dashboard — Deposit Requests &amp; Receipt Verification</h1>
            <p style="font-size:0.8rem;color:#9ca3af;margin-top:4px;">Synchronized with Android App &amp; Website MySQL Database</p>
        </div>
        <div class="filters">
            <a href="?status=all" class="filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">All Deposits</a>
            <a href="?status=pending" class="filter-btn <?php echo $filter === 'pending' ? 'active' : ''; ?>">Pending Deposits</a>
            <a href="?status=approved" class="filter-btn <?php echo $filter === 'approved' ? 'active' : ''; ?>">Approved</a>
            <a href="?status=rejected" class="filter-btn <?php echo $filter === 'rejected' ? 'active' : ''; ?>">Rejected</a>
        </div>
    </div>

    <?php if ($action_feedback !== ''): ?>
        <div class="alert alert-ok"><?php echo htmlspecialchars($action_feedback); ?></div>
    <?php endif; ?>
    <?php if ($action_error !== ''): ?>
        <div class="alert alert-err"><?php echo htmlspecialchars($action_error); ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Reference</th>
                <th>User Name &amp; ID</th>
                <th>Deposit Amount</th>
                <th>Date &amp; Time</th>
                <th>Payment Receipt</th>
                <th>Status</th>
                <th>Admin Action (Approve / Reject)</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($deposits)): ?>
            <tr>
                <td colspan="7" style="text-align:center;padding:28px;color:#9ca3af;">No deposit records found for this filter.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($deposits as $d):
                $st = strtolower(trim((string)($d['status'] ?? 'pending')));
                $badge_cls = $st === 'approved' ? 'badge-approved' : ($st === 'rejected' ? 'badge-rejected' : 'badge-pending');
                $receipt_rel = $d['receipt_path'] ?? ($d['proof_image'] ?? '');
                $receipt_href = $receipt_rel !== '' ? ('../' . ltrim((string)$receipt_rel, '/')) : '';
            ?>
            <tr>
                <td style="font-family:monospace;font-weight:800;"><?php echo htmlspecialchars((string)$d['reference_code']); ?></td>
                <td>
                    <strong><?php echo htmlspecialchars((string)($d['full_name'] ?? 'User')); ?></strong>
                    <div style="font-size:0.72rem;color:#9ca3af;">User ID: #<?php echo (int)$d['user_id']; ?> • <?php echo htmlspecialchars((string)($d['email'] ?? '')); ?></div>
                </td>
                <td style="font-weight:900;color:#eab308;font-size:0.92rem;"><?php echo format_currency((float)$d['amount']); ?></td>
                <td style="color:#d1d5db;font-size:0.76rem;"><?php echo htmlspecialchars((string)($d['created_at'] ?? '')); ?></td>
                <td>
                    <?php if ($receipt_href !== ''): ?>
                        <a href="<?php echo htmlspecialchars($receipt_href); ?>" target="_blank" class="receipt-link">Open Receipt</a>
                    <?php else: ?>
                        <span style="color:#6b7280;font-size:0.75rem;">No file attached</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars(strtoupper($st)); ?></span>
                    <?php if (!empty($d['admin_note'])): ?>
                        <div style="font-size:0.7rem;color:#9ca3af;margin-top:3px;"><?php echo htmlspecialchars((string)$d['admin_note']); ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($st === 'pending'): ?>
                        <form method="POST" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                            <input type="hidden" name="deposit_id" value="<?php echo (int)$d['id']; ?>">
                            <input type="text" name="admin_note" class="note-input" placeholder="Admin note / reason">
                            <button type="submit" name="admin_action" value="approve" class="btn-approve">Approve</button>
                            <button type="submit" name="admin_action" value="reject" class="btn-reject">Reject</button>
                        </form>
                    <?php else: ?>
                        <span style="font-size:0.74rem;color:#6b7280;">Processed <?php echo htmlspecialchars((string)($d['reviewed_at'] ?? '')); ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
