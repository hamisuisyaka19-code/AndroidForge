<?php
/**
 * GoldMine Investment Platform - Synchronized Deposit Funds & Deposit Status Page (deposit.php)
 * Works seamlessly for both web browser users and the Android mobile application fallback engine:
 * - Saves deposits to the existing MySQL `deposits` and `transactions` tables
 * - Accepts receipt uploads under `receipt`, `proof_image`, or `payment_receipt`
 * - Displays the user's Deposit History & Admin Approval Status (`PENDING`, `APPROVED`, `REJECTED`)
 *   directly below the Submit Deposit Order button.
 */
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/payment.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

require_user_login();

$pdo = get_db_connection();
$user_id = (int)$_SESSION['user_id'];

// Ensure deposit table columns exist safely
try {
    $cols = [];
    $col_stmt = $pdo->query("SHOW COLUMNS FROM deposits");
    if ($col_stmt) {
        foreach ($col_stmt->fetchAll() as $c) {
            $cols[strtolower((string)$c['Field'])] = true;
        }
    }
    if (!isset($cols['payment_method'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN payment_method VARCHAR(100) DEFAULT 'Manual Bank Transfer'");
    }
    if (!isset($cols['receipt_path'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN receipt_path VARCHAR(255) DEFAULT NULL");
    }
    if (!isset($cols['proof_image'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN proof_image VARCHAR(255) DEFAULT NULL");
    }
    if (!isset($cols['admin_note'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN admin_note TEXT DEFAULT NULL");
    }
    if (!isset($cols['reviewed_at'])) {
        $pdo->exec("ALTER TABLE deposits ADD COLUMN reviewed_at DATETIME DEFAULT NULL");
    }
} catch (Exception $ignored) {}

$u_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$u_stmt->execute([$user_id]);
$user = $u_stmt->fetch();

$error_msg = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
    $csrf_valid = true;
    if (!empty($_POST['csrf_token']) && function_exists('verify_csrf_token')) {
        $csrf_valid = verify_csrf_token($_POST['csrf_token']);
    }

    if (!$csrf_valid) {
        $error_msg = 'Security token mismatch. Please try again.';
    } else {
        $amount = (float)$_POST['amount'];
        if ($amount < 500) {
            $error_msg = 'Minimum deposit amount is ₦500.00.';
        } else {
            $upload_dir = __DIR__ . '/uploads/deposit_receipts';
            if (!is_dir($upload_dir)) {
                @mkdir($upload_dir, 0755, true);
            }

            $receipt_db_path = null;
            foreach (['receipt', 'proof_image', 'payment_receipt', 'file'] as $fk) {
                if (!empty($_FILES[$fk]) && $_FILES[$fk]['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES[$fk];
                    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'pdf'], true)) {
                        $ext = 'jpg';
                    }
                    $stored_name = 'receipt_' . $user_id . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
                    if (move_uploaded_file($file['tmp_name'], $upload_dir . '/' . $stored_name)) {
                        $receipt_db_path = 'uploads/deposit_receipts/' . $stored_name;
                    }
                    break;
                }
            }

            try {
                $pdo->beginTransaction();
                $ref = generate_reference('DEP');
                $method = 'Manual Bank Transfer';

                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path, proof_image) VALUES (?, ?, ?, ?, 'pending', ?, ?)");
                $ins->execute([$ref, $user_id, $amount, $method, $receipt_db_path, $receipt_db_path]);

                $curr_bal = (float)($user['balance'] ?? 0);
                $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'deposit', ?, ?, 'pending', ?)");
                $tx->execute([$ref, $user_id, $amount, $curr_bal, "Deposit request via $method ($ref)"]);

                if (function_exists('add_user_notification')) {
                    add_user_notification(
                        $user_id,
                        "Deposit Request Submitted",
                        "Your deposit of " . format_currency($amount) . " ($ref) is awaiting administrator approval.",
                        "info",
                        "/deposit.php"
                    );
                }

                $pdo->commit();
                $success_msg = "Deposit order $ref (" . format_currency($amount) . ") submitted successfully! Status: PENDING — Awaiting admin approval.";
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error_msg = 'Could not save deposit request: ' . $e->getMessage();
            }
        }
    }
}

// Fetch user's deposit history ordered newest first
$dep_stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 50");
$dep_stmt->execute([$user_id]);
$deposits = $dep_stmt->fetchAll();

$csrf_token = function_exists('generate_csrf_token') ? generate_csrf_token() : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Funds - <?php echo htmlspecialchars(APP_NAME); ?></title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #080d0a; color: #ffffff; padding: 16px 16px 90px; }
        .container { max-width: 520px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .header h1 { font-size: 1.25rem; font-weight: 800; color: #fff; }
        .bal-pill { background: #121814; border: 1px solid #27342a; color: #eab308; padding: 6px 12px; border-radius: 999px; font-size: 0.8rem; font-weight: 700; }
        .card { background: #121814; border: 1px solid #222e25; border-radius: 16px; padding: 16px; margin-bottom: 16px; }
        .bank-box { background: #090d0a; border: 1px solid rgba(234,179,8,0.3); border-radius: 12px; padding: 12px; margin-top: 10px; font-size: 0.85rem; line-height: 1.6; }
        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 0.8rem; color: #9ca3af; font-weight: 600; margin-bottom: 6px; }
        .form-control { width: 100%; background: #090d0a; border: 1px solid #27342a; border-radius: 10px; padding: 11px 12px; color: #fff; font-size: 0.9rem; font-weight: 700; }
        .btn-submit { width: 100%; background: linear-gradient(135deg, #facc15, #ca8a04); color: #000; border: none; border-radius: 12px; padding: 13px; font-size: 0.9rem; font-weight: 900; cursor: pointer; }
        .alert { padding: 12px; border-radius: 12px; margin-bottom: 14px; font-size: 0.84rem; font-weight: 600; }
        .alert-error { background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #fca5a5; }
        .alert-success { background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); color: #6ee7b7; }
        .dep-item { background: #121814; border: 1px solid #222e25; border-radius: 14px; padding: 14px; margin-bottom: 10px; }
        .dep-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
        .dep-ref { font-size: 0.8rem; font-weight: 800; color: #fff; font-family: monospace; }
        .badge { font-size: 0.68rem; font-weight: 900; padding: 3px 9px; border-radius: 99px; text-transform: uppercase; }
        .badge-pending { background: rgba(234,179,8,0.2); color: #eab308; border: 1px solid rgba(234,179,8,0.35); }
        .badge-approved { background: rgba(16,185,129,0.2); color: #10b981; border: 1px solid rgba(16,185,129,0.35); }
        .badge-rejected { background: rgba(239,68,68,0.2); color: #ef4444; border: 1px solid rgba(239,68,68,0.35); }
        .dep-amount { font-size: 1.05rem; font-weight: 900; color: #eab308; margin-bottom: 4px; }
        .dep-status-text { font-size: 0.76rem; color: #d1d5db; margin-top: 4px; }
        .dep-date { font-size: 0.7rem; color: #6b7280; margin-top: 4px; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div>
            <h1>Deposit Funds</h1>
            <p style="font-size:0.75rem;color:#9ca3af;margin-top:2px;">Manual Bank Transfer &amp; Live Approval Status</p>
        </div>
        <div class="bal-pill">Wallet: <?php echo format_currency((float)($user['balance'] ?? 0)); ?></div>
    </div>

    <?php if ($error_msg !== ''): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <?php if ($success_msg !== ''): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>

    <div class="card">
        <h3 style="font-size:0.9rem;color:#eab308;font-weight:800;">Step 1: Transfer to Official GoldMine Account</h3>
        <div class="bank-box">
            <div>Bank Name: <strong style="color:#fff;"><?php echo htmlspecialchars(COMPANY_BANK_NAME); ?></strong></div>
            <div>Account Number: <strong style="color:#eab308;font-size:1rem;"><?php echo htmlspecialchars(COMPANY_ACCOUNT_NUMBER); ?></strong></div>
            <div>Account Name: <strong style="color:#fff;"><?php echo htmlspecialchars(COMPANY_ACCOUNT_NAME); ?></strong></div>
        </div>

        <form method="POST" action="deposit.php" enctype="multipart/form-data" style="margin-top:14px;">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <div class="form-group">
                <label>Deposit Amount (₦) — Minimum ₦500.00</label>
                <input type="number" name="amount" min="500" step="any" required class="form-control" placeholder="e.g. 10000">
            </div>
            <div class="form-group">
                <label>Upload Payment Receipt (JPG, PNG, WEBP, or PDF)</label>
                <input type="file" name="receipt" accept="image/*,.pdf" required class="form-control">
            </div>
            <button type="submit" class="btn-submit">Submit Deposit Order</button>
        </form>
    </div>

    <!-- DEPOSIT HISTORY / DEPOSIT STATUS SECTION BELOW SUBMIT BUTTON -->
    <div style="margin-top: 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h3 style="font-size:0.95rem;font-weight:800;color:#fff;">Deposit History &amp; Approval Status</h3>
            <span style="font-size:0.72rem;color:#9ca3af;"><?php echo count($deposits); ?> Record(s)</span>
        </div>

        <?php if (empty($deposits)): ?>
            <div class="card" style="text-align:center;color:#9ca3af;font-size:0.82rem;">
                No deposit requests submitted yet. Once you submit a deposit, its live status (PENDING, APPROVED, or REJECTED) will appear here.
            </div>
        <?php else: ?>
            <?php foreach ($deposits as $dep):
                $st = strtolower(trim((string)($dep['status'] ?? 'pending')));
                if ($st === 'approved' || $st === 'completed') {
                    $badge_class = 'badge-approved';
                    $badge_label = 'APPROVED';
                    $status_desc = 'APPROVED — Admin has approved the deposit and credited your wallet.';
                } elseif ($st === 'rejected') {
                    $badge_class = 'badge-rejected';
                    $badge_label = 'REJECTED';
                    $reason = trim((string)($dep['admin_note'] ?? ''));
                    $status_desc = 'REJECTED — Admin has rejected the deposit' . ($reason !== '' ? ' (' . $reason . ')' : '.');
                } else {
                    $badge_class = 'badge-pending';
                    $badge_label = 'PENDING';
                    $status_desc = 'PENDING — Deposit submitted and awaiting admin approval.';
                }
                $rec_file = $dep['receipt_path'] ?? ($dep['proof_image'] ?? '');
            ?>
                <div class="dep-item"
                     data-deposit-id="<?php echo (int)$dep['id']; ?>"
                     data-deposit-ref="<?php echo htmlspecialchars((string)$dep['reference_code']); ?>"
                     data-deposit-amount="<?php echo htmlspecialchars((string)$dep['amount']); ?>"
                     data-deposit-status="<?php echo htmlspecialchars(strtolower($badge_label)); ?>"
                     data-deposit-date="<?php echo htmlspecialchars((string)($dep['created_at'] ?? '')); ?>"
                     data-deposit-note="<?php echo htmlspecialchars((string)($dep['admin_note'] ?? '')); ?>">
                    <div class="dep-top">
                        <span class="dep-ref"><?php echo htmlspecialchars((string)$dep['reference_code']); ?></span>
                        <span class="badge <?php echo $badge_class; ?>"><?php echo $badge_label; ?></span>
                    </div>
                    <div class="dep-amount">+<?php echo format_currency((float)$dep['amount']); ?></div>
                    <div class="dep-status-text"><?php echo htmlspecialchars($status_desc); ?></div>
                    <div class="dep-date">
                        Submitted: <?php echo htmlspecialchars((string)($dep['created_at'] ?? '')); ?>
                        <?php if (!empty($rec_file)): ?>
                            • <a href="<?php echo htmlspecialchars((string)$rec_file); ?>" target="_blank" style="color:#eab308;text-decoration:underline;">View Receipt</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
