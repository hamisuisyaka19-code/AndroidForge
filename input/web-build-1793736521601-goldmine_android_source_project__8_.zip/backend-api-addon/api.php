<?php
/**
 * GoldMine Investment Platform - Mobile Android & Website Synchronized API Controller
 * Provides JSON REST endpoints for the Android Mobile Application and Admin Approval System.
 * Connects directly to the existing GoldMine cPanel MySQL database without losing any data.
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Session-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Locate parent files safely whether placed at root or inside /api/
$base_dir = __DIR__;
if (!file_exists($base_dir . '/config/database.php')) {
    $base_dir = dirname(__DIR__);
}
if (!file_exists($base_dir . '/config/database.php')) {
    $base_dir = __DIR__ . '/..';
}

require_once $base_dir . '/config/app.php';
require_once $base_dir . '/config/database.php';
require_once $base_dir . '/config/payment.php';
require_once $base_dir . '/includes/functions.php';

function json_out(bool $success, string $message, mixed $data = null, int $code = 200): void {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function get_request_data(): array {
    $input = file_get_contents('php://input');
    $json = json_decode($input, true);
    if (is_array($json)) {
        return array_merge($_REQUEST, $json);
    }
    return $_REQUEST;
}

function resolve_authenticated_user_id(PDO $pdo, array $req): ?int {
    if (!empty($req['user_id']) && (int)$req['user_id'] > 0) {
        return (int)$req['user_id'];
    }
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(\d+)/i', $auth, $m)) {
        return (int)$m[1];
    }
    if (preg_match('/Bearer\s+(gm_[a-f0-9]+_(\d+))/i', $auth, $m)) {
        return (int)$m[2];
    }
    $session_tok = $_SERVER['HTTP_X_SESSION_TOKEN'] ?? ($req['token'] ?? ($req['auth_token'] ?? ''));
    if (!empty($session_tok)) {
        if (ctype_digit((string)$session_tok)) {
            return (int)$session_tok;
        }
        if (preg_match('/_(\d+)$/', (string)$session_tok, $m)) {
            return (int)$m[1];
        }
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE remember_token = ? LIMIT 1");
            $stmt->execute([(string)$session_tok]);
            $found = $stmt->fetchColumn();
            if ($found) return (int)$found;
        } catch (Exception $ignored) {}
    }
    if (!empty($_SESSION['user_id'])) {
        return (int)$_SESSION['user_id'];
    }
    if (!empty($req['email'])) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ? LIMIT 1");
            $stmt->execute([trim((string)$req['email']), trim((string)$req['email'])]);
            $found = $stmt->fetchColumn();
            if ($found) return (int)$found;
        } catch (Exception $ignored) {}
    }
    return null;
}

/**
 * Ensures the `deposits` table supports all required columns (`receipt_path`, `proof_image`, `payment_method`, `admin_note`, `reviewed_at`)
 * non-destructively so both the existing website Admin Dashboard and Android App read/write seamlessly.
 */
function ensure_deposits_table_columns(PDO $pdo): array {
    $cols = [];
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM deposits");
        if ($stmt) {
            foreach ($stmt->fetchAll() as $row) {
                $cols[strtolower((string)$row['Field'])] = true;
            }
        }
        if (!isset($cols['payment_method'])) {
            $pdo->exec("ALTER TABLE deposits ADD COLUMN payment_method VARCHAR(100) DEFAULT 'Manual Bank Transfer'");
            $cols['payment_method'] = true;
        }
        if (!isset($cols['receipt_path'])) {
            $pdo->exec("ALTER TABLE deposits ADD COLUMN receipt_path VARCHAR(255) DEFAULT NULL");
            $cols['receipt_path'] = true;
        }
        if (!isset($cols['proof_image'])) {
            $pdo->exec("ALTER TABLE deposits ADD COLUMN proof_image VARCHAR(255) DEFAULT NULL");
            $cols['proof_image'] = true;
        }
        if (!isset($cols['admin_note'])) {
            $pdo->exec("ALTER TABLE deposits ADD COLUMN admin_note TEXT DEFAULT NULL");
            $cols['admin_note'] = true;
        }
        if (!isset($cols['reviewed_at'])) {
            $pdo->exec("ALTER TABLE deposits ADD COLUMN reviewed_at DATETIME DEFAULT NULL");
            $cols['reviewed_at'] = true;
        }
    } catch (Exception $ignored) {}
    return $cols;
}

/**
 * Formats a deposit record with clear status badges and human-readable admin approval status descriptions.
 */
function format_deposit_record(array $row): array {
    $raw_status = strtolower(trim((string)($row['status'] ?? 'pending')));
    if ($raw_status === 'completed' || $raw_status === 'approved') {
        $norm_status = 'approved';
        $status_badge = 'APPROVED';
        $admin_status_text = 'Admin has approved the deposit and credited your wallet';
    } elseif ($raw_status === 'rejected' || $raw_status === 'declined' || $raw_status === 'cancelled') {
        $norm_status = 'rejected';
        $status_badge = 'REJECTED';
        $reason = trim((string)($row['admin_note'] ?? ($row['rejection_reason'] ?? '')));
        $admin_status_text = $reason !== ''
            ? ('Admin has rejected the deposit: ' . $reason)
            : 'Admin has rejected the deposit';
    } else {
        $norm_status = 'pending';
        $status_badge = 'PENDING';
        $admin_status_text = 'Deposit submitted and awaiting admin approval';
    }

    $receipt = $row['receipt_path'] ?? ($row['proof_image'] ?? ($row['receipt'] ?? ''));
    $receipt_url = '';
    if (!empty($receipt)) {
        $receipt_url = str_starts_with((string)$receipt, 'http')
            ? (string)$receipt
            : (rtrim(defined('APP_URL') ? APP_URL : 'https://goalmindai.com.ng', '/') . '/' . ltrim((string)$receipt, '/'));
    }

    return [
        'id' => (int)($row['id'] ?? 0),
        'reference_code' => (string)($row['reference_code'] ?? ''),
        'user_id' => (int)($row['user_id'] ?? 0),
        'user_name' => (string)($row['full_name'] ?? ($row['user_name'] ?? '')),
        'user_email' => (string)($row['email'] ?? ''),
        'amount' => round((float)($row['amount'] ?? 0), 2),
        'payment_method' => (string)($row['payment_method'] ?? 'Manual Bank Transfer'),
        'status' => $norm_status,
        'status_badge' => $status_badge,
        'admin_approval_status' => $admin_status_text,
        'admin_note' => (string)($row['admin_note'] ?? ($row['rejection_reason'] ?? '')),
        'receipt_path' => (string)$receipt,
        'receipt_url' => $receipt_url,
        'created_at' => (string)($row['created_at'] ?? date('Y-m-d H:i:s')),
        'reviewed_at' => (string)($row['reviewed_at'] ?? ($row['updated_at'] ?? ''))
    ];
}

/**
 * Fetches all deposits for a specific user ordered newest first.
 */
function get_user_deposits_list(PDO $pdo, int $uid): array {
    ensure_deposits_table_columns($pdo);
    $list = [];
    try {
        $stmt = $pdo->prepare("
            SELECT d.*, u.full_name, u.email
            FROM deposits d
            LEFT JOIN users u ON d.user_id = u.id
            WHERE d.user_id = ?
            ORDER BY d.id DESC
            LIMIT 100
        ");
        $stmt->execute([$uid]);
        foreach ($stmt->fetchAll() as $r) {
            $list[] = format_deposit_record($r);
        }
    } catch (Exception $ignored) {}
    return $list;
}

/**
 * Atomically approves a pending deposit and credits the user's wallet ONCE ONLY.
 */
function approve_deposit_atomically(PDO $pdo, int $deposit_id, string $admin_note = 'Verified and approved by Admin'): array {
    ensure_deposits_table_columns($pdo);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
        $stmt->execute([$deposit_id]);
        $dep = $stmt->fetch();

        if (!$dep) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Deposit record not found.'];
        }

        $current_status = strtolower(trim((string)($dep['status'] ?? 'pending')));
        if ($current_status === 'approved' || $current_status === 'completed') {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'This deposit has already been approved and credited.'];
        }
        if ($current_status === 'rejected') {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'This deposit was already rejected.'];
        }

        $uid = (int)$dep['user_id'];
        $amount = round((float)$dep['amount'], 2);
        $ref = (string)$dep['reference_code'];
        $now_str = date('Y-m-d H:i:s');

        // 1. Update deposit status to approved (only where status = 'pending')
        $upd = $pdo->prepare("UPDATE deposits SET status = 'approved', admin_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'");
        $upd->execute([$admin_note, $now_str, $deposit_id]);

        if ($upd->rowCount() !== 1) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Deposit status could not be updated or was already processed.'];
        }

        // 2. Credit user wallet balance ONCE ONLY
        $u_lock = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        $u_lock->execute([$uid]);
        $old_balance = (float)$u_lock->fetchColumn();
        $new_balance = round($old_balance + $amount, 2);

        $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?")->execute([$new_balance, $uid]);

        // 3. Update matching transaction record or insert if missing
        $tx_upd = $pdo->prepare("UPDATE transactions SET status = 'approved', balance_after = ?, description = ? WHERE reference_code = ? AND user_id = ?");
        $tx_upd->execute([$new_balance, "Deposit Approved via Manual Bank Transfer ($ref)", $ref, $uid]);
        if ($tx_upd->rowCount() === 0) {
            $tx_ins = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'deposit', ?, ?, 'approved', ?)");
            $tx_ins->execute([$ref, $uid, $amount, $new_balance, "Deposit Approved via Manual Bank Transfer ($ref)"]);
        }

        // 4. Notify user
        if (function_exists('add_user_notification')) {
            add_user_notification(
                $uid,
                "Deposit Approved & Credited",
                "Your deposit of " . format_currency($amount) . " (Ref: $ref) has been approved by Admin and credited to your wallet. New balance: " . format_currency($new_balance) . ".",
                "success",
                "/deposit.php"
            );
        }

        if (function_exists('log_audit_action')) {
            log_audit_action(null, $uid, "Deposit Approved", "Approved deposit $ref of " . format_currency($amount));
        }

        $pdo->commit();

        // Fetch updated deposit row
        $re_stmt = $pdo->prepare("SELECT d.*, u.full_name, u.email FROM deposits d LEFT JOIN users u ON d.user_id = u.id WHERE d.id = ?");
        $re_stmt->execute([$deposit_id]);
        $updated_row = $re_stmt->fetch() ?: $dep;

        return [
            'success' => true,
            'message' => 'Deposit approved and ' . format_currency($amount) . ' credited to user wallet.',
            'deposit' => format_deposit_record($updated_row),
            'new_balance' => $new_balance
        ];
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        return ['success' => false, 'message' => 'Database error while approving deposit: ' . $e->getMessage()];
    }
}

/**
 * Atomically rejects a pending deposit WITHOUT crediting the user's wallet.
 */
function reject_deposit_atomically(PDO $pdo, int $deposit_id, string $rejection_reason = 'Payment receipt could not be verified'): array {
    ensure_deposits_table_columns($pdo);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? FOR UPDATE");
        $stmt->execute([$deposit_id]);
        $dep = $stmt->fetch();

        if (!$dep) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Deposit record not found.'];
        }

        $current_status = strtolower(trim((string)($dep['status'] ?? 'pending')));
        if ($current_status !== 'pending') {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Only pending deposits can be rejected (current status: ' . strtoupper($current_status) . ').'];
        }

        $uid = (int)$dep['user_id'];
        $amount = round((float)$dep['amount'], 2);
        $ref = (string)$dep['reference_code'];
        $now_str = date('Y-m-d H:i:s');
        $clean_reason = trim($rejection_reason) !== '' ? trim($rejection_reason) : 'Payment receipt could not be verified';

        // 1. Update deposit status to rejected and store rejection reason
        $upd = $pdo->prepare("UPDATE deposits SET status = 'rejected', admin_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'");
        $upd->execute([$clean_reason, $now_str, $deposit_id]);

        // 2. Update matching transaction record to rejected (do NOT credit wallet)
        $tx_upd = $pdo->prepare("UPDATE transactions SET status = 'rejected', description = ? WHERE reference_code = ? AND user_id = ?");
        $tx_upd->execute(["Deposit Rejected ($ref): $clean_reason", $ref, $uid]);

        // 3. Notify user
        if (function_exists('add_user_notification')) {
            add_user_notification(
                $uid,
                "Deposit Rejected",
                "Your deposit request of " . format_currency($amount) . " (Ref: $ref) was rejected by Admin. Reason: $clean_reason.",
                "error",
                "/deposit.php"
            );
        }

        if (function_exists('log_audit_action')) {
            log_audit_action(null, $uid, "Deposit Rejected", "Rejected deposit $ref: $clean_reason");
        }

        $pdo->commit();

        $re_stmt = $pdo->prepare("SELECT d.*, u.full_name, u.email FROM deposits d LEFT JOIN users u ON d.user_id = u.id WHERE d.id = ?");
        $re_stmt->execute([$deposit_id]);
        $updated_row = $re_stmt->fetch() ?: $dep;

        return [
            'success' => true,
            'message' => 'Deposit rejected. User wallet was not credited.',
            'deposit' => format_deposit_record($updated_row)
        ];
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        return ['success' => false, 'message' => 'Database error while rejecting deposit: ' . $e->getMessage()];
    }
}

function resolve_canonical_duration_days(string $plan_name, int $fallback_days = 3): int {
    $lower = strtolower(trim($plan_name));
    if (str_contains($lower, 'starter')) return 3;
    if (str_contains($lower, 'classic')) return 7;
    if (str_contains($lower, 'premium')) return 15;
    if (str_contains($lower, 'vip')) return 30;
    if (str_contains($lower, 'diamond')) return 60;
    return max(1, $fallback_days);
}

function resolve_canonical_roi_percentage(string $plan_name, float $amount, float $fallback_roi = 0.0): float {
    $lower = strtolower(trim($plan_name));
    if (str_contains($lower, 'starter')) return 35.00;
    if (str_contains($lower, 'classic') || str_contains($lower, 'premium') || str_contains($lower, 'vip') || str_contains($lower, 'diamond')) {
        return 45.00;
    }
    if (abs($fallback_roi - 35.0) < 0.01 || abs($fallback_roi - 45.0) < 0.01) {
        return $fallback_roi;
    }
    if ($amount > 0 && $amount <= 5000.00) {
        return 35.00;
    }
    return 45.00;
}

function sync_official_investment_plans(PDO $pdo): void {
    $official_plans = [
        [
            'name' => 'Starter Gold',
            'slug' => 'starter-gold',
            'match' => '%Starter%',
            'min_amount' => 1000.00,
            'max_amount' => 5000.00,
            'roi_percentage' => 35.00,
            'duration_days' => 3,
            'description' => 'Investment range: ₦1,000 – ₦5,000 | 35% ROI | 3 Days. Profit: ₦350 – ₦1,750 | Total Return: ₦1,350 – ₦6,750.'
        ],
        [
            'name' => 'Classic Gold',
            'slug' => 'classic-gold',
            'match' => '%Classic%',
            'min_amount' => 10000.00,
            'max_amount' => 20000.00,
            'roi_percentage' => 45.00,
            'duration_days' => 7,
            'description' => 'Investment range: ₦10,000 – ₦20,000 | 45% ROI | 7 Days. Profit: ₦4,500 – ₦9,000 | Total Return: ₦14,500 – ₦29,000.'
        ],
        [
            'name' => 'Premium Gold',
            'slug' => 'premium-gold',
            'match' => '%Premium%',
            'min_amount' => 30000.00,
            'max_amount' => 50000.00,
            'roi_percentage' => 45.00,
            'duration_days' => 15,
            'description' => 'Investment range: ₦30,000 – ₦50,000 | 45% ROI | 15 Days. Profit: ₦13,500 – ₦22,500 | Total Return: ₦43,500 – ₦72,500.'
        ],
        [
            'name' => 'VIP Gold',
            'slug' => 'vip-gold',
            'match' => '%VIP%',
            'min_amount' => 100000.00,
            'max_amount' => 120000.00,
            'roi_percentage' => 45.00,
            'duration_days' => 30,
            'description' => 'Investment range: ₦100,000 – ₦120,000 | 45% ROI | 30 Days. Profit: ₦45,000 – ₦54,000 | Total Return: ₦145,000 – ₦174,000.'
        ],
        [
            'name' => 'Diamond Gold',
            'slug' => 'diamond-gold',
            'match' => '%Diamond%',
            'min_amount' => 200000.00,
            'max_amount' => 1000000.00,
            'roi_percentage' => 45.00,
            'duration_days' => 60,
            'description' => 'Investment range: ₦200,000 – ₦1,000,000 | 45% ROI | 60 Days. Profit: ₦90,000 – ₦450,000 | Total Return: ₦290,000 – ₦1,450,000.'
        ]
    ];

    try {
        foreach ($official_plans as $op) {
            $chk = $pdo->prepare("SELECT id FROM investment_plans WHERE slug = ? OR name LIKE ? LIMIT 1");
            $chk->execute([$op['slug'], $op['match']]);
            $existing_id = $chk->fetchColumn();
            if ($existing_id) {
                $upd = $pdo->prepare("UPDATE investment_plans SET name = ?, slug = ?, min_amount = ?, max_amount = ?, duration_days = ?, roi_percentage = ?, description = ?, status = 'active' WHERE id = ?");
                $upd->execute([$op['name'], $op['slug'], $op['min_amount'], $op['max_amount'], $op['duration_days'], $op['roi_percentage'], $op['description'], $existing_id]);
            } else {
                $ins = $pdo->prepare("INSERT INTO investment_plans (name, slug, min_amount, max_amount, roi_percentage, duration_days, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
                $ins->execute([$op['name'], $op['slug'], $op['min_amount'], $op['max_amount'], $op['roi_percentage'], $op['duration_days'], $op['description']]);
            }
        }
    } catch (Exception $ignored) {}
}

/**
 * Dynamically synchronizes matured investments and computes accurate Total Invested
 * and Total Profit directly from the user's actual records in the `investments` table.
 */
function sync_user_investments_and_profit(PDO $pdo, int $uid): array {
    if (function_exists('check_and_update_matured_investments')) {
        check_and_update_matured_investments();
    }

    $now = time();
    $mat_stmt = $pdo->prepare("
        SELECT i.*, COALESCE(p.duration_days, i.duration_days) AS canonical_duration_days, COALESCE(p.roi_percentage, i.roi_percentage) AS canonical_roi
        FROM investments i
        LEFT JOIN investment_plans p ON i.plan_id = p.id
        WHERE i.user_id = ? AND i.status = 'active'
    ");
    $mat_stmt->execute([$uid]);
    $active_rows = $mat_stmt->fetchAll();

    foreach ($active_rows as $inv) {
        $plan_name = (string)($inv['plan_name'] ?? '');
        $dur_days = resolve_canonical_duration_days($plan_name, (int)($inv['canonical_duration_days'] ?? $inv['duration_days'] ?? 3));
        $start_str = $inv['start_date'] ?? ($inv['created_at'] ?? date('Y-m-d H:i:s', $now));
        $start_ts = strtotime((string)$start_str);
        $mat_ts = !empty($inv['maturity_date']) ? strtotime((string)$inv['maturity_date']) : ($start_ts + ($dur_days * 86400));
        if ($mat_ts > 0 && $mat_ts <= $now) {
            try {
                $pdo->beginTransaction();
                $upd = $pdo->prepare("UPDATE investments SET status = 'completed' WHERE id = ? AND status = 'active'");
                $upd->execute([$inv['id']]);
                if ($upd->rowCount() === 1) {
                    $amt = (float)($inv['amount'] ?? 0);
                    $roi = resolve_canonical_roi_percentage($plan_name, $amt, (float)($inv['canonical_roi'] ?? $inv['roi_percentage'] ?? 0));
                    $profit = round(($amt * $roi) / 100.0, 2);
                    $payout = round($amt + $profit, 2);

                    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$payout, $uid]);

                    $ref_check = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = ? AND description LIKE ?");
                    $ref_check->execute([$uid, '%' . $inv['reference_code'] . '%Matured%']);
                    if ((int)$ref_check->fetchColumn() === 0) {
                        $bal_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
                        $bal_stmt->execute([$uid]);
                        $bal_after = (float)$bal_stmt->fetchColumn();
                        $mat_ref = 'MAT-' . date('Ymd') . '-' . strtoupper(substr(md5((string)$inv['reference_code']), 0, 6));
                        $tx_ins = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'investment', ?, ?, 'completed', ?)");
                        $tx_ins->execute([$mat_ref, $uid, $payout, $bal_after, "Matured Investment Payout (" . $inv['plan_name'] . " - " . $inv['reference_code'] . ")"]);
                    }
                }
                $pdo->commit();
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
            }
        }
    }

    $all_stmt = $pdo->prepare("
        SELECT i.*, COALESCE(p.duration_days, i.duration_days) AS canonical_duration_days, COALESCE(p.roi_percentage, i.roi_percentage) AS canonical_roi
        FROM investments i
        LEFT JOIN investment_plans p ON i.plan_id = p.id
        WHERE i.user_id = ? AND i.status IN ('active', 'completed')
        ORDER BY i.id DESC
    ");
    $all_stmt->execute([$uid]);
    $valid_investments = $all_stmt->fetchAll();

    $seen_refs = [];
    $total_invested = 0.00;
    $completed_profit = 0.00;
    $active_profit = 0.00;
    $active_earned_so_far = 0.00;
    $active_count = 0;
    $completed_count = 0;

    foreach ($valid_investments as $inv) {
        $ref_key = !empty($inv['reference_code']) ? (string)$inv['reference_code'] : ('ID-' . $inv['id']);
        if (isset($seen_refs[$ref_key])) {
            continue;
        }
        $seen_refs[$ref_key] = true;

        $amt = (float)($inv['amount'] ?? 0);
        if ($amt <= 0) continue;

        $plan_name = (string)($inv['plan_name'] ?? '');
        $roi = resolve_canonical_roi_percentage($plan_name, $amt, (float)($inv['canonical_roi'] ?? $inv['roi_percentage'] ?? 0));
        $inv_profit = round(($amt * $roi) / 100.0, 2);

        $total_invested += $amt;
        $status = strtolower((string)($inv['status'] ?? ''));

        if ($status === 'completed') {
            $completed_count++;
            $completed_profit += $inv_profit;
        } elseif ($status === 'active') {
            $active_count++;
            $active_profit += $inv_profit;

            $dur_days = resolve_canonical_duration_days($plan_name, (int)($inv['canonical_duration_days'] ?? $inv['duration_days'] ?? 3));
            $dur_secs = $dur_days * 86400;
            $start_str = $inv['start_date'] ?? ($inv['created_at'] ?? date('Y-m-d H:i:s', $now));
            $start_ts = strtotime((string)$start_str);
            $elapsed = max(0, min($dur_secs, $now - $start_ts));
            $active_earned_so_far += round($inv_profit * ($elapsed / $dur_secs), 2);
        }
    }

    $total_invested = round($total_invested, 2);
    $completed_profit = round($completed_profit, 2);
    $active_profit = round($active_profit, 2);
    $total_profit = round($completed_profit + $active_profit, 2);

    $pdo->prepare("UPDATE users SET total_invested = ?, total_profit = ? WHERE id = ?")
        ->execute([$total_invested, $total_profit, $uid]);

    return [
        'total_invested' => $total_invested,
        'total_profit' => $total_profit,
        'completed_profit' => $completed_profit,
        'active_profit' => $active_profit,
        'active_earned_so_far' => round($active_earned_so_far, 2),
        'active_investments_count' => $active_count,
        'completed_investments_count' => $completed_count
    ];
}

$pdo = get_db_connection();
if (!$pdo) {
    json_out(false, 'Database connection unavailable', null, 500);
}

// Ensure all 5 official investment packages and deposit columns exist
sync_official_investment_plans($pdo);
ensure_deposits_table_columns($pdo);

$action = trim($_GET['action'] ?? ($_POST['action'] ?? ''));
$req = get_request_data();

switch ($action) {
    // ------------------------------------------------------------------------
    // PING / STATUS
    // ------------------------------------------------------------------------
    case 'ping':
    case 'status':
        json_out(true, 'GoldMine Investment Platform API online', [
            'app_name' => APP_NAME,
            'version' => '1.1.0',
            'currency' => APP_CURRENCY,
            'currency_code' => APP_CURRENCY_CODE,
            'server_time' => date('Y-m-d H:i:s'),
            'company_bank' => [
                'bank_name' => COMPANY_BANK_NAME,
                'account_number' => COMPANY_ACCOUNT_NUMBER,
                'account_name' => COMPANY_ACCOUNT_NAME
            ]
        ]);
        break;

    // ------------------------------------------------------------------------
    // AUTH: LOGIN
    // ------------------------------------------------------------------------
    case 'login':
        $login_input = trim($req['login_input'] ?? ($req['email'] ?? ($req['username'] ?? '')));
        $password = (string)($req['password'] ?? '');

        if (empty($login_input) || empty($password)) {
            json_out(false, 'Email/phone and password are required', null, 400);
        }

        $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR phone = ?) LIMIT 1");
        $stmt->execute([$login_input, $login_input]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if ($user['status'] === 'suspended') {
                json_out(false, 'Your account has been suspended. Please contact customer support.', null, 403);
            }

            $profit_sync = sync_user_investments_and_profit($pdo, (int)$user['id']);
            $user['total_invested'] = $profit_sync['total_invested'];
            $user['total_profit'] = $profit_sync['total_profit'];

            $token = 'gm_' . bin2hex(random_bytes(16)) . '_' . $user['id'];
            $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?")->execute([$token, $user['id']]);
            $_SESSION['user_id'] = (int)$user['id'];

            log_audit_action(null, (int)$user['id'], 'Android App Login', 'Logged in from Android App');

            unset($user['password_hash']);
            json_out(true, 'Login successful', [
                'user' => $user,
                'token' => (string)$user['id'],
                'auth_token' => $token
            ]);
        } else {
            json_out(false, 'Invalid email/phone or password', null, 401);
        }
        break;

    // ------------------------------------------------------------------------
    // AUTH: REGISTER
    // ------------------------------------------------------------------------
    case 'register':
        $full_name = trim($req['full_name'] ?? '');
        $email = trim($req['email'] ?? '');
        $phone = trim($req['phone'] ?? '');
        $password = (string)($req['password'] ?? '');

        if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
            json_out(false, 'All registration fields are required', null, 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_out(false, 'Please provide a valid email address', null, 400);
        }
        if (strlen($password) < 6) {
            json_out(false, 'Password must be at least 6 characters', null, 400);
        }

        $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ? LIMIT 1");
        $chk->execute([$email, $phone]);
        if ($chk->fetch()) {
            json_out(false, 'An account with this email or phone number already exists', null, 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $ins = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, balance, total_invested, total_profit, status) VALUES (?, ?, ?, ?, 0.00, 0.00, 0.00, 'active')");
        if ($ins->execute([$full_name, $email, $phone, $hash])) {
            $user_id = (int)$pdo->lastInsertId();
            $_SESSION['user_id'] = $user_id;
            add_user_notification($user_id, "Welcome to GoldMine!", "Your account has been created successfully. Explore our 5 Gold packages and start growing your wealth.", "success");
            log_audit_action(null, $user_id, "Android Registration", "Account created via Android App");

            $token = 'gm_' . bin2hex(random_bytes(16)) . '_' . $user_id;
            $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?")->execute([$token, $user_id]);

            $stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, created_at FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $new_user = $stmt->fetch();

            json_out(true, 'Registration successful', [
                'user' => $new_user,
                'token' => (string)$user_id,
                'auth_token' => $token
            ], 201);
        } else {
            json_out(false, 'Failed to create account. Please try again.', null, 500);
        }
        break;

    // ------------------------------------------------------------------------
    // DASHBOARD / USER PROFILE & WALLET SYNCHRONIZATION
    // ------------------------------------------------------------------------
    case 'dashboard':
    case 'user_data':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        $profit_sync = sync_user_investments_and_profit($pdo, $uid);

        $stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, created_at FROM users WHERE id = ?");
        $stmt->execute([$uid]);
        $user = $stmt->fetch();
        if (!$user) json_out(false, 'User not found', null, 404);

        $user['balance'] = round((float)$user['balance'], 2);
        $user['total_invested'] = $profit_sync['total_invested'];
        $user['total_profit'] = $profit_sync['total_profit'];

        $active_count = $profit_sync['active_investments_count'];
        $completed_count = $profit_sync['completed_investments_count'];

        $inv_stmt = $pdo->prepare("SELECT * FROM investments WHERE user_id = ? ORDER BY id DESC LIMIT 5");
        $inv_stmt->execute([$uid]);
        $recent_investments = $inv_stmt->fetchAll();

        $tx_stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 10");
        $tx_stmt->execute([$uid]);
        $recent_transactions = $tx_stmt->fetchAll();

        $user_deposits = get_user_deposits_list($pdo, $uid);
        $unread_notifications = get_unread_notification_count($uid);

        json_out(true, 'Dashboard loaded', [
            'user' => $user,
            'active_investments_count' => $active_count,
            'completed_investments_count' => $completed_count,
            'completed_profit' => $profit_sync['completed_profit'],
            'active_profit' => $profit_sync['active_profit'],
            'active_earned_so_far' => $profit_sync['active_earned_so_far'],
            'unread_notifications' => $unread_notifications,
            'recent_investments' => $recent_investments,
            'recent_transactions' => $recent_transactions,
            'deposits' => $user_deposits,
            'company_bank' => [
                'bank_name' => COMPANY_BANK_NAME,
                'account_number' => COMPANY_ACCOUNT_NUMBER,
                'account_name' => COMPANY_ACCOUNT_NAME
            ]
        ]);
        break;

    // ------------------------------------------------------------------------
    // INVESTMENT PLANS
    // ------------------------------------------------------------------------
    case 'plans':
        sync_official_investment_plans($pdo);

        $stmt = $pdo->query("SELECT id, name, slug, min_amount, max_amount, roi_percentage, duration_days, description, status FROM investment_plans WHERE status = 'active' ORDER BY min_amount ASC");
        $plans = $stmt->fetchAll();
        foreach ($plans as &$p) {
            $min_amt = (float)($p['min_amount'] ?? 1000.00);
            $max_amt = (float)($p['max_amount'] ?? $min_amt);
            $plan_name = (string)($p['name'] ?? '');
            $roi = resolve_canonical_roi_percentage($plan_name, $min_amt, (float)($p['roi_percentage'] ?? 35.00));
            $dur = resolve_canonical_duration_days($plan_name, (int)($p['duration_days'] ?? 3));
            $p['roi_percentage'] = $roi;
            $p['duration_days'] = $dur;
            $min_profit = ($min_amt * $roi) / 100.0;
            $max_profit = ($max_amt * $roi) / 100.0;
            $daily_profit = $min_profit / max(1, $dur);
            $min_total_return = $min_amt + $min_profit;
            $max_total_return = $max_amt + $max_profit;
            $p['daily_profit_rate'] = round($roi / max(1, $dur), 2);
            $p['daily_profit'] = round($daily_profit, 2);
            $p['expected_profit'] = round($min_profit, 2);
            $p['min_profit'] = round($min_profit, 2);
            $p['max_profit'] = round($max_profit, 2);
            $p['total_return'] = round($min_total_return, 2);
            $p['min_total_return'] = round($min_total_return, 2);
            $p['max_total_return'] = round($max_total_return, 2);
            $p['description'] = sprintf(
                'Range: %s – %s | %d%% ROI | %d Days. Profit: %s – %s | Total Return: %s – %s.',
                format_currency($min_amt),
                format_currency($max_amt),
                (int)$roi,
                $dur,
                format_currency($min_profit),
                format_currency($max_profit),
                format_currency($min_total_return),
                format_currency($max_total_return)
            );
        }
        unset($p);
        json_out(true, 'Plans retrieved', ['plans' => $plans]);
        break;

    // ------------------------------------------------------------------------
    // SUBMIT INVESTMENT ORDER
    // ------------------------------------------------------------------------
    case 'invest':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        sync_official_investment_plans($pdo);

        $plan_id = (int)($req['plan_id'] ?? 0);
        $amount = (float)($req['amount'] ?? 0);

        if ($plan_id <= 0 || $amount <= 0) {
            json_out(false, 'Valid plan ID and investment amount are required', null, 400);
        }

        $p_stmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND status = 'active' LIMIT 1");
        $p_stmt->execute([$plan_id]);
        $plan = $p_stmt->fetch();

        if (!$plan) {
            json_out(false, 'Selected investment plan is currently unavailable', null, 404);
        }
        if ($amount < (float)$plan['min_amount']) {
            json_out(false, 'Minimum investment for ' . $plan['name'] . ' is ' . format_currency($plan['min_amount']), null, 400);
        }
        if ($amount > (float)$plan['max_amount']) {
            json_out(false, 'Maximum investment for ' . $plan['name'] . ' is ' . format_currency($plan['max_amount']), null, 400);
        }

        $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        $pdo->beginTransaction();
        $u_stmt->execute([$uid]);
        $curr_balance = (float)$u_stmt->fetchColumn();

        if ($curr_balance < $amount) {
            $pdo->rollBack();
            json_out(false, 'Insufficient balance (' . format_currency($curr_balance) . '). Please deposit funds first.', null, 400);
        }

        try {
            $ref = generate_reference('INV');
            $plan_name = (string)($plan['name'] ?? '');
            $effective_roi = resolve_canonical_roi_percentage($plan_name, $amount, (float)($plan['roi_percentage'] ?? 35.00));
            $duration_days = resolve_canonical_duration_days($plan_name, (int)($plan['duration_days'] ?? 3));
            $profit = round(($amount * $effective_roi) / 100.0, 2);
            $expected_return = round($amount + $profit, 2);

            $deduct = $pdo->prepare("UPDATE users SET balance = balance - ?, total_invested = total_invested + ? WHERE id = ?");
            $deduct->execute([$amount, $amount, $uid]);

            $now_ts = time();
            $start_date_str = date('Y-m-d H:i:s', $now_ts);
            $maturity_ts = $now_ts + ($duration_days * 86400);
            $maturity_date_str = date('Y-m-d H:i:s', $maturity_ts);

            $ins = $pdo->prepare("INSERT INTO investments (reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, start_date, maturity_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $ins->execute([$ref, $uid, $plan['id'], $plan['name'], $amount, $effective_roi, $expected_return, $duration_days, $start_date_str, $maturity_date_str]);

            $new_bal = $curr_balance - $amount;
            $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'investment', ?, ?, 'pending', ?)");
            $tx->execute([$ref, $uid, $amount, $new_bal, "Invested in " . $plan['name'] . " ($ref)"]);

            add_user_notification(
                $uid,
                "Investment Order Submitted: " . $plan['name'],
                "Your order $ref for " . format_currency($amount) . " in " . $plan['name'] . " (" . $duration_days . " Days • " . $effective_roi . "% ROI) has been submitted for administrator review.",
                "info",
                "/my-invest.php"
            );

            log_audit_action(null, $uid, "Android Investment Order", "Plan: " . $plan['name'] . " - Amount: " . format_currency($amount) . " - ROI: " . $effective_roi . "%");

            $pdo->commit();

            json_out(true, 'Investment order submitted successfully! It is currently pending administrator review.', [
                'reference_code' => $ref,
                'plan_name' => $plan['name'],
                'amount' => $amount,
                'expected_return' => $expected_return,
                'roi_percentage' => $effective_roi,
                'duration_days' => $duration_days,
                'start_date' => $start_date_str,
                'maturity_date' => $maturity_date_str,
                'start_timestamp' => $now_ts,
                'maturity_timestamp' => $maturity_ts,
                'seconds_remaining' => $duration_days * 86400,
                'new_balance' => $new_bal
            ]);
        } catch (Exception $e) {
            $pdo->rollBack();
            json_out(false, 'Investment processing failed: ' . $e->getMessage(), null, 500);
        }
        break;

    // ------------------------------------------------------------------------
    // MY INVESTMENTS LIST
    // ------------------------------------------------------------------------
    case 'my_investments':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        sync_official_investment_plans($pdo);

        $pdo->exec("
            UPDATE investments i
            JOIN investment_plans p ON i.plan_id = p.id
            SET i.duration_days = p.duration_days,
                i.roi_percentage = p.roi_percentage,
                i.expected_return = i.amount + (i.amount * p.roi_percentage / 100.0),
                i.maturity_date = DATE_ADD(COALESCE(i.start_date, i.created_at), INTERVAL p.duration_days DAY)
            WHERE i.status IN ('active', 'pending')
              AND (i.duration_days != p.duration_days OR ABS(i.roi_percentage - p.roi_percentage) > 0.001 OR i.maturity_date IS NULL OR TIMESTAMPDIFF(SECOND, COALESCE(i.start_date, i.created_at), i.maturity_date) != p.duration_days * 86400)
        ");

        sync_user_investments_and_profit($pdo, $uid);

        $filter = trim($req['filter'] ?? 'all');
        $query = "SELECT i.*, COALESCE(p.duration_days, i.duration_days) AS canonical_duration_days, COALESCE(p.roi_percentage, i.roi_percentage) AS canonical_roi FROM investments i LEFT JOIN investment_plans p ON i.plan_id = p.id WHERE i.user_id = ?";
        $params = [$uid];

        if (in_array($filter, ['active', 'completed', 'pending', 'rejected'])) {
            $query .= " AND i.status = ?";
            $params[] = $filter;
        }
        $query .= " ORDER BY i.id DESC";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $now = time();
        $investments = [];
        foreach ($rows as $inv) {
            $plan_name = (string)($inv['plan_name'] ?? '');
            $amt = (float)($inv['amount'] ?? 0);
            $duration_days = resolve_canonical_duration_days($plan_name, (int)($inv['canonical_duration_days'] ?? $inv['duration_days'] ?? 3));
            $effective_roi = resolve_canonical_roi_percentage($plan_name, $amt, (float)($inv['canonical_roi'] ?? $inv['roi_percentage'] ?? 35.00));
            $profit = round(($amt * $effective_roi) / 100.0, 2);
            $inv['duration_days'] = $duration_days;
            $inv['roi_percentage'] = $effective_roi;
            $inv['expected_profit'] = $profit;
            $inv['daily_profit'] = round($profit / max(1, $duration_days), 2);
            $inv['expected_return'] = round($amt + $profit, 2);
            $start_str = $inv['start_date'] ?? ($inv['created_at'] ?? date('Y-m-d H:i:s', $now));
            $start_ts = strtotime($start_str);
            $maturity_ts = $start_ts + ($duration_days * 86400);
            $inv['start_date'] = date('Y-m-d H:i:s', $start_ts);
            $inv['maturity_date'] = date('Y-m-d H:i:s', $maturity_ts);
            $inv['start_timestamp'] = $start_ts;
            $inv['maturity_timestamp'] = $maturity_ts;
            $inv['seconds_remaining'] = max(0, $maturity_ts - $now);
            $investments[] = $inv;
        }

        json_out(true, 'Investments retrieved', [
            'filter' => $filter,
            'server_timestamp' => $now,
            'investments' => $investments
        ]);
        break;

    // ------------------------------------------------------------------------
    // COUNTING DATE / LIVE COUNTDOWN
    // ------------------------------------------------------------------------
    case 'counting_date':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        sync_official_investment_plans($pdo);

        $pdo->exec("
            UPDATE investments i
            JOIN investment_plans p ON i.plan_id = p.id
            SET i.duration_days = p.duration_days,
                i.roi_percentage = p.roi_percentage,
                i.expected_return = i.amount + (i.amount * p.roi_percentage / 100.0),
                i.maturity_date = DATE_ADD(COALESCE(i.start_date, i.created_at), INTERVAL p.duration_days DAY)
            WHERE i.status = 'active'
              AND (i.duration_days != p.duration_days OR ABS(i.roi_percentage - p.roi_percentage) > 0.001 OR i.maturity_date IS NULL OR TIMESTAMPDIFF(SECOND, COALESCE(i.start_date, i.created_at), i.maturity_date) != p.duration_days * 86400)
        ");

        sync_user_investments_and_profit($pdo, $uid);

        $stmt = $pdo->prepare("
            SELECT i.*, COALESCE(p.duration_days, i.duration_days) AS canonical_duration_days, COALESCE(p.roi_percentage, i.roi_percentage) AS canonical_roi
            FROM investments i
            LEFT JOIN investment_plans p ON i.plan_id = p.id
            WHERE i.user_id = ? AND i.status = 'active'
            ORDER BY i.maturity_date ASC
        ");
        $stmt->execute([$uid]);
        $rows = $stmt->fetchAll();

        $now = time();
        $countdowns = [];
        foreach ($rows as $inv) {
            $plan_name = (string)($inv['plan_name'] ?? '');
            $amt = (float)($inv['amount'] ?? 0);
            $duration_days = resolve_canonical_duration_days($plan_name, (int)($inv['canonical_duration_days'] ?? $inv['duration_days'] ?? 3));
            $effective_roi = resolve_canonical_roi_percentage($plan_name, $amt, (float)($inv['canonical_roi'] ?? $inv['roi_percentage'] ?? 35.00));
            $inv['duration_days'] = $duration_days;
            $package_duration_seconds = max(1, $duration_days * 86400);

            $profit = round(($amt * $effective_roi) / 100.0, 2);
            $inv['roi_percentage'] = $effective_roi;
            $inv['expected_profit'] = $profit;
            $inv['daily_profit'] = round($profit / max(1, $duration_days), 2);
            $inv['expected_return'] = round($amt + $profit, 2);

            $start_str = $inv['start_date'] ?? ($inv['created_at'] ?? date('Y-m-d H:i:s', $now));
            $start_ts = strtotime($start_str);
            $end_ts = $start_ts + $package_duration_seconds;

            $inv['start_date'] = date('Y-m-d H:i:s', $start_ts);
            $inv['maturity_date'] = date('Y-m-d H:i:s', $end_ts);

            $elapsed = max(0, $now - $start_ts);
            $remaining = max(0, $end_ts - $now);
            $progress_percent = min(100, round(($elapsed / $package_duration_seconds) * 100));

            $days = floor($remaining / 86400);
            $hours = floor(($remaining % 86400) / 3600);
            $minutes = floor(($remaining % 3600) / 60);
            $seconds = $remaining % 60;

            $inv['start_timestamp'] = $start_ts;
            $inv['maturity_timestamp'] = $end_ts;
            $inv['seconds_remaining'] = $remaining;
            $inv['progress_percent'] = (int)$progress_percent;
            $inv['countdown_formatted'] = sprintf('%02dd : %02dh : %02dm : %02ds', $days, $hours, $minutes, $seconds);
            $inv['days'] = (int)$days;
            $inv['hours'] = (int)$hours;
            $inv['minutes'] = (int)$minutes;
            $inv['seconds'] = (int)$seconds;
            $countdowns[] = $inv;
        }

        json_out(true, 'Counting date active investments', [
            'countdowns' => $countdowns,
            'total_active' => count($countdowns),
            'server_timestamp' => $now
        ]);
        break;

    // ------------------------------------------------------------------------
    // DEPOSITS LIST & DEPOSIT STATUS CHECK (FOR ANDROID & WEBSITE)
    // ------------------------------------------------------------------------
    case 'deposits':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? LIMIT 1");
        $u_stmt->execute([$uid]);
        $wallet_balance = round((float)$u_stmt->fetchColumn(), 2);

        $deposits = get_user_deposits_list($pdo, $uid);

        json_out(true, 'User deposits and approval statuses retrieved', [
            'wallet_balance' => $wallet_balance,
            'deposits' => $deposits
        ]);
        break;

    // ------------------------------------------------------------------------
    // DEPOSIT (SUBMIT DEPOSIT REQUEST & RECEIPT TO ADMIN DASHBOARD)
    // ------------------------------------------------------------------------
    case 'deposit':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? LIMIT 1");
            $u_stmt->execute([$uid]);
            $wallet_balance = round((float)$u_stmt->fetchColumn(), 2);

            json_out(true, 'Deposit instructions and deposit history', [
                'company_bank' => [
                    'bank_name' => COMPANY_BANK_NAME,
                    'account_number' => COMPANY_ACCOUNT_NUMBER,
                    'account_name' => COMPANY_ACCOUNT_NAME
                ],
                'min_deposit' => 500.00,
                'wallet_balance' => $wallet_balance,
                'deposits' => get_user_deposits_list($pdo, $uid)
            ]);
        }

        $amount = (float)($req['amount'] ?? 0);
        $method = 'Manual Bank Transfer';
        if ($amount < 500) {
            json_out(false, 'Minimum deposit amount is ₦500.00', null, 400);
        }

        $upload_dir = $base_dir . '/uploads/deposit_receipts';
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }

        $receipt_db_path = null;

        // 1. Check multipart file upload under `receipt`, `proof_image`, or `payment_receipt`
        $file_key = null;
        foreach (['receipt', 'proof_image', 'payment_receipt', 'file'] as $k) {
            if (!empty($_FILES[$k]) && $_FILES[$k]['error'] === UPLOAD_ERR_OK) {
                $file_key = $k;
                break;
            }
        }

        if ($file_key !== null) {
            $file = $_FILES[$file_key];
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);
            $allowed = [
                'image/jpeg' => 'jpg',
                'image/jpg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'application/pdf' => 'pdf'
            ];

            $ext = $allowed[$mime] ?? strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'pdf'], true)) {
                json_out(false, 'Receipt must be a JPG, PNG, WEBP, or PDF file', null, 400);
            }
            if ($file['size'] > 10 * 1024 * 1024) {
                json_out(false, 'Receipt file must not exceed 10 MB', null, 400);
            }

            $stored_name = 'receipt_' . $uid . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $upload_dir . '/' . $stored_name)) {
                $receipt_db_path = 'uploads/deposit_receipts/' . $stored_name;
            }
        } elseif (!empty($req['receipt_base64'])) {
            // 2. Support base64-encoded receipt image from Android client
            $b64 = (string)$req['receipt_base64'];
            $ext = 'jpg';
            if (preg_match('/^data:image\/(\w+);base64,/', $b64, $m)) {
                $ext = strtolower($m[1]) === 'png' ? 'png' : 'jpg';
                $b64 = substr($b64, strpos($b64, ',') + 1);
            }
            $decoded = base64_decode($b64, true);
            if ($decoded !== false && strlen($decoded) > 0) {
                $stored_name = 'receipt_' . $uid . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
                if (file_put_contents($upload_dir . '/' . $stored_name, $decoded) !== false) {
                    $receipt_db_path = 'uploads/deposit_receipts/' . $stored_name;
                }
            }
        }

        $ref = generate_reference('DEP');
        $cols = ensure_deposits_table_columns($pdo);

        try {
            $pdo->beginTransaction();

            // Populate both receipt_path and proof_image so every Admin Dashboard template displays the receipt
            if (isset($cols['proof_image']) && isset($cols['receipt_path'])) {
                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path, proof_image) VALUES (?, ?, ?, ?, 'pending', ?, ?)");
                $ins->execute([$ref, $uid, $amount, $method, $receipt_db_path, $receipt_db_path]);
            } elseif (isset($cols['proof_image'])) {
                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, proof_image) VALUES (?, ?, ?, ?, 'pending', ?)");
                $ins->execute([$ref, $uid, $amount, $method, $receipt_db_path]);
            } else {
                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path) VALUES (?, ?, ?, ?, 'pending', ?)");
                $ins->execute([$ref, $uid, $amount, $method, $receipt_db_path]);
            }

            $deposit_id = (int)$pdo->lastInsertId();

            $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? LIMIT 1");
            $u_stmt->execute([$uid]);
            $curr_bal = round((float)$u_stmt->fetchColumn(), 2);

            $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'deposit', ?, ?, 'pending', ?)");
            $tx->execute([$ref, $uid, $amount, $curr_bal, "Deposit request via " . $method . " ($ref)"]);

            add_user_notification(
                $uid,
                "Deposit Request Submitted",
                "Your deposit of " . format_currency($amount) . " ($ref) has been received and is awaiting administrator approval.",
                "info",
                "/deposit.php"
            );
            log_audit_action(null, $uid, "Android Deposit Request", "Deposit $ref for " . format_currency($amount));

            $pdo->commit();

            $dep_stmt = $pdo->prepare("SELECT d.*, u.full_name, u.email FROM deposits d LEFT JOIN users u ON d.user_id = u.id WHERE d.id = ?");
            $dep_stmt->execute([$deposit_id]);
            $created_dep = $dep_stmt->fetch();

            json_out(true, 'Deposit request submitted successfully! Your deposit is now PENDING administrator verification.', [
                'deposit' => $created_dep ? format_deposit_record($created_dep) : [
                    'id' => $deposit_id,
                    'reference_code' => $ref,
                    'user_id' => $uid,
                    'amount' => $amount,
                    'status' => 'pending',
                    'status_badge' => 'PENDING',
                    'admin_approval_status' => 'Deposit submitted and awaiting admin approval',
                    'receipt_path' => (string)$receipt_db_path,
                    'created_at' => date('Y-m-d H:i:s')
                ],
                'deposits' => get_user_deposits_list($pdo, $uid)
            ]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            json_out(false, 'Deposit request failed: ' . $e->getMessage(), null, 500);
        }
        break;

    // ------------------------------------------------------------------------
    // ADMIN DASHBOARD: VIEW PENDING & ALL DEPOSITS, APPROVE & REJECT DEPOSITS
    // ------------------------------------------------------------------------
    case 'admin_deposits':
        ensure_deposits_table_columns($pdo);
        $status_filter = strtolower(trim($req['status'] ?? 'all'));
        $sql = "
            SELECT d.*, u.full_name, u.email, u.phone, u.balance AS user_balance
            FROM deposits d
            LEFT JOIN users u ON d.user_id = u.id
        ";
        $params = [];
        if (in_array($status_filter, ['pending', 'approved', 'rejected'], true)) {
            $sql .= " WHERE d.status = ?";
            $params[] = $status_filter;
        }
        $sql .= " ORDER BY CASE WHEN d.status = 'pending' THEN 0 ELSE 1 END, d.id DESC LIMIT 200";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $formatted = [];
        $pending_count = 0;
        foreach ($rows as $r) {
            $item = format_deposit_record($r);
            $item['user_phone'] = (string)($r['phone'] ?? '');
            $item['user_balance'] = round((float)($r['user_balance'] ?? 0), 2);
            if ($item['status'] === 'pending') {
                $pending_count++;
            }
            $formatted[] = $item;
        }

        json_out(true, 'Admin deposits retrieved', [
            'pending_count' => $pending_count,
            'deposits' => $formatted
        ]);
        break;

    case 'admin_approve_deposit':
        $deposit_id = (int)($req['deposit_id'] ?? ($req['id'] ?? 0));
        $admin_note = trim((string)($req['admin_note'] ?? 'Payment verified and approved by Admin'));
        if ($deposit_id <= 0) {
            json_out(false, 'Valid deposit_id is required', null, 400);
        }
        $res = approve_deposit_atomically($pdo, $deposit_id, $admin_note);
        if ($res['success']) {
            json_out(true, $res['message'], $res);
        } else {
            json_out(false, $res['message'], null, 400);
        }
        break;

    case 'admin_reject_deposit':
        $deposit_id = (int)($req['deposit_id'] ?? ($req['id'] ?? 0));
        $reason = trim((string)($req['reason'] ?? ($req['admin_note'] ?? 'Payment receipt could not be verified')));
        if ($deposit_id <= 0) {
            json_out(false, 'Valid deposit_id is required', null, 400);
        }
        $res = reject_deposit_atomically($pdo, $deposit_id, $reason);
        if ($res['success']) {
            json_out(true, $res['message'], $res);
        } else {
            json_out(false, $res['message'], null, 400);
        }
        break;

    // ------------------------------------------------------------------------
    // WITHDRAW
    // ------------------------------------------------------------------------
    case 'withdraw':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        $amount = (float)($req['amount'] ?? 0);
        $bank_name = trim($req['bank_name'] ?? '');
        $account_number = trim($req['account_number'] ?? '');
        $account_name = trim($req['account_name'] ?? '');

        if ($amount < 1000) {
            json_out(false, 'Minimum withdrawal amount is ₦1,000.00', null, 400);
        }
        if (empty($bank_name) || empty($account_number) || empty($account_name)) {
            json_out(false, 'Bank name, account number, and account holder name are required', null, 400);
        }

        $pdo->beginTransaction();
        $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        $u_stmt->execute([$uid]);
        $curr_balance = (float)$u_stmt->fetchColumn();

        if ($curr_balance < $amount) {
            $pdo->rollBack();
            json_out(false, 'Insufficient balance. Available: ' . format_currency($curr_balance), null, 400);
        }

        try {
            $ref = generate_reference('WTH');
            $deduct = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $deduct->execute([$amount, $uid]);

            $b_stmt = $pdo->prepare("INSERT INTO user_bank_details (user_id, bank_name, account_number, account_name) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE bank_name = VALUES(bank_name), account_number = VALUES(account_number), account_name = VALUES(account_name)");
            $b_stmt->execute([$uid, $bank_name, $account_number, $account_name]);

            $ins = $pdo->prepare("INSERT INTO withdrawals (reference_code, user_id, amount, bank_name, account_number, account_name, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
            $ins->execute([$ref, $uid, $amount, $bank_name, $account_number, $account_name]);

            $new_bal = $curr_balance - $amount;
            $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'withdrawal', ?, ?, 'pending', ?)");
            $tx->execute([$ref, $uid, $amount, $new_bal, "Withdrawal to $bank_name ($account_number)"]);

            add_user_notification($uid, "Withdrawal Requested", "Your withdrawal request for " . format_currency($amount) . " ($ref) is under administrative review.", "info", "/withdraw.php");
            log_audit_action(null, $uid, "Android Withdrawal Request", "Withdrawal $ref for " . format_currency($amount));

            $pdo->commit();

            json_out(true, 'Withdrawal request submitted successfully! It will be processed by administrators shortly.', [
                'reference_code' => $ref,
                'amount' => $amount,
                'new_balance' => $new_bal,
                'status' => 'pending'
            ]);
        } catch (Exception $e) {
            $pdo->rollBack();
            json_out(false, 'Withdrawal processing failed: ' . $e->getMessage(), null, 500);
        }
        break;

    // ------------------------------------------------------------------------
    // TRANSACTIONS
    // ------------------------------------------------------------------------
    case 'transactions':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        $type_filter = trim($req['type'] ?? 'all');
        $query = "SELECT * FROM transactions WHERE user_id = ?";
        $params = [$uid];

        if (in_array($type_filter, ['deposit', 'investment', 'withdrawal'])) {
            $query .= " AND type = ?";
            $params[] = $type_filter;
        }
        $query .= " ORDER BY id DESC LIMIT 100";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $txs = $stmt->fetchAll();

        json_out(true, 'Transactions retrieved', [
            'type' => $type_filter,
            'transactions' => $txs
        ]);
        break;

    // ------------------------------------------------------------------------
    // NOTIFICATIONS
    // ------------------------------------------------------------------------
    case 'notifications':
        $uid = resolve_authenticated_user_id($pdo, $req);
        if (!$uid) json_out(false, 'Authentication required', null, 401);

        if (!empty($req['mark_read_all'])) {
            $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$uid]);
        }

        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50");
        $stmt->execute([$uid]);
        $notes = $stmt->fetchAll();

        json_out(true, 'Notifications retrieved', [
            'notifications' => $notes,
            'unread_count' => get_unread_notification_count($uid)
        ]);
        break;

    // ------------------------------------------------------------------------
    // CUSTOMER SUPPORT & FAQ
    // ------------------------------------------------------------------------
    case 'support':
        json_out(true, 'Customer support information', [
            'whatsapp' => '+2348000000000',
            'whatsapp_link' => 'https://wa.me/2348000000000?text=Hello%20GoldMine%20Support',
            'telegram' => '@GoldMinePlatform',
            'telegram_link' => 'https://t.me/GoldMinePlatform',
            'email' => 'support@goalmindai.com.ng',
            'office_hours' => '24/7 Priority Support',
            'faqs' => [
                [
                    'q' => 'What is the GoldMine ROI rate?',
                    'a' => 'Starter Gold (3 Days, ₦1,000–₦5,000) earns 35% ROI, while Classic Gold (7 Days), Premium Gold (15 Days), VIP Gold (30 Days), and Diamond Gold (60 Days) earn 45% ROI upon maturity.'
                ],
                [
                    'q' => 'How does Deposit & Admin Approval work?',
                    'a' => 'Transfer your deposit amount to Kuda Bank (2009888249 - Hamisu Isiyaka), attach your payment receipt, and tap Submit Deposit Order. Your deposit appears immediately in Deposit History as PENDING until verified by Admin, after which your wallet is credited automatically.'
                ],
                [
                    'q' => 'How does Counting Date work?',
                    'a' => 'Once your investment order is active, the Counting Date screen displays a live ticking countdown showing exact days, hours, minutes, and seconds remaining until capital + ROI payout.'
                ],
                [
                    'q' => 'How long do withdrawals take?',
                    'a' => 'Withdrawals are reviewed and credited directly to your registered Nigerian bank account within 1 to 24 business hours.'
                ]
            ]
        ]);
        break;

    default:
        json_out(false, 'Invalid action specified. Supported actions: ping, login, register, dashboard, plans, invest, my_investments, counting_date, deposit, deposits, admin_deposits, admin_approve_deposit, admin_reject_deposit, withdraw, transactions, notifications, support.', null, 400);
        break;
}
