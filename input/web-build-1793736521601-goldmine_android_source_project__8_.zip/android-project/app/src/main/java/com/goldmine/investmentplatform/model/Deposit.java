package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Deposit implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("reference_code")
    private String referenceCode;

    @SerializedName("user_id")
    private int userId;

    @SerializedName("user_name")
    private String userName;

    @SerializedName("amount")
    private double amount;

    @SerializedName("payment_method")
    private String paymentMethod;

    @SerializedName("status")
    private String status; // pending, approved, rejected

    @SerializedName("status_badge")
    private String statusBadge; // PENDING, APPROVED, REJECTED

    @SerializedName("admin_approval_status")
    private String adminApprovalStatus;

    @SerializedName("admin_note")
    private String adminNote;

    @SerializedName("receipt_path")
    private String receiptPath;

    @SerializedName("receipt_url")
    private String receiptUrl;

    @SerializedName("created_at")
    private String createdAt;

    @SerializedName("reviewed_at")
    private String reviewedAt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReferenceCode() {
        return referenceCode != null ? referenceCode : "";
    }

    public void setReferenceCode(String referenceCode) {
        this.referenceCode = referenceCode;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName != null ? userName : "";
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod != null && !paymentMethod.isEmpty() ? paymentMethod : "Manual Bank Transfer";
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getStatus() {
        return status != null && !status.isEmpty() ? status.toLowerCase() : "pending";
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusBadge() {
        if (statusBadge != null && !statusBadge.isEmpty()) {
            return statusBadge.toUpperCase();
        }
        String st = getStatus();
        if ("approved".equals(st) || "completed".equals(st)) {
            return "APPROVED";
        } else if ("rejected".equals(st) || "declined".equals(st)) {
            return "REJECTED";
        }
        return "PENDING";
    }

    public void setStatusBadge(String statusBadge) {
        this.statusBadge = statusBadge;
    }

    public String getAdminApprovalStatus() {
        if (adminApprovalStatus != null && !adminApprovalStatus.isEmpty()) {
            return adminApprovalStatus;
        }
        String st = getStatus();
        if ("approved".equals(st) || "completed".equals(st)) {
            return "APPROVED — Admin has approved the deposit";
        } else if ("rejected".equals(st) || "declined".equals(st)) {
            if (adminNote != null && !adminNote.trim().isEmpty()) {
                return "REJECTED — Admin has rejected the deposit (" + adminNote.trim() + ")";
            }
            return "REJECTED — Admin has rejected the deposit";
        }
        return "PENDING — Deposit submitted and awaiting admin approval";
    }

    public void setAdminApprovalStatus(String adminApprovalStatus) {
        this.adminApprovalStatus = adminApprovalStatus;
    }

    public String getAdminNote() {
        return adminNote != null ? adminNote : "";
    }

    public void setAdminNote(String adminNote) {
        this.adminNote = adminNote;
    }

    public String getReceiptPath() {
        return receiptPath != null ? receiptPath : "";
    }

    public void setReceiptPath(String receiptPath) {
        this.receiptPath = receiptPath;
    }

    public String getReceiptUrl() {
        return receiptUrl != null ? receiptUrl : "";
    }

    public void setReceiptUrl(String receiptUrl) {
        this.receiptUrl = receiptUrl;
    }

    public String getCreatedAt() {
        return createdAt != null ? createdAt : "";
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getReviewedAt() {
        return reviewedAt != null ? reviewedAt : "";
    }

    public void setReviewedAt(String reviewedAt) {
        this.reviewedAt = reviewedAt;
    }
}
