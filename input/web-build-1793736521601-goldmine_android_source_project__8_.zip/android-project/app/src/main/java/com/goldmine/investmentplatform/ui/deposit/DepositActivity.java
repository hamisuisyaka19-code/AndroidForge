package com.goldmine.investmentplatform.ui.deposit;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.adapter.DepositsAdapter;
import com.goldmine.investmentplatform.api.GoldMineRepository;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityDepositBinding;
import com.goldmine.investmentplatform.model.Deposit;
import com.goldmine.investmentplatform.util.Constants;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;

public class DepositActivity extends AppCompatActivity {
    private ActivityDepositBinding binding;
    private SessionManager sessionManager;
    private DepositsAdapter depositsAdapter;
    private Uri selectedReceiptUri = null;
    private String selectedReceiptName = "payment_receipt.jpg";

    private final ActivityResultLauncher<String> filePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    selectedReceiptUri = uri;
                    selectedReceiptName = resolveFileName(uri);
                    binding.tvSelectedReceipt.setText("Receipt attached: " + selectedReceiptName);
                    binding.tvSelectedReceipt.setTextColor(getResources().getColor(android.R.color.holo_green_light));
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDepositBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);

        binding.tvBankName.setText(Constants.COMPANY_BANK_NAME);
        binding.tvAccountNumber.setText(Constants.COMPANY_ACCOUNT_NUMBER);
        binding.tvAccountName.setText(Constants.COMPANY_ACCOUNT_NAME);
        binding.tvHeaderWalletBalance.setText(CurrencyFormatter.formatNaira(sessionManager.getUserBalance()));

        depositsAdapter = new DepositsAdapter();
        binding.rvDepositHistory.setLayoutManager(new LinearLayoutManager(this));
        binding.rvDepositHistory.setAdapter(depositsAdapter);

        binding.btnBack.setOnClickListener(v -> finish());

        binding.btnCopyAccount.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("GoldMine Account Number", Constants.COMPANY_ACCOUNT_NUMBER);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Account number copied to clipboard!", Toast.LENGTH_SHORT).show();
        });

        binding.btnSelectReceipt.setOnClickListener(v -> filePickerLauncher.launch("image/*"));

        binding.btnSubmitDeposit.setOnClickListener(v -> submitDeposit());

        binding.btnRefreshDeposits.setOnClickListener(v -> {
            Toast.makeText(this, "Refreshing deposit approval status...", Toast.LENGTH_SHORT).show();
            loadDepositHistory();
        });

        loadDepositHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDepositHistory();
    }

    private void submitDeposit() {
        String amountStr = binding.etDepositAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter deposit amount", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid deposit amount", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount < Constants.MIN_DEPOSIT_AMOUNT) {
            Toast.makeText(this, "Minimum deposit amount is ₦500.00", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedReceiptUri == null) {
            Toast.makeText(this, "Please attach your payment receipt image for admin verification", Toast.LENGTH_SHORT).show();
            return;
        }

        byte[] receiptBytes = readUriBytes(selectedReceiptUri);
        String mimeType = getContentResolver().getType(selectedReceiptUri);
        if (mimeType == null || mimeType.trim().isEmpty()) {
            mimeType = "image/jpeg";
        }

        setLoading(true);

        GoldMineRepository.getInstance().submitDeposit(
                amount,
                receiptBytes,
                selectedReceiptName,
                mimeType,
                new GoldMineRepository.ActionCallback() {
                    @Override
                    public void onSuccess(String message) {
                        setLoading(false);
                        binding.etDepositAmount.setText("");
                        selectedReceiptUri = null;
                        binding.tvSelectedReceipt.setText("Tap to choose receipt image or PDF");
                        Toast.makeText(DepositActivity.this, message, Toast.LENGTH_LONG).show();
                        // Immediately refresh the Deposit History & Status list below the button
                        loadDepositHistory();
                    }

                    @Override
                    public void onError(String message) {
                        setLoading(false);
                        Toast.makeText(DepositActivity.this, message, Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    private void loadDepositHistory() {
        GoldMineRepository.getInstance().getDeposits(new GoldMineRepository.DepositsCallback() {
            @Override
            public void onSuccess(List<Deposit> deposits, double walletBalance) {
                if (binding == null) return;
                binding.tvHeaderWalletBalance.setText(CurrencyFormatter.formatNaira(walletBalance));
                if (deposits != null && !deposits.isEmpty()) {
                    depositsAdapter.setDeposits(deposits);
                    binding.rvDepositHistory.setVisibility(View.VISIBLE);
                    binding.tvEmptyDeposits.setVisibility(View.GONE);
                } else {
                    binding.rvDepositHistory.setVisibility(View.GONE);
                    binding.tvEmptyDeposits.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onError(String message) {
                if (binding == null) return;
                binding.tvHeaderWalletBalance.setText(CurrencyFormatter.formatNaira(sessionManager.getUserBalance()));
            }
        });
    }

    private byte[] readUriBytes(Uri uri) {
        if (uri == null) return null;
        try (InputStream is = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            if (is == null) return null;
            byte[] data = new byte[8192];
            int nRead;
            while ((nRead = is.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }
            buffer.flush();
            return buffer.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private String resolveFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        result = cursor.getString(idx);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return (result != null && !result.trim().isEmpty()) ? result.trim() : "payment_receipt.jpg";
    }

    private void setLoading(boolean loading) {
        binding.progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.btnSubmitDeposit.setEnabled(!loading);
        binding.btnSubmitDeposit.setText(loading ? "Uploading Receipt & Submitting..." : "Submit Deposit Order");
    }
}
