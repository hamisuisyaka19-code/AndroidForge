package com.goldmine.investmentplatform.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemDepositStatusBinding;
import com.goldmine.investmentplatform.model.Deposit;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;

public class DepositsAdapter extends RecyclerView.Adapter<DepositsAdapter.DepositViewHolder> {
    private List<Deposit> deposits = new ArrayList<>();

    public void setDeposits(List<Deposit> list) {
        this.deposits = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DepositViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemDepositStatusBinding binding = ItemDepositStatusBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new DepositViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DepositViewHolder holder, int position) {
        holder.bind(deposits.get(position));
    }

    @Override
    public int getItemCount() {
        return deposits.size();
    }

    static class DepositViewHolder extends RecyclerView.ViewHolder {
        private final ItemDepositStatusBinding binding;

        public DepositViewHolder(ItemDepositStatusBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Deposit d) {
            binding.tvDepositReference.setText(d.getReferenceCode());
            binding.tvDepositAmount.setText("+" + CurrencyFormatter.formatNaira(d.getAmount()));
            binding.tvDepositDate.setText(TimeUtils.formatDateTime(d.getCreatedAt()));

            String status = d.getStatus();
            if ("approved".equals(status) || "completed".equals(status)) {
                binding.tvDepositStatusBadge.setText("APPROVED");
                binding.tvDepositStatusBadge.setTextColor(Color.parseColor("#10B981"));
                binding.tvDepositStatusBadge.setBackgroundColor(Color.parseColor("#2610B981"));
                binding.tvAdminApprovalStatus.setText("APPROVED — Admin has approved the deposit and credited your wallet");
                binding.tvAdminApprovalStatus.setTextColor(Color.parseColor("#10B981"));
                binding.tvAdminRejectionNote.setVisibility(View.GONE);
            } else if ("rejected".equals(status) || "declined".equals(status) || "cancelled".equals(status)) {
                binding.tvDepositStatusBadge.setText("REJECTED");
                binding.tvDepositStatusBadge.setTextColor(Color.parseColor("#EF4444"));
                binding.tvDepositStatusBadge.setBackgroundColor(Color.parseColor("#26EF4444"));
                binding.tvAdminApprovalStatus.setText("REJECTED — Admin has rejected the deposit");
                binding.tvAdminApprovalStatus.setTextColor(Color.parseColor("#EF4444"));
                if (!d.getAdminNote().trim().isEmpty()) {
                    binding.tvAdminRejectionNote.setVisibility(View.VISIBLE);
                    binding.tvAdminRejectionNote.setText("Admin Reason: " + d.getAdminNote().trim());
                } else {
                    binding.tvAdminRejectionNote.setVisibility(View.GONE);
                }
            } else {
                binding.tvDepositStatusBadge.setText("PENDING");
                binding.tvDepositStatusBadge.setTextColor(Color.parseColor("#EAB308"));
                binding.tvDepositStatusBadge.setBackgroundColor(Color.parseColor("#26EAB308"));
                binding.tvAdminApprovalStatus.setText("PENDING — Deposit submitted and awaiting admin approval");
                binding.tvAdminApprovalStatus.setTextColor(Color.parseColor("#EAB308"));
                binding.tvAdminRejectionNote.setVisibility(View.GONE);
            }
        }
    }
}
