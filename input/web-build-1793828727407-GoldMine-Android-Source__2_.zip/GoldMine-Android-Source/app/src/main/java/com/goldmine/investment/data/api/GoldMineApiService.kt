package com.goldmine.investment.data.api

import com.goldmine.investment.data.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface GoldMineApiService {

    // 1. Authentication
    @POST("auth/login.php")
    suspend fun login(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthData>>

    @POST("auth/register.php")
    suspend fun register(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthData>>

    // 2. Dashboard
    @GET("dashboard.php")
    suspend fun getDashboard(): Response<ApiResponse<DashboardData>>

    // 3. Investment Packages
    @GET("plans.php")
    suspend fun getPlans(
        @Query("category") category: String = "all"
    ): Response<ApiResponse<PlansResponse>>

    // 4. Create Investment
    @POST("invest/create.php")
    suspend fun createInvestment(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    // 5. My Investments
    @GET("invest/my_investments.php")
    suspend fun getMyInvestments(
        @Query("filter") filter: String = "all"
    ): Response<ApiResponse<MyInvestmentsResponse>>

    // 6. Counting Date Countdown
    @GET("invest/counting_date.php")
    suspend fun getCountingDate(): Response<ApiResponse<CountingDateResponse>>

    // 7. Deposit Info & Submit
    @GET("deposit/info.php")
    suspend fun getDepositInfo(): Response<ApiResponse<PaymentInfo>>

    @Multipart
    @POST("deposit/submit.php")
    suspend fun submitDepositMultipart(
        @Part("amount") amount: RequestBody,
        @Part receipt: MultipartBody.Part
    ): Response<ApiResponse<Map<String, Any>>>

    @POST("deposit/submit.php")
    suspend fun submitDepositBase64(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("deposit/history.php")
    suspend fun getDepositHistory(): Response<ApiResponse<DepositHistoryResponse>>

    // 8. Withdrawal
    @POST("withdraw/submit.php")
    suspend fun submitWithdrawal(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("withdraw/history.php")
    suspend fun getWithdrawalHistory(): Response<ApiResponse<WithdrawalHistoryResponse>>

    // 9. Transactions
    @GET("transactions.php")
    suspend fun getTransactions(
        @Query("type") type: String = "all",
        @Query("page") page: Int = 1
    ): Response<ApiResponse<TransactionsResponse>>

    // 10. Profile & Notifications
    @GET("user/profile.php")
    suspend fun getProfile(): Response<ApiResponse<Map<String, Any>>>

    @GET("user/notifications.php")
    suspend fun getNotifications(): Response<ApiResponse<Map<String, Any>>>
}
