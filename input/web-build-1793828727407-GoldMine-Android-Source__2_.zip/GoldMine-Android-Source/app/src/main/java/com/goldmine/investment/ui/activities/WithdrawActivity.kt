package com.goldmine.investment.ui.activities

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.repository.WalletRepository
import com.goldmine.investment.databinding.ActivityWithdrawBinding
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class WithdrawActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWithdrawBinding
    private val walletRepo = WalletRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWithdrawBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        val user = SessionManager.getUser()
        if (user != null) {
            binding.tvAvailableBalance.text = "₦" + String.format("%,.2f", user.balance)
        }

        binding.btnSubmitWithdrawal.setOnClickListener {
            val amountStr = binding.etAmount.text.toString().trim()
            val amount = amountStr.toDoubleOrNull() ?: 0.0
            val bankName = binding.etBankName.text.toString().trim()
            val accountNum = binding.etAccountNumber.text.toString().trim()
            val accountName = binding.etAccountName.text.toString().trim()

            if (amount < 2000.0) {
                Toast.makeText(this, "Minimum withdrawal is ₦2,000.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val currentBalance = SessionManager.getUser()?.balance ?: 0.0
            if (amount > currentBalance) {
                Toast.makeText(this, "Amount exceeds available balance (₦" + String.format("%,.2f", currentBalance) + ")", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (bankName.isEmpty() || accountNum.isEmpty() || accountName.isEmpty()) {
                Toast.makeText(this, "Please fill in all bank account details", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            submitWithdrawal(amount, bankName, accountNum, accountName)
        }
    }

    private fun submitWithdrawal(amount: Double, bank: String, accNum: String, accName: String) {
        binding.btnSubmitWithdrawal.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            val res = walletRepo.submitWithdrawal(amount, bank, accNum, accName)
            binding.btnSubmitWithdrawal.isEnabled = true
            binding.progressBar.visibility = View.GONE

            res.onSuccess { msg ->
                Toast.makeText(this@WithdrawActivity, msg, Toast.LENGTH_LONG).show()
                finish()
            }.onFailure { err ->
                Toast.makeText(this@WithdrawActivity, err.message ?: "Withdrawal failed", Toast.LENGTH_LONG).show()
            }
        }
    }
}
