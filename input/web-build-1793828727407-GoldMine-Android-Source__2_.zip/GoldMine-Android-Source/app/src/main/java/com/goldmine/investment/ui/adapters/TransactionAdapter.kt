package com.goldmine.investment.ui.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.Deposit
import com.goldmine.investment.data.model.Transaction
import com.goldmine.investment.databinding.ItemTransactionBinding

class TransactionAdapter : RecyclerView.Adapter<TransactionAdapter.TxViewHolder>() {

    private val items = mutableListOf<Transaction>()

    fun submitList(list: List<Transaction>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TxViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return TxViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TxViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class TxViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(tx: Transaction) {
            binding.tvTxType.text = tx.type.replaceFirstChar { it.uppercase() }
            binding.tvTxDescription.text = tx.description
            binding.tvTxDate.text = tx.formattedDate ?: tx.createdAt.take(19)

            val sign = if (tx.isNegative) "-" else "+"
            val color = if (tx.isNegative) Color.parseColor("#F87171") else Color.parseColor("#EAB308")
            binding.tvTxAmount.text = "$sign₦" + String.format("%,.2f", tx.amount)
            binding.tvTxAmount.setTextColor(color)

            binding.tvTxStatus.text = tx.status.replaceFirstChar { it.uppercase() }
            when (tx.status.lowercase()) {
                "completed", "approved" -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#152B1E"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#34D399"))
                }
                "pending" -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#262215"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#FACC15"))
                }
                else -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#291215"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#F87171"))
                }
            }
        }
    }
}

class DepositHistoryAdapter : RecyclerView.Adapter<DepositHistoryAdapter.DepositViewHolder>() {

    private val items = mutableListOf<Deposit>()

    fun submitList(list: List<Deposit>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DepositViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return DepositViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DepositViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class DepositViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(d: Deposit) {
            binding.tvTxType.text = "Deposit Request"
            binding.tvTxDescription.text = "Ref: ${d.referenceCode} • ${d.paymentMethod}"
            binding.tvTxDate.text = d.createdAt.take(19)

            binding.tvTxAmount.text = "+₦" + String.format("%,.2f", d.amount)
            binding.tvTxAmount.setTextColor(Color.parseColor("#34D399"))

            binding.tvTxStatus.text = d.status.replaceFirstChar { it.uppercase() }
            when (d.status.lowercase()) {
                "approved" -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#152B1E"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#34D399"))
                }
                "pending", "under_review" -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#262215"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#FACC15"))
                }
                else -> {
                    binding.tvTxStatus.setBackgroundColor(Color.parseColor("#291215"))
                    binding.tvTxStatus.setTextColor(Color.parseColor("#F87171"))
                }
            }
        }
    }
}
