package com.goldmine.investment.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.R
import com.goldmine.investment.data.model.DashboardData
import com.goldmine.investment.data.repository.WalletRepository
import com.goldmine.investment.databinding.FragmentDashboardBinding
import com.goldmine.investment.ui.activities.DepositActivity
import com.goldmine.investment.ui.activities.MainActivity
import com.goldmine.investment.ui.activities.WithdrawActivity
import com.goldmine.investment.ui.adapters.TransactionAdapter
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val walletRepo = WalletRepository()
    private val transactionAdapter = TransactionAdapter()
    private var isBalanceVisible = true
    private var cachedBalance = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvRecentTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRecentTransactions.adapter = transactionAdapter

        binding.swipeRefresh.setOnRefreshListener {
            loadDashboard()
        }

        binding.btnDeposit.setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }

        binding.btnWithdraw.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }

        binding.btnToggleBalance.setOnClickListener {
            isBalanceVisible = !isBalanceVisible
            updateBalanceDisplay()
        }

        binding.tvViewAllTransactions.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_my_invest)
        }

        loadDashboard()
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    private fun loadDashboard() {
        binding.swipeRefresh.isRefreshing = true

        lifecycleScope.launch {
            val result = walletRepo.getDashboard()
            binding.swipeRefresh.isRefreshing = false

            result.onSuccess { data ->
                renderDashboard(data)
            }.onFailure { err ->
                Toast.makeText(requireContext(), "Failed to refresh dashboard: " + err.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderDashboard(data: DashboardData) {
        val user = data.user
        binding.tvUserName.text = user.fullName
        cachedBalance = data.metrics.availableBalance
        updateBalanceDisplay()

        binding.tvTotalInvested.text = "₦" + String.format("%,.2f", data.metrics.totalInvested)
        binding.tvTotalProfit.text = "₦" + String.format("%,.2f", data.metrics.totalProfit)
        binding.tvActiveInvestCount.text = data.metrics.activeInvestments.toString()
        binding.tvCompletedInvestCount.text = data.metrics.completedInvestments.toString()

        if (data.recentTransactions.isEmpty()) {
            binding.tvEmptyTransactions.visibility = View.VISIBLE
            binding.rvRecentTransactions.visibility = View.GONE
        } else {
            binding.tvEmptyTransactions.visibility = View.GONE
            binding.rvRecentTransactions.visibility = View.VISIBLE
            transactionAdapter.submitList(data.recentTransactions)
        }
    }

    private fun updateBalanceDisplay() {
        if (isBalanceVisible) {
            binding.tvBalance.text = "₦ " + String.format("%,.2f", cachedBalance)
        } else {
            binding.tvBalance.text = "₦ ••••••••"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
