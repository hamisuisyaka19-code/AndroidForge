package com.goldmine.investment.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.repository.AuthRepository
import com.goldmine.investment.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val authRepo = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val loginInput = binding.etLoginInput.text.toString().trim()
            val password = binding.etPassword.text.toString()

            if (loginInput.isEmpty() || password.isEmpty()) {
                showError("Please enter your email or phone and password.")
                return@setOnClickListener
            }

            performLogin(loginInput, password)
        }

        binding.tvGoToRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun performLogin(input: String, pass: String) {
        binding.tvError.visibility = View.GONE
        binding.btnLogin.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = authRepo.login(input, pass)
            binding.btnLogin.isEnabled = true
            binding.progressBar.visibility = View.GONE

            result.onSuccess {
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            }.onFailure { error ->
                showError(error.message ?: "Authentication failed. Check your credentials.")
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }
}
