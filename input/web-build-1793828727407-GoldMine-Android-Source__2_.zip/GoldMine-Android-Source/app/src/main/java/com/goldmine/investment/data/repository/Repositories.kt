package com.goldmine.investment.data.repository

import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.data.model.*
import com.goldmine.investment.util.SessionManager
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class AuthRepository {
    private val api = ApiClient.getService()

    suspend fun login(loginInput: String, password: String):Result<User> {
        return try {
            val response = api.login(mapOf(
                "login_input" to loginInput,
                "password" to password
            ))
            if (response.isSuccessful && response.body()?.status == true) {
                val authData = response.body()!!.data!!
                SessionManager.saveAuth(authData.token, authData.user)
                Result.success(authData.user)
            } else {
                val errorMsg = response.body()?.message ?: "Invalid email or password"
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(fullName: String, email: String, phone: String, password: String): Result<User> {
        return try {
            val response = api.register(mapOf(
                "full_name" to fullName,
                "email" to email,
                "phone" to phone,
                "password" to password,
                "confirm_password" to password
            ))
            if (response.isSuccessful && response.body()?.status == true) {
                val authData = response.body()!!.data!!
                SessionManager.saveAuth(authData.token, authData.user)
                Result.success(authData.user)
            } else {
                val errorMsg = response.body()?.message ?: "Registration failed"
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class InvestmentRepository {
    private val api = ApiClient.getService()

    suspend fun getPlans(category: String = "all"): Result<List<InvestmentPlan>> {
        return try {
            val response = api.getPlans(category)
            if (response.isSuccessful && response.body()?.status == true) {
                val plans = response.body()!!.data?.plans ?: emptyList()
                Result.success(plans)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load packages"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createInvestment(planId: Int, amount: Double): Result<String> {
        return try {
            val response = api.createInvestment(mapOf(
                "plan_id" to planId,
                "amount" to amount
            ))
            if (response.isSuccessful && response.body()?.status == true) {
                Result.success(response.body()!!.message)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to submit investment"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMyInvestments(filter: String = "all"): Result<List<Investment>> {
        return try {
            val response = api.getMyInvestments(filter)
            if (response.isSuccessful && response.body()?.status == true) {
                val list = response.body()!!.data?.investments ?: emptyList()
                Result.success(list)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load investments"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCountingDate(): Result<CountingDateResponse> {
        return try {
            val response = api.getCountingDate()
            if (response.isSuccessful && response.body()?.status == true) {
                val data = response.body()!!.data ?: CountingDateResponse(emptyList(), 0, System.currentTimeMillis() / 1000, "Africa/Lagos")
                Result.success(data)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load countdowns"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class WalletRepository {
    private val api = ApiClient.getService()

    suspend fun getDashboard(): Result<DashboardData> {
        return try {
            val response = api.getDashboard()
            if (response.isSuccessful && response.body()?.status == true) {
                val data = response.body()!!.data!!
                SessionManager.updateUser(data.user)
                Result.success(data)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load dashboard"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDepositInfo(): Result<PaymentInfo> {
        return try {
            val response = api.getDepositInfo()
            if (response.isSuccessful && response.body()?.status == true) {
                Result.success(response.body()!!.data!!)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load deposit info"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitDeposit(amount: Double, receiptFile: File): Result<String> {
        return try {
            val amountPart = amount.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val filePart = MultipartBody.Part.createFormData(
                "receipt",
                receiptFile.name,
                receiptFile.asRequestBody("image/*".toMediaTypeOrNull())
            )
            val response = api.submitDepositMultipart(amountPart, filePart)
            if (response.isSuccessful && response.body()?.status == true) {
                Result.success(response.body()!!.message)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to submit deposit"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitWithdrawal(amount: Double, bankName: String, accountNumber: String, accountName: String): Result<String> {
        return try {
            val response = api.submitWithdrawal(mapOf(
                "amount" to amount,
                "bank_name" to bankName,
                "account_number" to accountNumber,
                "account_name" to accountName
            ))
            if (response.isSuccessful && response.body()?.status == true) {
                Result.success(response.body()!!.message)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to submit withdrawal"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTransactions(type: String = "all"): Result<List<Transaction>> {
        return try {
            val response = api.getTransactions(type)
            if (response.isSuccessful && response.body()?.status == true) {
                val list = response.body()!!.data?.transactions ?: emptyList()
                Result.success(list)
            } else {
                Result.failure(Exception(response.body()?.message ?: "Failed to load transactions"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
