package com.goldmine.investment.ui.fragments

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.R
import com.goldmine.investment.data.model.InvestmentPlan
import com.goldmine.investment.data.repository.InvestmentRepository
import com.goldmine.investment.databinding.DialogInvestBinding
import com.goldmine.investment.databinding.FragmentPlansBinding
import com.goldmine.investment.ui.activities.MainActivity
import com.goldmine.investment.ui.adapters.PlanAdapter
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class PlansFragment : Fragment() {

    private var _binding: FragmentPlansBinding? = null
    private val binding get() = _binding!!
    private val investRepo = InvestmentRepository()
    private lateinit var planAdapter: PlanAdapter
    private var currentCategory = "all"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlansBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        planAdapter = PlanAdapter { plan ->
            showInvestModal(plan)
        }

        binding.rvPlans.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlans.adapter = planAdapter

        binding.swipeRefresh.setOnRefreshListener {
            loadPlans(currentCategory)
        }

        setupCategoryChips()
        updateBalanceHeader()
        loadPlans("all")
    }

    private fun setupCategoryChips() {
        binding.chipAllPlans.setOnClickListener {
            currentCategory = "all"
            updateChipStyles(binding.chipAllPlans)
            loadPlans("all")
        }

        binding.chipPopular.setOnClickListener {
            currentCategory = "popular"
            updateChipStyles(binding.chipPopular)
            loadPlans("popular")
        }

        binding.chipPremium.setOnClickListener {
            currentCategory = "premium"
            updateChipStyles(binding.chipPremium)
            loadPlans("premium")
        }
    }

    private fun updateChipStyles(selectedView: TextView) {
        val allViews = listOf(
            binding.chipAllPlans,
            binding.chipPopular,
            binding.chipPremium
        )

        allViews.forEach { v ->
            if (v == selectedView) {
                v.setBackgroundResource(R.drawable.bg_gold_button)
                v.setTextColor(Color.BLACK)
            } else {
                v.setBackgroundResource(R.drawable.bg_countdown_box)
                v.setTextColor(Color.parseColor("#A1A1AA"))
            }
        }
    }

    private fun updateBalanceHeader() {
        val user = SessionManager.getUser()
        if (user != null) {
            binding.tvWalletBalance.text = "₦" + String.format("%,.2f", user.balance)
        }
    }

    private fun loadPlans(category: String) {
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = investRepo.getPlans(category)
            binding.progressBar.visibility = View.GONE
            binding.swipeRefresh.isRefreshing = false

            result.onSuccess { plans ->
                planAdapter.submitList(plans)
            }.onFailure { err ->
                Toast.makeText(requireContext(), "Failed to load packages: " + err.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showInvestModal(plan: InvestmentPlan) {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val modalBinding = DialogInvestBinding.inflate(layoutInflater)
        dialog.setContentView(modalBinding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        modalBinding.tvModalTitle.text = "Invest in " + plan.name
        modalBinding.tvModalLimits.text = "Limits: ₦" + String.format("%,.0f", plan.minAmount) + " - ₦" + String.format("%,.0f", plan.maxAmount) + " • Duration: " + plan.durationDays + " Days"

        val user = SessionManager.getUser()
        val currentBalance = user?.balance ?: 0.0
        modalBinding.tvModalBalance.text = "₦" + String.format("%,.2f", currentBalance)

        // Set default amount to minimum
        modalBinding.etModalAmount.setText(String.format("%.0f", plan.minAmount))

        // Multiplier formula based on plan specification
        val profitRate = if (plan.id >= 3) 1.025 else 0.35
        val initialProfit = plan.minAmount * profitRate
        val initialExpectedReturn = plan.minAmount + initialProfit
        modalBinding.tvModalExpectedReturn.text = "₦" + String.format("%,.2f", initialExpectedReturn)

        modalBinding.etModalAmount.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val amt = s.toString().toDoubleOrNull() ?: 0.0
                val calcProfit = amt * profitRate
                val expectedReturn = amt + calcProfit
                modalBinding.tvModalExpectedReturn.text = "₦" + String.format("%,.2f", expectedReturn)
                modalBinding.tvModalProfitBreakdown.text = "Includes ₦" + String.format("%,.2f", amt) + " capital + ₦" + String.format("%,.2f", calcProfit) + " proposed profit (Non-guaranteed)"
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        modalBinding.btnModalCancel.setOnClickListener {
            dialog.dismiss()
        }

        modalBinding.btnModalConfirm.setOnClickListener {
            val amt = modalBinding.etModalAmount.text.toString().toDoubleOrNull() ?: 0.0

            if (amt < plan.minAmount) {
                Toast.makeText(requireContext(), "Minimum investment is ₦" + String.format("%,.2f", plan.minAmount), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (amt > plan.maxAmount) {
                Toast.makeText(requireContext(), "Maximum investment is ₦" + String.format("%,.2f", plan.maxAmount), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (amt > currentBalance) {
                Toast.makeText(requireContext(), "Insufficient wallet balance. Please deposit funds first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            modalBinding.btnModalConfirm.isEnabled = false
            modalBinding.btnModalConfirm.text = "Submitting Order..."

            lifecycleScope.launch {
                val res = investRepo.createInvestment(plan.id, amt)
                if (res.isSuccess) {
                    dialog.dismiss()
                    Toast.makeText(requireContext(), "Investment order placed! Now under admin review.", Toast.LENGTH_LONG).show()
                    // Navigate to My Invest tab
                    (activity as? MainActivity)?.navigateToTab(R.id.nav_my_invest)
                } else {
                    modalBinding.btnModalConfirm.isEnabled = true
                    modalBinding.btnModalConfirm.text = "Confirm Investment Order"
                    Toast.makeText(requireContext(), res.exceptionOrNull()?.message ?: "Failed to invest", Toast.LENGTH_LONG).show()
                }
            }
        }

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
