package com.goldmine.investment.ui.fragments

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.R
import com.goldmine.investment.data.repository.InvestmentRepository
import com.goldmine.investment.databinding.FragmentMyInvestBinding
import com.goldmine.investment.ui.activities.MainActivity
import com.goldmine.investment.ui.adapters.MyInvestAdapter
import kotlinx.coroutines.launch

class MyInvestFragment : Fragment() {

    private var _binding: FragmentMyInvestBinding? = null
    private val binding get() = _binding!!
    private val investRepo = InvestmentRepository()
    private lateinit var myInvestAdapter: MyInvestAdapter
    private var currentFilter = "all"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyInvestBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        myInvestAdapter = MyInvestAdapter { _ ->
            // Switch to Counting Date tab
            (activity as? MainActivity)?.navigateToTab(R.id.nav_counting)
        }

        binding.rvInvestments.layoutManager = LinearLayoutManager(requireContext())
        binding.rvInvestments.adapter = myInvestAdapter

        binding.swipeRefresh.setOnRefreshListener {
            loadInvestments(currentFilter)
        }

        setupFilterChips()
        loadInvestments("all")
    }

    private fun setupFilterChips() {
        val chips = listOf(
            binding.chipAll to "all",
            binding.chipActive to "active",
            binding.chipPending to "pending",
            binding.chipCompleted to "completed",
            binding.chipRejected to "rejected"
        )

        chips.forEach { (view, filter) ->
            view.setOnClickListener {
                currentFilter = filter
                updateChipStyles(view)
                loadInvestments(filter)
            }
        }
    }

    private fun updateChipStyles(selectedView: TextView) {
        val allViews = listOf(
            binding.chipAll,
            binding.chipActive,
            binding.chipPending,
            binding.chipCompleted,
            binding.chipRejected
        )

        allViews.forEach { v ->
            if (v == selectedView) {
                v.setBackgroundResource(R.drawable.bg_gold_button)
                v.setTextColor(Color.BLACK)
            } else {
                v.setBackgroundResource(R.drawable.bg_countdown_box)
                v.setTextColor(Color.parseColor("#A1A1AA"))
            }
        }
    }

    private fun loadInvestments(filter: String) {
        binding.swipeRefresh.isRefreshing = true

        lifecycleScope.launch {
            val res = investRepo.getMyInvestments(filter)
            binding.swipeRefresh.isRefreshing = false

            res.onSuccess { list ->
                if (list.isEmpty()) {
                    binding.tvEmpty.visibility = View.VISIBLE
                    binding.rvInvestments.visibility = View.GONE
                } else {
                    binding.tvEmpty.visibility = View.GONE
                    binding.rvInvestments.visibility = View.VISIBLE
                    myInvestAdapter.submitList(list)
                }
            }.onFailure { err ->
                Toast.makeText(requireContext(), "Failed to load investments: " + err.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
