package com.goldmine.investment.ui.activities

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.data.model.Deposit
import com.goldmine.investment.databinding.ActivityDepositBinding
import com.goldmine.investment.ui.adapters.DepositHistoryAdapter
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream

class DepositActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDepositBinding
    private var selectedFileUri: Uri? = null
    private val depositAdapter = DepositHistoryAdapter()

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedFileUri = uri
                binding.tvReceiptSelectedName.text = "✓ Receipt Selected (Ready to upload)"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDepositBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        loadDepositInfo()
        loadDepositHistory()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener { finish() }

        binding.btnCopyAccount.setOnClickListener {
            val accountNum = binding.tvAccountNumber.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Account Number", accountNum))
            Toast.makeText(this, "Account number copied: $accountNum", Toast.LENGTH_SHORT).show()
        }

        binding.btnSelectReceipt.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            }
            filePickerLauncher.launch(intent)
        }

        binding.btnSubmitDeposit.setOnClickListener {
            val amountStr = binding.etDepositAmount.text.toString().trim()
            val amount = amountStr.toDoubleOrNull() ?: 0.0

            if (amount < 500.0) {
                Toast.makeText(this, "Minimum deposit is ₦500.00", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedFileUri == null) {
                Toast.makeText(this, "Please select proof of transfer receipt first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            submitDeposit(amount, selectedFileUri!!)
        }

        binding.rvDepositHistory.layoutManager = LinearLayoutManager(this)
        binding.rvDepositHistory.adapter = depositAdapter
    }

    private fun loadDepositInfo() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService().getDepositInfo()
                if (res.isSuccessful && res.body()?.status == true) {
                    val info = res.body()!!.data!!
                    binding.tvBankName.text = info.bankName
                    binding.tvAccountNumber.text = info.accountNumber
                    binding.tvAccountName.text = info.accountName
                }
            } catch (e: Exception) {
                // Keep default fallback values
            }
        }
    }

    private fun loadDepositHistory() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService().getDepositHistory()
                if (res.isSuccessful && res.body()?.status == true) {
                    val list = res.body()!!.data?.deposits ?: emptyList()
                    depositAdapter.submitList(list)
                }
            } catch (e: Exception) {
                // Ignore history failure
            }
        }
    }

    private fun submitDeposit(amount: Double, uri: Uri) {
        binding.btnSubmitDeposit.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val tempFile = copyUriToTempFile(uri)
                val amountPart = amount.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                val requestFile = okhttp3.RequestBody.create(
                    contentResolver.getType(uri)?.let { it.toMediaTypeOrNull() } ?: "image/*".toMediaTypeOrNull(),
                    tempFile
                )
                val filePart = MultipartBody.Part.createFormData("receipt", tempFile.name, requestFile)

                val response = ApiClient.getService().submitDepositMultipart(amountPart, filePart)
                binding.btnSubmitDeposit.isEnabled = true
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful && response.body()?.status == true) {
                    Toast.makeText(this@DepositActivity, response.body()?.message ?: "Deposit submitted!", Toast.LENGTH_LONG).show()
                    binding.etDepositAmount.text.clear()
                    selectedFileUri = null
                    binding.tvReceiptSelectedName.text = "📁 Tap to Select Receipt (Image or PDF)"
                    loadDepositHistory()
                } else {
                    Toast.makeText(this@DepositActivity, response.body()?.message ?: "Submission failed", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.btnSubmitDeposit.isEnabled = true
                binding.progressBar.visibility = View.GONE
                Toast.makeText(this@DepositActivity, "Error: " + e.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun copyUriToTempFile(uri: Uri): File {
        val inputStream = contentResolver.openInputStream(uri) ?: throw Exception("Cannot open file")
        val tempFile = File.createTempFile("deposit_receipt_", ".jpg", cacheDir)
        val outputStream = FileOutputStream(tempFile)
        inputStream.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }
}
