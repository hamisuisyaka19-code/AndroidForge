package com.goldmine.investment.ui.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.Investment
import com.goldmine.investment.databinding.ItemMyInvestBinding

class MyInvestAdapter(
    private val onCountingDateClick: (Investment) -> Unit
) : RecyclerView.Adapter<MyInvestAdapter.InvestViewHolder>() {

    private val investments = mutableListOf<Investment>()

    fun submitList(list: List<Investment>) {
        investments.clear()
        investments.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvestViewHolder {
        val binding = ItemMyInvestBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return InvestViewHolder(binding)
    }

    override fun onBindViewHolder(holder: InvestViewHolder, position: Int) {
        holder.bind(investments[position])
    }

    override fun getItemCount(): Int = investments.size

    inner class InvestViewHolder(private val binding: ItemMyInvestBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(inv: Investment) {
            binding.tvPlanName.text = inv.planName
            binding.tvReferenceCode.text = "Reference: " + inv.referenceCode
            binding.tvInvestedAmount.text = "₦" + String.format("%,.2f", inv.amount)
            val profit = if (inv.profitAmount > 0) inv.profitAmount else (inv.expectedReturn - inv.amount)
            binding.tvProfitAmount.text = "₦" + String.format("%,.2f", profit)
            binding.tvExpectedReturn.text = "₦" + String.format("%,.2f", inv.expectedReturn)
            binding.tvInvestmentDate.text = inv.createdAt.take(10)
            binding.tvMaturityDate.text = inv.maturityDate?.take(10) ?: "Awaiting Admin Approval"

            // Style status badge
            val statusText = inv.status.uppercase()
            binding.tvStatusBadge.text = statusText
            when (inv.status.lowercase()) {
                "active" -> {
                    binding.tvStatusBadge.setBackgroundColor(Color.parseColor("#152B1E"))
                    binding.tvStatusBadge.setTextColor(Color.parseColor("#34D399"))
                    binding.layoutCountingDateAction.visibility = View.VISIBLE
                    binding.btnViewCountingDate.setOnClickListener { onCountingDateClick(inv) }
                }
                "completed" -> {
                    binding.tvStatusBadge.setBackgroundColor(Color.parseColor("#181E2B"))
                    binding.tvStatusBadge.setTextColor(Color.parseColor("#60A5FA"))
                    binding.layoutCountingDateAction.visibility = View.GONE
                }
                "pending" -> {
                    binding.tvStatusBadge.setBackgroundColor(Color.parseColor("#262215"))
                    binding.tvStatusBadge.setTextColor(Color.parseColor("#FACC15"))
                    binding.layoutCountingDateAction.visibility = View.GONE
                }
                "rejected" -> {
                    binding.tvStatusBadge.setBackgroundColor(Color.parseColor("#291215"))
                    binding.tvStatusBadge.setTextColor(Color.parseColor("#F87171"))
                    binding.layoutCountingDateAction.visibility = View.GONE
                }
                else -> {
                    binding.layoutCountingDateAction.visibility = View.GONE
                }
            }
        }
    }
}
