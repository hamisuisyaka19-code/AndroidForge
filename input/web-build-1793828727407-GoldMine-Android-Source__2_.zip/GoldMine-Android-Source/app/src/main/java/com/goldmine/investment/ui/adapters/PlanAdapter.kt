package com.goldmine.investment.ui.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.InvestmentPlan
import com.goldmine.investment.databinding.ItemPlanCardBinding

class PlanAdapter(
    private val onInvestClick: (InvestmentPlan) -> Unit
) : RecyclerView.Adapter<PlanAdapter.PlanViewHolder>() {

    private val plans = mutableListOf<InvestmentPlan>()

    fun submitList(list: List<InvestmentPlan>) {
        plans.clear()
        plans.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {
        val binding = ItemPlanCardBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return PlanViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        holder.bind(plans[position])
    }

    override fun getItemCount(): Int = plans.size

    inner class PlanViewHolder(private val binding: ItemPlanCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(plan: InvestmentPlan) {
            binding.tvPlanName.text = plan.name
            binding.tvPlanDescription.text = plan.description ?: "Official verified Gold Tier package."
            binding.tvDailyProfitBadge.text = "Daily Profit: ${plan.dailyProfit ?: "35%"}"
            binding.tvDailyProfit.text = plan.dailyProfit ?: "35%"
            binding.tvDuration.text = "${plan.durationDays} Days"
            binding.tvMinInvestment.text = "₦" + String.format("%,.0f", plan.minAmount)

            // Computed profit and total return values
            val profitVal = plan.profitAtMin ?: (if (plan.id >= 3) plan.minAmount * 1.025 else plan.minAmount * 0.35)
            val totalVal = plan.totalReturnAtMin ?: (plan.minAmount + profitVal)

            binding.tvProfit.text = "₦" + String.format("%,.0f", profitVal)
            binding.tvTotalReturn.text = "₦" + String.format("%,.0f", totalVal) + " (Capital + Profit)"

            // Category Badge & Theme
            val category = plan.category ?: if (plan.id >= 3) "premium" else "popular"
            if (category.equals("premium", ignoreCase = true)) {
                binding.tvCategoryBadge.text = "PREMIUM TIER"
                binding.tvCategoryBadge.setTextColor(Color.parseColor("#FACC15"))
                binding.tvCategoryBadge.setBackgroundColor(Color.parseColor("#262215"))
            } else {
                binding.tvCategoryBadge.text = "POPULAR CHOICE"
                binding.tvCategoryBadge.setTextColor(Color.parseColor("#34D399"))
                binding.tvCategoryBadge.setBackgroundColor(Color.parseColor("#152B1E"))
            }

            // Choose Gold Bullion Emblem icon based on plan
            val icon = when (plan.id) {
                1 -> "🥇" // Starter Gold
                2 -> "👑" // Classic Gold
                3 -> "💎" // Premium Gold
                4 -> "🏛️" // VIP Gold
                else -> "✨"
            }
            binding.tvPlanIcon.text = icon

            binding.btnInvestNow.text = "Invest Now (${plan.name})"
            binding.btnInvestNow.setOnClickListener {
                onInvestClick(plan)
            }
        }
    }
}
