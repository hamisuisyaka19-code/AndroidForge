package com.goldmine.investment.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.goldmine.investment.R
import com.goldmine.investment.databinding.ActivityMainBinding
import com.goldmine.investment.ui.fragments.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val dashboardFragment = DashboardFragment()
    private val plansFragment = PlansFragment()
    private val myInvestFragment = MyInvestFragment()
    private val countingDateFragment = CountingDateFragment()
    private val profileFragment = ProfileFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(dashboardFragment)
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    loadFragment(dashboardFragment)
                    true
                }
                R.id.nav_plans -> {
                    loadFragment(plansFragment)
                    true
                }
                R.id.nav_my_invest -> {
                    loadFragment(myInvestFragment)
                    true
                }
                R.id.nav_counting -> {
                    loadFragment(countingDateFragment)
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(profileFragment)
                    true
                }
                else -> false
            }
        }
    }

    fun navigateToTab(tabId: Int) {
        binding.bottomNav.selectedItemId = tabId
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
