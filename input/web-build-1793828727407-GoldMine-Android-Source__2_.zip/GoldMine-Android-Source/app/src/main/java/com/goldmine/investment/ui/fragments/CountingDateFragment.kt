package com.goldmine.investment.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.goldmine.investment.R
import com.goldmine.investment.data.repository.InvestmentRepository
import com.goldmine.investment.databinding.FragmentCountingDateBinding
import com.goldmine.investment.ui.activities.MainActivity
import com.goldmine.investment.ui.adapters.CountingDateAdapter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class CountingDateFragment : Fragment() {

    private var _binding: FragmentCountingDateBinding? = null
    private val binding get() = _binding!!
    private val investRepo = InvestmentRepository()
    private val countingAdapter = CountingDateAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCountingDateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvCountdowns.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCountdowns.adapter = countingAdapter

        binding.swipeRefresh.setOnRefreshListener {
            loadCountingDate()
        }

        binding.btnEmptyInvestNow.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_plans)
        }

        loadCountingDate()
    }

    override fun onResume() {
        super.onResume()
        countingAdapter.startTicker()
    }

    override fun onPause() {
        super.onPause()
        countingAdapter.stopTicker()
    }

    private fun loadCountingDate() {
        binding.swipeRefresh.isRefreshing = true

        lifecycleScope.launch {
            val res = investRepo.getCountingDate()
            binding.swipeRefresh.isRefreshing = false

            res.onSuccess { data ->
                val lagosSdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).apply {
                    timeZone = TimeZone.getTimeZone(data.timezone)
                }
                binding.tvLiveServerTime.text = lagosSdf.format(Date(data.serverTimestamp * 1000))

                if (data.countdowns.isEmpty()) {
                    binding.layoutEmpty.visibility = View.VISIBLE
                    binding.rvCountdowns.visibility = View.GONE
                } else {
                    binding.layoutEmpty.visibility = View.GONE
                    binding.rvCountdowns.visibility = View.VISIBLE
                    countingAdapter.submitList(data.countdowns)
                }
            }.onFailure { err ->
                Toast.makeText(requireContext(), "Failed to load countdowns: " + err.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        countingAdapter.stopTicker()
        _binding = null
    }
}
