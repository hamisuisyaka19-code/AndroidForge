package com.goldmine.investment.data.model

import com.google.gson.annotations.SerializedName

/**
 * Standard API envelope returned by GoldMine cPanel backend
 */
data class ApiResponse<T>(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("data") val data: T?,
    @SerializedName("timestamp") val timestamp: Long?,
    @SerializedName("server_time") val serverTime: String?,
    @SerializedName("timezone") val timezone: String?
)

/**
 * Logged-in user entity matching MySQL `users` table
 */
data class User(
    @SerializedName("id") val id: Int,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("balance") val balance: Double,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double,
    @SerializedName("status") val status: String,
    @SerializedName("email_verified") val emailVerified: Boolean = false,
    @SerializedName("created_at") val createdAt: String? = null
)

/**
 * Authentication response payload
 */
data class AuthData(
    @SerializedName("token") val token: String,
    @SerializedName("user") val user: User
)

/**
 * Dashboard response payload
 */
data class DashboardData(
    @SerializedName("user") val user: User,
    @SerializedName("metrics") val metrics: DashboardMetrics,
    @SerializedName("recent_transactions") val recentTransactions: List<Transaction>,
    @SerializedName("payment_info") val paymentInfo: PaymentInfo
)

data class DashboardMetrics(
    @SerializedName("available_balance") val availableBalance: Double,
    @SerializedName("total_invested") val totalInvested: Double,
    @SerializedName("total_profit") val totalProfit: Double,
    @SerializedName("active_investments") val activeInvestments: Int,
    @SerializedName("completed_investments") val completedInvestments: Int,
    @SerializedName("pending_investments") val pendingInvestments: Int,
    @SerializedName("unread_notifications") val unreadNotifications: Int
)

/**
 * Company manual bank transfer details from config/payment.php
 */
data class PaymentInfo(
    @SerializedName("bank_name") val bankName: String,
    @SerializedName("account_number") val accountNumber: String,
    @SerializedName("account_name") val accountName: String,
    @SerializedName("min_deposit") val minDeposit: Double,
    @SerializedName("min_withdrawal") val minWithdrawal: Double
)

/**
 * Investment Package matching MySQL `investment_plans` table
 */
data class InvestmentPlan(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String,
    @SerializedName("daily_profit") val dailyProfit: String? = "35%",
    @SerializedName("min_amount") val minAmount: Double,
    @SerializedName("max_amount") val maxAmount: Double,
    @SerializedName("roi_percentage") val roiPercentage: Double? = 35.0,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("profit_at_min") val profitAtMin: Double? = 350.0,
    @SerializedName("total_return_at_min") val totalReturnAtMin: Double? = 1350.0,
    @SerializedName("category") val category: String? = "popular",
    @SerializedName("badge") val badge: String? = null,
    @SerializedName("description") val description: String?,
    @SerializedName("sort_order") val sortOrder: Int
)

data class PlansResponse(
    @SerializedName("plans") val plans: List<InvestmentPlan>,
    @SerializedName("count") val count: Int,
    @SerializedName("currency") val currency: String,
    @SerializedName("category_filter") val categoryFilter: String?,
    @SerializedName("risk_disclosure") val riskDisclosure: String?
)

/**
 * User investment order matching MySQL `investments` table
 */
data class Investment(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("plan_id") val planId: Int,
    @SerializedName("plan_name") val planName: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("roi_percentage") val roiPercentage: Double,
    @SerializedName("expected_return") val expectedReturn: Double,
    @SerializedName("profit_amount") val profitAmount: Double,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("start_date") val startDate: String?,
    @SerializedName("maturity_date") val maturityDate: String?,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("seconds_remaining") val secondsRemaining: Long,
    @SerializedName("progress_percent") val progressPercent: Int,
    @SerializedName("is_counting") val isCounting: Boolean
)

data class MyInvestmentsResponse(
    @SerializedName("investments") val investments: List<Investment>,
    @SerializedName("filter") val filter: String,
    @SerializedName("count") val count: Int,
    @SerializedName("server_timestamp") val serverTimestamp: Long
)

/**
 * Counting date item for active investment countdown
 */
data class CountingDateItem(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("plan_name") val planName: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("expected_return") val expectedReturn: Double,
    @SerializedName("duration_days") val durationDays: Int,
    @SerializedName("start_date") val startDate: String?,
    @SerializedName("maturity_date") val maturityDate: String?,
    @SerializedName("start_timestamp") val startTimestamp: Long,
    @SerializedName("maturity_timestamp") val maturityTimestamp: Long,
    @SerializedName("seconds_remaining") var secondsRemaining: Long,
    @SerializedName("progress_percent") var progressPercent: Int,
    @SerializedName("is_matured") var isMatured: Boolean,
    @SerializedName("countdown") val countdown: CountdownUnits
)

data class CountdownUnits(
    @SerializedName("days") var days: Int,
    @SerializedName("hours") var hours: Int,
    @SerializedName("minutes") var minutes: Int,
    @SerializedName("seconds") var seconds: Int
)

data class CountingDateResponse(
    @SerializedName("countdowns") val countdowns: List<CountingDateItem>,
    @SerializedName("count") val count: Int,
    @SerializedName("server_timestamp") val serverTimestamp: Long,
    @SerializedName("timezone") val timezone: String
)

/**
 * Deposit record matching MySQL `deposits` table
 */
data class Deposit(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("status") val status: String,
    @SerializedName("receipt_path") val receiptPath: String?,
    @SerializedName("receipt_url") val receiptUrl: String?,
    @SerializedName("admin_notes") val adminNotes: String?,
    @SerializedName("created_at") val createdAt: String
)

data class DepositHistoryResponse(
    @SerializedName("deposits") val deposits: List<Deposit>,
    @SerializedName("count") val count: Int
)

/**
 * Withdrawal record matching MySQL `withdrawals` table
 */
data class Withdrawal(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("bank_name") val bankName: String,
    @SerializedName("account_number") val accountNumber: String,
    @SerializedName("account_name") val accountName: String,
    @SerializedName("status") val status: String,
    @SerializedName("admin_notes") val adminNotes: String?,
    @SerializedName("created_at") val createdAt: String
)

data class WithdrawalHistoryResponse(
    @SerializedName("withdrawals") val withdrawals: List<Withdrawal>,
    @SerializedName("count") val count: Int
)

/**
 * Transaction record matching MySQL `transactions` table
 */
data class Transaction(
    @SerializedName("id") val id: Int,
    @SerializedName("reference_code") val referenceCode: String,
    @SerializedName("type") val type: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("fee") val fee: Double,
    @SerializedName("balance_after") val balanceAfter: Double,
    @SerializedName("status") val status: String,
    @SerializedName("description") val description: String,
    @SerializedName("is_negative") val isNegative: Boolean,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("formatted_date") val formattedDate: String?
)

data class TransactionsResponse(
    @SerializedName("transactions") val transactions: List<Transaction>,
    @SerializedName("count") val count: Int,
    @SerializedName("filter") val filter: String
)
