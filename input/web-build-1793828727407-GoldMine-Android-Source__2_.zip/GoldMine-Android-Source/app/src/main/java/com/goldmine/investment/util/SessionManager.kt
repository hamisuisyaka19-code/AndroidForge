package com.goldmine.investment.util

import android.content.Context
import android.content.SharedPreferences
import com.goldmine.investment.data.model.User
import com.google.gson.Gson

object SessionManager {
    private const val PREF_NAME = "goldmine_session_prefs"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_USER_JSON = "user_json"
    private const val KEY_BASE_URL = "custom_base_url"

    private lateinit var prefs: SharedPreferences
    private val gson = Gson()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun saveAuth(token: String, user: User) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER_JSON, gson.toJson(user))
            .apply()
    }

    fun getToken(): String? {
        return prefs.getString(KEY_TOKEN, null)
    }

    fun isLoggedIn(): Boolean {
        return !getToken().isNullOrEmpty()
    }

    fun getUser(): User? {
        val json = prefs.getString(KEY_USER_JSON, null) ?: return null
        return try {
            gson.fromJson(json, User::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun updateUser(user: User) {
        prefs.edit().putString(KEY_USER_JSON, gson.toJson(user)).apply()
    }

    fun logout() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_USER_JSON)
            .apply()
    }

    fun getBaseUrl(): String {
        return prefs.getString(KEY_BASE_URL, "https://goalmindai.com.ng/api/") ?: "https://goalmindai.com.ng/api/"
    }

    fun setBaseUrl(url: String) {
        prefs.edit().putString(KEY_BASE_URL, url).apply()
    }
}
