package com.goldmine.investment.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.api.ApiClient
import com.goldmine.investment.databinding.FragmentProfileBinding
import com.goldmine.investment.ui.activities.LoginActivity
import com.goldmine.investment.util.SessionManager
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val user = SessionManager.getUser()
        if (user != null) {
            renderProfile(user.fullName, user.email, user.phone, user.totalInvested, user.totalProfit)
        }

        binding.btnSignOut.setOnClickListener {
            SessionManager.logout()
            Toast.makeText(requireContext(), "Signed out successfully", Toast.LENGTH_SHORT).show()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            activity?.finishAffinity()
        }

        loadProfileFromBackend()
    }

    private fun loadProfileFromBackend() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService().getProfile()
                if (res.isSuccessful && res.body()?.status == true) {
                    val data = res.body()!!.data
                    val userMap = data?.get("user") as? Map<*, *>
                    if (userMap != null) {
                        val name = userMap["full_name"]?.toString() ?: ""
                        val email = userMap["email"]?.toString() ?: ""
                        val phone = userMap["phone"]?.toString() ?: ""
                        val invested = (userMap["total_invested"] as? Number)?.toDouble() ?: 0.0
                        val profit = (userMap["total_profit"] as? Number)?.toDouble() ?: 0.0
                        renderProfile(name, email, phone, invested, profit)
                    }
                }
            } catch (e: Exception) {
                // Keep local cache
            }
        }
    }

    private fun renderProfile(name: String, email: String, phone: String, invested: Double, profit: Double) {
        binding.tvFullName.text = name
        binding.tvEmail.text = email
        binding.tvPhone.text = phone
        binding.tvAvatar.text = name.firstOrNull()?.uppercase() ?: "U"
        binding.tvProfileInvested.text = "₦" + String.format("%,.2f", invested)
        binding.tvProfileProfit.text = "₦" + String.format("%,.2f", profit)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
