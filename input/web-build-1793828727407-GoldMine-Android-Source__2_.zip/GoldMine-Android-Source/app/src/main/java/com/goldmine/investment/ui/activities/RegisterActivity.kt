package com.goldmine.investment.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.data.repository.AuthRepository
import com.goldmine.investment.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val authRepo = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {
            val name = binding.etFullName.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val password = binding.etPassword.text.toString()

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                showError("All fields are required.")
                return@setOnClickListener
            }
            if (password.length < 8) {
                showError("Password must be at least 8 characters.")
                return@setOnClickListener
            }

            performRegister(name, email, phone, password)
        }

        binding.tvGoToLogin.setOnClickListener {
            finish()
        }
    }

    private fun performRegister(name: String, email: String, phone: String, pass: String) {
        binding.tvError.visibility = View.GONE
        binding.btnRegister.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            val result = authRepo.register(name, email, phone, pass)
            binding.btnRegister.isEnabled = true
            binding.progressBar.visibility = View.GONE

            result.onSuccess {
                startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                finishAffinity()
            }.onFailure { error ->
                showError(error.message ?: "Registration failed.")
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }
}
