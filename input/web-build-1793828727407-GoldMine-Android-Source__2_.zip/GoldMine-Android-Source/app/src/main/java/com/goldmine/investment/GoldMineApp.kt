package com.goldmine.investment

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.goldmine.investment.util.SessionManager

class GoldMineApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize session manager
        SessionManager.init(this)
        // Enforce dark mode for Black & Gold luxury aesthetic
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
    }
}
