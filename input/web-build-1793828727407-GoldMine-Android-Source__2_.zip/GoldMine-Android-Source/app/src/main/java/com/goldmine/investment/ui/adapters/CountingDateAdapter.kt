package com.goldmine.investment.ui.adapters

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.data.model.CountingDateItem
import com.goldmine.investment.databinding.ItemCountingDateBinding

class CountingDateAdapter : RecyclerView.Adapter<CountingDateAdapter.CountdownViewHolder>() {

    private val items = mutableListOf<CountingDateItem>()
    private val handler = Handler(Looper.getMainLooper())
    private var isTickerRunning = false

    private val tickerRunnable = object : Runnable {
        override fun run() {
            var updatedAny = false
            val currentSystemSec = System.currentTimeMillis() / 1000

            items.forEach { item ->
                if (!item.isMatured) {
                    val remaining = maxOf(0L, item.maturityTimestamp - currentSystemSec)
                    item.secondsRemaining = remaining

                    val totalDuration = maxOf(1L, item.maturityTimestamp - item.startTimestamp)
                    val elapsed = maxOf(0L, currentSystemSec - item.startTimestamp)
                    item.progressPercent = minOf(100, ((elapsed.toDouble() / totalDuration.toDouble()) * 100).toInt())

                    item.countdown.days = (remaining / 86400).toInt()
                    item.countdown.hours = ((remaining % 86400) / 3600).toInt()
                    item.countdown.minutes = ((remaining % 3600) / 60).toInt()
                    item.countdown.seconds = (remaining % 60).toInt()

                    if (remaining <= 0) {
                        item.isMatured = true
                    }
                    updatedAny = true
                }
            }

            if (updatedAny) {
                notifyDataSetChanged()
            }

            handler.postDelayed(this, 1000)
        }
    }

    fun submitList(list: List<CountingDateItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
        startTicker()
    }

    fun startTicker() {
        if (!isTickerRunning) {
            isTickerRunning = true
            handler.post(tickerRunnable)
        }
    }

    fun stopTicker() {
        isTickerRunning = false
        handler.removeCallbacks(tickerRunnable)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountdownViewHolder {
        val binding = ItemCountingDateBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return CountdownViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountdownViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class CountdownViewHolder(private val binding: ItemCountingDateBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: CountingDateItem) {
            binding.tvPlanName.text = item.planName
            binding.tvReferenceCode.text = "Reference: " + item.referenceCode
            binding.tvAmount.text = "₦" + String.format("%,.2f", item.amount)
            binding.tvStartDate.text = item.startDate?.take(10) ?: "N/A"
            binding.tvMaturityDate.text = item.maturityDate?.take(10) ?: "N/A"

            if (item.isMatured) {
                binding.tvDays.text = "00"
                binding.tvHours.text = "00"
                binding.tvMinutes.text = "00"
                binding.tvSeconds.text = "00"
                binding.pbCountdownProgress.progress = 100
                binding.tvProgressPercent.text = "100%"
                binding.tvStatusBadge.text = "COMPLETED"
                binding.tvMaturityNotice.text = "Maturity reached! Settlement processed."
            } else {
                binding.tvDays.text = String.format("%02d", item.countdown.days)
                binding.tvHours.text = String.format("%02d", item.countdown.hours)
                binding.tvMinutes.text = String.format("%02d", item.countdown.minutes)
                binding.tvSeconds.text = String.format("%02d", item.countdown.seconds)
                binding.pbCountdownProgress.progress = item.progressPercent
                binding.tvProgressPercent.text = "${item.progressPercent}%"
                binding.tvStatusBadge.text = "ACTIVE COUNTDOWN"
                binding.tvMaturityNotice.text = "Auto-settles upon 100% completion"
            }
        }
    }
}
