package ng.com.goldmine.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

/**
 * SplashActivity provides a luxury Black and Gold entry screen.
 * Implements Android 12+ SplashScreen API support.
 */
@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Install modern Android 12+ SplashScreen before super.onCreate()
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Smooth fade-in animation for the branding logo
        LinearLayout logoContainer = findViewById(R.id.logo_container);
        if (logoContainer != null) {
            Animation fadeIn = new AlphaAnimation(0.0f, 1.0f);
            fadeIn.setDuration(1000);
            logoContainer.startAnimation(fadeIn);
        }

        // Navigate to MainActivity after delay
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    // Pass any incoming deep link data from push notifications or links
                    if (getIntent() != null && getIntent().getData() != null) {
                        intent.setData(getIntent().getData());
                    }
                    startActivity(intent);
                    finish();
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                }
            }
        }, Constants.SPLASH_DELAY_MS);
    }
}
