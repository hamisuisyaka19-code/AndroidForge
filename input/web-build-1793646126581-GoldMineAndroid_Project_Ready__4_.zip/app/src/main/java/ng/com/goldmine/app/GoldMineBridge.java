package ng.com.goldmine.app;

import android.webkit.JavascriptInterface;

/**
 * GoldMineBridge - JavaScript Interface bridge for live data synchronization.
 * Securely communicates user investment records from https://goalmindai.com.ng/my-invest.php
 * directly to the native Android Counting engine.
 */
public class GoldMineBridge {

    public interface InvestmentSyncListener {
        void onInvestmentsReceived(String json);
    }

    private final InvestmentSyncListener listener;

    public GoldMineBridge(InvestmentSyncListener listener) {
        this.listener = listener;
    }

    @JavascriptInterface
    public void onInvestmentsLoaded(String json) {
        if (listener != null) {
            listener.onInvestmentsReceived(json);
        }
    }
}
