package ng.com.goldmine.app;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * InvestmentModel represents a user investment on GoldMine.
 * Synchronized with the real PHP platform at https://goalmindai.com.ng/my-invest.php.
 */
public class InvestmentModel {
    private String id;
    private String planName;
    private String amount;
    private String startDate;
    private String maturityDate;
    private long startTimestamp;
    private long maturityTimestamp;
    private String status; // "Active", "Completed", "Pending"

    public InvestmentModel(String id, String planName, String amount, String startDate,
                           String maturityDate, long startTimestamp, long maturityTimestamp, String status) {
        this.id = id;
        this.planName = planName;
        this.amount = amount;
        this.startDate = startDate;
        this.maturityDate = maturityDate;
        this.startTimestamp = startTimestamp;
        this.maturityTimestamp = maturityTimestamp;
        this.status = status;
    }

    public String getId() { return id; }
    public String getPlanName() { return planName; }
    public String getAmount() { return amount; }
    public String getStartDate() { return startDate; }
    public String getMaturityDate() { return maturityDate; }
    public long getStartTimestamp() { return startTimestamp; }
    public long getMaturityTimestamp() { return maturityTimestamp; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isMatured() {
        return System.currentTimeMillis() >= maturityTimestamp;
    }

    public long getRemainingMillis() {
        long diff = maturityTimestamp - System.currentTimeMillis();
        return Math.max(0, diff);
    }

    public int getRemainingDays() {
        return (int) (getRemainingMillis() / (1000 * 60 * 60 * 24));
    }

    public int getRemainingHours() {
        return (int) ((getRemainingMillis() / (1000 * 60 * 60)) % 24);
    }

    public int getRemainingMinutes() {
        return (int) ((getRemainingMillis() / (1000 * 60)) % 60);
    }

    public int getRemainingSeconds() {
        return (int) ((getRemainingMillis() / 1000) % 60);
    }

    public int getProgressPercent() {
        if (maturityTimestamp <= startTimestamp) return 100;
        long total = maturityTimestamp - startTimestamp;
        long elapsed = System.currentTimeMillis() - startTimestamp;
        if (elapsed <= 0) return 0;
        if (elapsed >= total) return 100;
        return (int) ((elapsed * 100) / total);
    }

    public JSONObject toJsonObject() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("planName", planName);
        obj.put("amount", amount);
        obj.put("startDate", startDate);
        obj.put("maturityDate", maturityDate);
        obj.put("startTimestamp", startTimestamp);
        obj.put("maturityTimestamp", maturityTimestamp);
        obj.put("status", status);
        return obj;
    }

    public static InvestmentModel fromJsonObject(JSONObject obj) {
        if (obj == null) return null;
        String id = obj.optString("id", "inv_" + System.currentTimeMillis());
        String planName = obj.optString("planName", "Gold Investment Plan");
        String amount = obj.optString("amount", "₦0.00");
        String startDate = obj.optString("startDate", "");
        String maturityDate = obj.optString("maturityDate", "");
        long startTimestamp = obj.optLong("startTimestamp", System.currentTimeMillis());
        long maturityTimestamp = obj.optLong("maturityTimestamp", System.currentTimeMillis() + 86400000L * 7);
        String status = obj.optString("status", "Active");
        return new InvestmentModel(id, planName, amount, startDate, maturityDate, startTimestamp, maturityTimestamp, status);
    }
}
