package ng.com.goldmine.app;

/**
 * Constants for GoldMine Investment Platform.
 * Connects securely to the existing live cPanel PHP & MySQL hosted backend:
 * https://goalmindai.com.ng
 *
 * NOTE: The backend database, PHP logic, and payment credentials remain untouched.
 * The Android app connects directly via secure HTTPS.
 */
public final class Constants {

    private Constants() {
        // Prevent instantiation
    }

    // Base URL for the GoldMine Investment Platform
    public static final String BASE_URL = "https://goalmindai.com.ng/";

    // Verified Live PHP Portal Routes
    public static final String URL_LOGIN = BASE_URL + "login.php";
    public static final String URL_REGISTER = BASE_URL + "register.php";
    public static final String URL_DASHBOARD = BASE_URL + "dashboard.php";
    public static final String URL_PLANS = BASE_URL + "invest.php";
    public static final String URL_MY_INVESTMENTS = BASE_URL + "my-invest.php";
    public static final String URL_DEPOSIT = BASE_URL + "deposit.php";
    public static final String URL_WITHDRAW = BASE_URL + "withdraw.php";
    public static final String URL_TRANSACTIONS = BASE_URL + "transactions.php";
    public static final String URL_PROFILE = BASE_URL + "profile.php";
    public static final String URL_NOTIFICATIONS = BASE_URL + "notifications.php";
    public static final String URL_SETTINGS = BASE_URL + "settings.php";
    public static final String URL_LOGOUT = BASE_URL + "logout.php";
    public static final String URL_SUPPORT = BASE_URL + "customer-care.php";

    // Host domain verification
    public static final String HOST_DOMAIN = "goalmindai.com.ng";

    // Splash display timeout (milliseconds)
    public static final int SPLASH_DELAY_MS = 2000;

    // Back-press exit time threshold
    public static final long BACK_PRESS_INTERVAL = 2000L;
}
