# Add project specific ProGuard rules here.
# Keep WebView interfaces and models
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class ng.com.goldmine.app.** { *; }

-dontwarn android.webkit.**
-keepattributes JavascriptInterface
-keepattributes *Annotation*
