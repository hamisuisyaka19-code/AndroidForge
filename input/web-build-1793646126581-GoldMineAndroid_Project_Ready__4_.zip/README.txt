================================================================================
GOLDMINE INVESTMENT PLATFORM — ANDROID STUDIO PROJECT
================================================================================
Application Name: GoldMine Investment Platform
Package Name:     ng.com.goldmine.app
Version:          1.0.0
Min SDK:          24 (Android 7.0 Nougat)
Target SDK:       34 (Android 14)
Language:         Java
Theme:            Luxury Black and Gold (#0A0A0A & #D4AF37)
Live Portal:      https://goalmindai.com.ng
GitHub Repo:      goldmine-android-app
================================================================================

1. PROJECT OVERVIEW & ARCHITECTURE
--------------------------------------------------------------------------------
This is a production-ready, clean Android Studio project specifically tailored
for the live GoldMine Investment Platform hosted at:
https://goalmindai.com.ng

Verified Live PHP Platform Routes Configured:
- Homepage:         https://goalmindai.com.ng/
- Login:            https://goalmindai.com.ng/login.php
- Registration:     https://goalmindai.com.ng/register.php
- Dashboard:        https://goalmindai.com.ng/dashboard.php
- Investment Plans: https://goalmindai.com.ng/invest.php
- My Investments:   https://goalmindai.com.ng/my-invest.php
- Deposit:          https://goalmindai.com.ng/deposit.php
- Withdrawal:       https://goalmindai.com.ng/withdraw.php
- Transactions:     https://goalmindai.com.ng/transactions.php
- Profile:          https://goalmindai.com.ng/profile.php
- Notifications:    https://goalmindai.com.ng/notifications.php
- Settings:         https://goalmindai.com.ng/settings.php
- Logout:           https://goalmindai.com.ng/logout.php
- Customer Support: https://goalmindai.com.ng/customer-care.php

Key Features & Integrity Protections:
- Strict Backend & cPanel Safety: Zero modification of existing PHP files,
  MySQL databases, or cPanel settings. The Android app connects securely via
  strict HTTPS directly to the live server.
- Session Cookie Persistence: Preserves PHPSESSID and authentication session
  cookies across screens and app restarts with automatic CookieManager flushing.
- Anti-Accidental-Logout Back Navigation: OnBackPressedCallback inspects
  navigation history to avoid traversing through logout.php, keeping users
  logged in securely.
- Universal File & Receipt Chooser: Users can photograph deposit slips with
  camera or select JPG, PNG, WEBP, and PDF documents with FileProvider.
- Strict HTTPS Enforcement: SSL verification is strictly enforced without
  bypasses, fully compliant with Google Play Store Security Policies.
- Automatic Download Manager: Transaction receipts, account statements, and
  PDF certificates are automatically routed to Android's native DownloadManager.
- Offline Connection Handling: Automatic offline detection with a dedicated
  Black & Gold retry screen, wifi-loss listener, and pull-to-refresh.
- Android 12, 13 & 14+ Compliant:
  * Uses androidx.core:core-splashscreen API
  * Declares android:exported="true" on all launcher activities
  * Implements Android 13+ POST_NOTIFICATIONS runtime permissions
  * Strict HTTPS Network Security Config

2. HOW TO OPEN IN ANDROID STUDIO
--------------------------------------------------------------------------------
Step 1: Extract this ZIP file on your computer.
Step 2: Launch Android Studio (Electric Eel, Hedgehog, Iguana, Jellyfish, or newer).
Step 3: Select "Open" (or File -> Open).
Step 4: Navigate to the extracted folder containing "settings.gradle" and click OK.
Step 5: Allow Android Studio and Gradle to sync dependencies automatically.
Step 6: Select your connected Android phone or Emulator and click "Run" (Green Play button).

3. HOW TO GENERATE A SIGNED RELEASE APK / AAB (FOR GOOGLE PLAY STORE)
--------------------------------------------------------------------------------
1. In Android Studio, go to the top menu:
   Build -> Generate Signed Bundle / APK...
2. Choose:
   - "Android App Bundle (.aab)" for Google Play Store upload, or
   - "APK" for direct installation on phones.
3. Click "Next".
4. Select or create your Key store path (.jks file), enter passwords and key alias.
5. Select Build Variant: "release".
6. Check "V1 (Jar Signature)" and "V2 (Full APK Signature)".
7. Click "Finish". Your signed release package will be generated in app/release/.

4. HOW TO PUSH THIS PROJECT TO YOUR GITHUB REPOSITORY (goldmine-android-app)
--------------------------------------------------------------------------------
Run the following commands in your terminal inside the extracted project directory:

git init
git add .
git commit -m "Initial commit: Complete GoldMine Investment Platform Android Project"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/goldmine-android-app.git
git push -u origin main

(Replace YOUR_GITHUB_USERNAME with your actual GitHub username or repository URL)

================================================================================
Built with excellence for GoldMine Investment Platform.
All rights reserved.
================================================================================
