package com.goldmine.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.goldmine.app.data.model.InvestmentPlanDto
import com.goldmine.app.data.model.InvestmentRecordDto
import com.goldmine.app.data.repository.InvestmentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class UiState<out T> {
    object Idle : UiState<Nothing>()
    object Loading : UiState<Nothing>()
    data class Success<out T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

class InvestmentViewModel(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _plansState = MutableStateFlow<UiState<List<InvestmentPlanDto>>>(UiState.Idle)
    val plansState: StateFlow<UiState<List<InvestmentPlanDto>>> = _plansState.asStateFlow()

    private val _myInvestmentsState = MutableStateFlow<UiState<List<InvestmentRecordDto>>>(UiState.Idle)
    val myInvestmentsState: StateFlow<UiState<List<InvestmentRecordDto>>> = _myInvestmentsState.asStateFlow()

    private val _investActionState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val investActionState: StateFlow<UiState<String>> = _investActionState.asStateFlow()

    fun loadPlans() {
        viewModelScope.launch {
            _plansState.value = UiState.Loading
            try {
                val plans = repository.fetchInvestmentPlans()
                _plansState.value = UiState.Success(plans)
            } catch (e: Exception) {
                _plansState.value = UiState.Error(e.localizedMessage ?: "Failed to load plans")
            }
        }
    }

    fun loadMyInvestments() {
        viewModelScope.launch {
            _myInvestmentsState.value = UiState.Loading
            try {
                val list = repository.fetchMyInvestments()
                _myInvestmentsState.value = UiState.Success(list)
            } catch (e: Exception) {
                _myInvestmentsState.value = UiState.Error(e.localizedMessage ?: "Failed to fetch investments")
            }
        }
    }

    fun submitInvestment(planId: String, amount: Double) {
        viewModelScope.launch {
            _investActionState.value = UiState.Loading
            try {
                val result = repository.createInvestment(planId, amount)
                _investActionState.value = UiState.Success(result.message)
                loadMyInvestments() // Refresh list with new active countdown
            } catch (e: Exception) {
                _investActionState.value = UiState.Error(e.localizedMessage ?: "Investment failed")
            }
        }
    }
}
