package com.goldmine.app.data.api

import com.goldmine.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

/**
 * Communicates with the EXISTING GoldMine API backend.
 * All method signatures, parameters, and payloads match existing server structure.
 */
interface GoldMineApiService {

    // === AUTHENTICATION ===
    @POST("api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<ApiResponse<AuthData>>

    @POST("api/v1/auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): Response<ApiResponse<AuthData>>

    @GET("api/v1/auth/profile")
    suspend fun getUserProfile(): Response<ApiResponse<UserDto>>

    // === INVESTMENT PLANS & CREATION ===
    @GET("api/v1/plans")
    suspend fun getInvestmentPlans(): Response<ApiResponse<List<InvestmentPlanDto>>>

    @POST("api/v1/invest/create")
    suspend fun createInvestment(
        @Body request: CreateInvestmentRequest
    ): Response<ApiResponse<InvestmentResultDto>>

    @GET("api/v1/invest/my-investments")
    suspend fun getMyInvestments(): Response<ApiResponse<MyInvestmentsDto>>

    @POST("api/v1/invest/{id}/claim")
    suspend fun claimMaturedInvestment(
        @Path("id") investmentId: String
    ): Response<ApiResponse<ClaimResultDto>>

    // === WALLET & TRANSACTIONS ===
    @GET("api/v1/wallet/balance")
    suspend fun getWalletBalance(): Response<ApiResponse<WalletDto>>

    @POST("api/v1/wallet/deposit")
    suspend fun submitDeposit(
        @Body request: DepositRequest
    ): Response<ApiResponse<DepositResultDto>>

    @POST("api/v1/wallet/withdraw")
    suspend fun submitWithdrawal(
        @Body request: WithdrawalRequest
    ): Response<ApiResponse<WithdrawalResultDto>>

    @GET("api/v1/wallet/transactions")
    suspend fun getTransactionHistory(
        @Query("page") page: Int = 1,
        @Query("type") type: String? = null
    ): Response<ApiResponse<List<TransactionDto>>>

    // === SERVER SYNC ===
    @GET("api/v1/system/time")
    suspend fun getServerTime(): Response<ApiResponse<ServerTimeDto>>
}
