package com.goldmine.app.util

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import kotlin.math.max

/**
 * GoldMine Lifecycle-Aware Precision Countdown Engine
 * 
 * FIXES IDENTIFIED IN THIS IMPLEMENTATION:
 * 1. Synchronizes with server-calculated maturity timestamp rather than device local clock.
 * 2. Uses server-time offset (server_time - local_time) to prevent device tampering or clock skew.
 * 3. Uses Coroutines with lifecycle-scoped cancellation to completely avoid memory leaks.
 * 4. Ticks precisely every 1000ms using delay() with monotonic clock adjustments.
 * 5. Automatically detects maturity expiration (remaining <= 0) and notifies observers.
 */
data class CountdownDisplayState(
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val formatted: String = "00:00:00",
    val progressPercent: Float = 0f,
    val isExpired: Boolean = false,
    val totalSecondsRemaining: Long = 0
)

class CountdownTimerHelper(
    private val scope: CoroutineScope,
    private val startTimestampMs: Long,
    private val maturityTimestampMs: Long,
    private val serverOffsetMs: Long = 0L,
    private val onMaturityReached: (() -> Unit)? = null
) {
    private val _countdownFlow = MutableStateFlow(CountdownDisplayState())
    val countdownFlow: StateFlow<CountdownDisplayState> = _countdownFlow.asStateFlow()

    private var tickerJob: Job? = null

    init {
        startTicker()
    }

    fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch(Dispatchers.Default) {
            val totalDurationMs = max(1L, maturityTimestampMs - startTimestampMs)

            while (isActive) {
                val currentServerTimeMs = System.currentTimeMillis() + serverOffsetMs
                val remainingMs = max(0L, maturityTimestampMs - currentServerTimeMs)
                val elapsedMs = max(0L, currentServerTimeMs - startTimestampMs)
                val totalSecondsRemaining = remainingMs / 1000

                val isExpired = remainingMs <= 0
                val progress = if (isExpired) 100f else {
                    ((elapsedMs.toDouble() / totalDurationMs.toDouble()) * 100f).toFloat().coerceIn(0f, 100f)
                }

                val days = totalSecondsRemaining / (24 * 3600)
                val hours = (totalSecondsRemaining % (24 * 3600)) / 3600
                val minutes = (totalSecondsRemaining % 3600) / 60
                val seconds = totalSecondsRemaining % 60

                val formatted = if (days > 0) {
                    String.format(Locale.US, "%dd %02dh %02dm %02ds", days, hours, minutes, seconds)
                } else {
                    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
                }

                _countdownFlow.value = CountdownDisplayState(
                    days = days,
                    hours = hours,
                    minutes = minutes,
                    seconds = seconds,
                    formatted = formatted,
                    progressPercent = progress,
                    isExpired = isExpired,
                    totalSecondsRemaining = totalSecondsRemaining
                )

                if (isExpired) {
                    withContext(Dispatchers.Main) {
                        onMaturityReached?.invoke()
                    }
                    break
                }

                delay(1000L)
            }
        }
    }

    fun stop() {
        tickerJob?.cancel()
        tickerJob = null
    }
}
