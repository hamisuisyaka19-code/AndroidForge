# GoldMine Native Android Application

Welcome to the **GoldMine** Android Studio Project. This application is architected specifically for your existing GoldMine backend API with zero modifications required on your server.

## Features
- **100% Native Kotlin**: Built with modern MVVM, Coroutines, StateFlow, and Retrofit.
- **Precision Countdown**: Resolves timer freezing, static values, and memory leaks by using server timestamp synchronization and coroutine scopes.
- **Luxury Black & Gold Theme**: Handcrafted Material 3 design with metallic gold cards and polished typography.
- **Complete Screen Implementation**: Splash, Login, Register, Home, Plans, Invest Form, Active Countdown, Wallet, Deposit, Withdrawal, History, Profile.

## How to Import & Run in Android Studio
1. Unzip the project folder.
2. In Android Studio, select **File > Open...** and navigate to the root directory.
3. Allow Gradle to sync dependencies.
4. Open `app/build.gradle.kts` and update `BASE_API_URL` with your live HTTPS API domain.
5. Build and run on your Android device or emulator!
