package com.goldmine.investment.ui.invest

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.main.MainActivity
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class InvestActivity : AppCompatActivity() {

    private val repository = GoldMineRepository()

    private var planId: Int = 1
    private var planName: String = "Starter Plan"
    private var minAmount: Double = 1000.0
    private var maxAmount: Double = 50000.0
    private var roiPercentage: Double = 35.0
    private var durationDays: Int = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invest)

        planId = intent.getIntExtra(EXTRA_PLAN_ID, 1)
        planName = intent.getStringExtra(EXTRA_PLAN_NAME) ?: "Starter Plan"
        minAmount = intent.getDoubleExtra(EXTRA_MIN_AMOUNT, 1000.0)
        maxAmount = intent.getDoubleExtra(EXTRA_MAX_AMOUNT, 50000.0)
        roiPercentage = intent.getDoubleExtra(EXTRA_ROI_PERCENTAGE, 35.0)
        durationDays = intent.getIntExtra(EXTRA_DURATION_DAYS, 3)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val tvPlanName = findViewById<TextView>(R.id.tvPlanName)
        val tvProfitBadge = findViewById<TextView>(R.id.tvProfitBadge)
        val tvPlanDesc = findViewById<TextView>(R.id.tvPlanDesc)
        val tvMinAmount = findViewById<TextView>(R.id.tvMinAmount)
        val tvDuration = findViewById<TextView>(R.id.tvDuration)
        val tvRoiRate = findViewById<TextView>(R.id.tvRoiRate)
        val etInvestAmount = findViewById<EditText>(R.id.etInvestAmount)
        val tvCalculatedProfit = findViewById<TextView>(R.id.tvCalculatedProfit)
        val tvCalculatedTotal = findViewById<TextView>(R.id.tvCalculatedTotal)
        val btnSubmit = findViewById<Button>(R.id.btnSubmitInvest)

        btnBack.setOnClickListener { finish() }

        tvPlanName.text = planName
        tvProfitBadge.text = "${roiPercentage.toInt()}% Profit"
        tvPlanDesc.text = "Invest and earn ${roiPercentage.toInt()}% profit in $durationDays days."
        tvMinAmount.text = CurrencyFormatter.formatClean(minAmount)
        tvDuration.text = "$durationDays Days"
        tvRoiRate.text = "${roiPercentage.toInt()}% (${CurrencyFormatter.formatClean(minAmount * (roiPercentage / 100.0))} per ${CurrencyFormatter.formatClean(minAmount)})"

        etInvestAmount.setText(minAmount.toInt().toString())

        fun updateCalculations() {
            val inputStr = etInvestAmount.text.toString().trim()
            val amount = inputStr.toDoubleOrNull() ?: 0.0
            val profit = amount * (roiPercentage / 100.0)
            val total = amount + profit

            tvCalculatedProfit.text = "+${CurrencyFormatter.format(profit)}"
            tvCalculatedTotal.text = CurrencyFormatter.format(total)
        }

        updateCalculations()

        etInvestAmount.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateCalculations()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnSubmit.setOnClickListener {
            val inputStr = etInvestAmount.text.toString().trim()
            val amount = inputStr.toDoubleOrNull()

            if (amount == null || amount < minAmount) {
                Toast.makeText(this, "Minimum investment for $planName is ${CurrencyFormatter.formatClean(minAmount)}", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            btnSubmit.isEnabled = false
            btnSubmit.text = "Processing..."

            lifecycleScope.launch {
                repository.invest(planId, amount).onSuccess { data ->
                    val ref = data["reference_code"] ?: "INV-${System.currentTimeMillis()}"
                    AlertDialog.Builder(this@InvestActivity)
                        .setTitle("Investment Successful! 🎉")
                        .setMessage("Your investment of ${CurrencyFormatter.format(amount)} in $planName has been activated.\n\nReference: $ref\nMaturity Duration: $durationDays Days")
                        .setPositiveButton("View in Countdown") { _, _ ->
                            val intent = Intent(this@InvestActivity, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                putExtra(MainActivity.EXTRA_NAV_TAB, R.id.nav_my_invest)
                            }
                            startActivity(intent)
                            finish()
                        }
                        .setCancelable(false)
                        .show()
                }.onFailure { err ->
                    btnSubmit.isEnabled = true
                    btnSubmit.text = "Invest Now"
                    Toast.makeText(this@InvestActivity, err.message ?: "Investment failed. Please check wallet balance.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    companion object {
        const val EXTRA_PLAN_ID = "extra_plan_id"
        const val EXTRA_PLAN_NAME = "extra_plan_name"
        const val EXTRA_MIN_AMOUNT = "extra_min_amount"
        const val EXTRA_MAX_AMOUNT = "extra_max_amount"
        const val EXTRA_ROI_PERCENTAGE = "extra_roi_percentage"
        const val EXTRA_DURATION_DAYS = "extra_duration_days"
    }
}
