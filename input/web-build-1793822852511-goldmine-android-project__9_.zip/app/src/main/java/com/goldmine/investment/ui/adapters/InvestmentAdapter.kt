package com.goldmine.investment.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.InvestmentDto
import com.goldmine.investment.util.CountdownHelper
import com.goldmine.investment.util.CurrencyFormatter

class InvestmentAdapter : RecyclerView.Adapter<InvestmentAdapter.InvViewHolder>() {

    data class ItemHolder(
        val dto: InvestmentDto,
        val targetEndTimeMillis: Long,
        val totalDurationSeconds: Long
    )

    private var items = mutableListOf<ItemHolder>()

    fun submitList(list: List<InvestmentDto>) {
        val now = System.currentTimeMillis()
        items = list.map { inv ->
            val totalSec = if (inv.durationDays > 0) inv.durationDays * 86400L else 86400L
            ItemHolder(
                dto = inv,
                targetEndTimeMillis = now + (inv.secondsRemaining * 1000L),
                totalDurationSeconds = totalSec
            )
        }.toMutableList()
        notifyDataSetChanged()
    }

    /**
     * Active 1-second ticker method called periodically by parent coroutine.
     * Updates views smoothly without resetting scroll or re-binding entire layout.
     */
    fun tick() {
        notifyItemRangeChanged(0, items.size, PAYLOAD_TICK)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_investment, parent, false)
        return InvViewHolder(view)
    }

    override fun onBindViewHolder(holder: InvViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_TICK)) {
            holder.updateTicker(items[position])
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    override fun onBindViewHolder(holder: InvViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class InvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvPlanName = itemView.findViewById<TextView>(R.id.tvInvPlanName)
        private val tvAmount = itemView.findViewById<TextView>(R.id.tvInvAmount)
        private val tvProfit = itemView.findViewById<TextView>(R.id.tvInvProfit)
        private val tvCountdown = itemView.findViewById<TextView>(R.id.tvInvCountdown)
        private val pbCountdown = itemView.findViewById<ProgressBar>(R.id.pbCountdown)

        fun bind(holder: ItemHolder) {
            val item = holder.dto
            tvPlanName.text = item.planName
            tvAmount.text = CurrencyFormatter.format(item.amount)
            tvProfit.text = "Profit: ${CurrencyFormatter.format(item.profitAmount)} (${item.roiPercentage.toInt()}%)"
            updateTicker(holder)
        }

        fun updateTicker(holder: ItemHolder) {
            val now = System.currentTimeMillis()
            val remainingMillis = holder.targetEndTimeMillis - now
            val remainingSec = if (remainingMillis > 0) remainingMillis / 1000L else 0L

            if (remainingSec <= 0) {
                tvCountdown.text = "Matured & Completed ✓"
                tvCountdown.setTextColor(itemView.context.getColor(R.color.green_profit))
                pbCountdown.progress = 100
            } else {
                tvCountdown.text = "Time Left: " + CountdownHelper.formatDynamic(remainingSec)
                tvCountdown.setTextColor(0xFF2563EB.toInt())

                val elapsedSec = (holder.totalDurationSeconds - remainingSec).coerceAtLeast(0)
                val percent = ((elapsedSec.toDouble() / holder.totalDurationSeconds.toDouble()) * 100).toInt()
                pbCountdown.progress = percent.coerceIn(5, 95)
            }
        }
    }

    companion object {
        private const val PAYLOAD_TICK = "payload_tick"
    }
}
