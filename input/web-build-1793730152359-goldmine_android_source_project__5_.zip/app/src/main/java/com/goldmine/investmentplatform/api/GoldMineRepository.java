package com.goldmine.investmentplatform.api;

import android.os.Handler;
import android.os.Looper;
import com.goldmine.investmentplatform.GoldMineApp;
import com.goldmine.investmentplatform.model.Investment;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.model.Transaction;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.util.Constants;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.*;

public class GoldMineRepository {
    private static GoldMineRepository instance;
    private final OkHttpClient client;
    private final SessionManager sessionManager;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Gson gson = new Gson();

    public interface AuthCallback {
        void onSuccess(User user);
        void onError(String message);
    }

    public interface ActionCallback {
        void onSuccess(String message);
        void onError(String message);
    }

    public interface DashboardCallback {
        void onSuccess(User user, int activeInvestCount, int completedInvestCount, List<Transaction> recentTransactions);
        void onError(String message);
    }

    public interface InvestmentsCallback {
        void onSuccess(List<Investment> list);
        void onError(String message);
    }

    public interface PlansCallback {
        void onSuccess(List<InvestmentPlan> plans);
        void onError(String message);
    }

    public interface TransactionsCallback {
        void onSuccess(List<Transaction> transactions);
        void onError(String message);
    }

    private GoldMineRepository() {
        this.client = ApiClient.getOkHttpClient();
        this.sessionManager = new SessionManager(GoldMineApp.getInstance());
    }

    public static synchronized GoldMineRepository getInstance() {
        if (instance == null) {
            instance = new GoldMineRepository();
        }
        return instance;
    }

    // -------------------------------------------------------------
    // 1. AUTHENTICATION (Login with Dual Engine)
    // -------------------------------------------------------------
    public void login(String loginInput, String password, AuthCallback callback) {
        // Attempt 1: Direct JSON API endpoint (if uploaded to cPanel)
        RequestBody formBody = new FormBody.Builder()
                .add("login_input", loginInput)
                .add("password", password)
                .build();

        Request apiRequest = new Request.Builder()
                .url(Constants.API_BASE_URL + "index.php?action=login")
                .post(formBody)
                .build();

        client.newCall(apiRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Network failure or 404 on API endpoint -> fallback to native website login
                loginViaNativeWebsite(loginInput, password, callback);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String bodyStr = response.body().string();
                    try {
                        JsonObject json = gson.fromJson(bodyStr, JsonObject.class);
                        if (json != null && json.has("success") && json.get("success").getAsBoolean()) {
                            JsonObject data = json.getAsJsonObject("data");
                            User user = gson.fromJson(data.get("user"), User.class);
                            String token = data.has("token") ? data.get("token").getAsString() : String.valueOf(user.getId());
                            sessionManager.saveUserSession(user, token);
                            postSuccess(callback, user);
                            return;
                        }
                    } catch (Exception ignored) {
                        // Response was HTML (e.g. 404 or web redirect), fallback to native website
                    }
                }
                // Fallback to native website flow
                loginViaNativeWebsite(loginInput, password, callback);
            }
        });
    }

    private void loginViaNativeWebsite(String loginInput, String password, AuthCallback callback) {
        // Step 1: GET /login.php to obtain CSRF token and PHPSESSID cookie
        Request getLoginReq = new Request.Builder()
                .url(Constants.BASE_URL + "login.php")
                .get()
                .build();

        client.newCall(getLoginReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                postError(callback, "Connection failed: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful() || response.body() == null) {
                    postError(callback, "Unable to reach GoldMine server (HTTP " + response.code() + ")");
                    return;
                }

                String html = response.body().string();
                String csrfToken = extractCsrfToken(html);

                // Step 2: POST /login.php with csrf_token, login_input, and password
                RequestBody postBody = new FormBody.Builder()
                        .add("csrf_token", csrfToken)
                        .add("login_input", loginInput)
                        .add("password", password)
                        .build();

                Request postLoginReq = new Request.Builder()
                        .url(Constants.BASE_URL + "login.php")
                        .post(postBody)
                        .build();

                client.newCall(postLoginReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        postError(callback, "Login error: " + e.getMessage());
                    }

                    @Override
                    public void onResponse(Call call, Response loginResp) throws IOException {
                        String postRespHtml = loginResp.body() != null ? loginResp.body().string() : "";

                        // Check if login failed
                        if (postRespHtml.contains("Invalid email/phone or password")) {
                            postError(callback, "Invalid email/phone or password. Please verify your credentials.");
                            return;
                        }
                        if (postRespHtml.contains("suspended")) {
                            postError(callback, "Your account has been suspended. Please contact support.");
                            return;
                        }
                        if (postRespHtml.contains("Security token mismatch")) {
                            // Retry once with refreshed token
                            postError(callback, "Session security mismatch. Please try again.");
                            return;
                        }

                        // Check if successfully authenticated:
                        // Either we got redirected to dashboard.php, or we fetch /dashboard.php now
                        fetchDashboardUser(callback, loginInput);
                    }
                });
            }
        });
    }

    private void fetchDashboardUser(AuthCallback callback, String defaultIdentifier) {
        Request dashReq = new Request.Builder()
                .url(Constants.BASE_URL + "dashboard.php")
                .get()
                .build();

        client.newCall(dashReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                postError(callback, "Failed to load account profile: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";

                // If redirected back to login.php, authentication failed
                if (html.contains("Login to Your Account") || html.contains("<title>Login")) {
                    postError(callback, "Invalid email/phone or password.");
                    return;
                }

                User user = parseUserFromDashboardHtml(html, defaultIdentifier);
                String phpSession = ApiClient.getCookieJar(GoldMineApp.getInstance()).getPhpSessionId();
                sessionManager.saveUserSession(user, phpSession);
                postSuccess(callback, user);
            }
        });
    }

    // -------------------------------------------------------------
    // 2. REGISTRATION (Dual Engine)
    // -------------------------------------------------------------
    public void register(String fullName, String email, String phone, String password, AuthCallback callback) {
        // Step 1: GET /register.php to get CSRF token
        Request getReq = new Request.Builder()
                .url(Constants.BASE_URL + "register.php")
                .get()
                .build();

        client.newCall(getReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                postError(callback, "Connection failed: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                String csrfToken = extractCsrfToken(html);

                RequestBody body = new FormBody.Builder()
                        .add("csrf_token", csrfToken)
                        .add("full_name", fullName)
                        .add("email", email)
                        .add("phone", phone)
                        .add("password", password)
                        .add("agree", "1")
                        .build();

                Request postReq = new Request.Builder()
                        .url(Constants.BASE_URL + "register.php")
                        .post(body)
                        .build();

                client.newCall(postReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        postError(callback, "Registration error: " + e.getMessage());
                    }

                    @Override
                    public void onResponse(Call call, Response regResp) throws IOException {
                        String respHtml = regResp.body() != null ? regResp.body().string() : "";

                        if (respHtml.contains("already registered")) {
                            postError(callback, "Email address or phone number is already registered.");
                            return;
                        }

                        // Auto-login after registration
                        login(email, password, callback);
                    }
                });
            }
        });
    }

    // -------------------------------------------------------------
    // 3. DASHBOARD DATA & DYNAMIC PROFIT SYNCHRONIZATION
    // -------------------------------------------------------------
    public void getDashboard(DashboardCallback callback) {
        int userId = sessionManager.getUserId();

        if (userId > 0) {
            ApiClient.getService().getDashboard(userId).enqueue(new retrofit2.Callback<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>>() {
                @Override
                public void onResponse(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, retrofit2.Response<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                        JsonObject data = response.body().getData();
                        if (data != null && data.has("user")) {
                            User user = gson.fromJson(data.get("user"), User.class);
                            int activeCount = data.has("active_investments_count") ? data.get("active_investments_count").getAsInt() : 0;
                            int completedCount = data.has("completed_investments_count") ? data.get("completed_investments_count").getAsInt() : 0;

                            List<Transaction> recentTx = new ArrayList<>();
                            if (data.has("recent_transactions") && data.get("recent_transactions").isJsonArray()) {
                                for (JsonElement el : data.getAsJsonArray("recent_transactions")) {
                                    recentTx.add(gson.fromJson(el, Transaction.class));
                                }
                            }

                            // Verify and synchronize Total Profit from actual investments
                            enrichDashboardWithActualInvestments(user, activeCount, completedCount, recentTx, callback);
                            return;
                        }
                    }
                    fetchDashboardFromHtml(callback);
                }

                @Override
                public void onFailure(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, Throwable t) {
                    fetchDashboardFromHtml(callback);
                }
            });
        } else {
            fetchDashboardFromHtml(callback);
        }
    }

    private void fetchDashboardFromHtml(DashboardCallback callback) {
        Request req = new Request.Builder()
                .url(Constants.BASE_URL + "dashboard.php")
                .get()
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";

                if (html.contains("Login to Your Account")) {
                    mainHandler.post(() -> callback.onError("Session expired. Please log in again."));
                    return;
                }

                User user = parseUserFromDashboardHtml(html, sessionManager.getUserEmail());
                int activeCount = extractRegexInt(html, "Active Invest.*?<p[^>]*>(\\d+)</p>", 0);
                int completedCount = extractRegexInt(html, "Completed.*?<p[^>]*>(\\d+)</p>", 0);
                List<Transaction> recentTx = parseDashboardTransactionsHtml(html);

                enrichDashboardWithActualInvestments(user, activeCount, completedCount, recentTx, callback);
            }
        });
    }

    /**
     * Fetches the user's actual investment records from my-invest.php and counting-date.php,
     * deduplicates by reference_code so no investment is ever counted twice, transitions any
     * newly matured investments, and computes accurate Total Invested and Total Profit (35% ROI).
     */
    private void enrichDashboardWithActualInvestments(User user, int initialActiveCount, int initialCompletedCount, List<Transaction> recentTx, DashboardCallback callback) {
        Request myInvReq = new Request.Builder()
                .url(Constants.BASE_URL + "my-invest.php")
                .get()
                .build();

        client.newCall(myInvReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                finalizeDashboardTotals(user, new ArrayList<>(), initialActiveCount, initialCompletedCount, recentTx, callback);
            }

            @Override
            public void onResponse(Call call, Response myInvResp) throws IOException {
                String myInvHtml = myInvResp.body() != null ? myInvResp.body().string() : "";
                long serverNow = extractServerTimeSeconds(myInvResp, myInvHtml);
                List<Investment> myInvList = parseMyInvestmentsHtml(myInvHtml, serverNow);

                Request cdReq = new Request.Builder()
                        .url(Constants.BASE_URL + "counting-date.php")
                        .get()
                        .build();

                client.newCall(cdReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        finalizeDashboardTotals(user, myInvList, initialActiveCount, initialCompletedCount, recentTx, callback);
                    }

                    @Override
                    public void onResponse(Call call, Response cdResp) throws IOException {
                        String cdHtml = cdResp.body() != null ? cdResp.body().string() : "";
                        long cdServerNow = extractServerTimeSeconds(cdResp, cdHtml);
                        List<Investment> cdList = parseCountingDateHtml(cdHtml, cdServerNow);

                        java.util.Map<String, Investment> mergedMap = new java.util.LinkedHashMap<>();
                        for (Investment inv : myInvList) {
                            String key = (inv.getReferenceCode() != null && !inv.getReferenceCode().isEmpty())
                                    ? inv.getReferenceCode()
                                    : ("INV-" + inv.getId() + "-" + inv.getAmount());
                            mergedMap.put(key, inv);
                        }
                        for (Investment cdInv : cdList) {
                            String key = (cdInv.getReferenceCode() != null && !cdInv.getReferenceCode().isEmpty())
                                    ? cdInv.getReferenceCode()
                                    : ("CD-" + cdInv.getId() + "-" + cdInv.getAmount());
                            if (mergedMap.containsKey(key)) {
                                Investment existing = mergedMap.get(key);
                                if (existing != null) {
                                    existing.setMaturityDate(cdInv.getMaturityDate());
                                    existing.setMaturityTimestamp(cdInv.getMaturityTimestamp());
                                    existing.setSecondsRemaining(cdInv.getSecondsRemaining());
                                    existing.setProgressPercent(cdInv.getProgressPercent());
                                    if (cdInv.getSecondsRemaining() <= 0 && "active".equalsIgnoreCase(existing.getStatus())) {
                                        existing.setStatus("completed");
                                    }
                                }
                            } else {
                                mergedMap.put(key, cdInv);
                            }
                        }

                        finalizeDashboardTotals(user, new ArrayList<>(mergedMap.values()), initialActiveCount, initialCompletedCount, recentTx, callback);
                    }
                });
            }
        });
    }

    private void finalizeDashboardTotals(User user, List<Investment> deduplicatedInvestments, int fallbackActiveCount, int fallbackCompletedCount, List<Transaction> recentTx, DashboardCallback callback) {
        double computedInvested = 0.0;
        double computedProfit = 0.0;
        int computedActive = 0;
        int computedCompleted = 0;

        java.util.Set<String> seenRefs = new java.util.HashSet<>();
        for (Investment inv : deduplicatedInvestments) {
            if (inv == null || inv.getAmount() <= 0) continue;
            String refKey = (inv.getReferenceCode() != null && !inv.getReferenceCode().isEmpty())
                    ? inv.getReferenceCode().trim()
                    : (inv.getPlanName() + "_" + inv.getAmount() + "_" + inv.getId());
            if (seenRefs.contains(refKey)) {
                continue; // Never count the same investment twice
            }
            seenRefs.add(refKey);

            String status = inv.getStatus() != null ? inv.getStatus().trim().toLowerCase() : "";
            boolean isCompleted = "completed".equals(status) || "matured".equals(status)
                    || ("active".equals(status) && inv.getMaturityTimestamp() > 0 && inv.getSecondsRemaining() <= 0);
            boolean isActive = ("active".equals(status) || "approved".equals(status)) && !isCompleted;

            if (isCompleted || isActive) {
                double capital = inv.getAmount();
                // Earned profit = 35% of capital (expected_return - capital), never invested capital
                double profit = com.goldmine.investmentplatform.util.TimeUtils.calculateProfit(capital);
                computedInvested += capital;
                computedProfit += profit;

                if (isCompleted) {
                    computedCompleted++;
                } else {
                    computedActive++;
                }
            }
        }

        int finalActiveCount = !deduplicatedInvestments.isEmpty() ? computedActive : fallbackActiveCount;
        int finalCompletedCount = !deduplicatedInvestments.isEmpty() ? computedCompleted : fallbackCompletedCount;

        if (computedInvested > 0) {
            user.setTotalInvested(computedInvested);
        }
        if (computedProfit > 0) {
            user.setTotalProfit(computedProfit);
        } else if (user.getTotalProfit() <= 0 && user.getTotalInvested() > 0 && (finalActiveCount > 0 || finalCompletedCount > 0)) {
            // Fallback when investment capital is recorded on the user row with active/completed plans
            user.setTotalProfit(com.goldmine.investmentplatform.util.TimeUtils.calculateProfit(user.getTotalInvested()));
        }

        sessionManager.updateUserFinancials(user.getBalance(), user.getTotalInvested(), user.getTotalProfit());

        mainHandler.post(() -> callback.onSuccess(user, finalActiveCount, finalCompletedCount, recentTx));
    }

    // -------------------------------------------------------------
    // 4. INVESTMENT PACKAGES (Plans)
    // -------------------------------------------------------------
    public void getPlans(PlansCallback callback) {
        // Return the 4 official GoldMine packages (35% ROI across all packages)
        List<InvestmentPlan> list = new ArrayList<>();
        list.add(createPlan(1, "Starter Gold", "starter-gold", 1000, 4999, 35, 3, "Example: ₦1,000 → ₦350 profit → ₦1,350 total return (3 Days)."));
        list.add(createPlan(2, "Classic Gold", "classic-gold", 5000, 9999, 35, 7, "Example: ₦5,000 → ₦1,750 profit → ₦6,750 total return (7 Days)."));
        list.add(createPlan(3, "Premium Gold", "premium-gold", 10000, 49999, 35, 15, "Example: ₦10,000 → ₦3,500 profit → ₦13,500 total return (15 Days)."));
        list.add(createPlan(4, "VIP Gold", "vip-gold", 50000, 10000000, 35, 30, "Example: ₦50,000 → ₦17,500 profit → ₦67,500 total return (30 Days)."));
        mainHandler.post(() -> callback.onSuccess(list));
    }

    private InvestmentPlan createPlan(int id, String name, String slug, double min, double max, double roi, int duration, String desc) {
        JsonObject obj = new JsonObject();
        obj.addProperty("id", id);
        obj.addProperty("name", name);
        obj.addProperty("slug", slug);
        obj.addProperty("min_amount", min);
        obj.addProperty("max_amount", max);
        obj.addProperty("roi_percentage", roi);
        obj.addProperty("duration_days", duration);
        obj.addProperty("description", desc);
        obj.addProperty("status", "active");
        return gson.fromJson(obj, InvestmentPlan.class);
    }

    // -------------------------------------------------------------
    // 5. SUBMIT INVESTMENT
    // -------------------------------------------------------------
    public void submitInvestment(int planId, double amount, ActionCallback callback) {
        // Step 1: GET /invest.php to extract CSRF token
        Request getReq = new Request.Builder()
                .url(Constants.BASE_URL + "invest.php")
                .get()
                .build();

        client.newCall(getReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                String csrfToken = extractCsrfToken(html);

                RequestBody body = new FormBody.Builder()
                        .add("csrf_token", csrfToken)
                        .add("plan_id", String.valueOf(planId))
                        .add("amount", String.valueOf(amount))
                        .build();

                Request postReq = new Request.Builder()
                        .url(Constants.BASE_URL + "invest.php")
                        .post(body)
                        .build();

                client.newCall(postReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        mainHandler.post(() -> callback.onError("Submission error: " + e.getMessage()));
                    }

                    @Override
                    public void onResponse(Call call, Response postResp) throws IOException {
                        String respHtml = postResp.body() != null ? postResp.body().string() : "";
                        if (respHtml.contains("Insufficient balance")) {
                            mainHandler.post(() -> callback.onError("Insufficient balance. Please deposit funds first."));
                            return;
                        }
                        mainHandler.post(() -> callback.onSuccess("Investment order submitted successfully! Awaiting administrator review."));
                    }
                });
            }
        });
    }

    // -------------------------------------------------------------
    // 6. COUNTING DATE (Live Active Countdowns)
    // -------------------------------------------------------------
    public void getCountingDate(InvestmentsCallback callback) {
        int userId = sessionManager.getUserId();

        // Attempt 1: Try JSON API endpoint first
        ApiClient.getService().getCountingDate(userId).enqueue(new retrofit2.Callback<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, retrofit2.Response<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("countdowns")) {
                        long serverTs = data.has("server_timestamp") ? data.get("server_timestamp").getAsLong() : (System.currentTimeMillis() / 1000L);
                        JsonArray arr = data.getAsJsonArray("countdowns");
                        List<Investment> list = new ArrayList<>();
                        for (JsonElement el : arr) {
                            Investment inv = gson.fromJson(el, Investment.class);
                            normalizeAndSyncInvestment(inv, serverTs);
                            list.add(inv);
                        }
                        mainHandler.post(() -> callback.onSuccess(list));
                        return;
                    }
                }
                fetchCountingDateFromHtml(callback);
            }

            @Override
            public void onFailure(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, Throwable t) {
                fetchCountingDateFromHtml(callback);
            }
        });
    }

    private void fetchCountingDateFromHtml(InvestmentsCallback callback) {
        Request req = new Request.Builder()
                .url(Constants.BASE_URL + "counting-date.php")
                .get()
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Failed to load counting date: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                long serverEpochSeconds = extractServerTimeSeconds(response, html);
                List<Investment> list = parseCountingDateHtml(html, serverEpochSeconds);
                mainHandler.post(() -> callback.onSuccess(list));
            }
        });
    }

    // -------------------------------------------------------------
    // 7. MY INVESTMENTS
    // -------------------------------------------------------------
    public void getMyInvestments(String filter, InvestmentsCallback callback) {
        int userId = sessionManager.getUserId();

        // Attempt 1: Try JSON API endpoint first
        ApiClient.getService().getMyInvestments(userId, filter).enqueue(new retrofit2.Callback<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, retrofit2.Response<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("investments")) {
                        long serverTs = System.currentTimeMillis() / 1000L;
                        JsonArray arr = data.getAsJsonArray("investments");
                        List<Investment> list = new ArrayList<>();
                        for (JsonElement el : arr) {
                            Investment inv = gson.fromJson(el, Investment.class);
                            normalizeAndSyncInvestment(inv, serverTs);
                            list.add(inv);
                        }
                        mainHandler.post(() -> callback.onSuccess(list));
                        return;
                    }
                }
                fetchMyInvestmentsFromHtml(filter, callback);
            }

            @Override
            public void onFailure(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, Throwable t) {
                fetchMyInvestmentsFromHtml(filter, callback);
            }
        });
    }

    private void fetchMyInvestmentsFromHtml(String filter, InvestmentsCallback callback) {
        String url = Constants.BASE_URL + "my-invest.php" + (filter.isEmpty() || "all".equals(filter) ? "" : "?filter=" + filter);
        Request req = new Request.Builder()
                .url(url)
                .get()
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Failed to load investments: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                long serverEpochSeconds = extractServerTimeSeconds(response, html);
                List<Investment> list = parseMyInvestmentsHtml(html, serverEpochSeconds);
                mainHandler.post(() -> callback.onSuccess(list));
            }
        });
    }

    // -------------------------------------------------------------
    // 8. DEPOSIT
    // -------------------------------------------------------------
    public void submitDeposit(double amount, ActionCallback callback) {
        Request getReq = new Request.Builder()
                .url(Constants.BASE_URL + "deposit.php")
                .get()
                .build();

        client.newCall(getReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                String csrfToken = extractCsrfToken(html);

                RequestBody body = new FormBody.Builder()
                        .add("csrf_token", csrfToken)
                        .add("amount", String.valueOf(amount))
                        .build();

                Request postReq = new Request.Builder()
                        .url(Constants.BASE_URL + "deposit.php")
                        .post(body)
                        .build();

                client.newCall(postReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        mainHandler.post(() -> callback.onError("Deposit error: " + e.getMessage()));
                    }

                    @Override
                    public void onResponse(Call call, Response postResp) throws IOException {
                        mainHandler.post(() -> callback.onSuccess("Deposit order submitted! Once verified by administrator, your balance will be credited."));
                    }
                });
            }
        });
    }

    // -------------------------------------------------------------
    // 9. WITHDRAWAL
    // -------------------------------------------------------------
    public void submitWithdrawal(double amount, String bank, String accountNum, String accountName, ActionCallback callback) {
        Request getReq = new Request.Builder()
                .url(Constants.BASE_URL + "withdraw.php")
                .get()
                .build();

        client.newCall(getReq).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String html = response.body() != null ? response.body().string() : "";
                String csrfToken = extractCsrfToken(html);

                RequestBody body = new FormBody.Builder()
                        .add("csrf_token", csrfToken)
                        .add("amount", String.valueOf(amount))
                        .add("bank_name", bank)
                        .add("account_number", accountNum)
                        .add("account_name", accountName)
                        .build();

                Request postReq = new Request.Builder()
                        .url(Constants.BASE_URL + "withdraw.php")
                        .post(body)
                        .build();

                client.newCall(postReq).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        mainHandler.post(() -> callback.onError("Withdrawal error: " + e.getMessage()));
                    }

                    @Override
                    public void onResponse(Call call, Response postResp) throws IOException {
                        String respHtml = postResp.body() != null ? postResp.body().string() : "";
                        if (respHtml.contains("Insufficient balance")) {
                            mainHandler.post(() -> callback.onError("Insufficient balance for withdrawal."));
                            return;
                        }
                        if (respHtml.contains("Minimum withdrawal amount")) {
                            mainHandler.post(() -> callback.onError("Minimum withdrawal amount is ₦2,000.00."));
                            return;
                        }
                        mainHandler.post(() -> callback.onSuccess("Withdrawal request submitted! It will be reviewed and transferred to your bank account."));
                    }
                });
            }
        });
    }

    // -------------------------------------------------------------
    // 10. TRANSACTIONS
    // -------------------------------------------------------------
    public void getTransactions(String type, TransactionsCallback callback) {
        int userId = sessionManager.getUserId();
        ApiClient.getService().getTransactions(userId, type).enqueue(new retrofit2.Callback<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, retrofit2.Response<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("transactions")) {
                        JsonArray arr = data.getAsJsonArray("transactions");
                        List<Transaction> list = new ArrayList<>();
                        for (JsonElement el : arr) {
                            list.add(gson.fromJson(el, Transaction.class));
                        }
                        mainHandler.post(() -> callback.onSuccess(list));
                        return;
                    }
                }
                mainHandler.post(() -> callback.onSuccess(new ArrayList<>()));
            }

            @Override
            public void onFailure(retrofit2.Call<com.goldmine.investmentplatform.model.ApiResponse<JsonObject>> call, Throwable t) {
                mainHandler.post(() -> callback.onSuccess(new ArrayList<>()));
            }
        });
    }

    // -------------------------------------------------------------
    // HTML PARSING & TIMESTAMP SYNCHRONIZATION UTILITIES
    // -------------------------------------------------------------
    private String extractCsrfToken(String html) {
        Pattern pattern = Pattern.compile("name=[\"']csrf_token[\"']\\s+value=[\"']([^\"']+)[\"']");
        Matcher matcher = pattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    private long extractServerTimeSeconds(Response response, String html) {
        try {
            // 1. Check if page embeds data-server-time or server_timestamp
            Pattern p = Pattern.compile("data-server-time=[\"'](\\d+)[\"']");
            Matcher m = p.matcher(html);
            if (m.find()) {
                return Long.parseLong(m.group(1));
            }
            // 2. Use HTTP Date header from production server
            java.util.Date httpDate = response.headers().getDate("Date");
            if (httpDate != null) {
                return httpDate.getTime() / 1000L;
            }
        } catch (Exception ignored) {}
        return System.currentTimeMillis() / 1000L;
    }

    /**
     * Enforces strict synchronization between package duration, creation timestamp,
     * maturity timestamp, and live countdown:
     * maturity_timestamp = investment_created_timestamp + (package_duration_days * 86400)
     * remaining_time = maturity_timestamp - current_server_time
     */
    private void normalizeAndSyncInvestment(Investment inv, long serverNowSeconds) {
        int canonicalDays = com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalDurationDays(
                inv.getPlanName(), inv.getDurationDays()
        );
        inv.setDurationDays(canonicalDays);
        long packageDurationSeconds = (long) canonicalDays * 86400L;

        // Enforce dynamic ROI rule: 50% for exactly ₦500, 35% for all other amounts
        double effectiveRoi = com.goldmine.investmentplatform.util.TimeUtils.resolveRoiPercentage(inv.getAmount());
        inv.setRoiPercentage(effectiveRoi);
        inv.setExpectedReturn(com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(inv.getAmount()));

        long startTs = inv.getStartTimestamp();
        if (startTs <= 0 && inv.getStartDate() != null && !inv.getStartDate().isEmpty()) {
            startTs = com.goldmine.investmentplatform.util.TimeUtils.parseToEpochSeconds(inv.getStartDate());
        }

        long maturityTs = inv.getMaturityTimestamp();
        if (maturityTs <= 0 && inv.getMaturityDate() != null && !inv.getMaturityDate().isEmpty()) {
            maturityTs = com.goldmine.investmentplatform.util.TimeUtils.parseToEpochSeconds(inv.getMaturityDate());
        }

        // If startTs is known, enforce exact formula: maturity_timestamp = start_timestamp + package_duration_in_seconds
        if (startTs > 0) {
            long expectedMaturityTs = startTs + packageDurationSeconds;
            if (maturityTs <= 0 || Math.abs(maturityTs - expectedMaturityTs) > 60) {
                maturityTs = expectedMaturityTs;
                inv.setMaturityDate(com.goldmine.investmentplatform.util.TimeUtils.formatSqlDateTime(maturityTs));
            }
        } else if (maturityTs > 0) {
            // If only maturity_timestamp was parsed from HTML, derive start_timestamp or cap miscalculated duration
            long rawRemaining = maturityTs - serverNowSeconds;
            if (rawRemaining > packageDurationSeconds) {
                // Miscalculated maturity date in HTML (e.g., 7 days instead of 2 days):
                // infer creation timestamp from original 7-day offset or clamp to canonical duration
                long inferredStart = maturityTs - (7L * 86400L);
                if (inferredStart > 0 && (serverNowSeconds - inferredStart) >= 0 && (serverNowSeconds - inferredStart) <= packageDurationSeconds) {
                    startTs = inferredStart;
                } else {
                    startTs = serverNowSeconds;
                }
                maturityTs = startTs + packageDurationSeconds;
                inv.setMaturityDate(com.goldmine.investmentplatform.util.TimeUtils.formatSqlDateTime(maturityTs));
            } else {
                startTs = maturityTs - packageDurationSeconds;
            }
            inv.setStartDate(com.goldmine.investmentplatform.util.TimeUtils.formatSqlDateTime(startTs));
        }

        inv.setStartTimestamp(startTs);
        inv.setMaturityTimestamp(maturityTs);

        if (maturityTs > 0) {
            long remaining = Math.max(0L, maturityTs - serverNowSeconds);
            inv.setSecondsRemaining(remaining);
            long elapsed = Math.max(0L, packageDurationSeconds - remaining);
            int progress = (int) Math.min(100L, Math.max(0L, (elapsed * 100L) / Math.max(1L, packageDurationSeconds)));
            inv.setProgressPercent(progress);
            if (remaining == 0 && "active".equalsIgnoreCase(inv.getStatus())) {
                inv.setStatus("completed");
            }
        }
    }

    private User parseUserFromDashboardHtml(String html, String defaultIdentifier) {
        User user = new User();
        user.setEmail(defaultIdentifier);

        // Extract Full Name: <h4 style="font-size: 1rem; font-weight: 700; color: #fff; margin:0;">Hamisu Isiyaka</h4>
        Pattern namePattern = Pattern.compile("(?:Good\\s+(?:Morning|Afternoon|Evening),|Welcome,)\\s*.*?<h4[^>]*>([^<]+)</h4>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher nameMatcher = namePattern.matcher(html);
        if (nameMatcher.find()) {
            user.setFullName(nameMatcher.group(1).trim());
        } else {
            user.setFullName(sessionManager.getUserName());
        }

        // Extract Balance: <div class="balance-amount"><span>₦</span> 85,500.00</div>
        Pattern balPattern = Pattern.compile("balance-amount.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher balMatcher = balPattern.matcher(html);
        if (balMatcher.find()) {
            String clean = balMatcher.group(1).replace(",", "").trim();
            try {
                user.setBalance(Double.parseDouble(clean));
            } catch (Exception ignored) {}
        }

        // Extract Total Invested: Total Invested.*?₦\s*([\d,]+\.?\d*)
        Pattern invPattern = Pattern.compile("Total\\s+Invested.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher invMatcher = invPattern.matcher(html);
        if (invMatcher.find()) {
            String clean = invMatcher.group(1).replace(",", "").trim();
            try {
                user.setTotalInvested(Double.parseDouble(clean));
            } catch (Exception ignored) {}
        }

        // Extract Total Profit: Total Profit.*?₦\s*([\d,]+\.?\d*)
        Pattern profPattern = Pattern.compile("Total\\s+Profit.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher profMatcher = profPattern.matcher(html);
        if (profMatcher.find()) {
            String clean = profMatcher.group(1).replace(",", "").trim();
            try {
                user.setTotalProfit(Double.parseDouble(clean));
            } catch (Exception ignored) {}
        }

        return user;
    }

    private List<Transaction> parseDashboardTransactionsHtml(String html) {
        List<Transaction> list = new ArrayList<>();
        try {
            Pattern txPattern = Pattern.compile("((?:DEP|INV|WTH|MAT)-[0-9]{8}-[A-Za-z0-9]+).*?<span[^>]*class=[\"']badge[^\"']*badge-([a-z]+)[\"'][^>]*>.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
            Matcher m = txPattern.matcher(html);
            int idx = 1;
            while (m.find() && list.size() < 5) {
                String ref = m.group(1).trim();
                String status = m.group(2).trim().toLowerCase();
                String amtStr = m.group(3).replace(",", "").trim();
                double amt = 0.0;
                try { amt = Double.parseDouble(amtStr); } catch (Exception ignored) {}

                String type = "investment";
                if (ref.startsWith("DEP")) type = "deposit";
                else if (ref.startsWith("WTH")) type = "withdrawal";

                JsonObject obj = new JsonObject();
                obj.addProperty("id", idx++);
                obj.addProperty("reference_code", ref);
                obj.addProperty("type", type);
                obj.addProperty("amount", amt);
                obj.addProperty("status", status);
                obj.addProperty("description", type.substring(0, 1).toUpperCase() + type.substring(1) + " (" + ref + ")");
                obj.addProperty("created_at", "Recent");
                list.add(gson.fromJson(obj, Transaction.class));
            }
        } catch (Exception ignored) {}
        return list;
    }

    private List<Investment> parseCountingDateHtml(String html, long serverNowSeconds) {
        List<Investment> list = new ArrayList<>();
        Pattern cardPattern = Pattern.compile("data-countdown-target=[\"']([^\"']+)[\"'][^>]*>.*?([A-Z0-9\\-]+)</span>.*?<p[^>]*>([^<]+)</p>.*?Amount:\\s*<strong[^>]*>₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)</strong>.*?Maturity Date:\\s*<strong[^>]*>([^<]+)</strong>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher m = cardPattern.matcher(html);
        int idx = 1;
        while (m.find()) {
            String targetIso = m.group(1).trim();
            String ref = m.group(2).trim();
            String rawPlanText = m.group(3).trim();
            String amountStr = m.group(4).replace(",", "").trim();
            String matDateText = m.group(5).trim();

            String cleanPlanName = rawPlanText.contains("(")
                    ? rawPlanText.substring(0, rawPlanText.indexOf("(")).trim()
                    : rawPlanText;

            int parsedDays = 0;
            Matcher dm = Pattern.compile("(\\d+)\\s*Days", Pattern.CASE_INSENSITIVE).matcher(rawPlanText);
            if (dm.find()) {
                try { parsedDays = Integer.parseInt(dm.group(1)); } catch (Exception ignored) {}
            }
            int durationDays = com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalDurationDays(cleanPlanName, parsedDays);

            long maturityTs = com.goldmine.investmentplatform.util.TimeUtils.parseToEpochSeconds(targetIso);
            if (maturityTs <= 0) {
                maturityTs = com.goldmine.investmentplatform.util.TimeUtils.parseToEpochSeconds(matDateText);
            }

            JsonObject obj = new JsonObject();
            obj.addProperty("id", idx++);
            obj.addProperty("reference_code", ref);
            obj.addProperty("plan_name", cleanPlanName);
            double amt = 0.0;
            try {
                amt = Double.parseDouble(amountStr);
            } catch (Exception ignored) {}
            double dynamicRoi = com.goldmine.investmentplatform.util.TimeUtils.resolveRoiPercentage(amt);
            double expectedReturn = com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(amt);
            obj.addProperty("amount", amt);
            obj.addProperty("expected_return", expectedReturn);
            obj.addProperty("maturity_date", targetIso.isEmpty() ? matDateText : targetIso);
            obj.addProperty("maturity_timestamp", maturityTs);
            obj.addProperty("status", "active");
            obj.addProperty("roi_percentage", dynamicRoi);
            obj.addProperty("duration_days", durationDays);

            Investment inv = gson.fromJson(obj, Investment.class);
            normalizeAndSyncInvestment(inv, serverNowSeconds);
            list.add(inv);
        }
        return list;
    }

    private List<Investment> parseMyInvestmentsHtml(String html, long serverNowSeconds) {
        List<Investment> list = new ArrayList<>();
        Pattern p = Pattern.compile("([A-Z]{3}-[0-9]{8}-[A-Za-z0-9]+).*?<span[^>]*class=[\"']badge[^\"']*badge-([a-z]+)[\"'][^>]*>.*?([^<]+)•.*?(?:Capital|Amount):.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*).*?(?:Payout|Return):.*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(html);
        int idx = 1;
        while (m.find()) {
            String ref = m.group(1).trim();
            String status = m.group(2).trim().toLowerCase();
            String planName = m.group(3).trim();
            String capStr = m.group(4).replace(",", "").trim();

            int durationDays = com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalDurationDays(planName, 0);

            JsonObject obj = new JsonObject();
            obj.addProperty("id", idx++);
            obj.addProperty("reference_code", ref);
            obj.addProperty("status", status);
            obj.addProperty("plan_name", planName);
            double amt = 0.0;
            try {
                amt = Double.parseDouble(capStr);
            } catch (Exception ignored) {}
            double dynamicRoi = com.goldmine.investmentplatform.util.TimeUtils.resolveRoiPercentage(amt);
            double expectedReturn = com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(amt);
            obj.addProperty("amount", amt);
            obj.addProperty("expected_return", expectedReturn);
            obj.addProperty("roi_percentage", dynamicRoi);
            obj.addProperty("duration_days", durationDays);

            Investment inv = gson.fromJson(obj, Investment.class);
            normalizeAndSyncInvestment(inv, serverNowSeconds);
            list.add(inv);
        }

        // Secondary fallback parser if card layout differs slightly
        if (list.isEmpty()) {
            Pattern fallback = Pattern.compile("(INV-[0-9]{8}-[A-Za-z0-9]+).*?(active|completed|pending|rejected).*?((?:Starter|Classic|Premium|VIP)\\s+Gold).*?₦(?:</span>)?\\s*([\\d,]+\\.?\\d*)", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
            Matcher fm = fallback.matcher(html);
            while (fm.find()) {
                String ref = fm.group(1).trim();
                String status = fm.group(2).trim().toLowerCase();
                String planName = fm.group(3).trim();
                String capStr = fm.group(4).replace(",", "").trim();
                double amt = 0.0;
                try { amt = Double.parseDouble(capStr); } catch (Exception ignored) {}
                if (amt <= 0) continue;

                int durationDays = com.goldmine.investmentplatform.util.TimeUtils.resolveCanonicalDurationDays(planName, 0);
                double dynamicRoi = com.goldmine.investmentplatform.util.TimeUtils.resolveRoiPercentage(amt);
                double expectedReturn = com.goldmine.investmentplatform.util.TimeUtils.calculateExpectedReturn(amt);

                JsonObject obj = new JsonObject();
                obj.addProperty("id", idx++);
                obj.addProperty("reference_code", ref);
                obj.addProperty("status", status);
                obj.addProperty("plan_name", planName);
                obj.addProperty("amount", amt);
                obj.addProperty("expected_return", expectedReturn);
                obj.addProperty("roi_percentage", dynamicRoi);
                obj.addProperty("duration_days", durationDays);

                Investment inv = gson.fromJson(obj, Investment.class);
                normalizeAndSyncInvestment(inv, serverNowSeconds);
                list.add(inv);
            }
        }

        return list;
    }

    private int extractRegexInt(String html, String regex, int defaultVal) {
        try {
            Pattern p = Pattern.compile(regex, Pattern.DOTALL);
            Matcher m = p.matcher(html);
            if (m.find()) {
                return Integer.parseInt(m.group(1).trim());
            }
        } catch (Exception ignored) {}
        return defaultVal;
    }

    private void postSuccess(AuthCallback callback, User user) {
        mainHandler.post(() -> callback.onSuccess(user));
    }

    private void postError(AuthCallback callback, String msg) {
        mainHandler.post(() -> callback.onError(msg));
    }
}
