package com.goldmine.investmentplatform.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemInvestmentBinding;
import com.goldmine.investmentplatform.model.Investment;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;

public class InvestmentsAdapter extends RecyclerView.Adapter<InvestmentsAdapter.InvViewHolder> {
    private List<Investment> investments = new ArrayList<>();

    public void setInvestments(List<Investment> list) {
        this.investments = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public InvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemInvestmentBinding binding = ItemInvestmentBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new InvViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull InvViewHolder holder, int position) {
        holder.bind(investments.get(position));
    }

    @Override
    public int getItemCount() {
        return investments.size();
    }

    static class InvViewHolder extends RecyclerView.ViewHolder {
        private final ItemInvestmentBinding binding;

        public InvViewHolder(ItemInvestmentBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Investment inv) {
            int durationDays = TimeUtils.resolveCanonicalDurationDays(inv.getPlanName(), inv.getDurationDays());
            binding.tvInvRefCode.setText(inv.getReferenceCode());
            binding.tvInvPlanName.setText(inv.getPlanName() + " (" + durationDays + " Days • " + (int) inv.getRoiPercentage() + "% ROI)");
            binding.tvInvAmount.setText(CurrencyFormatter.formatNaira(inv.getAmount()));
            binding.tvInvExpectedReturn.setText(CurrencyFormatter.formatNaira(inv.getExpectedReturn()));
            binding.tvInvMaturityDate.setText(TimeUtils.formatDate(inv.getMaturityDate()));

            String status = inv.getStatus().toLowerCase();
            binding.tvInvStatusBadge.setText(status);

            if ("active".equals(status)) {
                binding.tvInvStatusBadge.setTextColor(Color.parseColor("#10B981"));
                binding.tvInvStatusBadge.setBackgroundColor(Color.parseColor("#2510B981"));
            } else if ("completed".equals(status)) {
                binding.tvInvStatusBadge.setTextColor(Color.parseColor("#38BDF8"));
                binding.tvInvStatusBadge.setBackgroundColor(Color.parseColor("#2538BDF8"));
            } else if ("rejected".equals(status) || "cancelled".equals(status)) {
                binding.tvInvStatusBadge.setTextColor(Color.parseColor("#EF4444"));
                binding.tvInvStatusBadge.setBackgroundColor(Color.parseColor("#25EF4444"));
            } else {
                binding.tvInvStatusBadge.setTextColor(Color.parseColor("#EAB308"));
                binding.tvInvStatusBadge.setBackgroundColor(Color.parseColor("#25EAB308"));
            }
        }
    }
}
