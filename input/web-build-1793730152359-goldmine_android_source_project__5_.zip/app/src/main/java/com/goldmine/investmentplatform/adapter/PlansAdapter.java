package com.goldmine.investmentplatform.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemPlanBinding;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import java.util.ArrayList;
import java.util.List;

public class PlansAdapter extends RecyclerView.Adapter<PlansAdapter.PlanViewHolder> {
    private List<InvestmentPlan> plans = new ArrayList<>();
    private final OnPlanClickListener listener;

    public interface OnPlanClickListener {
        void onPlanClick(InvestmentPlan plan);
    }

    public PlansAdapter(OnPlanClickListener listener) {
        this.listener = listener;
    }

    public void setPlans(List<InvestmentPlan> plans) {
        this.plans = plans != null ? plans : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PlanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPlanBinding binding = ItemPlanBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new PlanViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PlanViewHolder holder, int position) {
        holder.bind(plans.get(position));
    }

    @Override
    public int getItemCount() {
        return plans.size();
    }

    class PlanViewHolder extends RecyclerView.ViewHolder {
        private final ItemPlanBinding binding;

        public PlanViewHolder(ItemPlanBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(InvestmentPlan plan) {
            int durationDays = plan.getDurationDays();
            double minAmount = plan.getMinAmount();
            double profit = minAmount * 0.35;
            double dailyProfit = profit / Math.max(1, durationDays);
            double dailyRate = 35.0 / Math.max(1, durationDays);
            double totalReturn = minAmount + profit;

            binding.tvPlanName.setText(plan.getName());
            binding.tvPlanDuration.setText("Duration: " + durationDays + " Days");
            binding.tvPlanRoiBadge.setText("35% ROI");
            binding.tvPlanMin.setText(CurrencyFormatter.formatNaira(minAmount));
            binding.tvPlanMax.setText(CurrencyFormatter.formatNaira(plan.getMaxAmount()));

            binding.tvPlanDailyProfitLabel.setText(String.format(java.util.Locale.US, "Daily Profit (%.2f%%/day)", dailyRate));
            binding.tvPlanProfitRate.setText("+" + CurrencyFormatter.formatNaira(dailyProfit) + "/day");
            binding.tvPlanTotalReturnLabel.setText("Total Return (+35% Profit)");
            binding.tvPlanTotalReturn.setText(CurrencyFormatter.formatNaira(totalReturn));

            String summaryDesc = String.format(
                    java.util.Locale.US,
                    "Example: %s → +%s profit → %s total return (%d Days).",
                    CurrencyFormatter.formatNaira(minAmount),
                    CurrencyFormatter.formatNaira(profit),
                    CurrencyFormatter.formatNaira(totalReturn),
                    durationDays
            );
            binding.tvPlanDescription.setText(summaryDesc);
            binding.btnInvestPlan.setText("Invest Now");

            binding.btnInvestPlan.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onPlanClick(plan);
                }
            });
        }
    }
}
