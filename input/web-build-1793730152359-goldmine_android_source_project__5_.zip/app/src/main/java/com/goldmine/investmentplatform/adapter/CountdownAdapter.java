package com.goldmine.investmentplatform.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemCountdownBinding;
import com.goldmine.investmentplatform.model.Investment;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CountdownAdapter extends RecyclerView.Adapter<CountdownAdapter.CdViewHolder> {
    private List<Investment> countdowns = new ArrayList<>();

    public void setCountdowns(List<Investment> list) {
        this.countdowns = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    public boolean tick() {
        boolean anyMaturedNow = false;
        for (Investment inv : countdowns) {
            long rem = inv.getSecondsRemaining();
            if (rem > 0) {
                long nextRem = rem - 1;
                inv.setSecondsRemaining(nextRem);
                if (nextRem == 0 && "active".equalsIgnoreCase(inv.getStatus())) {
                    inv.setStatus("completed");
                    anyMaturedNow = true;
                }
            }
        }
        notifyDataSetChanged();
        return anyMaturedNow;
    }

    @NonNull
    @Override
    public CdViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemCountdownBinding binding = ItemCountdownBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new CdViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CdViewHolder holder, int position) {
        holder.bind(countdowns.get(position));
    }

    @Override
    public int getItemCount() {
        return countdowns.size();
    }

    static class CdViewHolder extends RecyclerView.ViewHolder {
        private final ItemCountdownBinding binding;

        public CdViewHolder(ItemCountdownBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Investment inv) {
            int durationDays = TimeUtils.resolveCanonicalDurationDays(inv.getPlanName(), inv.getDurationDays());
            long totalPackageSeconds = Math.max(1L, (long) durationDays * 86400L);

            binding.tvCdRefCode.setText(inv.getReferenceCode());
            binding.tvCdPlanName.setText(inv.getPlanName() + " (" + durationDays + " Days • " + (int) inv.getRoiPercentage() + "% ROI)");
            binding.tvCdAmount.setText(CurrencyFormatter.formatNaira(inv.getAmount()));
            binding.tvCdExpectedReturn.setText(CurrencyFormatter.formatNaira(inv.getExpectedReturn()));
            binding.tvCdMaturityDate.setText(TimeUtils.formatDate(inv.getMaturityDate()));

            long rem = inv.getSecondsRemaining();
            if (rem < 0) rem = 0;
            // Guard: remaining countdown must never exceed the package's configured duration
            if (rem > totalPackageSeconds) {
                rem = totalPackageSeconds;
            }

            long days = rem / 86400;
            long hours = (rem % 86400) / 3600;
            long minutes = (rem % 3600) / 60;
            long seconds = rem % 60;

            binding.tvCdDays.setText(String.format(Locale.US, "%02d", days));
            binding.tvCdHours.setText(String.format(Locale.US, "%02d", hours));
            binding.tvCdMinutes.setText(String.format(Locale.US, "%02d", minutes));
            binding.tvCdSeconds.setText(String.format(Locale.US, "%02d", seconds));

            long elapsed = Math.max(0L, totalPackageSeconds - rem);
            int progress = (int) Math.min(100L, Math.max(0L, (elapsed * 100L) / totalPackageSeconds));
            binding.pbCountdownProgress.setProgress(progress);
        }
    }
}
