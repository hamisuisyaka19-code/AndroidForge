package com.goldmine.investmentplatform.ui.invest;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.api.GoldMineRepository;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityInvestBinding;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.util.CurrencyFormatter;

public class InvestActivity extends AppCompatActivity {
    private ActivityInvestBinding binding;
    private SessionManager sessionManager;
    private InvestmentPlan selectedPlan;
    private double userBalance = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInvestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);
        userBalance = sessionManager.getUserBalance();

        selectedPlan = (InvestmentPlan) getIntent().getSerializableExtra("selected_plan");

        setupUI();
        setupCalculations();

        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnSubmitInvestment.setOnClickListener(v -> submitOrder());
    }

    private void setupUI() {
        binding.tvAvailableBalancePill.setText("Bal: " + CurrencyFormatter.formatNaira(userBalance));

        if (selectedPlan != null) {
            int durationDays = selectedPlan.getDurationDays();
            binding.tvPlanName.setText(selectedPlan.getName());
            binding.tvPlanDuration.setText("Duration: " + durationDays + " Days");
            binding.tvPlanRoi.setText("35% ROI");
            binding.tvPlanLimits.setText("Minimum: " +
                    CurrencyFormatter.formatNaira(selectedPlan.getMinAmount()) + " • Maximum: " +
                    CurrencyFormatter.formatNaira(selectedPlan.getMaxAmount()));

            // Pre-fill with min amount
            binding.etInvestmentAmount.setText(String.valueOf((int) selectedPlan.getMinAmount()));
            updateCalculations(selectedPlan.getMinAmount());
        }
    }

    private void setupCalculations() {
        binding.etInvestmentAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    String str = s.toString().trim();
                    double amount = str.isEmpty() ? 0 : Double.parseDouble(str);
                    updateCalculations(amount);
                } catch (Exception e) {
                    updateCalculations(0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void updateCalculations(double investmentAmount) {
        int durationDays = selectedPlan != null ? selectedPlan.getDurationDays() : 3;
        double dailyRate = 35.0 / Math.max(1, durationDays);
        double profit = investmentAmount * 0.35;
        double dailyProfit = profit / Math.max(1, durationDays);
        double totalReturn = investmentAmount + profit;
        double balanceAfter = userBalance - investmentAmount;

        binding.tvPlanRoi.setText("35% ROI");
        binding.tvSummaryCapital.setText(CurrencyFormatter.formatNaira(investmentAmount));
        binding.tvSummaryDailyProfitLabel.setText(String.format(java.util.Locale.US, "Daily Profit (%.2f%%/day)", dailyRate));
        binding.tvSummaryDailyProfit.setText("+" + CurrencyFormatter.formatNaira(dailyProfit) + " / day");
        binding.tvSummaryProfitLabel.setText("Expected Profit (35% ROI)");
        binding.tvSummaryProfit.setText("+" + CurrencyFormatter.formatNaira(profit));
        binding.tvSummaryTotalPayout.setText(CurrencyFormatter.formatNaira(totalReturn));
        binding.tvSummaryBalanceAfter.setText(CurrencyFormatter.formatNaira(balanceAfter));

        if (balanceAfter < 0) {
            binding.tvSummaryBalanceAfter.setTextColor(android.graphics.Color.parseColor("#EF4444"));
        } else {
            binding.tvSummaryBalanceAfter.setTextColor(android.graphics.Color.parseColor("#A1A1AA"));
        }
    }

    private void submitOrder() {
        String amountStr = binding.etInvestmentAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            showError("Please enter an investment amount.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (Exception e) {
            showError("Invalid amount format.");
            return;
        }

        if (selectedPlan == null) {
            showError("No investment plan selected.");
            return;
        }

        if (amount < selectedPlan.getMinAmount()) {
            showError("Minimum investment for " + selectedPlan.getName() + " is " + CurrencyFormatter.formatNaira(selectedPlan.getMinAmount()));
            return;
        }

        if (amount > selectedPlan.getMaxAmount()) {
            showError("Maximum investment for " + selectedPlan.getName() + " is " + CurrencyFormatter.formatNaira(selectedPlan.getMaxAmount()));
            return;
        }

        if (userBalance < amount) {
            showError("Insufficient balance (" + CurrencyFormatter.formatNaira(userBalance) + "). Please deposit funds into your wallet first.");
            return;
        }

        binding.tvError.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnSubmitInvestment.setEnabled(false);

        GoldMineRepository.getInstance().submitInvestment(selectedPlan.getId(), amount, new GoldMineRepository.ActionCallback() {
            @Override
            public void onSuccess(String message) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitInvestment.setEnabled(true);

                userBalance -= amount;
                sessionManager.updateUserBalance(userBalance);

                Toast.makeText(InvestActivity.this, message, Toast.LENGTH_LONG).show();
                finish();
            }

            @Override
            public void onError(String message) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitInvestment.setEnabled(true);
                showError(message);
            }
        });
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
