# GoldMine Android source project

This is a minimal Kotlin Android WebView wrapper for the existing GoldMine website.

- App: GoldMine Investment Platform
- Package: com.goldmine.investment
- Start URL: https://goalmindai.com.ng/goldmine_build/
- Android Gradle Plugin: 8.1.1
- Kotlin: 1.9.0
- Compile SDK: 34
- JDK: 17

The ZIP root contains `settings.gradle.kts` and `app/` so an Android Gradle builder can identify the project root.

Important: this wrapper displays the website as it currently exists. A redesigned website must first be deployed to the same URL for the new design to appear in the app. The app does not modify PHP, MySQL, investment plans, or admin workflows.

Build with a compatible Android SDK and Gradle 8.0+ environment. This source ZIP has not been compiled in this environment.
