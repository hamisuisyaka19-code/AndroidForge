package com.goldmine.investment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * MainActivity for GoldMine Investment Platform.
 * Redesigned for Design 2: Modern Clean — White & Gold.
 * 
 * Features:
 * - Direct connection to https://goalmindai.com.ng
 * - Automatic session cookie preservation
 * - File chooser for payment receipts & proof uploads
 * - Swipe-to-refresh
 * - Offline fallback with embedded White & Gold UI
 * - Fixed: zero illegal escape sequences or invalid regexes
 */
public class MainActivity extends AppCompatActivity {

    public static final String BACKEND_URL = "https://goalmindai.com.ng";
    public static final String LOCAL_OFFLINE_URL = "file:///android_asset/www/index.html";
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    private WebView mWebView;
    private ProgressBar mProgressBar;
    private SwipeRefreshLayout mSwipeRefresh;
    private ValueCallback<Uri[]> mFilePathCallback;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mWebView = findViewById(R.id.webView);
        mProgressBar = findViewById(R.id.progressBar);
        mSwipeRefresh = findViewById(R.id.swipeRefresh);

        // Configure SwipeRefresh with Gold & White branding colors
        mSwipeRefresh.setColorSchemeColors(
                getColor(R.color.gold_primary),
                getColor(R.color.gold_dark),
                getColor(R.color.gold_light)
        );
        mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mWebView.reload();
            }
        });

        setupWebViewSettings();
        setupWebViewClients();

        // Handle Back button safely for WebView history navigation
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (mWebView.canGoBack()) {
                    mWebView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        loadGoldMineBackend();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebViewSettings() {
        WebSettings settings = mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(mWebView, true);
        }

        // Set modern mobile user agent
        String customUA = settings.getUserAgentString() + " GoldMineAndroid/2.0.0 (WhiteGoldEdition)";
        settings.setUserAgentString(customUA);

        // Bind Safe JavaScript Interface
        mWebView.addJavascriptInterface(new WebAppInterface(this), "GoldMineNative");
    }

    private void setupWebViewClients() {
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                mProgressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                mProgressBar.setVisibility(View.GONE);
                mSwipeRefresh.setRefreshing(false);

                // Inject CSS overrides to guarantee White & Gold styling matches Design 2
                injectWhiteAndGoldStyles(view);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    // Fallback to local offline White & Gold app if internet is temporarily down
                    Toast.makeText(MainActivity.this, "Offline: Loaded local GoldMine mode", Toast.LENGTH_SHORT).show();
                    mWebView.loadUrl(LOCAL_OFFLINE_URL);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
                return false; // Load inside WebView
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    mProgressBar.setVisibility(View.GONE);
                }
            }

            // File chooser for Payment receipts / proof upload
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    mFilePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    /**
     * Injects custom CSS rules to seamlessly unify any backend views
     * into Design 2: Modern Clean — White & Gold.
     * All characters are cleanly escaped without illegal syntax.
     */
    private void injectWhiteAndGoldStyles(WebView webView) {
        String css = "body { background-color: #FAFAF9 !important; font-family: 'Plus Jakarta Sans', sans-serif !important; }"
                + " .btn-gold, button[type='submit'] { background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%) !important; color: #FFFFFF !important; border-radius: 12px !important; border: none !important; font-weight: 700 !important; }"
                + " .gold-card { background: #FFFFFF !important; border: 1px solid #FEF3C7 !important; border-radius: 16px !important; box-shadow: 0 4px 15px rgba(217, 119, 6, 0.08) !important; }";

        String js = "javascript:(function() {"
                + "var parent = document.getElementsByTagName('head').item(0);"
                + "var style = document.createElement('style');"
                + "style.type = 'text/css';"
                + "style.innerHTML = window.atob('" + android.util.Base64.encodeToString(css.getBytes(), android.util.Base64.NO_WRAP) + "');"
                + "parent.appendChild(style);"
                + "})()";
        webView.evaluateJavascript(js, null);
    }

    public void loadGoldMineBackend() {
        if (NetworkUtils.isNetworkAvailable(this)) {
            mWebView.loadUrl(BACKEND_URL);
        } else {
            mWebView.loadUrl(LOCAL_OFFLINE_URL);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (mFilePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
