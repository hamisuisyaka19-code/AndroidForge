-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.goldmine.investment.WebAppInterface { *; }
-keepattributes JavascriptInterface
-dontwarn android.webkit.**
