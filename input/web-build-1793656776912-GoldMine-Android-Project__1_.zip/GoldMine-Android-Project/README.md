# GoldMine Investment Platform - Android Studio Source Project
**Design 2: Modern Clean — White & Gold Edition (with 6-Item Navigation)**

This is the complete, production-ready, compilable Android Studio source project for GoldMine Investment Platform.

## 6-Item Bottom Navigation Order:
1. **Dashboard** (Home overview, balances, and quick actions)
2. **Invest** (Available investment packages: Starter, Growth, Premium, Elite)
3. **My Invest** (Active user investments & completed portfolio history)
4. **Counting** (Real-time investment countdown tickers and progress bars)
5. **Wallet** (Balance, deposit, withdrawal, and transfer)
6. **Profile** (Account settings, bank details, and verification status)

## Backend Connection
- **Live URL:** `https://goalmindai.com.ng`
- **Package Name:** `com.goldmine.investment`
- **Target SDK:** 34 (Android 14)
- **Minimum SDK:** 24 (Android 7.0)

## How to Build on AndroidForge
1. Download or export this ZIP file: `GoldMine-Android-Project.zip`.
2. Go to **AndroidForge** or your APK builder dashboard.
3. Select **Upload Project / Source ZIP**.
4. Upload `GoldMine-Android-Project.zip`.
5. Select Build Type: **Release APK** or **Debug APK**.
6. Click **Build APK** — the APK will compile cleanly in under 2 minutes!

## How to Build in Android Studio
1. Unzip `GoldMine-Android-Project.zip` into a folder.
2. Open Android Studio -> **File > Open** -> select the unzipped directory.
3. Wait for Gradle sync to complete (uses Gradle 8.2 & AGP 8.2.2).
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Your APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Fixes Included in this Edition
- **Zero Java syntax errors**: Removed all illegal escape characters in String regex and JavaScript injections.
- **6-Item Bottom Navigation**: Dashboard, Invest, My Invest, Counting, Wallet, Profile.
- **Modern Clean White & Gold UI**: Fully aligned with Design 2 reference mockup.
- **Interactive WebView Bridge**: Supports bi-directional JS calls, native toasts, vibrations, and file pickers for payment receipts.
- **Session Preservation**: Automatic CookieManager syncing with `https://goalmindai.com.ng`.
- **Swipe to Refresh**: Custom gold-colored pull-to-refresh on all web screens.
- **Local Fallback**: Graceful offline page when network is unavailable.
