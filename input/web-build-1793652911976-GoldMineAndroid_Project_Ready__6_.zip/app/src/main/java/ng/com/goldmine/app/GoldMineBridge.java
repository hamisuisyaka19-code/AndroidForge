package ng.com.goldmine.app;

import android.webkit.JavascriptInterface;

/**
 * GoldMineBridge - JavaScript Interface bridge for live data synchronization.
 * Securely communicates user investment records from https://goalmindai.com.ng/my-invest.php
 * directly to the native Android Counting engine, and handles "Invest Now" plan selection
 * from dashboard.php and invest.php.
 */
public class GoldMineBridge {

    public interface InvestmentSyncListener {
        void onInvestmentsReceived(String json);
        void onInvestNowClicked(String planName, String amount, String duration, String roi, String terms);
    }

    private final InvestmentSyncListener listener;

    public GoldMineBridge(InvestmentSyncListener listener) {
        this.listener = listener;
    }

    @JavascriptInterface
    public void onInvestmentsLoaded(String json) {
        if (listener != null) {
            listener.onInvestmentsReceived(json);
        }
    }

    @JavascriptInterface
    public void openInvestConfirmation(String planName, String amount, String duration, String roi, String terms) {
        if (listener != null) {
            listener.onInvestNowClicked(planName, amount, duration, roi, terms);
        }
    }
}
