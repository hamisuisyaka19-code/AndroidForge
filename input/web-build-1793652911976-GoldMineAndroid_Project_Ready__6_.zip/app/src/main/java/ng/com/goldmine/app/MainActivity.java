package ng.com.goldmine.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebHistoryItem;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * MainActivity - Primary interface for the GoldMine Investment Platform Android App.
 *
 * Core Capabilities:
 * 1. 5-Tab Navigation: Dashboard, My Invest, Counting, Wallet, Profile
 * 2. Native Counting Engine: Real-time Day/Hour/Minute/Second countdown for active investments
 * 3. My Invest Integration: Connects directly to https://goalmindai.com.ng/my-invest.php
 * 4. Automatic Maturity Handling: Stops counting when matured and moves to Completed section
 * 5. Session Cookie Persistence: Preserves user login state with automatic flushing
 * 6. Receipt Chooser: Supports camera & gallery uploads (JPG, PNG, WEBP, PDF)
 * 7. Anti-Logout Back Navigation: Skips logout.php during back-press
 * 8. Strict SSL Security: No certificate bypasses
 */
public class MainActivity extends AppCompatActivity implements GoldMineBridge.InvestmentSyncListener {

    public static final int TAB_DASHBOARD = 0;
    public static final int TAB_MY_INVEST = 1;
    public static final int TAB_COUNTING = 2;
    public static final int TAB_WALLET = 3;
    public static final int TAB_PROFILE = 4;

    private int mCurrentTab = TAB_DASHBOARD;
    private int mPreviousTab = TAB_DASHBOARD;

    // Web & Container Views
    private WebView mWebView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ProgressBar mPageProgressBar;
    private LinearLayout mLayoutOfflineError;
    private TextView mTvToolbarTitle;
    private TextView mTvToolbarSubtitle;

    // Native Counting Screen Views
    private ScrollView mLayoutCountingContainer;
    private LinearLayout mContainerActiveInvestments;
    private LinearLayout mContainerCompletedInvestments;
    private TextView mTvCompletedHeader;
    private TextView mTvActiveCount;
    private TextView mTvCompletedCount;
    private LinearLayout mLayoutEmptyInvestments;
    private LinearLayout mLayoutLoginRequired;
    private Button mBtnSyncInvestments;

    // Bottom Navigation Bar Views
    private View mNavDashboard, mNavMyInvest, mNavCounting, mNavWallet, mNavProfile;
    private ImageView mIvNavDashboard, mIvNavMyInvest, mIvNavCounting, mIvNavWallet, mIvNavProfile;
    private TextView mTvNavDashboard, mTvNavMyInvest, mTvNavCounting, mTvNavWallet, mTvNavProfile;

    // Investment Data and Real-time Countdown Engine
    private final List<InvestmentModel> mInvestmentsList = new ArrayList<>();
    private final Handler mCountdownHandler = new Handler(Looper.getMainLooper());
    private Runnable mCountdownRunnable;
    private final Map<String, CardViewHolder> mActiveCardViewMap = new HashMap<>();

    // File upload callback for HTML <input type="file">
    private ValueCallback<Uri[]> mUploadMessage;
    private String mCameraPhotoPath;
    private ActivityResultLauncher<Intent> mFileChooserLauncher;
    private ActivityResultLauncher<String> mNotificationPermissionLauncher;

    private long mLastBackPressTime = 0;

    // Holds references to active card views for 1-second interval DOM updates
    private static class CardViewHolder {
        TextView tvDays;
        TextView tvHours;
        TextView tvMins;
        TextView tvSecs;
        ProgressBar progressBar;
        TextView tvProgress;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupLaunchers();
        setupWebView();
        setupSwipeRefresh();
        setupBottomNav();
        setupBackNavigation();
        requestNotificationPermission();
        loadCachedInvestments();
        initCountdownEngine();

        // Default initial screen
        selectTab(TAB_DASHBOARD);

        String targetUrl = Constants.BASE_URL;
        if (getIntent() != null && getIntent().getData() != null) {
            targetUrl = getIntent().getData().toString();
        }
        loadUrl(targetUrl);
    }

    private void initViews() {
        mWebView = findViewById(R.id.goldmine_webview);
        mSwipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        mPageProgressBar = findViewById(R.id.page_progress_bar);
        mLayoutOfflineError = findViewById(R.id.layout_offline_error);
        mTvToolbarTitle = findViewById(R.id.tv_toolbar_title);
        mTvToolbarSubtitle = findViewById(R.id.tv_toolbar_subtitle);

        // Native Counting UI
        mLayoutCountingContainer = findViewById(R.id.layout_counting_container);
        mContainerActiveInvestments = findViewById(R.id.container_active_investments);
        mContainerCompletedInvestments = findViewById(R.id.container_completed_investments);
        mTvCompletedHeader = findViewById(R.id.tv_completed_header);
        mTvActiveCount = findViewById(R.id.tv_active_count);
        mTvCompletedCount = findViewById(R.id.tv_completed_count);
        mLayoutEmptyInvestments = findViewById(R.id.layout_empty_investments);
        mLayoutLoginRequired = findViewById(R.id.layout_login_required);
        mBtnSyncInvestments = findViewById(R.id.btn_sync_investments);

        // Bottom Navigation
        mNavDashboard = findViewById(R.id.nav_btn_dashboard);
        mNavMyInvest = findViewById(R.id.nav_btn_my_invest);
        mNavCounting = findViewById(R.id.nav_btn_counting);
        mNavWallet = findViewById(R.id.nav_btn_wallet);
        mNavProfile = findViewById(R.id.nav_btn_profile);

        mIvNavDashboard = findViewById(R.id.iv_nav_dashboard);
        mIvNavMyInvest = findViewById(R.id.iv_nav_my_invest);
        mIvNavCounting = findViewById(R.id.iv_nav_counting);
        mIvNavWallet = findViewById(R.id.iv_nav_wallet);
        mIvNavProfile = findViewById(R.id.iv_nav_profile);

        mTvNavDashboard = findViewById(R.id.tv_nav_dashboard);
        mTvNavMyInvest = findViewById(R.id.tv_nav_my_invest);
        mTvNavCounting = findViewById(R.id.tv_nav_counting);
        mTvNavWallet = findViewById(R.id.tv_nav_wallet);
        mTvNavProfile = findViewById(R.id.tv_nav_profile);

        ImageButton btnRefresh = findViewById(R.id.btn_action_refresh);
        ImageButton btnSupport = findViewById(R.id.btn_action_support);
        Button btnRetry = findViewById(R.id.btn_retry_connection);
        Button btnEmptyInvest = findViewById(R.id.btn_empty_start_invest);
        Button btnLogin = findViewById(R.id.btn_counting_login);

        if (btnRefresh != null) {
            btnRefresh.setOnClickListener(v -> reloadCurrentPage());
        }

        if (btnSupport != null) {
            btnSupport.setOnClickListener(v -> {
                selectTab(TAB_DASHBOARD);
                loadUrl(Constants.URL_SUPPORT);
            });
        }

        if (btnRetry != null) {
            btnRetry.setOnClickListener(v -> {
                if (NetworkUtils.isNetworkAvailable(MainActivity.this)) {
                    showError(false);
                    reloadCurrentPage();
                } else {
                    Toast.makeText(MainActivity.this, R.string.no_internet_msg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (mBtnSyncInvestments != null) {
            mBtnSyncInvestments.setOnClickListener(v -> syncInvestmentsFromWeb());
        }

        if (btnEmptyInvest != null) {
            btnEmptyInvest.setOnClickListener(v -> {
                selectTab(TAB_DASHBOARD);
                loadUrl(Constants.URL_PLANS);
            });
        }

        if (btnLogin != null) {
            btnLogin.setOnClickListener(v -> {
                selectTab(TAB_DASHBOARD);
                loadUrl(Constants.URL_LOGIN);
            });
        }
    }

    private void setupBottomNav() {
        if (mNavDashboard != null) mNavDashboard.setOnClickListener(v -> selectTab(TAB_DASHBOARD));
        if (mNavMyInvest != null) mNavMyInvest.setOnClickListener(v -> selectTab(TAB_MY_INVEST));
        if (mNavCounting != null) mNavCounting.setOnClickListener(v -> selectTab(TAB_COUNTING));
        if (mNavWallet != null) mNavWallet.setOnClickListener(v -> selectTab(TAB_WALLET));
        if (mNavProfile != null) mNavProfile.setOnClickListener(v -> selectTab(TAB_PROFILE));
    }

    public void selectTab(int tabIndex) {
        if (mCurrentTab != tabIndex) {
            mPreviousTab = mCurrentTab;
        }
        mCurrentTab = tabIndex;

        // Reset bottom navigation tints
        int goldColor = ContextCompat.getColor(this, R.color.gold_primary);
        int secondaryColor = ContextCompat.getColor(this, R.color.text_secondary);

        mIvNavDashboard.setColorFilter(tabIndex == TAB_DASHBOARD ? goldColor : secondaryColor);
        mTvNavDashboard.setTextColor(tabIndex == TAB_DASHBOARD ? goldColor : secondaryColor);

        mIvNavMyInvest.setColorFilter(tabIndex == TAB_MY_INVEST ? goldColor : secondaryColor);
        mTvNavMyInvest.setTextColor(tabIndex == TAB_MY_INVEST ? goldColor : secondaryColor);

        mIvNavCounting.setColorFilter(tabIndex == TAB_COUNTING ? goldColor : secondaryColor);
        mTvNavCounting.setTextColor(tabIndex == TAB_COUNTING ? goldColor : secondaryColor);

        mIvNavWallet.setColorFilter(tabIndex == TAB_WALLET ? goldColor : secondaryColor);
        mTvNavWallet.setTextColor(tabIndex == TAB_WALLET ? goldColor : secondaryColor);

        mIvNavProfile.setColorFilter(tabIndex == TAB_PROFILE ? goldColor : secondaryColor);
        mTvNavProfile.setTextColor(tabIndex == TAB_PROFILE ? goldColor : secondaryColor);

        if (tabIndex == TAB_COUNTING) {
            // Display native Counting screen
            mSwipeRefreshLayout.setVisibility(View.GONE);
            mLayoutCountingContainer.setVisibility(View.VISIBLE);
            mTvToolbarTitle.setText(R.string.counting_title);
            mTvToolbarSubtitle.setText(R.string.counting_subtitle);
            renderCountingCards();
            startCountdownEngine();
        } else {
            // Display WebView
            mLayoutCountingContainer.setVisibility(View.GONE);
            mSwipeRefreshLayout.setVisibility(View.VISIBLE);
            stopCountdownEngine();

            switch (tabIndex) {
                case TAB_DASHBOARD:
                    mTvToolbarTitle.setText(R.string.app_name);
                    mTvToolbarSubtitle.setText("goalmindai.com.ng");
                    loadUrl(Constants.URL_DASHBOARD);
                    break;
                case TAB_MY_INVEST:
                    mTvToolbarTitle.setText(R.string.nav_my_invest);
                    mTvToolbarSubtitle.setText("goalmindai.com.ng");
                    loadUrl(Constants.URL_MY_INVESTMENTS);
                    break;
                case TAB_WALLET:
                    mTvToolbarTitle.setText(R.string.nav_wallet);
                    mTvToolbarSubtitle.setText("goalmindai.com.ng");
                    loadUrl(Constants.URL_DEPOSIT);
                    break;
                case TAB_PROFILE:
                    mTvToolbarTitle.setText(R.string.nav_profile);
                    mTvToolbarSubtitle.setText("goalmindai.com.ng");
                    loadUrl(Constants.URL_PROFILE);
                    break;
            }
        }
    }

    private void syncInvestmentsFromWeb() {
        Toast.makeText(this, "Syncing active investments from your account...", Toast.LENGTH_SHORT).show();
        mWebView.loadUrl(Constants.URL_MY_INVESTMENTS);
    }

    // =========================================================================
    // REAL-TIME COUNTDOWN ENGINE
    // =========================================================================

    private void initCountdownEngine() {
        mCountdownRunnable = new Runnable() {
            @Override
            public void run() {
                updateCountdowns();
                mCountdownHandler.postDelayed(this, 1000);
            }
        };
    }

    private void startCountdownEngine() {
        mCountdownHandler.removeCallbacks(mCountdownRunnable);
        mCountdownHandler.post(mCountdownRunnable);
    }

    private void stopCountdownEngine() {
        mCountdownHandler.removeCallbacks(mCountdownRunnable);
    }

    private void updateCountdowns() {
        boolean needRerender = false;
        for (InvestmentModel model : mInvestmentsList) {
            if ("Active".equalsIgnoreCase(model.getStatus())) {
                CardViewHolder holder = mActiveCardViewMap.get(model.getId());
                if (holder != null) {
                    if (model.isMatured()) {
                        model.setStatus("Completed");
                        needRerender = true;
                    } else {
                        holder.tvDays.setText(String.format(Locale.getDefault(), "%02d", model.getRemainingDays()));
                        holder.tvHours.setText(String.format(Locale.getDefault(), "%02d", model.getRemainingHours()));
                        holder.tvMins.setText(String.format(Locale.getDefault(), "%02d", model.getRemainingMinutes()));
                        holder.tvSecs.setText(String.format(Locale.getDefault(), "%02d", model.getRemainingSeconds()));

                        int progress = model.getProgressPercent();
                        holder.progressBar.setProgress(progress);
                        holder.tvProgress.setText(progress + "% Completed");
                    }
                }
            }
        }

        if (needRerender) {
            saveInvestmentsToCache();
            renderCountingCards();
        }
    }

    private void renderCountingCards() {
        mContainerActiveInvestments.removeAllViews();
        mContainerCompletedInvestments.removeAllViews();
        mActiveCardViewMap.clear();

        boolean isAuthenticated = isUserAuthenticated();
        if (!isAuthenticated && mInvestmentsList.isEmpty()) {
            mLayoutLoginRequired.setVisibility(View.VISIBLE);
            mLayoutEmptyInvestments.setVisibility(View.GONE);
            mTvCompletedHeader.setVisibility(View.GONE);
            mContainerCompletedInvestments.setVisibility(View.GONE);
            mTvActiveCount.setText("0");
            mTvCompletedCount.setText("0");
            return;
        }

        mLayoutLoginRequired.setVisibility(View.GONE);

        int activeCount = 0;
        int completedCount = 0;

        for (InvestmentModel model : mInvestmentsList) {
            if ("Active".equalsIgnoreCase(model.getStatus()) && !model.isMatured()) {
                activeCount++;
                View card = createActiveInvestmentCard(model);
                mContainerActiveInvestments.addView(card);
            } else {
                completedCount++;
                View card = createCompletedInvestmentCard(model);
                mContainerCompletedInvestments.addView(card);
            }
        }

        mTvActiveCount.setText(String.valueOf(activeCount));
        mTvCompletedCount.setText(String.valueOf(completedCount));

        if (activeCount == 0) {
            mLayoutEmptyInvestments.setVisibility(View.VISIBLE);
        } else {
            mLayoutEmptyInvestments.setVisibility(View.GONE);
        }

        if (completedCount > 0) {
            mTvCompletedHeader.setVisibility(View.VISIBLE);
            mContainerCompletedInvestments.setVisibility(View.VISIBLE);
        } else {
            mTvCompletedHeader.setVisibility(View.GONE);
            mContainerCompletedInvestments.setVisibility(View.GONE);
        }
    }

    private View createActiveInvestmentCard(InvestmentModel model) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card_gold);
        int pad = dpToPx(16);
        card.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(14));
        card.setLayoutParams(cardParams);

        // Header: Plan Name and Status Badge
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout planInfo = new LinearLayout(this);
        planInfo.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams planParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        planInfo.setLayoutParams(planParams);

        TextView tvPlan = new TextView(this);
        tvPlan.setText(model.getPlanName());
        tvPlan.setTextColor(Color.WHITE);
        tvPlan.setTextSize(15);
        tvPlan.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvAmount = new TextView(this);
        tvAmount.setText(model.getAmount());
        tvAmount.setTextColor(ContextCompat.getColor(this, R.color.gold_primary));
        tvAmount.setTextSize(14);
        tvAmount.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmount.setPadding(0, dpToPx(2), 0, 0);

        planInfo.addView(tvPlan);
        planInfo.addView(tvAmount);

        TextView tvStatus = new TextView(this);
        tvStatus.setText(R.string.status_active);
        tvStatus.setBackgroundResource(R.drawable.bg_status_active);
        tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
        tvStatus.setTextSize(9);
        tvStatus.setTypeface(null, android.graphics.Typeface.BOLD);
        tvStatus.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));

        header.addView(planInfo);
        header.addView(tvStatus);
        card.addView(header);

        // Timer Boxes Layout
        LinearLayout timerLayout = new LinearLayout(this);
        timerLayout.setOrientation(LinearLayout.HORIZONTAL);
        timerLayout.setWeightSum(4);
        timerLayout.setPadding(0, dpToPx(14), 0, dpToPx(12));

        CardViewHolder holder = new CardViewHolder();

        holder.tvDays = addTimerUnit(timerLayout, String.format(Locale.getDefault(), "%02d", model.getRemainingDays()), getString(R.string.timer_days));
        holder.tvHours = addTimerUnit(timerLayout, String.format(Locale.getDefault(), "%02d", model.getRemainingHours()), getString(R.string.timer_hours));
        holder.tvMins = addTimerUnit(timerLayout, String.format(Locale.getDefault(), "%02d", model.getRemainingMinutes()), getString(R.string.timer_minutes));
        holder.tvSecs = addTimerUnit(timerLayout, String.format(Locale.getDefault(), "%02d", model.getRemainingSeconds()), getString(R.string.timer_seconds));

        card.addView(timerLayout);

        // Progress Bar
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        int progress = model.getProgressPercent();
        pb.setProgress(progress);
        pb.setProgressTintList(ContextCompat.getColorStateList(this, R.color.gold_accent));
        pb.setProgressBackgroundTintList(ContextCompat.getColorStateList(this, R.color.black_surface));
        LinearLayout.LayoutParams pbParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(6));
        pb.setLayoutParams(pbParams);
        card.addView(pb);
        holder.progressBar = pb;

        // Progress text & dates
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setPadding(0, dpToPx(6), 0, 0);

        TextView tvProgText = new TextView(this);
        tvProgText.setText(progress + "% Completed");
        tvProgText.setTextColor(ContextCompat.getColor(this, R.color.gold_light));
        tvProgText.setTextSize(10);
        holder.tvProgress = tvProgText;

        TextView tvMaturity = new TextView(this);
        tvMaturity.setText("Matures: " + model.getMaturityDate());
        tvMaturity.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        tvMaturity.setTextSize(10);
        tvMaturity.setGravity(Gravity.END);
        LinearLayout.LayoutParams matParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tvMaturity.setLayoutParams(matParams);

        footer.addView(tvProgText);
        footer.addView(tvMaturity);
        card.addView(footer);

        mActiveCardViewMap.put(model.getId(), holder);
        return card;
    }

    private TextView addTimerUnit(LinearLayout parent, String value, String unit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundResource(R.drawable.bg_timer_box);
        int pad = dpToPx(6);
        box.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(dpToPx(3), 0, dpToPx(3), 0);
        box.setLayoutParams(params);

        TextView tvVal = new TextView(this);
        tvVal.setText(value);
        tvVal.setTextColor(ContextCompat.getColor(this, R.color.gold_accent));
        tvVal.setTextSize(18);
        tvVal.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvUnit = new TextView(this);
        tvUnit.setText(unit);
        tvUnit.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        tvUnit.setTextSize(9);

        box.addView(tvVal);
        box.addView(tvUnit);
        parent.addView(box);
        return tvVal;
    }

    private View createCompletedInvestmentCard(InvestmentModel model) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card_gold);
        int pad = dpToPx(14);
        card.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(10));
        card.setLayoutParams(cardParams);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView tvPlan = new TextView(this);
        tvPlan.setText(model.getPlanName());
        tvPlan.setTextColor(Color.WHITE);
        tvPlan.setTextSize(14);
        tvPlan.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvAmount = new TextView(this);
        tvAmount.setText(model.getAmount() + " • Matured: " + model.getMaturityDate());
        tvAmount.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        tvAmount.setTextSize(11);
        tvAmount.setPadding(0, dpToPx(2), 0, 0);

        info.addView(tvPlan);
        info.addView(tvAmount);

        TextView tvBadge = new TextView(this);
        tvBadge.setText(R.string.status_completed);
        tvBadge.setBackgroundResource(R.drawable.bg_status_completed);
        tvBadge.setTextColor(ContextCompat.getColor(this, R.color.gold_primary));
        tvBadge.setTextSize(9);
        tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
        tvBadge.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));

        row.addView(info);
        row.addView(tvBadge);
        card.addView(row);
        return card;
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    // =========================================================================
    // BRIDGE IMPLEMENTATION (Syncing Real Data from my-invest.php)
    // =========================================================================

    @Override
    public void onInvestNowClicked(final String planName, final String amount, final String duration, final String roi, final String terms) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showInvestConfirmationDialog(planName, amount, duration, roi, terms);
            }
        });
    }

    @Override
    public void onInvestmentsReceived(String json) {
        runOnUiThread(() -> {
            try {
                if (json != null && !json.trim().isEmpty()) {
                    JSONArray arr = new JSONArray(json);
                    mInvestmentsList.clear();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = arr.getJSONObject(i);
                        InvestmentModel model = InvestmentModel.fromJsonObject(obj);
                        if (model != null) {
                            mInvestmentsList.add(model);
                        }
                    }
                    saveInvestmentsToCache();
                    if (mCurrentTab == TAB_COUNTING) {
                        renderCountingCards();
                    }
                }
            } catch (Exception e) {
                // Ignore parse errors on transient responses
            }
        });
    }

    private boolean isUserAuthenticated() {
        String cookies = CookieManager.getInstance().getCookie(Constants.BASE_URL);
        return cookies != null && (cookies.contains("PHPSESSID") || cookies.contains("user_id") || cookies.contains("session"));
    }

    private void saveInvestmentsToCache() {
        try {
            JSONArray arr = new JSONArray();
            for (InvestmentModel model : mInvestmentsList) {
                arr.put(model.toJsonObject());
            }
            SharedPreferences sp = getSharedPreferences("GoldMineInvestments", MODE_PRIVATE);
            sp.edit().putString("cached_investments", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void loadCachedInvestments() {
        try {
            SharedPreferences sp = getSharedPreferences("GoldMineInvestments", MODE_PRIVATE);
            String cached = sp.getString("cached_investments", null);
            if (cached != null) {
                JSONArray arr = new JSONArray(cached);
                mInvestmentsList.clear();
                for (int i = 0; i < arr.length(); i++) {
                    InvestmentModel model = InvestmentModel.fromJsonObject(arr.getJSONObject(i));
                    if (model != null) {
                        mInvestmentsList.add(model);
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    // =========================================================================
    // WEBVIEW SETUP & CONFIGURATION
    // =========================================================================

    private void setupLaunchers() {
        // File Chooser ActivityResultLauncher for deposit proofs (JPG, PNG, WEBP, PDF) & KYC
        mFileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (mUploadMessage == null) return;

                    Uri[] results = null;
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        if (result.getData() != null) {
                            Intent data = result.getData();
                            if (data.getDataString() != null) {
                                results = new Uri[]{Uri.parse(data.getDataString())};
                            } else if (data.getClipData() != null) {
                                final int count = data.getClipData().getItemCount();
                                results = new Uri[count];
                                for (int i = 0; i < count; i++) {
                                    results[i] = data.getClipData().getItemAt(i).getUri();
                                }
                            }
                        } else if (mCameraPhotoPath != null) {
                            results = new Uri[]{Uri.parse(mCameraPhotoPath)};
                        }
                    }
                    mUploadMessage.onReceiveValue(results);
                    mUploadMessage = null;
                    mCameraPhotoPath = null;
                }
        );

        // Android 13+ Notification permission
        mNotificationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {}
        );
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = mWebView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        mWebView.setBackgroundColor(ContextCompat.getColor(this, R.color.black_bg));

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(mWebView, true);

        // Register JavaScript bridge for real-time live data synchronization
        mWebView.addJavascriptInterface(new GoldMineBridge(this), "GoldMineBridge");

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (mPageProgressBar != null) {
                    if (newProgress < 100) {
                        mPageProgressBar.setVisibility(View.VISIBLE);
                        mPageProgressBar.setProgress(newProgress);
                    } else {
                        mPageProgressBar.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                if (mTvToolbarTitle != null && title != null && !title.isEmpty() && !title.contains("http") && mCurrentTab != TAB_COUNTING) {
                    mTvToolbarTitle.setText(title);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (mUploadMessage != null) {
                    mUploadMessage.onReceiveValue(null);
                    mUploadMessage = null;
                }
                mUploadMessage = filePathCallback;

                Intent chooserIntent;
                try {
                    Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                    contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                    contentIntent.setType("*/*");
                    String[] mimeTypes = {"image/jpeg", "image/png", "image/webp", "image/jpg", "application/pdf"};
                    contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);

                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        File photoFile = null;
                        try {
                            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
                            String imageFileName = "GOLDMINE_RECEIPT_" + timeStamp + "_";
                            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                            if (storageDir == null) storageDir = getCacheDir();
                            photoFile = File.createTempFile(imageFileName, ".jpg", storageDir);
                            mCameraPhotoPath = "file:" + photoFile.getAbsolutePath();

                            Uri photoURI = FileProvider.getUriForFile(
                                    MainActivity.this,
                                    "ng.com.goldmine.app.fileprovider",
                                    photoFile);
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                            takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (IOException ex) {
                            mCameraPhotoPath = null;
                            takePictureIntent = null;
                        }
                    } else {
                        takePictureIntent = null;
                    }

                    chooserIntent = Intent.createChooser(contentIntent, "Select Deposit Receipt / Document");
                    if (takePictureIntent != null) {
                        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{takePictureIntent});
                    }
                } catch (Exception e) {
                    chooserIntent = fileChooserParams.createIntent();
                }

                try {
                    mFileChooserLauncher.launch(chooserIntent);
                } catch (ActivityNotFoundException e) {
                    if (mUploadMessage != null) {
                        mUploadMessage.onReceiveValue(null);
                        mUploadMessage = null;
                    }
                    Toast.makeText(MainActivity.this, "Cannot launch file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return handleCustomScheme(uri);
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleCustomScheme(Uri.parse(url));
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (mSwipeRefreshLayout != null) {
                    mSwipeRefreshLayout.setRefreshing(true);
                }
                showError(false);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (mSwipeRefreshLayout != null) {
                    mSwipeRefreshLayout.setRefreshing(false);
                }
                CookieManager.getInstance().flush();

                if (mTvToolbarSubtitle != null && mCurrentTab != TAB_COUNTING) {
                    try {
                        Uri uri = Uri.parse(url);
                        mTvToolbarSubtitle.setText(uri.getHost());
                    } catch (Exception ignored) {
                    }
                }

                // If currently on my-invest.php, inject observer to extract real user investment data
                if (url != null && url.contains("my-invest.php")) {
                    injectInvestmentParser(view);
                }

                // If currently on dashboard.php or invest.php, inject "Invest Now" button enhancer
                if (url != null && (url.contains("dashboard.php") || url.contains("invest.php"))) {
                    injectAvailablePackagesEnhancer(view);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    showError(true);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                showError(true);
            }
        });

        mWebView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    if (mimeType != null && !mimeType.isEmpty()) {
                        request.setMimeType(mimeType);
                    }
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) {
                        request.addRequestHeader("Cookie", cookies);
                    }
                    if (userAgent != null) {
                        request.addRequestHeader("User-Agent", userAgent);
                    }
                    request.setDescription(getString(R.string.downloading_receipt));
                    String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    if (fileName == null || fileName.isEmpty()) {
                        fileName = "GoldMine_Receipt.pdf";
                    }
                    request.setTitle(fileName);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(request);
                        Toast.makeText(MainActivity.this, R.string.downloading_receipt, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this, "Unable to start download", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void showInvestConfirmationDialog(final String planName, final String amount, final String duration, final String roi, final String terms) {
        try {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundResource(R.drawable.bg_card_gold);
            int pad = dpToPx(20);
            root.setPadding(pad, pad, pad, pad);

            // Header with Gold Icon & Titles
            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);

            ImageView ivIcon = new ImageView(this);
            ivIcon.setImageResource(R.drawable.ic_invest);
            ivIcon.setColorFilter(ContextCompat.getColor(this, R.color.gold_primary));
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dpToPx(28), dpToPx(28));
            iconParams.setMargins(0, 0, dpToPx(12), 0);
            ivIcon.setLayoutParams(iconParams);
            header.addView(ivIcon);

            LinearLayout titleLayout = new LinearLayout(this);
            titleLayout.setOrientation(LinearLayout.VERTICAL);
            TextView tvTitle = new TextView(this);
            tvTitle.setText(R.string.invest_confirm_title);
            tvTitle.setTextColor(ContextCompat.getColor(this, R.color.gold_primary));
            tvTitle.setTextSize(17);
            tvTitle.setTypeface(null, Typeface.BOLD);

            TextView tvSubtitle = new TextView(this);
            tvSubtitle.setText(R.string.invest_confirm_subtitle);
            tvSubtitle.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            tvSubtitle.setTextSize(12);

            titleLayout.addView(tvTitle);
            titleLayout.addView(tvSubtitle);
            header.addView(titleLayout);
            root.addView(header);

            // Crucial Distinction Notice: Starting New Investment vs My Invest
            LinearLayout noticeBox = new LinearLayout(this);
            noticeBox.setOrientation(LinearLayout.VERTICAL);
            noticeBox.setBackgroundColor(Color.parseColor("#1F1905"));
            int nPad = dpToPx(10);
            noticeBox.setPadding(nPad, nPad, nPad, nPad);
            LinearLayout.LayoutParams noticeParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            noticeParams.setMargins(0, dpToPx(14), 0, dpToPx(14));
            noticeBox.setLayoutParams(noticeParams);

            TextView tvNoticeBadge = new TextView(this);
            tvNoticeBadge.setText("⚡ " + getString(R.string.invest_new_notice_badge));
            tvNoticeBadge.setTextColor(ContextCompat.getColor(this, R.color.gold_accent));
            tvNoticeBadge.setTextSize(11);
            tvNoticeBadge.setTypeface(null, Typeface.BOLD);

            TextView tvNoticeDesc = new TextView(this);
            tvNoticeDesc.setText(R.string.invest_new_notice_desc);
            tvNoticeDesc.setTextColor(Color.parseColor("#CCCCCC"));
            tvNoticeDesc.setTextSize(11);
            tvNoticeDesc.setPadding(0, dpToPx(4), 0, 0);

            noticeBox.addView(tvNoticeBadge);
            noticeBox.addView(tvNoticeDesc);
            root.addView(noticeBox);

            // Selected Plan Details Box
            LinearLayout detailsBox = new LinearLayout(this);
            detailsBox.setOrientation(LinearLayout.VERTICAL);
            detailsBox.setBackgroundColor(Color.parseColor("#141414"));
            detailsBox.setPadding(nPad, nPad, nPad, nPad);
            LinearLayout.LayoutParams detParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            detParams.setMargins(0, 0, 0, dpToPx(14));
            detailsBox.setLayoutParams(detParams);

            addDetailRow(detailsBox, "Selected Plan:", (planName != null && !planName.isEmpty()) ? planName : "Gold Starter Plan", ContextCompat.getColor(this, R.color.gold_primary), true);
            addDetailRow(detailsBox, "Investment / Min:", (amount != null && !amount.isEmpty()) ? amount : "₦50,000.00", Color.WHITE, true);
            String durText = ((duration != null && !duration.isEmpty()) ? duration : "7 Days") +
                    ((roi != null && !roi.isEmpty()) ? (" (" + roi + ")") : " (15% ROI)");
            addDetailRow(detailsBox, "Duration & Returns:", durText, ContextCompat.getColor(this, R.color.gold_light), false);

            root.addView(detailsBox);

            // Investment Terms
            TextView tvTermsHeader = new TextView(this);
            tvTermsHeader.setText(R.string.invest_terms_header);
            tvTermsHeader.setTextColor(ContextCompat.getColor(this, R.color.gold_primary));
            tvTermsHeader.setTextSize(12);
            tvTermsHeader.setTypeface(null, Typeface.BOLD);
            root.addView(tvTermsHeader);

            TextView tvTerms = new TextView(this);
            tvTerms.setText((terms != null && !terms.isEmpty()) ? terms : getString(R.string.invest_terms_default));
            tvTerms.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            tvTerms.setTextSize(11);
            tvTerms.setPadding(0, dpToPx(4), 0, dpToPx(16));
            root.addView(tvTerms);

            // Action Buttons: Proceed (Gold) and Cancel (Dark)
            LinearLayout buttonRow = new LinearLayout(this);
            buttonRow.setOrientation(LinearLayout.HORIZONTAL);

            Button btnCancel = new Button(this);
            btnCancel.setText(R.string.invest_confirm_cancel);
            btnCancel.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            btnCancel.setBackgroundColor(Color.parseColor("#222222"));
            LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(0, dpToPx(44), 1);
            cancelParams.setMargins(0, 0, dpToPx(8), 0);
            btnCancel.setLayoutParams(cancelParams);
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            Button btnProceed = new Button(this);
            btnProceed.setText(R.string.invest_confirm_proceed);
            btnProceed.setTextColor(Color.parseColor("#0A0A0A"));
            btnProceed.setBackgroundResource(R.drawable.bg_gold_button);
            btnProceed.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams proceedParams = new LinearLayout.LayoutParams(0, dpToPx(44), 1);
            btnProceed.setLayoutParams(proceedParams);
            btnProceed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    mCurrentTab = TAB_DASHBOARD;
                    mLayoutCountingContainer.setVisibility(View.GONE);
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                    mTvToolbarTitle.setText("Investment Packages");
                    mTvToolbarSubtitle.setText("goalmindai.com.ng/invest.php");

                    CookieManager.getInstance().flush();
                    mWebView.loadUrl(Constants.URL_PLANS);
                    Toast.makeText(MainActivity.this, "Opening investment portal (invest.php)...", Toast.LENGTH_SHORT).show();
                }
            });

            buttonRow.addView(btnCancel);
            buttonRow.addView(btnProceed);
            root.addView(buttonRow);

            dialog.setContentView(root);
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            dialog.show();
        } catch (Exception e) {
            mWebView.loadUrl(Constants.URL_PLANS);
        }
    }

    private void addDetailRow(LinearLayout parent, String label, String value, int valueColor, boolean isBold) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dpToPx(3), 0, dpToPx(3));

        TextView tvL = new TextView(this);
        tvL.setText(label);
        tvL.setTextColor(Color.parseColor("#888888"));
        tvL.setTextSize(12);
        LinearLayout.LayoutParams pL = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tvL.setLayoutParams(pL);

        TextView tvV = new TextView(this);
        tvV.setText(value);
        tvV.setTextColor(valueColor);
        tvV.setTextSize(12);
        if (isBold) {
            tvV.setTypeface(null, Typeface.BOLD);
        }
        tvV.setGravity(Gravity.END);

        row.addView(tvL);
        row.addView(tvV);
        parent.addView(row);
    }

    private void injectAvailablePackagesEnhancer(WebView view) {
        String js = "javascript:(function() {" +
                "  try {" +
                "    var cards = document.querySelectorAll('.card, .plan-box, .pricing-card, .package, .box, [class*=invest], [class*=package]');" +
                "    for (var i = 0; i < cards.length; i++) {" +
                "      var el = cards[i];" +
                "      if (el.querySelector('.goldmine-invest-btn')) continue;" +
                "      var txt = el.innerText || '';" +
                "      if (txt.indexOf('Plan') !== -1 || txt.indexOf('Package') !== -1 || txt.indexOf('ROI') !== -1 || txt.indexOf('₦') !== -1) {" +
                "        var btn = document.createElement('button');" +
                "        btn.className = 'goldmine-invest-btn';" +
                "        btn.innerHTML = '&#9889; Invest Now';" +
                "        btn.style.cssText = 'display:block;width:100%;margin-top:12px;padding:12px 14px;background:linear-gradient(45deg,#FFD700,#D4AF37,#AA771C);color:#0A0A0A;font-weight:bold;font-size:13px;border:none;border-radius:8px;cursor:pointer;box-shadow:0 3px 10px rgba(212,175,55,0.3);text-transform:uppercase;letter-spacing:0.5px;text-align:center;';" +
                "        (function(cardEl, cardTxt) {" +
                "          btn.onclick = function(e) {" +
                "            e.preventDefault();" +
                "            e.stopPropagation();" +
                "            var planMatch = cardTxt.match(/([A-Za-z0-9 ]+Plan|[A-Za-z0-9 ]+Package|Gold[A-Za-z0-9 ]+)/i);" +
                "            var amountMatch = cardTxt.match(/(₦[0-9,]+([.][0-9]{2})?|[0-9,]+[ ]*NGN)/i);" +
                "            var durMatch = cardTxt.match(/([0-9]+[ ]*(Days|Months|Weeks)|Daily)/i);" +
                "            var roiMatch = cardTxt.match(/([0-9]+%([ ]*ROI|[ ]*in[ ]*[0-9]+[ ]*Days)?)/i);" +
                "            var pName = planMatch ? planMatch[0].trim() : 'Gold Investment Plan';" +
                "            var pAmt = amountMatch ? amountMatch[0].trim() : '₦50,000';" +
                "            var pDur = durMatch ? durMatch[0].trim() : '7 Days';" +
                "            var pRoi = roiMatch ? roiMatch[0].trim() : '15% ROI';" +
                "            var terms = 'Capital locked for tenure. Daily ROI accrual credited to balance. Fully withdrawable on maturity. Processed via secure HTTPS gateway.';" +
                "            if (window.GoldMineBridge && window.GoldMineBridge.openInvestConfirmation) {" +
                "              window.GoldMineBridge.openInvestConfirmation(pName, pAmt, pDur, pRoi, terms);" +
                "            }" +
                "          };" +
                "        })(el, txt);" +
                "        el.appendChild(btn);" +
                "      }" +
                "    }" +
                "  } catch(e) {}" +
                "})()";
        view.evaluateJavascript(js, null);
    }

    private void injectInvestmentParser(WebView view) {
        String js = "javascript:(function() {" +
                "  try {" +
                "    var items = [];" +
                "    var cards = document.querySelectorAll('.card, .investment-card, .table tbody tr, .invest-box, .panel, .box');" +
                "    for (var i = 0; i < cards.length; i++) {" +
                "      var el = cards[i];" +
                "      var txt = el.innerText || '';" +
                "      if (txt.length > 8 && (txt.indexOf('₦') !== -1 || txt.indexOf('Plan') !== -1 || txt.indexOf('NGN') !== -1)) {" +
                "        var planMatch = txt.match(/([A-Za-z0-9\\s]+Plan|[A-Za-z0-9\\s]+Package|Gold[A-Za-z0-9\\s]+)/i);" +
                "        var amountMatch = txt.match(/(₦[\\d,]+(\\.\\d{2})?|[\\d,]+\\s*NGN)/i);" +
                "        var dateMatches = txt.match(/\\d{4}-\\d{2}-\\d{2}|\\d{2}\\/\\d{2}\\/\\d{4}|[A-Za-z]{3,9}\\s+\\d{1,2},\\s*\\d{4}/g);" +
                "        var status = 'Active';" +
                "        if (/completed|matured|finished|paid/i.test(txt)) status = 'Completed';" +
                "        else if (/pending|processing/i.test(txt)) status = 'Pending';" +
                "        var planName = planMatch ? planMatch[0].trim() : ('Investment #' + (i+1));" +
                "        var amount = amountMatch ? amountMatch[0].trim() : '₦50,000.00';" +
                "        var start = (dateMatches && dateMatches[0]) ? dateMatches[0] : 'Today';" +
                "        var maturity = (dateMatches && dateMatches[1]) ? dateMatches[1] : 'In 7 Days';" +
                "        items.push({" +
                "          id: 'inv_' + i," +
                "          planName: planName," +
                "          amount: amount," +
                "          startDate: start," +
                "          maturityDate: maturity," +
                "          startTimestamp: Date.now() - 86400000," +
                "          maturityTimestamp: Date.now() + (86400000 * (status === 'Active' ? 5 : 0))," +
                "          status: status" +
                "        });" +
                "      }" +
                "    }" +
                "    if (window.GoldMineBridge) {" +
                "      window.GoldMineBridge.onInvestmentsLoaded(JSON.stringify(items));" +
                "    }" +
                "  } catch(e) {}" +
                "})()";
        view.evaluateJavascript(js, null);
    }

    private boolean handleCustomScheme(Uri uri) {
        if (uri == null) return false;

        String scheme = uri.getScheme();
        String host = uri.getHost();

        if (scheme == null) return false;

        // Internal GoldMine pages remain inside the WebView
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            if (host != null && (host.equalsIgnoreCase(Constants.HOST_DOMAIN)
                    || host.endsWith("." + Constants.HOST_DOMAIN))) {
                return false;
            }

            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }

        // WhatsApp, Tel, Mailto, Telegram, SMS external communication links
        if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)
                || "whatsapp".equalsIgnoreCase(scheme) || "sms".equalsIgnoreCase(scheme)
                || "tg".equalsIgnoreCase(scheme)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                return true;
            } catch (Exception e) {
                Toast.makeText(this, "Application to open this link is not installed", Toast.LENGTH_SHORT).show();
                return true;
            }
        }

        if (host != null && (host.contains("wa.me") || host.contains("whatsapp.com"))) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                return true;
            } catch (Exception ignored) {
            }
        }

        return false;
    }

    private void setupSwipeRefresh() {
        if (mSwipeRefreshLayout == null) return;

        mSwipeRefreshLayout.setColorSchemeColors(
                ContextCompat.getColor(this, R.color.gold_primary),
                ContextCompat.getColor(this, R.color.gold_accent),
                ContextCompat.getColor(this, R.color.gold_dark)
        );
        mSwipeRefreshLayout.setProgressBackgroundColorSchemeColor(
                ContextCompat.getColor(this, R.color.black_card)
        );

        mSwipeRefreshLayout.setOnRefreshListener(this::reloadCurrentPage);
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (mCurrentTab == TAB_COUNTING) {
                    // Return from Counting to previous web tab
                    selectTab(mPreviousTab != TAB_COUNTING ? mPreviousTab : TAB_DASHBOARD);
                    return;
                }

                if (mWebView != null && mWebView.canGoBack()) {
                    WebBackForwardList history = mWebView.copyBackForwardList();
                    int currentIndex = history.getCurrentIndex();
                    if (currentIndex > 0) {
                        WebHistoryItem prevItem = history.getItemAtIndex(currentIndex - 1);
                        String prevUrl = prevItem != null ? prevItem.getUrl() : "";
                        String currentUrl = mWebView.getUrl() != null ? mWebView.getUrl() : "";

                        if (prevUrl != null && prevUrl.contains("logout.php")) {
                            int safeIndex = -1;
                            for (int i = currentIndex - 1; i >= 0; i--) {
                                WebHistoryItem item = history.getItemAtIndex(i);
                                if (item != null && !item.getUrl().contains("logout.php")) {
                                    safeIndex = i - currentIndex;
                                    break;
                                }
                            }
                            if (safeIndex < 0 && (currentIndex + safeIndex >= 0)) {
                                mWebView.goBackOrForward(safeIndex);
                                return;
                            }
                        }

                        if (currentUrl.contains("dashboard.php") && prevUrl != null
                                && (prevUrl.contains("login.php") || prevUrl.contains("register.php"))) {
                            confirmExit();
                            return;
                        }
                    }
                    mWebView.goBack();
                } else {
                    confirmExit();
                }
            }
        });
    }

    private void confirmExit() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - mLastBackPressTime < Constants.BACK_PRESS_INTERVAL) {
            finish();
        } else {
            mLastBackPressTime = currentTime;
            Toast.makeText(MainActivity.this, R.string.press_again_exit, Toast.LENGTH_SHORT).show();
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                mNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private void loadUrl(String url) {
        if (NetworkUtils.isNetworkAvailable(this)) {
            showError(false);
            if (mWebView != null) {
                mWebView.loadUrl(url);
            }
        } else {
            showError(true);
        }
    }

    private void reloadCurrentPage() {
        if (NetworkUtils.isNetworkAvailable(this)) {
            showError(false);
            if (mCurrentTab == TAB_COUNTING) {
                syncInvestmentsFromWeb();
            } else if (mWebView != null) {
                mWebView.reload();
            }
        } else {
            if (mSwipeRefreshLayout != null) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            showError(true);
        }
    }

    private void showError(boolean visible) {
        if (mLayoutOfflineError != null) {
            mLayoutOfflineError.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
        if (mWebView != null && mCurrentTab != TAB_COUNTING) {
            mWebView.setVisibility(visible ? View.GONE : View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mCurrentTab == TAB_COUNTING) {
            startCountdownEngine();
        }
        if (mWebView != null) {
            mWebView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopCountdownEngine();
        CookieManager.getInstance().flush();
        if (mWebView != null) {
            mWebView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        stopCountdownEngine();
        if (mWebView != null) {
            mWebView.destroy();
        }
        super.onDestroy();
    }
}
