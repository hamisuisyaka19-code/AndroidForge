/**
 * GoldMine Investment Platform - Core Application Logic
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize live countdown timers on any page with data-maturity
    const timers = document.querySelectorAll('[data-countdown-target]');
    if (timers.length > 0) {
        function updateTimers() {
            const now = new Date().getTime();

            timers.forEach(timer => {
                const targetStr = timer.getAttribute('data-countdown-target');
                const targetDate = new Date(targetStr).getTime();
                const distance = targetDate - now;

                const daysEl = timer.querySelector('.cd-days');
                const hoursEl = timer.querySelector('.cd-hours');
                const minsEl = timer.querySelector('.cd-mins');
                const secsEl = timer.querySelector('.cd-secs');
                const statusEl = timer.querySelector('.cd-status');

                if (distance < 0) {
                    if (daysEl) daysEl.innerText = "00";
                    if (hoursEl) hoursEl.innerText = "00";
                    if (minsEl) minsEl.innerText = "00";
                    if (secsEl) secsEl.innerText = "00";
                    if (statusEl) {
                        statusEl.innerText = "Investment Completed";
                        statusEl.className = "badge badge-completed";
                    }
                } else {
                    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    if (daysEl) daysEl.innerText = String(days).padStart(2, '0');
                    if (hoursEl) hoursEl.innerText = String(hours).padStart(2, '0');
                    if (minsEl) minsEl.innerText = String(minutes).padStart(2, '0');
                    if (secsEl) secsEl.innerText = String(seconds).padStart(2, '0');
                }
            });
        }
        updateTimers();
        setInterval(updateTimers, 1000);
    }

    // 2. Toggle password visibility
    const toggles = document.querySelectorAll('.toggle-password');
    toggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const input = toggle.previousElementSibling;
            if (input && input.tagName === 'INPUT') {
                input.type = input.type === 'password' ? 'text' : 'password';
            }
        });
    });
});
