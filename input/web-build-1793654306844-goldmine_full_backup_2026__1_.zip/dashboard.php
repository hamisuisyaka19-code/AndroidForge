<?php
$page_title = "Dashboard";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();

check_and_update_matured_investments();
$user = get_current_user_data();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

// Count active and completed investments
$active_invest_count = 0;
$completed_invest_count = 0;
if ($pdo) {
    $stmt1 = $pdo->prepare("SELECT COUNT(*) FROM investments WHERE user_id = ? AND status = 'active'");
    $stmt1->execute([$user_id]);
    $active_invest_count = (int)$stmt1->fetchColumn();

    $stmt2 = $pdo->prepare("SELECT COUNT(*) FROM investments WHERE user_id = ? AND status = 'completed'");
    $stmt2->execute([$user_id]);
    $completed_invest_count = (int)$stmt2->fetchColumn();
}
?>
<div class="mobile-content">
  <!-- Top User Profile Greeting & Notification -->
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
    <div style="display:flex; align-items:center; gap:12px;">
      <div style="width: 44px; height: 44px; border-radius: 50%; background: #27272a; border: 2px solid var(--gm-gold); overflow: hidden; display: flex; align-items: center; justify-content: center;">
        <i class="fa-solid fa-user-tie" style="color: #eab308; font-size: 22px;"></i>
      </div>
      <div>
        <p style="font-size: 0.75rem; color: #a1a1aa; margin:0;">Good Morning,</p>
        <h4 style="font-size: 1rem; font-weight: 700; color: #fff; margin:0;"><?php echo htmlspecialchars($user['full_name']); ?></h4>
      </div>
    </div>
    <a href="/notifications.php" style="position: relative; width: 40px; height: 40px; background: #18181b; border: 1px solid #27272a; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff;">
      <i class="fa-regular fa-bell"></i>
      <?php if ($unread_count > 0): ?>
        <span style="position: absolute; top: 6px; right: 6px; width: 8px; height: 8px; background: #ef4444; border-radius: 50%;"></span>
      <?php endif; ?>
    </a>
  </div>

  <!-- Available Balance Card -->
  <div class="balance-card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <span style="font-size: 0.8rem; color: #a1a1aa; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">Available Balance</span>
      <i class="fa-regular fa-eye" style="color: #a1a1aa; cursor: pointer;"></i>
    </div>
    <div class="balance-amount">
      <span>₦</span> <?php echo number_format((float)$user['balance'], 2); ?>
    </div>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
      <a href="/deposit.php" class="btn-gold" style="padding: 10px; font-size: 0.88rem;">
        <i class="fa-solid fa-plus"></i> Deposit
      </a>
      <a href="/withdraw.php" class="btn-outline" style="padding: 10px; font-size: 0.88rem; border-color: rgba(234, 179, 8, 0.4); color: var(--gm-gold);">
        <i class="fa-solid fa-arrow-up-from-bracket"></i> Withdraw
      </a>
    </div>
  </div>

  <!-- Quick Action Grid (6 Icons matching reference) -->
  <div class="action-grid">
    <a href="/invest.php" class="action-item">
      <div class="action-icon"><i class="fa-solid fa-sack-dollar"></i></div>
      <span class="action-title">Invest</span>
    </a>
    <a href="/my-invest.php" class="action-item">
      <div class="action-icon"><i class="fa-solid fa-coins"></i></div>
      <span class="action-title">My Invest</span>
    </a>
    <a href="/counting-date.php" class="action-item">
      <div class="action-icon"><i class="fa-solid fa-calendar-day"></i></div>
      <span class="action-title">Counting Date</span>
    </a>
    <a href="/transactions.php" class="action-item">
      <div class="action-icon"><i class="fa-solid fa-receipt"></i></div>
      <span class="action-title">Transactions</span>
    </a>
    <a href="/notifications.php" class="action-item" style="position:relative;">
      <div class="action-icon">
        <i class="fa-regular fa-bell"></i>
        <?php if ($unread_count > 0): ?>
          <span style="position: absolute; top: 10px; right: 26px; background: #ef4444; color: #fff; font-size: 0.65rem; padding: 1px 5px; border-radius: 10px; font-weight: bold;"><?php echo $unread_count; ?></span>
        <?php endif; ?>
      </div>
      <span class="action-title">Notifications</span>
    </a>
    <a href="/profile.php" class="action-item">
      <div class="action-icon"><i class="fa-solid fa-user-gear"></i></div>
      <span class="action-title">Profile</span>
    </a>
  </div>

  <!-- Overview Stats Card -->
  <div class="gm-card">
    <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin-bottom: 14px;">Overview</h4>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 14px;">
      <div style="background: #1c1c20; padding: 12px; border-radius: 12px; border-left: 3px solid var(--gm-gold);">
        <p style="font-size: 0.72rem; color: #a1a1aa; margin-bottom: 4px;">Total Invested</p>
        <p style="font-size: 1.05rem; font-weight: 800; color: #fff;">₦<?php echo number_format((float)$user['total_invested'], 2); ?></p>
      </div>
      <div style="background: #1c1c20; padding: 12px; border-radius: 12px; border-left: 3px solid #22c55e;">
        <p style="font-size: 0.72rem; color: #a1a1aa; margin-bottom: 4px;">Total Profit</p>
        <p style="font-size: 1.05rem; font-weight: 800; color: #22c55e;">₦<?php echo number_format((float)$user['total_profit'], 2); ?></p>
      </div>
      <div style="background: #1c1c20; padding: 12px; border-radius: 12px; border-left: 3px solid #3b82f6;">
        <p style="font-size: 0.72rem; color: #a1a1aa; margin-bottom: 4px;">Active Invest</p>
        <p style="font-size: 1.2rem; font-weight: 800; color: #fff;"><?php echo $active_invest_count; ?></p>
      </div>
      <div style="background: #1c1c20; padding: 12px; border-radius: 12px; border-left: 3px solid #eab308;">
        <p style="font-size: 0.72rem; color: #a1a1aa; margin-bottom: 4px;">Completed</p>
        <p style="font-size: 1.2rem; font-weight: 800; color: #fff;"><?php echo $completed_invest_count; ?></p>
      </div>
    </div>
  </div>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
