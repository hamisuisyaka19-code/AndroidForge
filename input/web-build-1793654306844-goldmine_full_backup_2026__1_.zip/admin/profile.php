<?php
$admin_page_title = "Administrator Profile & Security";
$admin_page_subtitle = "Update admin credentials, email address & secure password";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';
$admin_id = (int)$_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired.";
    } elseif ($pdo) {
        $name = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (empty($name) || empty($email)) {
            $error = "Name and email are required.";
        } else {
            // Update name and email
            $upd = $pdo->prepare("UPDATE admins SET name = ?, email = ? WHERE id = ?");
            $upd->execute([$name, $email, $admin_id]);
            $_SESSION['admin_name'] = $name;
            $_SESSION['admin_email'] = $email;
            $notice = "Profile information updated successfully!";

            // Handle password change if filled
            if (!empty($new_pass)) {
                $chk = $pdo->prepare("SELECT password_hash FROM admins WHERE id = ? LIMIT 1");
                $chk->execute([$admin_id]);
                $hash = $chk->fetchColumn();

                if (!password_verify($current_pass, $hash)) {
                    $error = "Current password is incorrect.";
                } elseif (strlen($new_pass) < 8) {
                    $error = "New password must be at least 8 characters.";
                } elseif ($new_pass !== $confirm_pass) {
                    $error = "New passwords do not match.";
                } else {
                    $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
                    $p_upd = $pdo->prepare("UPDATE admins SET password_hash = ? WHERE id = ?");
                    $p_upd->execute([$new_hash, $admin_id]);
                    log_audit_action($admin_id, null, "Changed Admin Password", "Password updated");
                    $notice = "Profile and password updated successfully!";
                }
            }
        }
    }
}

// Fetch admin data
$admin_data = null;
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
    $stmt->execute([$admin_id]);
    $admin_data = $stmt->fetch();
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="max-width:600px;">
  <form method="POST" action="/admin/profile.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($admin_data['name'] ?? ''); ?>" required>
    </div>

    <div class="form-group">
      <label class="form-label">Admin Email Address</label>
      <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($admin_data['email'] ?? ''); ?>" required>
    </div>

    <div class="form-group">
      <label class="form-label">Username (Read-only)</label>
      <input type="text" class="form-control" value="<?php echo htmlspecialchars($admin_data['username'] ?? ''); ?>" readonly style="opacity:0.7;">
    </div>

    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin:24px 0 16px 0; border-top:1px solid #222226; padding-top:16px;">Change Password</h4>
    <p style="font-size:0.75rem; color:#a1a1aa; margin-bottom:12px;">Leave blank if you do not wish to change your password.</p>

    <div class="form-group">
      <label class="form-label">Current Password</label>
      <input type="password" name="current_password" class="form-control" placeholder="••••••••">
    </div>

    <div class="form-group">
      <label class="form-label">New Password (Min 8 chars)</label>
      <input type="password" name="new_password" class="form-control" placeholder="••••••••">
    </div>

    <div class="form-group">
      <label class="form-label">Confirm New Password</label>
      <input type="password" name="confirm_password" class="form-control" placeholder="••••••••">
    </div>

    <button type="submit" class="btn-gold" style="margin-top:10px;">Save Profile Changes</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
