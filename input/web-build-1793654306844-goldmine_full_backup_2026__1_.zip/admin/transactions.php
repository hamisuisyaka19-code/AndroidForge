<?php
$admin_page_title = "Global Platform Ledger";
$admin_page_subtitle = "Auditable records of all deposits, investments, returns, and disbursements";
require_once __DIR__ . '/../includes/admin-header.php';

$filter_type = $_GET['type'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$where = [];
$params = [];

if ($filter_type !== 'all' && in_array($filter_type, ['deposit', 'investment', 'withdrawal', 'adjustment', 'roi_payout'])) {
    $where[] = "t.type = ?";
    $params[] = $filter_type;
}
if (!empty($search)) {
    $where[] = "(t.reference_code LIKE ? OR u.full_name LIKE ? OR t.description LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$txs = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT t.*, u.full_name as user_name, u.email as user_email
                               FROM transactions t
                               JOIN users u ON t.user_id = u.id
                               $where_sql
                               ORDER BY t.id DESC LIMIT 100");
        $stmt->execute($params);
        $txs = $stmt->fetchAll();
    } catch (PDOException $e) {
        // error handling
    }
}
?>

<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <a href="/admin/transactions.php?type=all" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_type === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
      <a href="/admin/transactions.php?type=deposit" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_type === 'deposit' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Deposits</a>
      <a href="/admin/transactions.php?type=investment" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_type === 'investment' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Investments</a>
      <a href="/admin/transactions.php?type=withdrawal" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_type === 'withdrawal' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Withdrawals</a>
      <a href="/admin/transactions.php?type=adjustment" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_type === 'adjustment' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Adjustments</a>
    </div>

    <form method="GET" action="/admin/transactions.php" style="display:flex; gap:8px;">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ref or description..." class="form-control" style="width:220px; padding:7px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:7px 12px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>TX Reference</th>
          <th>User</th>
          <th>Type</th>
          <th>Amount</th>
          <th>Balance After</th>
          <th>Description</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($txs)): ?>
          <tr><td colspan="8" style="text-align:center; color:#71717a; padding:35px;">No transaction records found.</td></tr>
        <?php else: ?>
          <?php foreach ($txs as $t): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($t['reference_code']); ?></td>
              <td>
                <strong style="color:#fff;"><?php echo htmlspecialchars($t['user_name']); ?></strong>
                <span style="display:block; font-size:0.7rem; color:#71717a;"><?php echo htmlspecialchars($t['user_email']); ?></span>
              </td>
              <td><span style="font-weight:700; text-transform:uppercase; font-size:0.75rem; color:#e4e4e7;"><?php echo htmlspecialchars($t['type']); ?></span></td>
              <td style="font-weight:800; color:<?php echo $t['type'] === 'withdrawal' ? '#f87171' : 'var(--gm-gold)'; ?>;">
                <?php echo $t['type'] === 'withdrawal' ? '-' : '+'; ?>₦<?php echo number_format((float)$t['amount'], 2); ?>
              </td>
              <td style="font-weight:600; color:#d4d4d8;">₦<?php echo number_format((float)$t['balance_after'], 2); ?></td>
              <td style="font-size:0.8rem; color:#a1a1aa; max-width:220px;"><?php echo htmlspecialchars($t['description']); ?></td>
              <td style="color:#71717a; font-size:0.78rem;"><?php echo date('M d, Y h:i A', strtotime($t['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $t['status']; ?>"><?php echo ucfirst($t['status']); ?></span></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
