<?php
$admin_page_title = "Withdrawal Requests Management";
$admin_page_subtitle = "Verify bank accounts, review disbursement requests & audit withdrawals";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['withdrawal_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired.";
    } else {
        $wth_id = (int)$_POST['withdrawal_id'];
        $act = $_POST['action'];
        $admin_id = (int)$_SESSION['admin_id'];

        if ($pdo && $wth_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE id = ? LIMIT 1");
            $stmt->execute([$wth_id]);
            $wth = $stmt->fetch();

            if (!$wth) {
                $error = "Withdrawal record not found.";
            } elseif ($wth['status'] === 'completed' || $wth['status'] === 'rejected') {
                $error = "Withdrawal has already finalized.";
            } else {
                if ($act === 'approve') {
                    $upd = $pdo->prepare("UPDATE withdrawals SET status = 'completed', admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$admin_id, $wth_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE reference_code = ?");
                    $t_upd->execute([$wth['reference_code']]);

                    add_user_notification(
                        (int)$wth['user_id'],
                        "Withdrawal Approved & Disbursed",
                        "Your withdrawal request of " . format_currency($wth['amount']) . " to " . $wth['bank_name'] . " (" . $wth['account_number'] . ") has been completed.",
                        "success",
                        "/withdraw.php"
                    );

                    log_audit_action($admin_id, (int)$wth['user_id'], "Approved Withdrawal", "Ref: " . $wth['reference_code'] . " - " . format_currency($wth['amount']));
                    $notice = "Withdrawal " . htmlspecialchars($wth['reference_code']) . " approved and marked as completed.";
                } elseif ($act === 'reject') {
                    $pdo->beginTransaction();
                    // Refund balance to user
                    $upd_user = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $upd_user->execute([$wth['amount'], $wth['user_id']]);

                    $upd = $pdo->prepare("UPDATE withdrawals SET status = 'rejected', admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$admin_id, $wth_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'failed' WHERE reference_code = ?");
                    $t_upd->execute([$wth['reference_code']]);

                    add_user_notification(
                        (int)$wth['user_id'],
                        "Withdrawal Request Rejected",
                        "Your withdrawal request of " . format_currency($wth['amount']) . " was declined. The funds have been refunded back to your available balance.",
                        "danger",
                        "/withdraw.php"
                    );

                    log_audit_action($admin_id, (int)$wth['user_id'], "Rejected Withdrawal & Refunded", "Ref: " . $wth['reference_code']);
                    $pdo->commit();
                    $notice = "Withdrawal " . htmlspecialchars($wth['reference_code']) . " rejected and refunded.";
                }
            }
        }
    }
}

$filter_status = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$where = [];
$params = [];

if ($filter_status !== 'all' && in_array($filter_status, ['pending', 'processing', 'completed', 'rejected'])) {
    $where[] = "w.status = ?";
    $params[] = $filter_status;
}
if (!empty($search)) {
    $where[] = "(w.reference_code LIKE ? OR u.full_name LIKE ? OR w.account_number LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$withdrawals = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT w.*, u.full_name as user_name, u.email as user_email
                               FROM withdrawals w
                               JOIN users u ON w.user_id = u.id
                               $where_sql
                               ORDER BY CASE WHEN w.status = 'pending' THEN 1 ELSE 2 END, w.id DESC LIMIT 50");
        $stmt->execute($params);
        $withdrawals = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Failed to load withdrawals: " . $e->getMessage();
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
    <div style="display:flex; gap:8px;">
      <a href="/admin/withdrawals.php?status=all" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
      <a href="/admin/withdrawals.php?status=pending" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'pending' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Pending</a>
      <a href="/admin/withdrawals.php?status=completed" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'completed' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Completed</a>
      <a href="/admin/withdrawals.php?status=rejected" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'rejected' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Rejected</a>
    </div>

    <form method="GET" action="/admin/withdrawals.php" style="display:flex; gap:8px;">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ref or bank acc..." class="form-control" style="width:200px; padding:7px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:7px 12px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Reference</th>
          <th>User</th>
          <th>Amount</th>
          <th>Bank Information</th>
          <th>Date</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($withdrawals)): ?>
          <tr><td colspan="7" style="text-align:center; color:#71717a; padding:35px;">No withdrawal requests found.</td></tr>
        <?php else: ?>
          <?php foreach ($withdrawals as $w): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($w['reference_code']); ?></td>
              <td>
                <strong style="color:#fff;"><?php echo htmlspecialchars($w['user_name']); ?></strong>
                <span style="display:block; font-size:0.7rem; color:#71717a;"><?php echo htmlspecialchars($w['user_email']); ?></span>
              </td>
              <td style="font-weight:800; color:#f87171;">₦<?php echo number_format((float)$w['amount'], 2); ?></td>
              <td>
                <strong style="color:#fff; font-size:0.82rem;"><?php echo htmlspecialchars($w['bank_name']); ?></strong>
                <span style="display:block; font-family:monospace; color:var(--gm-gold); font-size:0.78rem;"><?php echo htmlspecialchars($w['account_number']); ?></span>
                <span style="display:block; font-size:0.7rem; color:#a1a1aa;"><?php echo htmlspecialchars($w['account_name']); ?></span>
              </td>
              <td style="color:#a1a1aa; font-size:0.8rem;"><?php echo date('M d, Y h:i A', strtotime($w['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $w['status']; ?>"><?php echo ucfirst($w['status']); ?></span></td>
              <td style="text-align:right;">
                <?php if ($w['status'] === 'pending'): ?>
                  <div style="display:inline-flex; gap:6px;">
                    <form method="POST" action="/admin/withdrawals.php" style="display:inline;">
                      <?php echo csrf_input(); ?>
                      <input type="hidden" name="action" value="approve">
                      <input type="hidden" name="withdrawal_id" value="<?php echo $w['id']; ?>">
                      <button type="submit" class="btn-action-approve"><i class="fa-solid fa-check"></i> Approve Disburse</button>
                    </form>
                    <form method="POST" action="/admin/withdrawals.php" style="display:inline;">
                      <?php echo csrf_input(); ?>
                      <input type="hidden" name="action" value="reject">
                      <input type="hidden" name="withdrawal_id" value="<?php echo $w['id']; ?>">
                      <button type="submit" class="btn-action-reject"><i class="fa-solid fa-xmark"></i> Reject & Refund</button>
                    </form>
                  </div>
                <?php else: ?>
                  <span style="color:#71717a; font-size:0.75rem;">Processed</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
