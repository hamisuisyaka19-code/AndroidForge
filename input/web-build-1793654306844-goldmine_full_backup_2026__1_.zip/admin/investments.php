<?php
$admin_page_title = "Investment Orders Management";
$admin_page_subtitle = "Review pending orders, approve start dates & enforce audit controls";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['inv_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $inv_id = (int)$_POST['inv_id'];
        $action = $_POST['action'];
        $admin_id = (int)$_SESSION['admin_id'];

        if ($pdo && $inv_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM investments WHERE id = ? LIMIT 1");
            $stmt->execute([$inv_id]);
            $inv = $stmt->fetch();

            if (!$inv) {
                $error = "Investment order not found.";
            } elseif ($inv['status'] !== 'pending') {
                $error = "This investment order has already been processed (Current status: " . ucfirst($inv['status']) . ").";
            } else {
                if ($action === 'approve') {
                    $start_date = date('Y-m-d H:i:s');
                    $days = (int)$inv['duration_days'];
                    $maturity_date = date('Y-m-d H:i:s', strtotime("+$days days"));

                    $upd = $pdo->prepare("UPDATE investments SET status = 'active', start_date = ?, maturity_date = ?, admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$start_date, $maturity_date, $admin_id, $inv_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE reference_code = ?");
                    $t_upd->execute([$inv['reference_code']]);

                    add_user_notification(
                        (int)$inv['user_id'],
                        "Investment Order Approved!",
                        "Your investment " . $inv['reference_code'] . " in " . $inv['plan_name'] . " has been approved! Counting Date countdown is now live.",
                        "success",
                        "/counting-date.php"
                    );

                    log_audit_action($admin_id, (int)$inv['user_id'], "Approved Investment", "Reference: " . $inv['reference_code']);
                    $notice = "Order " . htmlspecialchars($inv['reference_code']) . " approved successfully! Countdown is now active.";
                } elseif ($action === 'reject') {
                    $reason = sanitize($_POST['reject_reason'] ?? 'Verification declined by administrator.');
                    $pdo->beginTransaction();

                    // Refund user balance
                    $ref_upd = $pdo->prepare("UPDATE users SET balance = balance + ?, total_invested = GREATEST(0, total_invested - ?) WHERE id = ?");
                    $ref_upd->execute([$inv['amount'], $inv['amount'], $inv['user_id']]);

                    $upd = $pdo->prepare("UPDATE investments SET status = 'rejected', admin_notes = ?, admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$reason, $admin_id, $inv_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'failed' WHERE reference_code = ?");
                    $t_upd->execute([$inv['reference_code']]);

                    add_user_notification(
                        (int)$inv['user_id'],
                        "Investment Order Rejected",
                        "Your order " . $inv['reference_code'] . " was rejected ($reason). ₦" . number_format((float)$inv['amount'], 2) . " has been refunded to your available balance.",
                        "danger",
                        "/my-invest.php"
                    );

                    log_audit_action($admin_id, (int)$inv['user_id'], "Rejected Investment", "Reference: " . $inv['reference_code'] . " - Reason: $reason");
                    $pdo->commit();
                    $notice = "Order " . htmlspecialchars($inv['reference_code']) . " rejected and refunded.";
                }
            }
        }
    }
}

$filter_status = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$where_clauses = [];
$params = [];

if ($filter_status !== 'all' && in_array($filter_status, ['pending', 'active', 'completed', 'rejected'])) {
    $where_clauses[] = "i.status = ?";
    $params[] = $filter_status;
}

if (!empty($search)) {
    $where_clauses[] = "(i.reference_code LIKE ? OR u.full_name LIKE ? OR i.plan_name LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$where_sql = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";

$orders = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT i.*, u.full_name as user_name, u.email as user_email
                               FROM investments i
                               JOIN users u ON i.user_id = u.id
                               $where_sql
                               ORDER BY CASE WHEN i.status = 'pending' THEN 1 ELSE 2 END, i.id DESC
                               LIMIT 50");
        $stmt->execute($params);
        $orders = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Failed to retrieve orders: " . $e->getMessage();
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:14px;">
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <a href="/admin/investments.php?status=all" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
      <a href="/admin/investments.php?status=pending" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'pending' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Pending</a>
      <a href="/admin/investments.php?status=active" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'active' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Active</a>
      <a href="/admin/investments.php?status=completed" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'completed' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Completed</a>
      <a href="/admin/investments.php?status=rejected" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'rejected' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Rejected</a>
    </div>

    <form method="GET" action="/admin/investments.php" style="display:flex; gap:8px;">
      <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ref or user..." class="form-control" style="width:200px; padding:7px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:7px 12px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Ref Code</th>
          <th>User</th>
          <th>Plan Name</th>
          <th>Amount</th>
          <th>Expected Return</th>
          <th>Date Submitted</th>
          <th>Status</th>
          <th style="text-align:right;">Admin Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
          <tr><td colspan="8" style="text-align:center; color:#71717a; padding:35px;">No investment orders found.</td></tr>
        <?php else: ?>
          <?php foreach ($orders as $ord): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($ord['reference_code']); ?></td>
              <td>
                <a href="/admin/user-details.php?id=<?php echo $ord['user_id']; ?>" style="color:#fff; font-weight:600; text-decoration:none;"><?php echo htmlspecialchars($ord['user_name']); ?></a>
                <span style="display:block; font-size:0.7rem; color:#71717a;"><?php echo htmlspecialchars($ord['user_email']); ?></span>
              </td>
              <td><?php echo htmlspecialchars($ord['plan_name']); ?> <span style="font-size:0.7rem; color:var(--gm-gold);">(<?php echo (float)$ord['roi_percentage']; ?>%)</span></td>
              <td style="font-weight:800; color:#fff;">₦<?php echo number_format((float)$ord['amount'], 2); ?></td>
              <td style="font-weight:700; color:#22c55e;">₦<?php echo number_format((float)$ord['expected_return'], 2); ?></td>
              <td style="color:#a1a1aa; font-size:0.8rem;"><?php echo date('M d, Y h:i A', strtotime($ord['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $ord['status']; ?>"><?php echo ucfirst($ord['status']); ?></span></td>
              <td style="text-align:right;">
                <?php if ($ord['status'] === 'pending'): ?>
                  <div style="display:inline-flex; gap:6px;">
                    <form method="POST" action="/admin/investments.php" style="display:inline;">
                      <?php echo csrf_input(); ?>
                      <input type="hidden" name="action" value="approve">
                      <input type="hidden" name="inv_id" value="<?php echo $ord['id']; ?>">
                      <button type="submit" class="btn-action-approve"><i class="fa-solid fa-check"></i> Approve</button>
                    </form>
                    <button onclick="promptReject(<?php echo $ord['id']; ?>, '<?php echo htmlspecialchars($ord['reference_code']); ?>')" class="btn-action-reject">
                      <i class="fa-solid fa-xmark"></i> Reject
                    </button>
                  </div>
                <?php else: ?>
                  <span style="color:#71717a; font-size:0.75rem;">Processed</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Reject -->
<div id="rejectModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.85); z-index:100; align-items:center; justify-content:center; padding:20px;">
  <div style="background:#18181b; border:1px solid #ef4444; border-radius:18px; max-width:440px; width:100%; padding:24px;">
    <h4 style="color:#fff; margin:0 0 8px 0; font-size:1.1rem;">Reject Investment Order</h4>
    <p id="rejectModalSub" style="color:#a1a1aa; font-size:0.8rem; margin-bottom:14px;"></p>
    <form method="POST" action="/admin/investments.php">
      <?php echo csrf_input(); ?>
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="inv_id" id="rejectInvId" value="0">
      <div class="form-group">
        <label class="form-label">Rejection Reason (Sent to User)</label>
        <textarea name="reject_reason" rows="3" class="form-control" placeholder="e.g. Incomplete transaction audit validation..." required>Payment verification incomplete</textarea>
      </div>
      <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:14px;">
        <button type="button" onclick="closeRejectModal()" class="btn-outline" style="width:auto; padding:8px 16px;">Cancel</button>
        <button type="submit" class="btn-action-reject" style="padding:8px 18px;">Confirm Reject & Refund</button>
      </div>
    </form>
  </div>
</div>

<script>
function promptReject(id, ref) {
  document.getElementById('rejectInvId').value = id;
  document.getElementById('rejectModalSub').innerText = "Order " + ref + " will be rejected and the invested amount refunded to user's balance.";
  document.getElementById('rejectModal').style.display = 'flex';
}
function closeRejectModal() {
  document.getElementById('rejectModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
