<?php
$admin_page_title = "Notification Broadcast Center";
$admin_page_subtitle = "Deliver in-app alerts, security advisories & order updates to users";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_broadcast'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired.";
    } else {
        $target = $_POST['target'] ?? 'all';
        $title = sanitize($_POST['title'] ?? '');
        $message = sanitize($_POST['message'] ?? '');
        $type = in_array($_POST['type'] ?? '', ['info', 'success', 'warning', 'danger']) ? $_POST['type'] : 'info';

        if (empty($title) || empty($message)) {
            $error = "Please provide both title and notification message.";
        } elseif ($pdo) {
            try {
                if ($target === 'all') {
                    $u_stmt = $pdo->query("SELECT id FROM users");
                    $all_users = $u_stmt->fetchAll();
                    $ins = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
                    foreach ($all_users as $usr) {
                        $ins->execute([$usr['id'], $title, $message, $type]);
                    }
                    log_audit_action((int)$_SESSION['admin_id'], null, "Broadcast Notification Sent", "To All Users: $title");
                    $notice = "Broadcast dispatched to all " . count($all_users) . " users successfully!";
                } else {
                    $u_id = (int)$_POST['target_user_id'];
                    add_user_notification($u_id, $title, $message, $type);
                    log_audit_action((int)$_SESSION['admin_id'], $u_id, "Individual Notification Sent", $title);
                    $notice = "Notification sent to user #$u_id successfully!";
                }
            } catch (PDOException $e) {
                $error = "Failed to dispatch notification: " . $e->getMessage();
            }
        }
    }
}

// Fetch recent notifications
$recent_notifs = [];
if ($pdo) {
    $stmt = $pdo->query("SELECT n.*, u.full_name as user_name FROM notifications n JOIN users u ON n.user_id = u.id ORDER BY n.id DESC LIMIT 30");
    $recent_notifs = $stmt->fetchAll();
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div style="display:grid; grid-template-columns: 1fr 2fr; gap:20px;">
  <!-- Broadcast Form -->
  <div class="admin-card">
    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin-bottom:14px;"><i class="fa-solid fa-bullhorn" style="color:var(--gm-gold); margin-right:6px;"></i> Send Notification</h4>
    <form method="POST" action="/admin/notifications.php">
      <?php echo csrf_input(); ?>
      <input type="hidden" name="send_broadcast" value="1">

      <div class="form-group">
        <label class="form-label">Audience Target</label>
        <select name="target" class="form-control" onchange="document.getElementById('specificUserBox').style.display = (this.value === 'specific' ? 'block' : 'none');">
          <option value="all">All Registered Users</option>
          <option value="specific">Specific User ID</option>
        </select>
      </div>

      <div class="form-group" id="specificUserBox" style="display:none;">
        <label class="form-label">User ID</label>
        <input type="number" name="target_user_id" class="form-control" placeholder="e.g. 1">
      </div>

      <div class="form-group">
        <label class="form-label">Title</label>
        <input type="text" name="title" class="form-control" placeholder="e.g. System Maintenance Notice" required>
      </div>

      <div class="form-group">
        <label class="form-label">Type / Color</label>
        <select name="type" class="form-control">
          <option value="info">Info (Blue)</option>
          <option value="success">Success (Green)</option>
          <option value="warning">Warning (Amber)</option>
          <option value="danger">Critical (Red)</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Message Body</label>
        <textarea name="message" rows="4" class="form-control" placeholder="Enter message text..." required></textarea>
      </div>

      <button type="submit" class="btn-gold">Dispatch Broadcast</button>
    </form>
  </div>

  <!-- Notification Dispatch History -->
  <div class="admin-card">
    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin-bottom:14px;">Recent Dispatches</h4>
    <div style="overflow-x:auto;">
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Title</th>
            <th>Type</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent_notifs)): ?>
            <tr><td colspan="5" style="text-align:center; color:#71717a; padding:30px;">No notification history.</td></tr>
          <?php else: ?>
            <?php foreach ($recent_notifs as $rn): ?>
              <tr>
                <td><strong style="color:#fff;"><?php echo htmlspecialchars($rn['user_name']); ?></strong></td>
                <td>
                  <span style="font-weight:700; color:#e4e4e7;"><?php echo htmlspecialchars($rn['title']); ?></span>
                  <p style="font-size:0.75rem; color:#a1a1aa; margin:2px 0 0 0;"><?php echo htmlspecialchars($rn['message']); ?></p>
                </td>
                <td><span class="badge badge-<?php echo $rn['type']; ?>"><?php echo ucfirst($rn['type']); ?></span></td>
                <td><span style="font-size:0.75rem; color:<?php echo $rn['is_read'] ? '#22c55e' : '#eab308'; ?>;"><?php echo $rn['is_read'] ? 'Read' : 'Unread'; ?></span></td>
                <td style="color:#71717a; font-size:0.78rem;"><?php echo date('M d, Y h:i A', strtotime($rn['created_at'])); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
