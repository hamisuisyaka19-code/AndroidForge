<?php
$admin_page_title = "Admin Dashboard";
$admin_page_subtitle = "Platform Overview, Metrics & Quick Approvals";
require_once __DIR__ . '/../includes/admin-header.php';

// Action handling for quick approval on dashboard
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_type'], $_POST['inv_id'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $inv_id = (int)$_POST['inv_id'];
        $action = $_POST['action_type'];
        $admin_id = (int)$_SESSION['admin_id'];

        if ($pdo && $inv_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM investments WHERE id = ? LIMIT 1");
            $stmt->execute([$inv_id]);
            $inv = $stmt->fetch();

            if ($inv && $inv['status'] === 'pending') {
                if ($action === 'approve') {
                    $start_date = date('Y-m-d H:i:s');
                    $days = (int)$inv['duration_days'];
                    $maturity_date = date('Y-m-d H:i:s', strtotime("+$days days"));

                    $upd = $pdo->prepare("UPDATE investments SET status = 'active', start_date = ?, maturity_date = ?, admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$start_date, $maturity_date, $admin_id, $inv_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE reference_code = ?");
                    $t_upd->execute([$inv['reference_code']]);

                    add_user_notification(
                        (int)$inv['user_id'],
                        "Investment Order Approved!",
                        "Your investment " . $inv['reference_code'] . " in " . $inv['plan_name'] . " has been approved and is now active. Countdown has started!",
                        "success",
                        "/counting-date.php"
                    );

                    log_audit_action($admin_id, (int)$inv['user_id'], "Approved Investment Order", "Order " . $inv['reference_code']);
                    $notice = "Investment order " . htmlspecialchars($inv['reference_code']) . " approved successfully.";
                } elseif ($action === 'reject') {
                    $pdo->beginTransaction();
                    $ref_upd = $pdo->prepare("UPDATE users SET balance = balance + ?, total_invested = GREATEST(0, total_invested - ?) WHERE id = ?");
                    $ref_upd->execute([$inv['amount'], $inv['amount'], $inv['user_id']]);

                    $upd = $pdo->prepare("UPDATE investments SET status = 'rejected', admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd->execute([$admin_id, $inv_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'failed' WHERE reference_code = ?");
                    $t_upd->execute([$inv['reference_code']]);

                    add_user_notification(
                        (int)$inv['user_id'],
                        "Investment Order Rejected",
                        "Your investment order " . $inv['reference_code'] . " was rejected and ₦" . number_format((float)$inv['amount'], 2) . " was refunded to your balance.",
                        "danger",
                        "/my-invest.php"
                    );

                    log_audit_action($admin_id, (int)$inv['user_id'], "Rejected Investment Order", "Order " . $inv['reference_code']);
                    $pdo->commit();
                    $notice = "Investment order " . htmlspecialchars($inv['reference_code']) . " rejected and refunded.";
                }
            }
        }
    }
}

// Fetch all 7 required statistics
$stat_total_users = 0;
$stat_pending_invests = 0;
$stat_active_invests = 0;
$stat_completed_invests = 0;
$stat_pending_deposits = 0;
$stat_pending_withdrawals = 0;
$stat_total_plans = 0;
$recent_orders = [];

if ($pdo) {
    try {
        $stat_total_users = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $stat_pending_invests = (int)$pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'pending'")->fetchColumn();
        $stat_active_invests = (int)$pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'active'")->fetchColumn();
        $stat_completed_invests = (int)$pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'completed'")->fetchColumn();
        $stat_pending_deposits = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")->fetchColumn();
        $stat_pending_withdrawals = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")->fetchColumn();
        $stat_total_plans = (int)$pdo->query("SELECT COUNT(*) FROM investment_plans")->fetchColumn();

        $stmt = $pdo->query("SELECT i.*, u.full_name as user_name FROM investments i JOIN users u ON i.user_id = u.id ORDER BY i.id DESC LIMIT 8");
        $recent_orders = $stmt->fetchAll();
    } catch (PDOException $e) {
        // Fallback
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<!-- 7 Dashboard Statistics Grid (Requirement 7) -->
<div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 22px;">
  <!-- Total Users -->
  <a href="/admin/users.php" style="text-decoration:none; background: #1e3a8a; border: 1px solid #2563eb; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#93c5fd; font-weight:700; margin:0 0 4px 0;">Total Users</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_total_users); ?></h3>
    </div>
    <i class="fa-solid fa-users" style="font-size: 26px; color:#60a5fa;"></i>
  </a>

  <!-- Pending Investment Orders -->
  <a href="/admin/investments.php?status=pending" style="text-decoration:none; background: #9a3412; border: 1px solid #ea580c; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#fdba74; font-weight:700; margin:0 0 4px 0;">Pending Orders</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_pending_invests); ?></h3>
    </div>
    <i class="fa-solid fa-file-invoice" style="font-size: 26px; color:#fb923c;"></i>
  </a>

  <!-- Active Investments -->
  <a href="/admin/counting-date.php?status=active" style="text-decoration:none; background: #065f46; border: 1px solid #059669; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#a7f3d0; font-weight:700; margin:0 0 4px 0;">Active Invest</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_active_invests); ?></h3>
    </div>
    <i class="fa-solid fa-coins" style="font-size: 26px; color:#34d399;"></i>
  </a>

  <!-- Completed Investments -->
  <a href="/admin/counting-date.php?status=completed" style="text-decoration:none; background: #3730a3; border: 1px solid #4f46e5; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#c7d2fe; font-weight:700; margin:0 0 4px 0;">Completed</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_completed_invests); ?></h3>
    </div>
    <i class="fa-solid fa-circle-check" style="font-size: 26px; color:#818cf8;"></i>
  </a>

  <!-- Pending Deposits -->
  <a href="/admin/deposits.php?status=pending" style="text-decoration:none; background: #134e4a; border: 1px solid #0d9488; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#99f6e4; font-weight:700; margin:0 0 4px 0;">Pending Deposits</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_pending_deposits); ?></h3>
    </div>
    <i class="fa-solid fa-money-bill-transfer" style="font-size: 26px; color:#2dd4bf;"></i>
  </a>

  <!-- Pending Withdrawals -->
  <a href="/admin/withdrawals.php?status=pending" style="text-decoration:none; background: #991b1b; border: 1px solid #dc2626; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#fca5a5; font-weight:700; margin:0 0 4px 0;">Pending Withdrawals</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_pending_withdrawals); ?></h3>
    </div>
    <i class="fa-solid fa-money-bill-wave" style="font-size: 26px; color:#f87171;"></i>
  </a>

  <!-- Total Investment Plans -->
  <a href="/admin/investment-plans.php" style="text-decoration:none; background: #854d0e; border: 1px solid #ca8a04; border-radius: 16px; padding: 18px; display:flex; justify-content:space-between; align-items:center; transition: transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
    <div>
      <p style="font-size:0.72rem; text-transform:uppercase; color:#fef08a; font-weight:700; margin:0 0 4px 0;">Active Plans</p>
      <h3 style="font-size: 1.5rem; font-weight: 800; color:#fff; margin:0;"><?php echo number_format($stat_total_plans); ?></h3>
    </div>
    <i class="fa-solid fa-gem" style="font-size: 26px; color:#facc15;"></i>
  </a>
</div>

<!-- Chart & Quick Actions Row -->
<div style="display:grid; grid-template-columns: 2fr 1fr; gap: 18px; margin-bottom: 22px;">
  <!-- 30-Day SVG Area Chart -->
  <div class="admin-card" style="margin:0;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
      <h4 style="font-size:0.95rem; font-weight:800; color:#fff; margin:0;">Investment Overview (Last 30 Days)</h4>
      <span style="font-size:0.75rem; color:var(--gm-gold); font-weight:700; background:rgba(234,179,8,0.1); padding:3px 10px; border-radius:12px; border:1px solid rgba(234,179,8,0.25);">Live Growth Curve</span>
    </div>
    <div style="height: 180px; width: 100%;">
      <svg viewBox="0 0 500 140" style="width:100%; height:100%;">
        <defs>
          <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#eab308" stop-opacity="0.45"/>
            <stop offset="100%" stop-color="#eab308" stop-opacity="0.0"/>
          </linearGradient>
        </defs>
        <path d="M 0 110 Q 70 70, 120 90 T 250 75 T 380 35 T 500 25 L 500 140 L 0 140 Z" fill="url(#chartGrad)"/>
        <path d="M 0 110 Q 70 70, 120 90 T 250 75 T 380 35 T 500 25" fill="none" stroke="#eab308" stroke-width="3.5"/>
        <circle cx="120" cy="90" r="4.5" fill="#fff" stroke="#eab308" stroke-width="2"/>
        <circle cx="250" cy="75" r="4.5" fill="#fff" stroke="#eab308" stroke-width="2"/>
        <circle cx="380" cy="35" r="4.5" fill="#fff" stroke="#eab308" stroke-width="2"/>
        <circle cx="500" cy="25" r="4.5" fill="#fff" stroke="#eab308" stroke-width="2"/>
      </svg>
    </div>
    <div style="display:flex; justify-content:space-between; font-size:0.72rem; color:#71717a; margin-top:6px;">
      <span>Oct 1</span><span>Oct 7</span><span>Oct 13</span><span>Oct 19</span><span>Oct 25</span>
    </div>
  </div>

  <!-- Quick Actions Navigation Links -->
  <div class="admin-card" style="margin:0;">
    <h4 style="font-size:0.95rem; font-weight:800; color:#fff; margin-bottom:14px;">Quick Actions</h4>
    <div style="display:flex; flex-direction:column; gap:9px;">
      <a href="/admin/investments.php?status=pending" class="btn-outline" style="text-align:left; font-size:0.82rem; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">
        <span><i class="fa-solid fa-check" style="color:#22c55e; margin-right:6px;"></i> Approve Invest Orders</span>
        <?php if ($stat_pending_invests > 0): ?><span class="badge-count" style="background:#ea580c; color:#fff;"><?php echo $stat_pending_invests; ?></span><?php endif; ?>
      </a>
      <a href="/admin/deposits.php?status=pending" class="btn-outline" style="text-align:left; font-size:0.82rem; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">
        <span><i class="fa-solid fa-money-bill-transfer" style="color:#2dd4bf; margin-right:6px;"></i> Approve Deposits</span>
        <?php if ($stat_pending_deposits > 0): ?><span class="badge-count" style="background:#059669; color:#fff;"><?php echo $stat_pending_deposits; ?></span><?php endif; ?>
      </a>
      <a href="/admin/withdrawals.php?status=pending" class="btn-outline" style="text-align:left; font-size:0.82rem; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">
        <span><i class="fa-solid fa-money-bill-wave" style="color:#f87171; margin-right:6px;"></i> Approve Withdrawals</span>
        <?php if ($stat_pending_withdrawals > 0): ?><span class="badge-count" style="background:#dc2626; color:#fff;"><?php echo $stat_pending_withdrawals; ?></span><?php endif; ?>
      </a>
      <a href="/admin/counting-date.php" class="btn-outline" style="text-align:left; font-size:0.82rem; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">
        <span><i class="fa-solid fa-clock" style="color:var(--gm-gold); margin-right:6px;"></i> View Counting Dates</span>
        <span class="badge-count" style="background:#1e3a8a; color:#fff;"><?php echo $stat_active_invests; ?></span>
      </a>
      <a href="/admin/investment-plans.php" class="btn-outline" style="text-align:left; font-size:0.82rem; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">
        <span><i class="fa-solid fa-gem" style="color:var(--gm-gold); margin-right:6px;"></i> Manage Plans</span>
        <i class="fa-solid fa-chevron-right" style="font-size:10px; color:#71717a;"></i>
      </a>
    </div>
  </div>
</div>

<!-- Recent Investment Orders Table -->
<div class="admin-card">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin:0;">Recent Investment Orders</h4>
    <a href="/admin/investments.php" style="font-size:0.8rem; color:var(--gm-gold); font-weight:600; text-decoration:none;">View All Orders <i class="fa-solid fa-arrow-right"></i></a>
  </div>

  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>User</th>
          <th>Plan</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Status</th>
          <th style="text-align:right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recent_orders)): ?>
          <tr><td colspan="7" style="text-align:center; color:#71717a; padding:30px;">No investment orders recorded yet.</td></tr>
        <?php else: ?>
          <?php foreach ($recent_orders as $o): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($o['reference_code']); ?></td>
              <td style="font-weight:600; color:#fff;"><?php echo htmlspecialchars($o['user_name']); ?></td>
              <td><?php echo htmlspecialchars($o['plan_name']); ?></td>
              <td style="font-weight:800; color:#fff;">₦<?php echo number_format((float)$o['amount'], 2); ?></td>
              <td style="color:#a1a1aa; font-size:0.8rem;"><?php echo date('M d, Y', strtotime($o['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo ucfirst($o['status']); ?></span></td>
              <td style="text-align:right;">
                <?php if ($o['status'] === 'pending'): ?>
                  <form method="POST" action="/admin/dashboard.php" style="display:inline-flex; gap:6px;">
                    <?php echo csrf_input(); ?>
                    <input type="hidden" name="inv_id" value="<?php echo $o['id']; ?>">
                    <button type="submit" name="action_type" value="approve" class="btn-action-approve">
                      <i class="fa-solid fa-check"></i> Approve
                    </button>
                    <button type="submit" name="action_type" value="reject" class="btn-action-reject">
                      <i class="fa-solid fa-xmark"></i> Reject
                    </button>
                  </form>
                <?php else: ?>
                  <span style="color:#71717a; font-size:0.75rem; font-weight:600;">Processed</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
