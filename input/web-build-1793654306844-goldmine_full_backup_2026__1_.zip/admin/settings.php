<?php
$admin_page_title = "Platform Configuration & Security Settings";
$admin_page_subtitle = "Configure global application parameters, withdrawal thresholds & API modes";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired.";
    } elseif ($pdo) {
        $fields = [
            'app_name' => sanitize($_POST['app_name'] ?? 'GoldMine Investment Platform'),
            'site_url' => sanitize($_POST['site_url'] ?? 'https://goalmindai.com.ng'),
            'contact_email' => sanitize($_POST['contact_email'] ?? 'support@goalmindai.com.ng'),
            'currency_symbol' => sanitize($_POST['currency_symbol'] ?? '₦'),
            'min_withdrawal' => (string)(float)($_POST['min_withdrawal'] ?? 2000),
            'max_withdrawal' => (string)(float)($_POST['max_withdrawal'] ?? 500000),
            'flutterwave_mode' => in_array($_POST['flutterwave_mode'] ?? '', ['sandbox', 'live']) ? $_POST['flutterwave_mode'] : 'sandbox',
            'financial_settlement_enabled' => isset($_POST['financial_settlement_enabled']) ? '1' : '0'
        ];

        try {
            $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)");
            foreach ($fields as $k => $v) {
                $stmt->execute([$k, $v]);
            }
            log_audit_action((int)$_SESSION['admin_id'], null, "Updated Application Settings", "Configuration saved");
            $notice = "Settings updated successfully!";
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Load current settings
$current_settings = [];
if ($pdo) {
    try {
        $rows = $pdo->query("SELECT key_name, value FROM settings")->fetchAll();
        foreach ($rows as $r) {
            $current_settings[$r['key_name']] = $r['value'];
        }
    } catch (PDOException $e) {
        // fallback
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="max-width:700px;">
  <form method="POST" action="/admin/settings.php">
    <?php echo csrf_input(); ?>
    <input type="hidden" name="save_settings" value="1">

    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin-bottom:16px;">General Website Settings</h4>
    <div class="form-group">
      <label class="form-label">Application Name</label>
      <input type="text" name="app_name" class="form-control" value="<?php echo htmlspecialchars($current_settings['app_name'] ?? 'GoldMine Investment Platform'); ?>" required>
    </div>

    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
      <div class="form-group">
        <label class="form-label">Website Domain URL</label>
        <input type="url" name="site_url" class="form-control" value="<?php echo htmlspecialchars($current_settings['site_url'] ?? 'https://goalmindai.com.ng'); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Contact / Support Email</label>
        <input type="email" name="contact_email" class="form-control" value="<?php echo htmlspecialchars($current_settings['contact_email'] ?? 'support@goalmindai.com.ng'); ?>" required>
      </div>
    </div>

    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin:22px 0 16px 0; border-top:1px solid #222226; padding-top:16px;">Financial Thresholds</h4>
    <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:12px;">
      <div class="form-group">
        <label class="form-label">Currency Symbol</label>
        <input type="text" name="currency_symbol" class="form-control" value="<?php echo htmlspecialchars($current_settings['currency_symbol'] ?? '₦'); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Min Withdrawal (₦)</label>
        <input type="number" name="min_withdrawal" class="form-control" value="<?php echo htmlspecialchars($current_settings['min_withdrawal'] ?? '2000'); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Max Withdrawal (₦)</label>
        <input type="number" name="max_withdrawal" class="form-control" value="<?php echo htmlspecialchars($current_settings['max_withdrawal'] ?? '500000'); ?>" required>
      </div>
    </div>

    <h4 style="font-size:1rem; font-weight:800; color:#fff; margin:22px 0 16px 0; border-top:1px solid #222226; padding-top:16px;">Payment Gateway (Flutterwave)</h4>
    <div class="form-group">
      <label class="form-label">Environment Mode</label>
      <select name="flutterwave_mode" class="form-control">
        <option value="sandbox" <?php echo ($current_settings['flutterwave_mode'] ?? '') === 'sandbox' ? 'selected' : ''; ?>>Sandbox (Test Mode)</option>
        <option value="live" <?php echo ($current_settings['flutterwave_mode'] ?? '') === 'live' ? 'selected' : ''; ?>>Live Production Mode</option>
      </select>
    </div>

    <button type="submit" class="btn-gold" style="margin-top:14px;">Save Configuration Changes</button>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
