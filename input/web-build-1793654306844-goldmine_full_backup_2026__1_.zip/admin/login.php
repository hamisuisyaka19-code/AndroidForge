<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired. Please try again.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $pdo = get_db_connection();
        if ($pdo) {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE (username = ? OR email = ?) AND status = 'active' LIMIT 1");
            $stmt->execute([$username, $username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['admin_role'] = $admin['role'];

                $upd = $pdo->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
                $upd->execute([$admin['id']]);

                log_audit_action((int)$admin['id'], null, "Admin Login", "Logged into admin panel");
                header("Location: /admin/dashboard.php");
                exit;
            } else {
                $error = "Invalid administrator credentials.";
            }
        } else {
            $error = "Database connection error.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login - GoldMine Investment Platform</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: #09090b; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
    .login-box { max-width: 420px; width: 100%; background: #141417; border: 1px solid #27272a; border-radius: 20px; padding: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.8); }
  </style>
</head>
<body>
<div class="login-box">
  <div style="text-align:center; margin-bottom: 24px;">
    <div style="display:inline-flex; align-items:center; justify-content:center; width:56px; height:56px; background:linear-gradient(135deg, #facc15 0%, #ca8a04 100%); border-radius:16px; margin-bottom:10px;">
      <span style="font-size:24px; font-weight:900; color:#000;">GM</span>
    </div>
    <h3 style="color:#fff; font-size:1.3rem; font-weight:800; margin:0;">GoldMine Admin</h3>
    <p style="color:#a1a1aa; font-size:0.75rem; text-transform:uppercase; margin-top:4px;">Secure Administrative Portal</p>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 10px 14px; border-radius: 10px; font-size: 0.85rem; margin-bottom: 16px;">
      <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/admin/login.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Username or Admin Email</label>
      <input type="text" name="username" class="form-control" required placeholder="admin">
    </div>
    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required placeholder="••••••••">
    </div>
    <button type="submit" class="btn-gold" style="margin-top: 10px;">Access Admin Portal</button>
  </form>
</div>
</body>
</html>
