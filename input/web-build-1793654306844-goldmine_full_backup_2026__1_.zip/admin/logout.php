<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/session.php';
unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_email'], $_SESSION['admin_role']);
header("Location: /admin/login.php");
exit;
