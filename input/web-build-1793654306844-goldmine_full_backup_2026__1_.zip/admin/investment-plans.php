<?php
$admin_page_title = "Investment Plans Management";
$admin_page_subtitle = "Configure packages, ROI returns, duration & deposit limits";
require_once __DIR__ . '/../includes/admin-header.php';

$error = '';
$success = '';

// Handle Create / Edit Plan POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $plan_id = (int)($_POST['plan_id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $slug = sanitize(strtolower(str_replace(' ', '-', $name)));
        $min_amount = (float)($_POST['min_amount'] ?? 0);
        $max_amount = (float)($_POST['max_amount'] ?? 0);
        $roi_percentage = (float)($_POST['roi_percentage'] ?? 0);
        $duration_days = (int)($_POST['duration_days'] ?? 0);
        $description = sanitize($_POST['description'] ?? '');
        $status = in_array($_POST['status'] ?? '', ['active', 'inactive']) ? $_POST['status'] : 'active';
        $sort_order = (int)($_POST['sort_order'] ?? 0);

        if ($action === 'create' || $action === 'edit') {
            if (empty($name) || $min_amount <= 0 || $max_amount < $min_amount || $roi_percentage <= 0 || $duration_days <= 0) {
                $error = "Please fill in all fields with valid amounts and positive durations.";
            } elseif ($pdo) {
                try {
                    if ($action === 'create') {
                        $stmt = $pdo->prepare("INSERT INTO investment_plans (name, slug, min_amount, max_amount, roi_percentage, duration_days, description, status, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$name, $slug, $min_amount, $max_amount, $roi_percentage, $duration_days, $description, $status, $sort_order]);
                        log_audit_action((int)$_SESSION['admin_id'], null, "Created Investment Plan", "Plan: $name with {$roi_percentage}% ROI");
                        $success = "Investment plan '$name' created successfully!";
                    } elseif ($action === 'edit' && $plan_id > 0) {
                        $stmt = $pdo->prepare("UPDATE investment_plans SET name = ?, slug = ?, min_amount = ?, max_amount = ?, roi_percentage = ?, duration_days = ?, description = ?, status = ?, sort_order = ? WHERE id = ?");
                        $stmt->execute([$name, $slug, $min_amount, $max_amount, $roi_percentage, $duration_days, $description, $status, $sort_order, $plan_id]);
                        log_audit_action((int)$_SESSION['admin_id'], null, "Updated Investment Plan", "Plan ID $plan_id: $name");
                        $success = "Investment plan '$name' updated successfully!";
                    }
                } catch (PDOException $e) {
                    $error = "Database error: " . $e->getMessage();
                }
            }
        } elseif ($action === 'toggle_status' && $plan_id > 0) {
            $stmt = $pdo->prepare("UPDATE investment_plans SET status = CASE WHEN status = 'active' THEN 'inactive' ELSE 'active' END WHERE id = ?");
            $stmt->execute([$plan_id]);
            log_audit_action((int)$_SESSION['admin_id'], null, "Toggled Plan Status", "Plan ID $plan_id");
            $success = "Plan status updated!";
        }
    }
}

// Fetch all plans
$plans = [];
if ($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM investment_plans ORDER BY sort_order ASC, min_amount ASC");
        $plans = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Failed to load plans: " . $e->getMessage();
    }
}
?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($success); ?>
  </div>
<?php endif; ?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;">
  <div>
    <h3 style="font-size:1.1rem; font-weight:800; color:#fff; margin:0;">Available Investment Plans (<?php echo count($plans); ?>)</h3>
    <p style="font-size:0.75rem; color:#a1a1aa; margin:2px 0 0 0;">All modifications are immediately reflected in real-time on the user Invest screen.</p>
  </div>
  <button onclick="openPlanModal('create')" class="btn-gold" style="width:auto; padding:10px 18px; font-size:0.82rem;">
    <i class="fa-solid fa-plus"></i> Create New Plan
  </button>
</div>

<!-- Plans Grid / Table -->
<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Order</th>
          <th>Plan Name</th>
          <th>Min Amount</th>
          <th>Max Amount</th>
          <th>ROI %</th>
          <th>Duration</th>
          <th>Description</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($plans)): ?>
          <tr><td colspan="9" style="text-align:center; color:#71717a; padding:30px;">No investment plans configured.</td></tr>
        <?php else: ?>
          <?php foreach ($plans as $p): ?>
            <tr>
              <td style="color:#71717a; font-weight:700;"><?php echo $p['sort_order']; ?></td>
              <td>
                <strong style="color:#fff; font-size:0.9rem;"><?php echo htmlspecialchars($p['name']); ?></strong>
                <span style="display:block; font-size:0.7rem; color:#71717a; font-family:monospace;"><?php echo htmlspecialchars($p['slug']); ?></span>
              </td>
              <td style="font-weight:700; color:#fff;">₦<?php echo number_format((float)$p['min_amount'], 2); ?></td>
              <td style="font-weight:700; color:#fff;">₦<?php echo number_format((float)$p['max_amount'], 2); ?></td>
              <td>
                <span style="color:var(--gm-gold); font-weight:800; font-size:0.9rem;"><?php echo (float)$p['roi_percentage']; ?>% ROI</span>
              </td>
              <td>
                <span style="font-weight:700; color:#e4e4e7;"><?php echo $p['duration_days']; ?> Days</span>
              </td>
              <td style="max-width:200px; color:#a1a1aa; font-size:0.75rem;">
                <?php echo htmlspecialchars($p['description'] ?? ''); ?>
              </td>
              <td>
                <span class="badge badge-<?php echo $p['status'] === 'active' ? 'approved' : 'rejected'; ?>">
                  <?php echo ucfirst($p['status']); ?>
                </span>
              </td>
              <td style="text-align:right;">
                <div style="display:inline-flex; gap:6px;">
                  <button onclick="editPlan(<?php echo htmlspecialchars(json_encode($p)); ?>)" class="btn-outline" style="padding:5px 10px; font-size:0.75rem; width:auto;">
                    <i class="fa-solid fa-pen-to-square"></i> Edit
                  </button>
                  <form method="POST" action="/admin/investment-plans.php" style="display:inline;">
                    <?php echo csrf_input(); ?>
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="plan_id" value="<?php echo $p['id']; ?>">
                    <button type="submit" class="btn-outline" style="padding:5px 10px; font-size:0.75rem; width:auto; border-color:#52525b; color:#d4d4d8;">
                      <?php echo $p['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Create / Edit Plan -->
<div id="planModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.85); z-index:100; align-items:center; justify-content:center; padding:20px;">
  <div style="background:#16161a; border:1px solid #33333b; border-radius:20px; max-width:520px; width:100%; padding:26px; box-shadow:0 12px 45px rgba(0,0,0,0.9);">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;">
      <h4 id="planModalTitle" style="font-size:1.15rem; font-weight:800; color:#fff; margin:0;">Create Investment Plan</h4>
      <button onclick="closePlanModal()" style="background:none; border:none; color:#a1a1aa; font-size:1.2rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
    </div>

    <form method="POST" action="/admin/investment-plans.php">
      <?php echo csrf_input(); ?>
      <input type="hidden" name="action" id="planFormAction" value="create">
      <input type="hidden" name="plan_id" id="planFormId" value="0">

      <div class="form-group">
        <label class="form-label">Plan Name</label>
        <input type="text" name="name" id="planName" class="form-control" placeholder="e.g. Starter Plan" required>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Minimum Amount (₦)</label>
          <input type="number" step="50" name="min_amount" id="planMin" class="form-control" placeholder="500" required>
        </div>
        <div class="form-group">
          <label class="form-label">Maximum Amount (₦)</label>
          <input type="number" step="50" name="max_amount" id="planMax" class="form-control" placeholder="4999" required>
        </div>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">ROI Percentage (%)</label>
          <input type="number" step="0.5" name="roi_percentage" id="planRoi" class="form-control" placeholder="45.00" required>
        </div>
        <div class="form-group">
          <label class="form-label">Duration (Days)</label>
          <input type="number" name="duration_days" id="planDuration" class="form-control" placeholder="2" required>
        </div>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="planStatus" class="form-control">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Display Sort Order</label>
          <input type="number" name="sort_order" id="planSort" class="form-control" placeholder="1" value="1">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Description & Disclosed Terms</label>
        <textarea name="description" id="planDesc" rows="3" class="form-control" placeholder="Plan terms and conditions..."></textarea>
      </div>

      <button type="submit" class="btn-gold" style="margin-top:10px;">Save Investment Plan</button>
    </form>
  </div>
</div>

<script>
function openPlanModal(mode) {
  document.getElementById('planFormAction').value = mode;
  document.getElementById('planModalTitle').innerText = mode === 'create' ? 'Create Investment Plan' : 'Edit Investment Plan';
  if (mode === 'create') {
    document.getElementById('planFormId').value = 0;
    document.getElementById('planName').value = '';
    document.getElementById('planMin').value = '500';
    document.getElementById('planMax').value = '4999';
    document.getElementById('planRoi').value = '45.00';
    document.getElementById('planDuration').value = '2';
    document.getElementById('planDesc').value = 'Standard verified investment plan.';
    document.getElementById('planSort').value = '1';
    document.getElementById('planStatus').value = 'active';
  }
  document.getElementById('planModal').style.display = 'flex';
}

function editPlan(plan) {
  openPlanModal('edit');
  document.getElementById('planFormId').value = plan.id;
  document.getElementById('planName').value = plan.name;
  document.getElementById('planMin').value = plan.min_amount;
  document.getElementById('planMax').value = plan.max_amount;
  document.getElementById('planRoi').value = plan.roi_percentage;
  document.getElementById('planDuration').value = plan.duration_days;
  document.getElementById('planDesc').value = plan.description || '';
  document.getElementById('planSort').value = plan.sort_order || 1;
  document.getElementById('planStatus').value = plan.status;
}

function closePlanModal() {
  document.getElementById('planModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
