<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_admin_login();
$pdo = get_db_connection();
$id = (int)($_GET['id'] ?? 0);
if (!$pdo || $id < 1) { http_response_code(404); exit('Receipt not found.'); }
$stmt = $pdo->prepare('SELECT receipt_path FROM deposits WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$relative = $stmt->fetchColumn();
if (!$relative) { http_response_code(404); exit('No receipt attached to this deposit.'); }
$base = realpath(__DIR__ . '/../uploads/deposit_receipts');
$file = realpath(__DIR__ . '/../' . $relative);
if (!$base || !$file || strpos($file, $base . DIRECTORY_SEPARATOR) !== 0 || !is_file($file)) {
    http_response_code(404); exit('Receipt file not found.');
}
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($file);
$allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
if (!in_array($mime, $allowed, true)) { http_response_code(415); exit('Unsupported receipt format.'); }
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($file));
header('Content-Disposition: inline; filename="deposit-receipt-' . $id . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
readfile($file);
exit;
