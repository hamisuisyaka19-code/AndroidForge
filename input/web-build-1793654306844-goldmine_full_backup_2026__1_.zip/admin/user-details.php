<?php
$admin_page_title = "User Profile & Ledger Details";
$admin_page_subtitle = "Comprehensive individual account records, bank data & balance adjustments";
require_once __DIR__ . '/../includes/admin-header.php';

$user_id = (int)($_GET['id'] ?? 0);
if ($user_id <= 0) {
    echo "<div class='admin-card'><p style='color:#ef4444;'>Invalid user ID provided.</p><a href='/admin/users.php' class='btn-gold' style='display:inline-block; width:auto;'>Back to Users</a></div>";
    require_once __DIR__ . '/../includes/admin-footer.php';
    exit;
}

$notice = '';
$error = '';

// Balance adjustment handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_balance'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired.";
    } else {
        $adj_type = $_POST['adj_type'] ?? 'credit'; // 'credit' or 'debit'
        $adj_amount = (float)($_POST['adj_amount'] ?? 0);
        $reason = sanitize($_POST['reason'] ?? 'Manual Administrative Adjustment');

        if ($adj_amount <= 0) {
            $error = "Please enter an adjustment amount greater than zero.";
        } elseif ($pdo) {
            try {
                $pdo->beginTransaction();
                if ($adj_type === 'credit') {
                    $upd = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $upd->execute([$adj_amount, $user_id]);
                } else {
                    $upd = $pdo->prepare("UPDATE users SET balance = GREATEST(0, balance - ?) WHERE id = ?");
                    $upd->execute([$adj_amount, $user_id]);
                }

                $cur_bal = (float)$pdo->query("SELECT balance FROM users WHERE id = $user_id")->fetchColumn();
                $ref = generate_reference('ADJ');

                $ins_tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'adjustment', ?, ?, 'completed', ?)");
                $ins_tx->execute([$ref, $user_id, $adj_amount, $cur_bal, "$adj_type: $reason"]);

                add_user_notification(
                    $user_id,
                    "Account Balance Adjusted",
                    "Your balance was adjusted by " . ($adj_type === 'credit' ? '+' : '-') . format_currency($adj_amount) . ". Reason: $reason",
                    $adj_type === 'credit' ? 'success' : 'warning'
                );

                log_audit_action((int)$_SESSION['admin_id'], $user_id, "Balance Adjusted ($adj_type)", "Amount: $adj_amount, Reason: $reason");
                $pdo->commit();
                $notice = "Balance adjusted successfully! New balance: " . format_currency($cur_bal);
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Failed to adjust balance: " . $e->getMessage();
            }
        }
    }
}

// Fetch user data
$target_user = null;
$user_investments = [];
$user_deposits = [];
$user_withdrawals = [];

if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $target_user = $stmt->fetch();

    if ($target_user) {
        $inv_stmt = $pdo->prepare("SELECT * FROM investments WHERE user_id = ? ORDER BY id DESC LIMIT 20");
        $inv_stmt->execute([$user_id]);
        $user_investments = $inv_stmt->fetchAll();

        $dep_stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 10");
        $dep_stmt->execute([$user_id]);
        $user_deposits = $dep_stmt->fetchAll();

        $wth_stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY id DESC LIMIT 10");
        $wth_stmt->execute([$user_id]);
        $user_withdrawals = $wth_stmt->fetchAll();
    }
}

if (!$target_user) {
    echo "<div class='admin-card'><p style='color:#ef4444;'>User record not found.</p><a href='/admin/users.php' class='btn-gold' style='display:inline-block; width:auto;'>Back to Users</a></div>";
    require_once __DIR__ . '/../includes/admin-footer.php';
    exit;
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<!-- User Header & Stats Card -->
<div style="display:grid; grid-template-columns: 2fr 1fr; gap:18px; margin-bottom:22px;">
  <div class="admin-card" style="margin:0;">
    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
      <div style="display:flex; gap:16px; align-items:center;">
        <div style="width:58px; height:58px; border-radius:50%; background:#1c1c20; border:2px solid var(--gm-gold); display:flex; align-items:center; justify-content:center; color:var(--gm-gold); font-size:24px;">
          <i class="fa-solid fa-user-tie"></i>
        </div>
        <div>
          <h3 style="font-size:1.3rem; font-weight:800; color:#fff; margin:0;"><?php echo htmlspecialchars($target_user['full_name']); ?></h3>
          <p style="font-size:0.8rem; color:#a1a1aa; margin:2px 0 0 0;"><?php echo htmlspecialchars($target_user['email']); ?> • <?php echo htmlspecialchars($target_user['phone']); ?></p>
          <span style="font-size:0.7rem; color:#71717a;">Registered: <?php echo date('M d, Y h:i A', strtotime($target_user['created_at'])); ?></span>
        </div>
      </div>
      <span class="badge badge-<?php echo $target_user['status'] === 'active' ? 'approved' : 'rejected'; ?>">
        <?php echo ucfirst($target_user['status']); ?>
      </span>
    </div>

    <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:12px; margin-top:20px; padding-top:16px; border-top:1px solid #222226;">
      <div style="background:#18181b; padding:12px; border-radius:12px;">
        <span style="font-size:0.7rem; color:#a1a1aa; text-transform:uppercase;">Available Balance</span>
        <h4 style="font-size:1.25rem; font-weight:800; color:var(--gm-gold); margin:4px 0 0 0;">₦<?php echo number_format((float)$target_user['balance'], 2); ?></h4>
      </div>
      <div style="background:#18181b; padding:12px; border-radius:12px;">
        <span style="font-size:0.7rem; color:#a1a1aa; text-transform:uppercase;">Total Invested</span>
        <h4 style="font-size:1.25rem; font-weight:800; color:#fff; margin:4px 0 0 0;">₦<?php echo number_format((float)$target_user['total_invested'], 2); ?></h4>
      </div>
      <div style="background:#18181b; padding:12px; border-radius:12px;">
        <span style="font-size:0.7rem; color:#a1a1aa; text-transform:uppercase;">Total Profit</span>
        <h4 style="font-size:1.25rem; font-weight:800; color:#22c55e; margin:4px 0 0 0;">₦<?php echo number_format((float)$target_user['total_profit'], 2); ?></h4>
      </div>
    </div>
  </div>

  <!-- Manual Balance Adjustment Tool -->
  <div class="admin-card" style="margin:0;">
    <h4 style="font-size:0.95rem; font-weight:800; color:#fff; margin-bottom:12px;"><i class="fa-solid fa-scale-balanced" style="color:var(--gm-gold); margin-right:6px;"></i> Balance Adjustment</h4>
    <form method="POST" action="/admin/user-details.php?id=<?php echo $user_id; ?>">
      <?php echo csrf_input(); ?>
      <input type="hidden" name="adjust_balance" value="1">
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label" style="font-size:0.75rem;">Action Type</label>
        <select name="adj_type" class="form-control" style="padding:8px 12px; font-size:0.8rem;">
          <option value="credit">Credit Balance (+)</option>
          <option value="debit">Debit Balance (-)</option>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label" style="font-size:0.75rem;">Amount (₦)</label>
        <input type="number" step="100" name="adj_amount" class="form-control" placeholder="1000" style="padding:8px 12px; font-size:0.8rem;" required>
      </div>
      <div class="form-group" style="margin-bottom:12px;">
        <label class="form-label" style="font-size:0.75rem;">Reason (Recorded in Audit Log)</label>
        <input type="text" name="reason" class="form-control" placeholder="e.g. Deposit reconciliation" style="padding:8px 12px; font-size:0.8rem;" required>
      </div>
      <button type="submit" class="btn-gold" style="font-size:0.82rem; padding:10px;">Apply Balance Change</button>
    </form>
  </div>
</div>

<!-- User Investments Table -->
<div class="admin-card">
  <h4 style="font-size:1rem; font-weight:800; color:#fff; margin-bottom:14px;">User Investment History</h4>
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Reference</th>
          <th>Plan</th>
          <th>Amount</th>
          <th>Start Date</th>
          <th>Maturity Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($user_investments)): ?>
          <tr><td colspan="6" style="text-align:center; color:#71717a; padding:20px;">No investment records for this user.</td></tr>
        <?php else: ?>
          <?php foreach ($user_investments as $ui): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($ui['reference_code']); ?></td>
              <td><?php echo htmlspecialchars($ui['plan_name']); ?></td>
              <td style="font-weight:700; color:#fff;">₦<?php echo number_format((float)$ui['amount'], 2); ?></td>
              <td><?php echo !empty($ui['start_date']) ? date('M d, Y', strtotime($ui['start_date'])) : 'Pending'; ?></td>
              <td><?php echo !empty($ui['maturity_date']) ? date('M d, Y', strtotime($ui['maturity_date'])) : 'Pending'; ?></td>
              <td><span class="badge badge-<?php echo $ui['status']; ?>"><?php echo ucfirst($ui['status']); ?></span></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
