<?php
$admin_page_title = "Counting Date & Maturity Management";
$admin_page_subtitle = "Track active countdowns, maturity dates & automated completion";
require_once __DIR__ . '/../includes/admin-header.php';

// Trigger automatic maturity checks
check_and_update_matured_investments();

$filter_status = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

$where_clauses = [];
$params = [];

if ($filter_status !== 'all' && in_array($filter_status, ['pending', 'active', 'completed', 'rejected'])) {
    $where_clauses[] = "i.status = ?";
    $params[] = $filter_status;
}

if (!empty($search)) {
    $where_clauses[] = "(i.reference_code LIKE ? OR u.full_name LIKE ? OR i.plan_name LIKE ?)";
    $like_search = "%$search%";
    $params[] = $like_search;
    $params[] = $like_search;
    $params[] = $like_search;
}

$where_sql = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";

// Count total matching
$total_rows = 0;
$investments = [];

if ($pdo) {
    try {
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM investments i JOIN users u ON i.user_id = u.id $where_sql");
        $count_stmt->execute($params);
        $total_rows = (int)$count_stmt->fetchColumn();

        $query = "SELECT i.*, u.full_name as user_name, u.email as user_email
                  FROM investments i
                  JOIN users u ON i.user_id = u.id
                  $where_sql
                  ORDER BY CASE WHEN i.status = 'active' THEN 1 WHEN i.status = 'pending' THEN 2 ELSE 3 END, i.maturity_date ASC, i.id DESC
                  LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $investments = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Counting date query failed: " . $e->getMessage());
    }
}

$total_pages = max(1, ceil($total_rows / $limit));
$now = time();
?>

<!-- Filter & Search Controls -->
<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:14px;">
    <!-- Status Filter Buttons -->
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <a href="/admin/counting-date.php?status=all<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"
         style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">
        All (<?php echo $total_rows; ?>)
      </a>
      <a href="/admin/counting-date.php?status=active<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"
         style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'active' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">
        Active
      </a>
      <a href="/admin/counting-date.php?status=completed<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"
         style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'completed' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">
        Completed
      </a>
      <a href="/admin/counting-date.php?status=pending<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"
         style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'pending' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">
        Pending
      </a>
      <a href="/admin/counting-date.php?status=rejected<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"
         style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'rejected' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">
        Rejected
      </a>
    </div>

    <!-- Search Form -->
    <form method="GET" action="/admin/counting-date.php" style="display:flex; gap:8px;">
      <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ref or user..." class="form-control" style="width:220px; padding:8px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:8px 14px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
      <?php if (!empty($search)): ?>
        <a href="/admin/counting-date.php?status=<?php echo htmlspecialchars($filter_status); ?>" class="btn-outline" style="width:auto; padding:8px 12px; font-size:0.8rem;">Clear</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Main Table -->
<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Reference</th>
          <th>User</th>
          <th>Plan & ROI</th>
          <th>Amount</th>
          <th>Start Date</th>
          <th>Maturity Date</th>
          <th>Remaining Time</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($investments)): ?>
          <tr><td colspan="9" style="text-align:center; color:#71717a; padding:35px;">No investment records found matching criteria.</td></tr>
        <?php else: ?>
          <?php foreach ($investments as $inv):
              $start_ts = !empty($inv['start_date']) ? strtotime($inv['start_date']) : null;
              $end_ts = !empty($inv['maturity_date']) ? strtotime($inv['maturity_date']) : null;
              $is_matured = ($end_ts !== null && $end_ts <= $now);

              // Calculate remaining days/hours/minutes
              $remaining_text = "N/A";
              if ($inv['status'] === 'active' && $end_ts !== null) {
                  $diff = $end_ts - $now;
                  if ($diff <= 0) {
                      $remaining_text = "<span style='color:#22c55e; font-weight:800;'><i class='fa-solid fa-flag-checkered'></i> Matured</span>";
                  } else {
                      $d = floor($diff / 86400);
                      $h = floor(($diff % 86400) / 3600);
                      $m = floor(($diff % 3600) / 60);
                      $remaining_text = "<strong style='color:var(--gm-gold);'>{$d}d {$h}h {$m}m</strong>";
                  }
              } elseif ($inv['status'] === 'completed') {
                  $remaining_text = "<span style='color:#3b82f6;'><i class='fa-solid fa-circle-check'></i> Finished</span>";
              } elseif ($inv['status'] === 'pending') {
                  $remaining_text = "<span style='color:#ea580c;'>Awaiting Approval</span>";
              }
          ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);">
                <?php echo htmlspecialchars($inv['reference_code']); ?>
              </td>
              <td>
                <strong style="color:#fff;"><?php echo htmlspecialchars($inv['user_name']); ?></strong>
                <span style="display:block; font-size:0.72rem; color:#71717a;"><?php echo htmlspecialchars($inv['user_email']); ?></span>
              </td>
              <td>
                <span style="font-weight:600; color:#e4e4e7;"><?php echo htmlspecialchars($inv['plan_name']); ?></span>
                <span style="display:block; font-size:0.72rem; color:var(--gm-gold);"><?php echo (float)$inv['roi_percentage']; ?>% ROI (<?php echo $inv['duration_days']; ?> Days)</span>
              </td>
              <td style="font-weight:800; color:#fff;">
                ₦<?php echo number_format((float)$inv['amount'], 2); ?>
              </td>
              <td style="font-size:0.8rem; color:#d4d4d8;">
                <?php echo $start_ts ? date('M d, Y h:i A', $start_ts) : '<span style="color:#71717a;">Pending</span>'; ?>
              </td>
              <td style="font-size:0.8rem; color:<?php echo $is_matured ? '#22c55e' : '#facc15'; ?>; font-weight:600;">
                <?php echo $end_ts ? date('M d, Y h:i A', $end_ts) : '<span style="color:#71717a;">Not started</span>'; ?>
              </td>
              <td style="font-size:0.82rem;">
                <?php echo $remaining_text; ?>
              </td>
              <td>
                <span class="badge badge-<?php echo $inv['status']; ?>"><?php echo ucfirst($inv['status']); ?></span>
              </td>
              <td style="text-align:right;">
                <a href="/admin/user-details.php?id=<?php echo $inv['user_id']; ?>" class="btn-outline" style="padding:4px 10px; font-size:0.75rem; display:inline-block; width:auto;">
                  User Details
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($total_pages > 1): ?>
    <div style="display:flex; justify-content:center; gap:6px; margin-top:20px;">
      <?php for ($p = 1; $p <= $total_pages; $p++): ?>
        <a href="/admin/counting-date.php?page=<?php echo $p; ?>&status=<?php echo urlencode($filter_status); ?>&search=<?php echo urlencode($search); ?>"
           style="padding:6px 12px; border-radius:8px; font-size:0.8rem; text-decoration:none; <?php echo $p === $page ? 'background:var(--gm-gold); color:#000; font-weight:800;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">
          <?php echo $p; ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
