<?php
$admin_page_title = "User Management";
$admin_page_subtitle = "Registered investor profiles, balance records & account controls";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['user_id'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $u_id = (int)$_POST['user_id'];
        $act = $_POST['action'];

        if ($act === 'toggle_status' && $pdo && $u_id > 0) {
            $stmt = $pdo->prepare("UPDATE users SET status = CASE WHEN status = 'active' THEN 'suspended' ELSE 'active' END WHERE id = ?");
            $stmt->execute([$u_id]);
            log_audit_action((int)$_SESSION['admin_id'], $u_id, "Toggled User Account Status", "User ID $u_id");
            $notice = "User account status updated.";
        }
    }
}

$search = trim($_GET['search'] ?? '');
$filter_status = $_GET['status'] ?? 'all';

$where = [];
$params = [];
if ($filter_status !== 'all' && in_array($filter_status, ['active', 'suspended'])) {
    $where[] = "status = ?";
    $params[] = $filter_status;
}
if (!empty($search)) {
    $where[] = "(full_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}

$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$users = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users $where_sql ORDER BY id DESC LIMIT 50");
        $stmt->execute($params);
        $users = $stmt->fetchAll();
    } catch (PDOException $e) {
        // error handling
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
    <div style="display:flex; gap:8px;">
      <a href="/admin/users.php?status=all" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
      <a href="/admin/users.php?status=active" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'active' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Active</a>
      <a href="/admin/users.php?status=suspended" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'suspended' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Suspended</a>
    </div>

    <form method="GET" action="/admin/users.php" style="display:flex; gap:8px;">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search name, email, phone..." class="form-control" style="width:220px; padding:7px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:7px 12px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>User ID</th>
          <th>Full Name</th>
          <th>Email & Phone</th>
          <th>Available Balance</th>
          <th>Total Invested</th>
          <th>Registered</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($users)): ?>
          <tr><td colspan="8" style="text-align:center; color:#71717a; padding:35px;">No users found.</td></tr>
        <?php else: ?>
          <?php foreach ($users as $u): ?>
            <tr>
              <td style="font-family:monospace; color:#a1a1aa;">#<?php echo $u['id']; ?></td>
              <td><strong style="color:#fff;"><?php echo htmlspecialchars($u['full_name']); ?></strong></td>
              <td>
                <span style="display:block; color:#d4d4d8; font-size:0.8rem;"><?php echo htmlspecialchars($u['email']); ?></span>
                <span style="display:block; color:#71717a; font-size:0.72rem;"><?php echo htmlspecialchars($u['phone']); ?></span>
              </td>
              <td style="font-weight:800; color:var(--gm-gold);">₦<?php echo number_format((float)$u['balance'], 2); ?></td>
              <td style="font-weight:700; color:#fff;">₦<?php echo number_format((float)$u['total_invested'], 2); ?></td>
              <td style="color:#a1a1aa; font-size:0.78rem;"><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $u['status'] === 'active' ? 'approved' : 'rejected'; ?>"><?php echo ucfirst($u['status']); ?></span></td>
              <td style="text-align:right;">
                <div style="display:inline-flex; gap:6px;">
                  <a href="/admin/user-details.php?id=<?php echo $u['id']; ?>" class="btn-outline" style="padding:5px 10px; font-size:0.75rem; width:auto;">
                    <i class="fa-solid fa-eye"></i> Details
                  </a>
                  <form method="POST" action="/admin/users.php" style="display:inline;">
                    <?php echo csrf_input(); ?>
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                    <button type="submit" class="btn-outline" style="padding:5px 10px; font-size:0.75rem; width:auto; border-color:<?php echo $u['status'] === 'active' ? '#ef4444' : '#22c55e'; ?>; color:<?php echo $u['status'] === 'active' ? '#ef4444' : '#22c55e'; ?>;">
                      <?php echo $u['status'] === 'active' ? 'Suspend' : 'Activate'; ?>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
