<?php
$admin_page_title = "Deposit Requests Management";
$admin_page_subtitle = "Review incoming payments, approve credit to balances & audit transactions";
require_once __DIR__ . '/../includes/admin-header.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['deposit_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired. Please try again.";
    } else {
        $dep_id = (int)$_POST['deposit_id'];
        $act = $_POST['action'];
        $admin_id = (int)$_SESSION['admin_id'];

        if ($pdo && $dep_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ? LIMIT 1");
            $stmt->execute([$dep_id]);
            $dep = $stmt->fetch();

            if (!$dep) {
                $error = "Deposit record not found.";
            } elseif ($dep['status'] !== 'pending' && $dep['status'] !== 'under_review') {
                $error = "Deposit has already been processed (Status: " . ucfirst($dep['status']) . ").";
            } else {
                if ($act === 'approve') {
                    $pdo->beginTransaction();
                    // Credit user balance
                    $upd_user = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $upd_user->execute([$dep['amount'], $dep['user_id']]);

                    // Update deposit
                    $upd_dep = $pdo->prepare("UPDATE deposits SET status = 'approved', admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd_dep->execute([$admin_id, $dep_id]);

                    // Update transaction
                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE reference_code = ?");
                    $t_upd->execute([$dep['reference_code']]);

                    add_user_notification(
                        (int)$dep['user_id'],
                        "Deposit Approved & Credited",
                        "Your deposit of " . format_currency($dep['amount']) . " (" . $dep['reference_code'] . ") has been approved and added to your balance.",
                        "success",
                        "/deposit.php"
                    );

                    log_audit_action($admin_id, (int)$dep['user_id'], "Approved Deposit", "Deposit " . $dep['reference_code'] . " - " . format_currency($dep['amount']));
                    $pdo->commit();
                    $notice = "Deposit " . htmlspecialchars($dep['reference_code']) . " approved and credited successfully.";
                } elseif ($act === 'reject') {
                    $upd_dep = $pdo->prepare("UPDATE deposits SET status = 'rejected', admin_action_by = ?, admin_action_at = NOW() WHERE id = ?");
                    $upd_dep->execute([$admin_id, $dep_id]);

                    $t_upd = $pdo->prepare("UPDATE transactions SET status = 'failed' WHERE reference_code = ?");
                    $t_upd->execute([$dep['reference_code']]);

                    add_user_notification(
                        (int)$dep['user_id'],
                        "Deposit Request Rejected",
                        "Your deposit request of " . format_currency($dep['amount']) . " (" . $dep['reference_code'] . ") was declined by administration.",
                        "danger",
                        "/deposit.php"
                    );

                    log_audit_action($admin_id, (int)$dep['user_id'], "Rejected Deposit", "Deposit " . $dep['reference_code']);
                    $notice = "Deposit " . htmlspecialchars($dep['reference_code']) . " marked as rejected.";
                }
            }
        }
    }
}

$filter_status = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$where = [];
$params = [];

if ($filter_status !== 'all' && in_array($filter_status, ['pending', 'approved', 'rejected'])) {
    $where[] = "d.status = ?";
    $params[] = $filter_status;
}
if (!empty($search)) {
    $where[] = "(d.reference_code LIKE ? OR u.full_name LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like;
}
$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$deposits = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT d.*, u.full_name as user_name, u.email as user_email
                               FROM deposits d
                               JOIN users u ON d.user_id = u.id
                               $where_sql
                               ORDER BY CASE WHEN d.status = 'pending' THEN 1 ELSE 2 END, d.id DESC LIMIT 50");
        $stmt->execute($params);
        $deposits = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Failed to load deposits: " . $e->getMessage();
    }
}
?>

<?php if (!empty($notice)): ?>
  <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); color:#4ade80; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($notice); ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.35); color:#f87171; padding:12px 16px; border-radius:12px; margin-bottom:20px; font-size:0.85rem;">
    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
  </div>
<?php endif; ?>

<div class="admin-card" style="padding:16px 20px;">
  <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
    <div style="display:flex; gap:8px;">
      <a href="/admin/deposits.php?status=all" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
      <a href="/admin/deposits.php?status=pending" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'pending' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Pending</a>
      <a href="/admin/deposits.php?status=approved" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'approved' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Approved</a>
      <a href="/admin/deposits.php?status=rejected" style="padding:6px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-decoration:none; <?php echo $filter_status === 'rejected' ? 'background:var(--gm-gold); color:#000;' : 'background:#1a1a1f; color:#a1a1aa; border:1px solid #27272a;'; ?>">Rejected</a>
    </div>

    <form method="GET" action="/admin/deposits.php" style="display:flex; gap:8px;">
      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ref or user..." class="form-control" style="width:200px; padding:7px 12px; font-size:0.8rem;">
      <button type="submit" class="btn-gold" style="width:auto; padding:7px 12px; font-size:0.8rem;"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div style="overflow-x:auto;">
    <table>
      <thead>
        <tr>
          <th>Reference</th>
          <th>User</th>
          <th>Amount</th>
          <th>Gateway / Method</th>
          <th>Transfer Receipt</th>
          <th>Requested Date</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($deposits)): ?>
          <tr><td colspan="8" style="text-align:center; color:#71717a; padding:35px;">No deposit requests found.</td></tr>
        <?php else: ?>
          <?php foreach ($deposits as $d): ?>
            <tr>
              <td style="font-family:monospace; font-weight:700; color:var(--gm-gold);"><?php echo htmlspecialchars($d['reference_code']); ?></td>
              <td>
                <strong style="color:#fff;"><?php echo htmlspecialchars($d['user_name']); ?></strong>
                <span style="display:block; font-size:0.7rem; color:#71717a;"><?php echo htmlspecialchars($d['user_email']); ?></span>
              </td>
              <td style="font-weight:800; color:#fff;">₦<?php echo number_format((float)$d['amount'], 2); ?></td>
              <td><span style="background:#1a1a1f; border:1px solid #27272a; padding:3px 8px; border-radius:6px; font-size:0.75rem;"><?php echo htmlspecialchars($d['payment_method']); ?></span></td>
              <td><?php if (!empty($d['receipt_path'])): ?><a href="/admin/deposit-receipt.php?id=<?php echo (int)$d['id']; ?>" target="_blank" rel="noopener" style="color:var(--gm-gold); font-weight:700;">View Receipt <i class="fa-solid fa-arrow-up-right-from-square"></i></a><?php else: ?><span style="color:#71717a;">No receipt</span><?php endif; ?></td>
              <td style="color:#a1a1aa; font-size:0.8rem;"><?php echo date('M d, Y h:i A', strtotime($d['created_at'])); ?></td>
              <td><span class="badge badge-<?php echo $d['status']; ?>"><?php echo ucfirst($d['status']); ?></span></td>
              <td style="text-align:right;">
                <?php if ($d['status'] === 'pending'): ?>
                  <div style="display:inline-flex; gap:6px;">
                    <form method="POST" action="/admin/deposits.php" style="display:inline;">
                      <?php echo csrf_input(); ?>
                      <input type="hidden" name="action" value="approve">
                      <input type="hidden" name="deposit_id" value="<?php echo $d['id']; ?>">
                      <button type="submit" class="btn-action-approve"><i class="fa-solid fa-check"></i> Approve</button>
                    </form>
                    <form method="POST" action="/admin/deposits.php" style="display:inline;">
                      <?php echo csrf_input(); ?>
                      <input type="hidden" name="action" value="reject">
                      <input type="hidden" name="deposit_id" value="<?php echo $d['id']; ?>">
                      <button type="submit" class="btn-action-reject"><i class="fa-solid fa-xmark"></i> Reject</button>
                    </form>
                  </div>
                <?php else: ?>
                  <span style="color:#71717a; font-size:0.75rem;">Processed</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
