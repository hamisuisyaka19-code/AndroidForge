<?php
$page_title = "My Invest";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();

check_and_update_matured_investments();
$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

$filter = $_GET['filter'] ?? 'all';
$query = "SELECT * FROM investments WHERE user_id = ?";
$params = [$user_id];

if ($filter === 'active') {
    $query .= " AND status = 'active'";
} elseif ($filter === 'completed') {
    $query .= " AND status = 'completed'";
} elseif ($filter === 'pending') {
    $query .= " AND status = 'pending'";
} elseif ($filter === 'rejected') {
    $query .= " AND status = 'rejected'";
}
$query .= " ORDER BY id DESC";

$investments = [];
if ($pdo) {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $investments = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">My Invest</h3>
  </div>

  <!-- Filter Pills matching reference image with all 5 filter states -->
  <div style="display:flex; gap: 8px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 4px; scrollbar-width: none;">
    <a href="/my-invest.php?filter=all" style="padding: 6px 16px; white-space:nowrap; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $filter === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
    <a href="/my-invest.php?filter=active" style="padding: 6px 16px; white-space:nowrap; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $filter === 'active' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Active</a>
    <a href="/my-invest.php?filter=pending" style="padding: 6px 16px; white-space:nowrap; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $filter === 'pending' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Pending</a>
    <a href="/my-invest.php?filter=completed" style="padding: 6px 16px; white-space:nowrap; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $filter === 'completed' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Completed</a>
    <a href="/my-invest.php?filter=rejected" style="padding: 6px 16px; white-space:nowrap; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $filter === 'rejected' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Rejected</a>
  </div>

  <?php if (empty($investments)): ?>
    <div style="text-align: center; padding: 60px 20px;">
      <i class="fa-solid fa-coins" style="font-size: 48px; color: #3f3f46; margin-bottom: 16px;"></i>
      <h4 style="color: #fff; margin-bottom: 8px;">No Investments Found</h4>
      <p style="color: #a1a1aa; font-size: 0.85rem; margin-bottom: 20px;">You do not have any <?php echo htmlspecialchars($filter); ?> investments yet.</p>
      <a href="/invest.php" class="btn-gold" style="display:inline-block; width:auto; padding:10px 24px;">Start Investing</a>
    </div>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap: 14px;">
      <?php foreach ($investments as $inv): ?>
        <div class="gm-card" style="padding: 16px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 12px;">
            <div style="display:flex; align-items:center; gap: 10px;">
              <div style="width: 36px; height: 36px; border-radius: 10px; background: rgba(234, 179, 8, 0.12); display:flex; align-items:center; justify-content:center; color: var(--gm-gold);">
                <i class="fa-solid fa-coins"></i>
              </div>
              <div>
                <span style="font-size: 0.8rem; font-weight: 700; color: #e4e4e7;"><?php echo htmlspecialchars($inv['reference_code']); ?></span>
                <p style="font-size: 0.72rem; color: #a1a1aa; margin:0;"><?php echo htmlspecialchars($inv['plan_name']); ?></p>
              </div>
            </div>
            <div style="text-align: right;">
              <span style="font-size: 1rem; font-weight: 800; color: #fff;">₦<?php echo number_format((float)$inv['amount'], 2); ?></span>
              <div>
                <span class="badge badge-<?php echo $inv['status']; ?>"><?php echo ucfirst($inv['status']); ?></span>
              </div>
            </div>
          </div>
          <div style="border-top: 1px solid #222226; padding-top: 10px; display:flex; justify-content:space-between; font-size: 0.72rem; color: #a1a1aa;">
            <span>Invested: <?php echo !empty($inv['start_date']) ? date('M d, Y', strtotime($inv['start_date'])) : 'Pending Review'; ?></span>
            <span>Maturity: <?php echo !empty($inv['maturity_date']) ? date('M d, Y', strtotime($inv['maturity_date'])) : 'N/A'; ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
