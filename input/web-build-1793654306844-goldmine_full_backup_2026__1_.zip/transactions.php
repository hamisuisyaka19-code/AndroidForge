<?php
$page_title = "Transactions";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();

$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

$type_filter = $_GET['type'] ?? 'all';
$query = "SELECT * FROM transactions WHERE user_id = ?";
$params = [$user_id];

if (in_array($type_filter, ['deposit', 'investment', 'withdrawal'])) {
    $query .= " AND type = ?";
    $params[] = $type_filter;
}
$query .= " ORDER BY id DESC LIMIT 50";

$txs = [];
if ($pdo) {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $txs = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Transaction History</h3>
  </div>

  <div style="display:flex; gap: 8px; margin-bottom: 18px; overflow-x: auto; padding-bottom: 4px;">
    <a href="/transactions.php?type=all" style="padding: 6px 14px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; <?php echo $type_filter === 'all' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">All</a>
    <a href="/transactions.php?type=deposit" style="padding: 6px 14px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; <?php echo $type_filter === 'deposit' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Deposits</a>
    <a href="/transactions.php?type=investment" style="padding: 6px 14px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; <?php echo $type_filter === 'investment' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Investments</a>
    <a href="/transactions.php?type=withdrawal" style="padding: 6px 14px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; <?php echo $type_filter === 'withdrawal' ? 'background:var(--gm-gold); color:#000;' : 'background:#18181b; color:#a1a1aa; border:1px solid #27272a;'; ?>">Withdrawals</a>
  </div>

  <?php if (empty($txs)): ?>
    <div style="text-align: center; padding: 50px 20px;">
      <i class="fa-solid fa-receipt" style="font-size: 44px; color: #3f3f46; margin-bottom: 14px;"></i>
      <p style="color: #a1a1aa; font-size: 0.85rem;">No transaction records found.</p>
    </div>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap: 10px;">
      <?php foreach ($txs as $t): ?>
        <div class="gm-card" style="padding: 14px; margin-bottom: 0;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
              <span style="font-size: 0.85rem; font-weight: 700; color: #fff; text-transform: capitalize;"><?php echo htmlspecialchars($t['type']); ?></span>
              <p style="font-size: 0.72rem; color: #a1a1aa; margin: 2px 0;"><?php echo htmlspecialchars($t['description']); ?></p>
              <span style="font-size: 0.68rem; color: #71717a;"><?php echo date('M d, Y h:i A', strtotime($t['created_at'])); ?></span>
            </div>
            <div style="text-align: right;">
              <span style="font-size: 0.95rem; font-weight: 800; color: <?php echo $t['type'] === 'withdrawal' ? '#f87171' : 'var(--gm-gold)'; ?>;">
                <?php echo $t['type'] === 'withdrawal' ? '-' : '+'; ?>₦<?php echo number_format((float)$t['amount'], 2); ?>
              </span>
              <div>
                <span class="badge badge-<?php echo $t['status']; ?>"><?php echo ucfirst($t['status']); ?></span>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
