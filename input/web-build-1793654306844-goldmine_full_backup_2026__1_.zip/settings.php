<?php
$page_title = "Settings";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Settings</h3>
  </div>
  <div class="gm-card">
    <h4 style="font-size:0.95rem; font-weight:700; color:#fff; margin-bottom:12px;">Security & Preferences</h4>
    <div style="display:flex; flex-direction:column; gap:12px;">
      <a href="/profile.php" class="btn-outline" style="text-align:left; font-size:0.85rem;"><i class="fa-solid fa-lock"></i> Change Password</a>
      <a href="/notifications.php" class="btn-outline" style="text-align:left; font-size:0.85rem;"><i class="fa-regular fa-bell"></i> Notification Preferences</a>
      <a href="/logout.php" class="btn-outline" style="text-align:left; font-size:0.85rem; color:#ef4444; border-color:#ef4444;"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/navbar.php'; require_once __DIR__ . '/includes/footer.php'; ?>