<?php
$page_title = "Notifications";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();

$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

if ($pdo) {
    // Mark all as read
    $upd = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $upd->execute([$user_id]);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Notifications</h3>
  </div>

  <?php if (empty($notifications)): ?>
    <div style="text-align:center; padding:60px 20px;">
      <i class="fa-regular fa-bell-slash" style="font-size:44px; color:#3f3f46; margin-bottom:14px;"></i>
      <p style="color:#a1a1aa; font-size:0.85rem;">You have no notifications yet.</p>
    </div>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap:10px;">
      <?php foreach ($notifications as $n): ?>
        <div class="gm-card" style="padding:14px; margin:0; border-left: 3px solid var(--gm-gold);">
          <h5 style="font-size:0.9rem; font-weight:700; color:#fff; margin-bottom:4px;"><?php echo htmlspecialchars($n['title']); ?></h5>
          <p style="font-size:0.78rem; color:#d4d4d8; line-height:1.4; margin-bottom:6px;"><?php echo htmlspecialchars($n['message']); ?></p>
          <span style="font-size:0.68rem; color:#71717a;"><?php echo date('M d, Y h:i A', strtotime($n['created_at'])); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
