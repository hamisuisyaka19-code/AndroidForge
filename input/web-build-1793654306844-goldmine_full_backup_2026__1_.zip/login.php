<?php
$page_title = "Login";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/csrf.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security token mismatch. Please try again.";
    } else {
        $login_input = trim($_POST['login_input'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($login_input) || empty($password)) {
            $error = "Please fill in all fields.";
        } else {
            $pdo = get_db_connection();
            if ($pdo) {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR phone = ?) LIMIT 1");
                $stmt->execute([$login_input, $login_input]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password_hash'])) {
                    if ($user['status'] === 'suspended') {
                        $error = "Your account has been suspended. Please contact support.";
                    } else {
                        session_regenerate_id(true);
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_email'] = $user['email'];
                        $_SESSION['user_name'] = $user['full_name'];
                        log_audit_action(null, (int)$user['id'], "User Login", "User logged in via " . $login_input);
                        header("Location: /dashboard.php");
                        exit;
                    }
                } else {
                    $error = "Invalid email/phone or password.";
                }
            } else {
                $error = "Unable to connect to database. Please check configuration.";
            }
        }
    }
}
?>
<div class="mobile-content" style="padding: 30px 20px;">
  <div style="text-align: center; margin-bottom: 28px;">
    <div style="display:inline-flex; align-items:center; justify-content:center; width:64px; height:64px; background:linear-gradient(135deg, #facc15 0%, #ca8a04 100%); border-radius:18px; box-shadow:0 8px 24px rgba(234, 179, 8, 0.35); margin-bottom: 12px;">
      <span style="font-size: 28px; font-weight: 900; color: #000;">GM</span>
    </div>
    <h2 style="font-size: 1.4rem; font-weight: 800; color:#fff;">
      Gold<span style="color:#eab308;">Mine</span>
    </h2>
    <p style="font-size: 0.8rem; color: #a1a1aa; text-transform: uppercase; letter-spacing: 1px;">Investment Platform</p>
  </div>

  <h3 style="font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 20px; text-align: left;">
    Login to Your Account
  </h3>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/login.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label"><i class="fa-regular fa-envelope" style="color:var(--gm-gold); margin-right:6px;"></i> Email or Phone Number</label>
      <input type="text" name="login_input" class="form-control" placeholder="Enter your email or phone" required value="<?php echo htmlspecialchars($_POST['login_input'] ?? ''); ?>">
    </div>

    <div class="form-group" style="position: relative;">
      <label class="form-label"><i class="fa-solid fa-lock" style="color:var(--gm-gold); margin-right:6px;"></i> Password</label>
      <input type="password" name="password" class="form-control" placeholder="Enter password" required>
      <i class="fa-regular fa-eye toggle-password" style="position: absolute; right: 14px; top: 40px; color: #71717a; cursor: pointer;"></i>
    </div>

    <div style="text-align: right; margin-bottom: 22px;">
      <a href="/forgot-password.php" style="color: var(--gm-gold); font-size: 0.82rem; font-weight: 600;">Forgot Password?</a>
    </div>

    <button type="submit" class="btn-gold" style="margin-bottom: 18px;">Login</button>
  </form>

  <div style="display:flex; align-items:center; margin: 18px 0; color:#52525b;">
    <div style="flex:1; height:1px; background:#27272a;"></div>
    <span style="padding: 0 12px; font-size: 0.8rem; text-transform:lowercase;">or</span>
    <div style="flex:1; height:1px; background:#27272a;"></div>
  </div>

  <a href="/register.php" class="btn-outline">Create New Account</a>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
