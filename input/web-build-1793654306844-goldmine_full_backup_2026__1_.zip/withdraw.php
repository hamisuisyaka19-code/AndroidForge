<?php
$page_title = "Withdraw";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_user_login();

$user = get_current_user_data();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired or invalid security token.";
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        $bank_name = sanitize($_POST['bank_name'] ?? '');
        $account_number = sanitize($_POST['account_number'] ?? '');
        $account_name = sanitize($_POST['account_name'] ?? '');

        if ($amount < 2000) {
            $error = "Minimum withdrawal amount is ₦2,000.00";
        } elseif ($amount > (float)$user['balance']) {
            $error = "Insufficient balance. Available: " . format_currency($user['balance']);
        } elseif (empty($bank_name) || empty($account_number) || empty($account_name)) {
            $error = "Please provide complete bank account details.";
        } else {
            $ref = generate_reference('WTH');
            try {
                $pdo->beginTransaction();

                // Lock balance
                $upd = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $upd->execute([$amount, $user_id]);

                // Insert withdrawal request
                $ins = $pdo->prepare("INSERT INTO withdrawals (reference_code, user_id, amount, bank_name, account_number, account_name, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
                $ins->execute([$ref, $user_id, $amount, $bank_name, $account_number, $account_name]);

                // Insert transaction record
                $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'withdrawal', ?, 'pending', ?)");
                $tx->execute([$ref, $user_id, $amount, "Withdrawal to " . $bank_name . " - " . $account_number]);

                add_user_notification($user_id, "Withdrawal Requested", "Your withdrawal request for " . format_currency($amount) . " ($ref) is under administrative review.", "info", "/withdraw.php");
                log_audit_action(null, $user_id, "Withdrawal Requested", "Withdrawal $ref for " . format_currency($amount));

                $pdo->commit();
                $success = "Withdrawal request submitted! It will be reviewed by administrators.";
                $user = get_current_user_data();
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Withdrawal processing error: " . $e->getMessage();
            }
        }
    }
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Withdraw</h3>
  </div>

  <div class="gm-card" style="margin-bottom: 20px; background: #16161a;">
    <span style="font-size: 0.78rem; color: #a1a1aa; text-transform: uppercase;">Available Balance</span>
    <h3 style="font-size: 1.8rem; font-weight: 800; color: var(--gm-gold); margin: 6px 0 0 0;">₦<?php echo number_format((float)$user['balance'], 2); ?></h3>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.4); color: #4ade80; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($success); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/withdraw.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Withdrawal Amount (₦)</label>
      <input type="number" step="100" name="amount" class="form-control" placeholder="Enter amount" required min="2000" max="<?php echo (float)$user['balance']; ?>">
    </div>

    <div class="form-group">
      <label class="form-label">Bank Details</label>
      <select name="bank_name" class="form-control" required style="margin-bottom: 10px;">
        <option value="">Select Bank</option>
        <option value="Access Bank">Access Bank</option>
        <option value="First Bank of Nigeria">First Bank of Nigeria</option>
        <option value="Guaranty Trust Bank (GTBank)">Guaranty Trust Bank (GTBank)</option>
        <option value="United Bank for Africa (UBA)">United Bank for Africa (UBA)</option>
        <option value="Zenith Bank">Zenith Bank</option>
        <option value="OPay">OPay</option>
        <option value="PalmPay">PalmPay</option>
        <option value="Kuda Bank">Kuda Bank</option>
      </select>
    </div>

    <div class="form-group">
      <label class="form-label">Account Number</label>
      <input type="text" name="account_number" class="form-control" placeholder="10-digit Account Number" maxlength="10" required>
    </div>

    <div class="form-group">
      <label class="form-label">Account Name</label>
      <input type="text" name="account_name" class="form-control" placeholder="Account Name matching bank" required>
    </div>

    <button type="submit" class="btn-gold" style="margin-top: 10px;">Request Withdrawal</button>
  </form>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
