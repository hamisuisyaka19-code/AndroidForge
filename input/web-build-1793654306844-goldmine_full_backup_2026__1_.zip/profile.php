<?php
$page_title = "Profile";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_user_login();

$user = get_current_user_data();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session token expired.";
    } else {
        $full_name = sanitize($_POST['full_name'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');

        if (!empty($full_name) && !empty($phone)) {
            $upd = $pdo->prepare("UPDATE users SET full_name = ?, phone = ? WHERE id = ?");
            if ($upd->execute([$full_name, $phone, $user_id])) {
                $_SESSION['user_name'] = $full_name;
                $success = "Profile updated successfully.";
                $user = get_current_user_data();
            }
        }
    }
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Profile</h3>
  </div>

  <div style="text-align:center; margin-bottom: 24px;">
    <div style="width: 72px; height: 72px; border-radius: 50%; background: #27272a; border: 3px solid var(--gm-gold); margin: 0 auto 12px auto; display: flex; align-items: center; justify-content: center;">
      <i class="fa-solid fa-user-tie" style="font-size: 36px; color: var(--gm-gold);"></i>
    </div>
    <h4 style="font-size: 1.1rem; font-weight: 800; color: #fff; margin:0;"><?php echo htmlspecialchars($user['full_name']); ?></h4>
    <p style="font-size: 0.8rem; color: #a1a1aa; margin-top: 4px;"><?php echo htmlspecialchars($user['email']); ?></p>
  </div>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.4); color: #4ade80; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($success); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/profile.php" style="margin-bottom: 24px;">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Full Name</label>
      <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Email Address (Read-only)</label>
      <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly style="opacity: 0.7;">
    </div>
    <div class="form-group">
      <label class="form-label">Phone Number</label>
      <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
    </div>
    <button type="submit" class="btn-gold">Save Changes</button>
  </form>

  <a href="/logout.php" class="btn-outline" style="border-color: #ef4444; color: #ef4444; text-align: center;">
    <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
  </a>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
