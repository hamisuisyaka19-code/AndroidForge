<?php
$page_title = "Deposit";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/config/payment.php';
require_user_login();

$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired or invalid security token.";
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        $method = 'Manual Bank Transfer';
        $receipt = $_FILES['receipt'] ?? null;

        if ($amount < 500) {
            $error = "Minimum deposit amount is ₦500.00";
        } elseif (!$receipt || ($receipt['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $error = "Please upload proof of your bank transfer.";
        } elseif (($receipt['size'] ?? 0) > 5 * 1024 * 1024) {
            $error = "Receipt file must not exceed 5 MB.";
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($receipt['tmp_name']);
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
            if (!isset($allowed[$mime])) {
                $error = "Receipt must be JPG, PNG, WEBP, or PDF.";
            } else {
            $upload_dir = __DIR__ . '/uploads/deposit_receipts';
            if (!is_dir($upload_dir) && !mkdir($upload_dir, 0750, true) && !is_dir($upload_dir)) {
                $error = "Unable to prepare secure receipt storage. Please contact support.";
            } else {
            $stored_name = bin2hex(random_bytes(24)) . '.' . $allowed[$mime];
            $stored_path = $upload_dir . '/' . $stored_name;
            if (!move_uploaded_file($receipt['tmp_name'], $stored_path)) {
                $error = "Receipt upload failed. Please try again.";
            } else {
            $receipt_db_path = 'uploads/deposit_receipts/' . $stored_name;
            $ref = generate_reference('DEP');
            try {
                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status, receipt_path) VALUES (?, ?, ?, ?, 'pending', ?)");
                $ins->execute([$ref, $user_id, $amount, $method, $receipt_db_path]);

                // Create pending transaction record
                $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'deposit', ?, 'pending', ?)");
                $tx->execute([$ref, $user_id, $amount, "Deposit request via " . $method]);

                add_user_notification($user_id, "Deposit Request Submitted", "Your deposit of " . format_currency($amount) . " ($ref) is awaiting administrator approval.", "info", "/deposit.php");
                log_audit_action(null, $user_id, "Deposit Request Submitted", "Deposit $ref for " . format_currency($amount));

                $success = "Deposit request submitted! Once verified by administrator, your balance will be credited.";
            } catch (Exception $e) {
                if (is_file($stored_path)) { @unlink($stored_path); }
                $error = "Deposit could not be submitted. Please try again.";
                error_log('Manual deposit submission failed: ' . $e->getMessage());
            }
            }
            }
            }
            }
        }
    }

// Fetch deposit history
$history = [];
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 10");
    $stmt->execute([$user_id]);
    $history = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Deposit</h3>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.4); color: #4ade80; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($success); ?>
    </div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data" action="/deposit.php" style="margin-bottom: 28px;">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Deposit Amount (₦)</label>
      <input type="number" step="100" name="amount" class="form-control" placeholder="Enter amount" required min="500">
    </div>

    <div class="form-group">
      <label class="form-label">Bank Transfer Details</label>
      <div style="background:#18181b; border:1px solid var(--gm-gold); border-radius:12px; padding:16px; line-height:1.8;">
        <div><span style="color:#a1a1aa;">Bank:</span> <strong style="color:#fff;">Kuda Bank</strong></div>
        <div><span style="color:#a1a1aa;">Account Name:</span> <strong style="color:#fff;">Hamisu Isiyaka</strong></div>
        <div><span style="color:#a1a1aa;">Account Number:</span> <strong style="color:var(--gm-gold); font-size:1.15rem;">2009888249</strong></div>
        <p style="color:#fbbf24; font-size:.78rem; margin:8px 0 0;">Transfer the exact amount entered above. Your deposit will remain pending until the administrator confirms receipt in the bank account.</p>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Upload Transfer Receipt (JPG, PNG, WEBP, or PDF — max 5 MB)</label>
      <input type="file" name="receipt" class="form-control" accept="image/jpeg,image/png,image/webp,application/pdf" required>
    </div>
    <input type="hidden" name="payment_method" value="Manual Bank Transfer">

    <button type="submit" class="btn-gold" style="margin-top: 10px;">Submit Deposit Request</button>
  </form>

  <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin-bottom: 14px;">Deposit History</h4>
  <div style="display:flex; flex-direction:column; gap: 10px;">
    <?php if (empty($history)): ?>
      <p style="color:#71717a; font-size:0.8rem; text-align:center;">No deposit records found.</p>
    <?php else: ?>
      <?php foreach ($history as $dep): ?>
        <div class="gm-card" style="padding: 14px; margin-bottom: 0;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-size: 1rem; font-weight: 800; color: #fff;">₦<?php echo number_format((float)$dep['amount'], 2); ?></span>
              <p style="font-size: 0.7rem; color: #a1a1aa; margin:2px 0 0 0;"><?php echo date('M d, Y, h:i A', strtotime($dep['created_at'])); ?></p>
            </div>
            <span class="badge badge-<?php echo $dep['status']; ?>"><?php echo ucfirst(str_replace('_', ' ', $dep['status'])); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
