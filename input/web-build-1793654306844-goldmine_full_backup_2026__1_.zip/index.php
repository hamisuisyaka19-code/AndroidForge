<?php
$page_title = "Welcome";
require_once __DIR__ . '/includes/header.php';
?>
<div class="mobile-content" style="display:flex; flex-direction:column; justify-content:space-between; min-height:100vh; padding: 40px 24px; text-align:center;">
  <div style="margin-top: 30px;">
    <!-- Logo style from reference image -->
    <div style="display:inline-flex; align-items:center; justify-content:center; width:90px; height:90px; background:linear-gradient(135deg, #facc15 0%, #ca8a04 100%); border-radius:24px; box-shadow:0 10px 30px rgba(234, 179, 8, 0.4); margin-bottom: 16px;">
      <span style="font-size: 42px; font-weight: 900; color: #000; letter-spacing:-1px;">GM</span>
    </div>
    <h1 style="font-size: 2rem; font-weight: 800; color: #fff; margin-bottom: 4px;">
      Gold<span style="color:#eab308;">Mine</span>
    </h1>
    <p style="font-size: 0.85rem; color: #a1a1aa; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600;">Investment Platform</p>
  </div>

  <div style="margin: 30px 0;">
    <!-- Gold nuggets visual graphic illustration -->
    <div style="width: 220px; height: 140px; margin: 0 auto; background: radial-gradient(circle, rgba(234, 179, 8, 0.25) 0%, rgba(0,0,0,0) 70%); display:flex; align-items:center; justify-content:center;">
      <i class="fa-solid fa-gem" style="font-size: 72px; color: #eab308; filter: drop-shadow(0 0 25px rgba(234, 179, 8, 0.8));"></i>
    </div>
    <h2 style="font-size: 1.45rem; font-weight: 800; color: #fff; margin-top: 16px; line-height: 1.3;">
      Grow Your Wealth<br><span style="color: #eab308;">With Smart Investment</span>
    </h2>
    <p style="font-size: 0.85rem; color: #a1a1aa; margin-top: 10px; max-width: 280px; margin-left: auto; margin-right: auto; line-height: 1.4;">
      Invest Securely, Earn Legit Profit, And Build a Better Future
    </p>
  </div>

  <div>
    <a href="/register.php" class="btn-gold" style="margin-bottom: 12px; font-size: 1.05rem;">Get Started</a>
    <a href="/login.php" class="btn-outline">Login</a>

    <!-- 4 Dots Carousel Indicator -->
    <div style="display:flex; justify-content:center; gap:6px; margin-top: 24px;">
      <span style="width: 20px; height: 6px; background: #eab308; border-radius: 4px;"></span>
      <span style="width: 6px; height: 6px; background: #3f3f46; border-radius: 50%;"></span>
      <span style="width: 6px; height: 6px; background: #3f3f46; border-radius: 50%;"></span>
      <span style="width: 6px; height: 6px; background: #3f3f46; border-radius: 50%;"></span>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
