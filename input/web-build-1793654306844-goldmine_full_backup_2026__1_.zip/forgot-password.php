<?php
$page_title = "Forgot Password";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/csrf.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $msg = "If your account exists, a secure password reset link has been dispatched.";
}
?>
<div class="mobile-content" style="padding: 30px 20px;">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/login.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Forgot Password</h3>
  </div>
  <p style="font-size:0.85rem; color:#a1a1aa; margin-bottom:20px;">Enter your registered email address to receive password reset instructions.</p>
  <?php if (!empty($msg)): ?>
    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.4); color: #4ade80; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($msg); ?>
    </div>
  <?php endif; ?>
  <form method="POST" action="/forgot-password.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-control" placeholder="user@example.com" required>
    </div>
    <button type="submit" class="btn-gold">Send Reset Link</button>
  </form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
