<?php
$page_title = "Investment Plans — 45% ROI";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_user_login();

$user = get_current_user_data();
$user_id = (int)$user['id'];
$pdo = get_db_connection();

// Automatic maturity check before viewing
check_and_update_matured_investments();

$plans = [];
if ($pdo) {
    try {
        $stmt = $pdo->query("SELECT id, name, slug, min_amount, max_amount, roi_percentage, duration_days, description FROM investment_plans WHERE status = 'active' ORDER BY sort_order ASC, min_amount ASC");
        $plans = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Failed to load plans: " . $e->getMessage());
    }
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired or invalid security token. Please try again.";
    } else {
        $plan_id = (int)($_POST['plan_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);

        // Fetch selected plan directly from database to ensure up-to-date values
        $p_stmt = $pdo->prepare("SELECT * FROM investment_plans WHERE id = ? AND status = 'active' LIMIT 1");
        $p_stmt->execute([$plan_id]);
        $plan = $p_stmt->fetch();

        if (!$plan) {
            $error = "Selected investment plan is currently unavailable.";
        } elseif ($amount < (float)$plan['min_amount']) {
            $error = "Minimum investment for " . htmlspecialchars($plan['name']) . " is " . format_currency($plan['min_amount']);
        } elseif ($amount > (float)$plan['max_amount']) {
            $error = "Maximum investment for " . htmlspecialchars($plan['name']) . " is " . format_currency($plan['max_amount']);
        } else {
            // Check available user balance
            if ((float)$user['balance'] < $amount) {
                $error = "Insufficient balance (" . format_currency($user['balance']) . "). Please deposit funds first.";
            } else {
                $ref = generate_reference('INV');
                $expected_return = $amount + ($amount * ((float)$plan['roi_percentage'] / 100));

                try {
                    $pdo->beginTransaction();

                    // Deduct user balance and increment total invested
                    $deduct = $pdo->prepare("UPDATE users SET balance = balance - ?, total_invested = total_invested + ? WHERE id = ?");
                    $deduct->execute([$amount, $amount, $user_id]);

                    // Insert investment in 'pending' status for Administrator Review & Approval
                    $ins = $pdo->prepare("INSERT INTO investments (reference_code, user_id, plan_id, plan_name, amount, roi_percentage, expected_return, duration_days, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
                    $ins->execute([$ref, $user_id, $plan['id'], $plan['name'], $amount, $plan['roi_percentage'], $expected_return, $plan['duration_days']]);

                    // Insert transaction record
                    $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, balance_after, status, description) VALUES (?, ?, 'investment', ?, ?, 'pending', ?)");
                    $new_bal = (float)$user['balance'] - $amount;
                    $tx->execute([$ref, $user_id, $amount, $new_bal, "Invested in " . $plan['name'] . " (" . $ref . ")"]);

                    // Send notification to user
                    add_user_notification(
                        $user_id,
                        "Investment Order Submitted: " . $plan['name'],
                        "Your order $ref for " . format_currency($amount) . " in " . $plan['name'] . " (" . $plan['roi_percentage'] . "% ROI) has been submitted for administrator review.",
                        "info",
                        "/my-invest.php"
                    );

                    log_audit_action(null, $user_id, "Submitted Investment Order", "Plan: " . $plan['name'] . " - Amount: " . format_currency($amount) . " - ROI: " . $plan['roi_percentage'] . "%");

                    $pdo->commit();
                    $success = "Investment order submitted successfully! It is now pending administrator review.";
                    $user = get_current_user_data();
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = "Failed to submit investment order: " . $e->getMessage();
                }
            }
        }
    }
}
?>

<div class="mobile-content" style="background:#080d0a;">
  <!-- Top Bar with Back Navigation & Balance Pill -->
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 18px;">
    <div style="display:flex; align-items:center; gap: 12px;">
      <a href="/dashboard.php" style="width:38px; height:38px; border-radius:12px; background:#122118; border:1px solid rgba(16,185,129,0.3); display:flex; align-items:center; justify-content:center; color:#34d399; font-size:1rem; text-decoration:none;">
        <i class="fa-solid fa-arrow-left"></i>
      </a>
      <div>
        <h3 style="font-size: 1.25rem; font-weight: 900; color: #ffffff; margin:0; letter-spacing:-0.3px;">Investment Plans</h3>
        <span style="font-size: 0.72rem; color: #a1a1aa;">Choose a plan & earn 45% verified returns</span>
      </div>
    </div>
    <a href="/deposit.php" style="padding: 6px 12px; border-radius: 20px; background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.35); color: #34d399; font-size: 0.75rem; font-weight: 700; display:flex; align-items:center; gap:5px; text-decoration:none;">
      <i class="fa-solid fa-wallet"></i> ₦<?php echo number_format((float)$user['balance'], 2); ?>
    </a>
  </div>

  <!-- Highlights Banner -->
  <div style="background: linear-gradient(135deg, rgba(6,78,59,0.5) 0%, rgba(15,28,22,0.85) 100%); border: 1px solid rgba(16,185,129,0.3); border-radius: 18px; padding: 14px 16px; margin-bottom: 20px; display:flex; align-items:center; justify-content:space-between;">
    <div>
      <div style="display:inline-flex; align-items:center; gap:6px; background:rgba(16,185,129,0.2); padding:2px 8px; border-radius:6px; font-size:0.68rem; font-weight:800; color:#34d399; margin-bottom:4px; text-transform:uppercase;">
        <i class="fa-solid fa-shield-halved"></i> Verified Gold Growth
      </div>
      <h4 style="font-size:0.95rem; font-weight:800; color:#fff; margin:0 0 2px 0;">Official 45% ROI Tiers</h4>
      <p style="font-size:0.72rem; color:#a1a1aa; margin:0;">Transparent daily tracking, countdown date & automated settlement</p>
    </div>
    <div style="width:48px; height:48px; border-radius:14px; background:rgba(234,179,8,0.15); border:1px solid rgba(234,179,8,0.3); display:flex; align-items:center; justify-content:center; color:#eab308; font-size:1.4rem; flex-shrink:0;">
      <i class="fa-solid fa-cubes-stacked"></i>
    </div>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px 16px; border-radius: 14px; font-size: 0.85rem; margin-bottom: 18px; display:flex; align-items:center; gap:10px;">
      <i class="fa-solid fa-circle-exclamation" style="font-size:1.1rem;"></i>
      <span><?php echo htmlspecialchars($error); ?></span>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); color: #34d399; padding: 14px 16px; border-radius: 14px; font-size: 0.85rem; margin-bottom: 18px;">
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;">
        <i class="fa-solid fa-circle-check" style="font-size:1.2rem; color:#34d399;"></i>
        <strong style="color:#ffffff; font-size:0.9rem;">Order Placed Successfully!</strong>
      </div>
      <p style="margin:0 0 10px 0; font-size:0.8rem; color:#d1fae5;"><?php echo htmlspecialchars($success); ?></p>
      <a href="/my-invest.php" style="display:inline-block; padding:6px 14px; border-radius:8px; background:#10b981; color:#000; font-weight:800; font-size:0.75rem; text-decoration:none;">
        View in My Invest <i class="fa-solid fa-arrow-right"></i>
      </a>
    </div>
  <?php endif; ?>

  <!-- Plan Cards Grid (Mobile 1-col, Desktop 2-col) -->
  <div class="invest-container">
    <?php 
    foreach ($plans as $idx => $plan): 
        $min_amt = (float)$plan['min_amount'];
        $max_amt = (float)$plan['max_amount'];
        $roi_pct = (float)$plan['roi_percentage'];
        $min_return = $min_amt + ($min_amt * ($roi_pct / 100));
    ?>
      <div class="invest-plan-card">
        <!-- Top Row: Title, ROI Badge & Gold Artwork -->
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; margin-bottom:14px;">
          <div>
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
              <span class="invest-badge-green">
                <i class="fa-solid fa-arrow-trend-up"></i> <?php echo $roi_pct; ?>% ROI
              </span>
              <span style="font-size:0.7rem; color:#a1a1aa; background:#16241c; padding:3px 8px; border-radius:6px; border:1px solid rgba(16,185,129,0.15);">
                <i class="fa-regular fa-clock"></i> <?php echo (int)$plan['duration_days']; ?> Days
              </span>
            </div>
            <h4 style="font-size: 1.25rem; font-weight: 900; color: #ffffff; margin:0 0 4px 0; letter-spacing:-0.2px;">
              <?php echo htmlspecialchars($plan['name']); ?>
            </h4>
            <p style="font-size: 0.75rem; color: #9ca3af; margin:0; line-height:1.35;">
              <?php echo htmlspecialchars($plan['description'] ?? 'Premium verified investment package.'); ?>
            </p>
          </div>

          <!-- Gold Bars Visual Illustration -->
          <div class="gold-illustration-wrapper">
            <?php if ($idx === 0): ?>
              <!-- Starter Gold: Single gold bullion bar with shine -->
              <svg width="46" height="46" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="8" y="24" width="48" height="24" rx="4" fill="url(#goldGrad1)" stroke="#ca8a04" stroke-width="1.5"/>
                <path d="M12 24L20 14H44L52 24H12Z" fill="url(#goldGradTop)" stroke="#ca8a04" stroke-width="1.5"/>
                <path d="M44 14L52 24V48L44 38V14Z" fill="url(#goldGradSide)" opacity="0.8"/>
                <circle cx="32" cy="34" r="6" fill="#fef08a" opacity="0.6"/>
                <text x="32" y="37" font-size="7" font-weight="900" fill="#713f12" text-anchor="middle">999.9</text>
                <defs>
                  <linearGradient id="goldGrad1" x1="8" y1="24" x2="56" y2="48" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#fef08a"/>
                    <stop offset="0.5" stop-color="#eab308"/>
                    <stop offset="1" stop-color="#a16207"/>
                  </linearGradient>
                  <linearGradient id="goldGradTop" x1="12" y1="14" x2="52" y2="24" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#fef9c3"/>
                    <stop offset="1" stop-color="#eab308"/>
                  </linearGradient>
                  <linearGradient id="goldGradSide" x1="44" y1="14" x2="52" y2="48" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#ca8a04"/>
                    <stop offset="1" stop-color="#713f12"/>
                  </linearGradient>
                </defs>
              </svg>
            <?php elseif ($idx === 1): ?>
              <!-- Classic Gold: Stacked pair of gold bars -->
              <svg width="46" height="46" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g transform="translate(0, 10)">
                  <rect x="6" y="22" width="40" height="18" rx="3" fill="#eab308" stroke="#ca8a04" stroke-width="1.2"/>
                  <path d="M10 22L16 14H40L46 22H10Z" fill="#fef08a" stroke="#ca8a04" stroke-width="1.2"/>
                </g>
                <g transform="translate(12, 0)">
                  <rect x="6" y="22" width="40" height="18" rx="3" fill="url(#goldGrad2)" stroke="#ca8a04" stroke-width="1.2"/>
                  <path d="M10 22L16 14H40L46 22H10Z" fill="#fef9c3" stroke="#ca8a04" stroke-width="1.2"/>
                </g>
                <defs>
                  <linearGradient id="goldGrad2" x1="6" y1="22" x2="46" y2="40" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#fef08a"/>
                    <stop offset="0.6" stop-color="#eab308"/>
                    <stop offset="1" stop-color="#854d0e"/>
                  </linearGradient>
                </defs>
              </svg>
            <?php elseif ($idx === 2): ?>
              <!-- Premium Gold: Pyramid pyramid bullion pile -->
              <svg width="48" height="48" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="4" y="32" width="26" height="15" rx="2" fill="#ca8a04"/>
                <path d="M7 32L11 26H26L30 32H7Z" fill="#fef08a"/>
                <rect x="34" y="32" width="26" height="15" rx="2" fill="#eab308"/>
                <path d="M37 32L41 26H56L60 32H37Z" fill="#fef08a"/>
                <rect x="19" y="16" width="26" height="15" rx="2" fill="#facc15" stroke="#ca8a04" stroke-width="1.2"/>
                <path d="M22 16L26 10H41L45 16H22Z" fill="#fef9c3" stroke="#ca8a04" stroke-width="1.2"/>
              </svg>
            <?php else: ?>
              <!-- VIP Gold: Executive vault with brilliant sparkles -->
              <svg width="48" height="48" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="32" cy="32" r="24" fill="url(#vaultGrad)" stroke="#eab308" stroke-width="2"/>
                <circle cx="32" cy="32" r="16" fill="#18181b" stroke="#ca8a04" stroke-width="2"/>
                <rect x="30" y="22" width="4" height="20" fill="#facc15" rx="2"/>
                <rect x="22" y="30" width="20" height="4" fill="#facc15" rx="2"/>
                <polygon points="46,14 49,20 55,23 49,26 46,32 43,26 37,23 43,20" fill="#fef08a"/>
                <defs>
                  <linearGradient id="vaultGrad" x1="10" y1="10" x2="54" y2="54" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#854d0e"/>
                    <stop offset="0.5" stop-color="#ca8a04"/>
                    <stop offset="1" stop-color="#fef08a"/>
                  </linearGradient>
                </defs>
              </svg>
            <?php endif; ?>
          </div>
        </div>

        <!-- Plan Financial Spec Grid -->
        <div style="background:#09140f; border:1px solid rgba(16,185,129,0.18); border-radius:14px; padding:12px 14px; margin-bottom:14px; display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <span style="font-size:0.68rem; text-transform:uppercase; color:#9ca3af; font-weight:700; letter-spacing:0.3px; display:block;">Daily Profit Rate</span>
            <span style="font-size:1.05rem; font-weight:900; color:#34d399;"><?php echo $roi_pct; ?>%</span>
          </div>
          <div>
            <span style="font-size:0.68rem; text-transform:uppercase; color:#9ca3af; font-weight:700; letter-spacing:0.3px; display:block;">Duration</span>
            <span style="font-size:1.05rem; font-weight:900; color:#ffffff;"><?php echo (int)$plan['duration_days']; ?> Days</span>
          </div>
          <div>
            <span style="font-size:0.68rem; text-transform:uppercase; color:#9ca3af; font-weight:700; letter-spacing:0.3px; display:block;">Min Investment</span>
            <span style="font-size:0.95rem; font-weight:800; color:#ffffff;">₦<?php echo number_format($min_amt); ?></span>
          </div>
          <div>
            <span style="font-size:0.68rem; text-transform:uppercase; color:#9ca3af; font-weight:700; letter-spacing:0.3px; display:block;">Total Return</span>
            <span style="font-size:0.95rem; font-weight:800; color:#eab308;">Capital + <?php echo $roi_pct; ?>%</span>
          </div>
        </div>

        <!-- Invest Now Button (Green Gradient) -->
        <button 
          type="button" 
          class="btn-invest-green"
          onclick="openInvestModal(
            <?php echo (int)$plan['id']; ?>, 
            '<?php echo htmlspecialchars(addslashes($plan['name'])); ?>', 
            <?php echo $min_amt; ?>, 
            <?php echo $max_amt; ?>, 
            <?php echo (int)$plan['duration_days']; ?>, 
            <?php echo $roi_pct; ?>
          )"
        >
          <i class="fa-solid fa-arrow-right-to-bracket"></i> Invest Now
        </button>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ========================================================
     INVESTMENT CONFIRMATION MODAL & TRANSACTION SUMMARY
     ======================================================== -->
<div id="investModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.85); backdrop-filter:blur(6px); z-index:100; align-items:center; justify-content:center; padding: 18px;">
  <div style="background:#0c1712; border:1px solid rgba(16,185,129,0.4); border-radius:24px; max-width:440px; width:100%; padding:22px; box-shadow:0 20px 50px rgba(0,0,0,0.9), 0 0 30px rgba(16,185,129,0.15); position:relative;">
    
    <!-- Modal Header -->
    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px;">
      <div>
        <span style="display:inline-flex; align-items:center; gap:5px; background:rgba(16,185,129,0.18); color:#34d399; font-size:0.68rem; font-weight:800; padding:3px 10px; border-radius:9999px; text-transform:uppercase; margin-bottom:4px;">
          <i class="fa-solid fa-check"></i> Investment Confirmation
        </span>
        <h4 id="modalPlanTitle" style="font-size:1.25rem; font-weight:900; color:#ffffff; margin:0;">Plan Name</h4>
      </div>
      <button type="button" onclick="closeInvestModal()" style="background:#16271e; border:1px solid rgba(16,185,129,0.25); color:#a1a1aa; width:34px; height:34px; border-radius:10px; font-size:1.1rem; cursor:pointer; display:flex; align-items:center; justify-content:center;">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <!-- Order Submission Form with Duplicate Protection -->
    <form id="investOrderForm" method="POST" action="/invest.php" onsubmit="handleInvestSubmit(event)">
      <?php echo csrf_input(); ?>
      <input type="hidden" name="plan_id" id="modalPlanId">

      <!-- Balance Status Bar -->
      <div style="background:#07100b; border:1px solid rgba(16,185,129,0.2); border-radius:14px; padding:12px 14px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
        <span style="font-size:0.78rem; color:#9ca3af;">Available Wallet Balance</span>
        <strong style="font-size:0.95rem; color:#34d399;">₦<?php echo number_format((float)$user['balance'], 2); ?></strong>
      </div>

      <!-- Amount Input with Min-Max Guidance -->
      <div class="form-group" style="margin-bottom:14px;">
        <label class="form-label" id="modalLimitLabel" style="font-size:0.78rem; font-weight:700; color:#d1fae5; margin-bottom:6px; display:block;">
          Investment Amount (₦)
        </label>
        <div style="position:relative;">
          <span style="position:absolute; left:14px; top:50%; transform:translateY(-50%); font-weight:800; color:#34d399; font-size:1rem;">₦</span>
          <input 
            type="number" 
            step="100" 
            name="amount" 
            id="modalAmount" 
            class="form-control" 
            style="padding-left:34px; background:#08120c; border:1px solid rgba(16,185,129,0.3); color:#fff; font-size:1rem; font-weight:700; border-radius:12px;" 
            placeholder="Enter amount" 
            required 
            oninput="recalcModalReturn()"
          >
        </div>
      </div>

      <!-- Transaction Summary Card -->
      <div style="background:#07100c; border:1px solid rgba(16,185,129,0.22); padding:14px; border-radius:14px; margin-bottom:18px; font-size:0.8rem; color:#a1a1aa; display:flex; flex-direction:column; gap:8px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>Plan Duration</span>
          <strong id="modalDuration" style="color:#ffffff;">-- Days</strong>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>Daily Profit Rate</span>
          <strong id="modalRoi" style="color:#34d399; font-weight:800;">45% ROI</strong>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>Expected Net Profit</span>
          <strong id="modalProfit" style="color:#34d399;">₦0.00</strong>
        </div>
        <div style="border-top:1px dashed rgba(16,185,129,0.25); padding-top:8px; display:flex; justify-content:space-between; align-items:center;">
          <span style="font-weight:700; color:#fff;">Total Expected Return</span>
          <strong id="modalReturn" style="color:#eab308; font-size:0.95rem; font-weight:900;">₦0.00</strong>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.75rem;">
          <span>Balance After Order</span>
          <span id="modalBalanceAfter" style="color:#9ca3af; font-weight:700;">₦<?php echo number_format((float)$user['balance'], 2); ?></span>
        </div>
      </div>

      <!-- Confirm Order Button -->
      <button type="submit" id="modalSubmitBtn" class="btn-invest-green" style="padding:14px; font-size:0.95rem;">
        <i class="fa-solid fa-lock"></i> Confirm & Submit Investment Order
      </button>
    </form>
  </div>
</div>

<script>
let currentModalRoi = 45;
let currentMin = 0;
let currentMax = 0;
const currentBalance = <?php echo (float)$user['balance']; ?>;
let isSubmitting = false;

function openInvestModal(id, name, min, max, days, roi) {
  currentModalRoi = Number(roi);
  currentMin = Number(min);
  currentMax = Number(max);
  isSubmitting = false;

  const submitBtn = document.getElementById('modalSubmitBtn');
  submitBtn.disabled = false;
  submitBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Confirm & Submit Investment Order';

  document.getElementById('modalPlanId').value = id;
  document.getElementById('modalPlanTitle').innerText = name;
  document.getElementById('modalLimitLabel').innerText = "Investment Amount (Min ₦" + min.toLocaleString() + " - Max ₦" + max.toLocaleString() + ")";
  
  const amtInput = document.getElementById('modalAmount');
  amtInput.min = min;
  amtInput.max = max;
  amtInput.value = min;

  document.getElementById('modalDuration').innerText = days + " Days";
  document.getElementById('modalRoi').innerText = roi + "% ROI";
  
  recalcModalReturn();
  document.getElementById('investModal').style.display = 'flex';
}

function recalcModalReturn() {
  const amt = Number(document.getElementById('modalAmount').value) || 0;
  const profit = amt * (currentModalRoi / 100);
  const totalReturn = amt + profit;
  const balAfter = currentBalance - amt;

  document.getElementById('modalProfit').innerText = "₦" + profit.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  document.getElementById('modalReturn').innerText = "₦" + totalReturn.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  
  const balAfterEl = document.getElementById('modalBalanceAfter');
  if (balAfter < 0) {
    balAfterEl.innerText = "Insufficient Balance (Deposit Required)";
    balAfterEl.style.color = "#ef4444";
  } else {
    balAfterEl.innerText = "₦" + balAfter.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    balAfterEl.style.color = "#34d399";
  }
}

function closeInvestModal() {
  document.getElementById('investModal').style.display = 'none';
}

// Prevent duplicate form submissions
function handleInvestSubmit(e) {
  if (isSubmitting) {
    e.preventDefault();
    return false;
  }
  const amt = Number(document.getElementById('modalAmount').value) || 0;
  if (amt < currentMin || amt > currentMax) {
    alert("Please enter an amount between ₦" + currentMin.toLocaleString() + " and ₦" + currentMax.toLocaleString());
    e.preventDefault();
    return false;
  }
  if (amt > currentBalance) {
    alert("Insufficient wallet balance. Please deposit funds first.");
    e.preventDefault();
    return false;
  }

  isSubmitting = true;
  const submitBtn = document.getElementById('modalSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting Order...';
  return true;
}
</script>

<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
