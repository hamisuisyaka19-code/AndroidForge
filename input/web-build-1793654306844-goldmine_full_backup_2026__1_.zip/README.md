# GoldMine Investment Platform — 45% ROI Invest Redesign Release Guide

Welcome to the **GoldMine Investment Platform (45% ROI Invest Redesign Release)**. This system is engineered specifically for cPanel shared hosting running **PHP 8.1+ (compatible up to PHP 8.3+)** and **MySQL / MariaDB** using PDO prepared statements, secure session handling, CSRF protection, and zero Node/Docker server dependencies.

---

## 1. What's Included in This Release

### A. Redesigned Invest Page (`invest.php`)
- **Dark Green & White Theme**: Styled with a dark emerald aesthetic (`#080d0a` / `#0f1a14`), high-contrast crisp white typography, and vibrant emerald accents (`#10b981`).
- **Four Official Gold Plans**:
  1. **Starter Gold**: 2 Days Duration | 45% ROI | Min: ₦500.00
  2. **Classic Gold**: 7 Days Duration | 45% ROI | Min: ₦5,000.00
  3. **Premium Gold**: 15 Days Duration | 45% ROI | Min: ₦10,000.00
  4. **VIP Gold**: 30 Days Duration | 45% ROI | Min: ₦50,000.00
- **Gold Bars Artwork**: Rich, vector-quality gold ingot and bullion graphics embedded directly in each plan card.
- **Green 45% ROI Badges**: Prominent badges showing the official daily rate.
- **Green Gradient Investment Buttons**: High-converting emerald gradient with subtle glow and tactile feedback.
- **Comprehensive Investment Confirmation Interface**:
  - Displays selected plan, duration, and configured ROI percentage.
  - Allows user to input amount within configured minimum and maximum limits.
  - Live Transaction Summary (Investment Capital, Expected 45% Net Profit, Total Payout, Balance After Order).
  - Client-side and server-side validation.
  - **Duplicate Submission Prevention**: Disables button with animated spinner state upon submit.
  - Order is saved into `investments` in `pending` review status and immediately reflects in My Invest.

### B. Consistent 45% ROI Database & Calculation Logic
- ROI is configured in MySQL `investment_plans` at `45.00%`.
- Return calculation: `$expected_return = $amount + ($amount * ($plan['roi_percentage'] / 100))`.
- No separate hardcoded values; all user, counting date, and admin views retrieve the configured rate dynamically.

### C. Safe Non-Destructive Migration
- Included `database/upgrade_invest_45_percent.sql` to effortlessly update existing databases in phpMyAdmin without dropping any tables or losing user data.

---

## 2. Upgrading an Existing cPanel Installation
If you already deployed GoldMine on your cPanel host:
1. In cPanel **File Manager**, navigate to `public_html/`.
2. Upload `goldmine_investment_platform_invest_45_percent.zip`.
3. Extract the ZIP in `public_html/` to update application files.
4. Open **phpMyAdmin**, select your database, click the **SQL** tab.
5. Import or run `database/upgrade_invest_45_percent.sql`.
6. All user balances, historical orders, and transactions remain 100% intact.
7. Delete `goldmine_investment_platform_invest_45_percent.zip` from your server root.

---

## 3. Fresh Installation (15-Point cPanel Guide)

### 1. Upload the ZIP
Upload `goldmine_investment_platform_invest_45_percent.zip` to your cPanel `public_html/` via File Manager or FTP.

### 2. Extract Files
Extract `goldmine_investment_platform_invest_45_percent.zip` directly into `public_html/`. Verify that `.htaccess`, `index.php`, `admin/`, `config/`, and `database/` reside directly in your web root.

### 3. Create MySQL Database
In cPanel **MySQL® Databases**, create a new database (e.g., `cpaneluser_goldmine`).

### 4. Create MySQL User
Create a MySQL database user with a strong password (e.g., `cpaneluser_gmadmin`).

### 5. Assign Privileges
Add the user to the database with **ALL PRIVILEGES** selected.

### 6. Import `database.sql`
In **phpMyAdmin**, select your newly created database, click the **Import** tab, choose `database/database.sql`, and click **Go**.

### 7. Configure `config/database.php`
Edit `config/database.php` in File Manager with your credentials:
```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'cpaneluser_goldmine');
define('DB_USER', 'cpaneluser_gmadmin');
define('DB_PASS', 'YourSecurePasswordHere');
```

### 8. Set Domain & Timezone
In `config/app.php`, verify your domain:
```php
define('APP_URL', 'https://goalmindai.com.ng');
define('APP_TIMEZONE', 'Africa/Lagos');
```

### 9. Configure Payment Gateways
In `config/payment.php`, configure your Flutterwave and manual bank deposit details:
```php
define('FLUTTERWAVE_PUBLIC_KEY', 'FLWPUBK_TEST-...');
define('FLUTTERWAVE_SECRET_KEY', 'FLWSECK_TEST-...');
define('FLUTTERWAVE_ENV', 'sandbox'); // Switch to 'live' when going live
```

### 10. Enable SSL (HTTPS)
In cPanel **SSL/TLS Status**, ensure an AutoSSL certificate is active for `goalmindai.com.ng`. The included `.htaccess` automatically enforces HTTPS and hides sensitive directory listings.

### 11. Initial Admin Login
- Admin URL: `https://goalmindai.com.ng/admin/login.php`
- Default Username: `admin`
- Default Password: `ChangeThisAdminPassword2026!`
- *Important: Immediately update your admin password in Admin -> Profile.*

### 12. Test User Registration & Login
Navigate to `https://goalmindai.com.ng/register.php` and create a test user to verify database connectivity.

### 13. Test Investment & Counting Date Workflow
1. Log in as a user and click **Invest Now** on the **Starter Gold** plan (45% ROI).
2. Enter an investment amount and submit.
3. The order will be in `pending` status awaiting administrative review.
4. As admin, navigate to **Admin -> Investment Orders** and click **Approve**.
5. The user's **Counting Date** page and **Dashboard** will now feature the live countdown timer ticking down to maturity.

### 14. File Permissions
Ensure folders have `755` permissions and files have `644` permissions.

### 15. Setup Cron Job (Optional Automation)
In cPanel **Cron Jobs**, add a job to run every 15 minutes:
```bash
/usr/local/bin/php /home/cpaneluser/public_html/includes/cron-maturity.php >/dev/null 2>&1
```
