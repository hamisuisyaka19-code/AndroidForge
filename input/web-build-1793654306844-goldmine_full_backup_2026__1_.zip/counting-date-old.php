<?php
$page_title = "Counting Date";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_user_login();

check_and_update_matured_investments();
$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

$active_investments = [];
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM investments WHERE user_id = ? AND status = 'active' ORDER BY maturity_date ASC");
    $stmt->execute([$user_id]);
    $active_investments = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Counting Date</h3>
  </div>

  <?php if (empty($active_investments)): ?>
    <div style="text-align: center; padding: 60px 20px;">
      <i class="fa-solid fa-hourglass-empty" style="font-size: 48px; color: #3f3f46; margin-bottom: 16px;"></i>
      <h4 style="color: #fff; margin-bottom: 8px;">No Active Countdowns</h4>
      <p style="color: #a1a1aa; font-size: 0.85rem; margin-bottom: 20px;">Once your investment orders are approved by admin, their live counting date countdown will appear here.</p>
      <a href="/invest.php" class="btn-gold" style="display:inline-block; width:auto; padding:10px 24px;">Invest Now</a>
    </div>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap: 18px;">
      <?php foreach ($active_investments as $inv):
          $start_ts = strtotime($inv['start_date'] ?? date('Y-m-d H:i:s'));
          $end_ts = strtotime($inv['maturity_date'] ?? date('Y-m-d H:i:s', time() + 86400));
          $total_duration = max(1, $end_ts - $start_ts);
          $elapsed = max(0, time() - $start_ts);
          $progress_percent = min(100, round(($elapsed / $total_duration) * 100));
      ?>
        <div class="gm-card" data-countdown-target="<?php echo date('c', $end_ts); ?>" style="border: 1px solid rgba(234, 179, 8, 0.3);">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
            <div style="display:flex; align-items:center; gap: 8px;">
              <span style="font-size: 0.95rem; font-weight: 800; color: #fff;"><?php echo htmlspecialchars($inv['reference_code']); ?></span>
            </div>
            <span class="badge badge-active cd-status">Active</span>
          </div>

          <p style="font-size: 0.82rem; color: #a1a1aa; margin:0 0 10px 0;"><?php echo htmlspecialchars($inv['plan_name']); ?></p>

          <div style="background:#111113; border-radius:10px; padding:10px 14px; font-size: 0.78rem; color: #a1a1aa; margin-bottom: 14px; display:flex; flex-direction:column; gap:4px;">
            <div>Amount: <strong style="color:#fff;">₦<?php echo number_format((float)$inv['amount'], 2); ?></strong></div>
            <div>Start Date: <strong style="color:#fff;"><?php echo date('M d, Y', $start_ts); ?></strong></div>
            <div>Maturity Date: <strong style="color:var(--gm-gold);"><?php echo date('M d, Y', $end_ts); ?></strong></div>
          </div>

          <div style="text-align: center; margin-bottom: 8px;">
            <span style="font-size: 0.75rem; color: #a1a1aa; text-transform: uppercase; letter-spacing: 0.5px;">Time Remaining</span>
          </div>

          <!-- Countdown Boxes matching image: 01 Days, 12 Hours, 34 Minutes, 56 Seconds -->
          <div class="countdown-box-container">
            <div class="countdown-box">
              <div class="countdown-num cd-days">00</div>
              <div class="countdown-lbl">Days</div>
            </div>
            <div class="countdown-box">
              <div class="countdown-num cd-hours">00</div>
              <div class="countdown-lbl">Hours</div>
            </div>
            <div class="countdown-box">
              <div class="countdown-num cd-mins">00</div>
              <div class="countdown-lbl">Minutes</div>
            </div>
            <div class="countdown-box">
              <div class="countdown-num cd-secs">00</div>
              <div class="countdown-lbl">Seconds</div>
            </div>
          </div>

          <!-- Progress Bar -->
          <div style="width: 100%; height: 8px; background: #27272a; border-radius: 9999px; overflow: hidden; margin-top: 14px; position:relative;">
            <div style="width: <?php echo $progress_percent; ?>%; height: 100%; background: var(--gm-gold-gradient); border-radius: 9999px;"></div>
          </div>
          <div style="text-align: right; font-size: 0.7rem; color: #a1a1aa; margin-top: 4px;">
            <?php echo $progress_percent; ?>%
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
