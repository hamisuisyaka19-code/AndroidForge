<?php
$page_title = "Create an Account";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/csrf.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security token error. Please refresh and try again.";
    } else {
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $agree = isset($_POST['agree']);

        if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
            $error = "All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } elseif (!$agree) {
            $error = "You must agree to the Terms & Conditions.";
        } else {
            $pdo = get_db_connection();
            if ($pdo) {
                // Check duplicate email
                $chk = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                $chk->execute([$email]);
                if ($chk->fetch()) {
                    $error = "An account with this email already exists.";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $ins = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, balance, status) VALUES (?, ?, ?, ?, 0.00, 'active')");
                    if ($ins->execute([$full_name, $email, $phone, $hash])) {
                        $user_id = (int)$pdo->lastInsertId();
                        add_user_notification($user_id, "Welcome to GoldMine!", "Your account has been created successfully. Explore our high-yield plans and start growing your wealth.", "success");
                        log_audit_action(null, $user_id, "User Registered", "Account created with email " . $email);
                        $_SESSION['user_id'] = $user_id;
                        $_SESSION['user_email'] = $email;
                        $_SESSION['user_name'] = $full_name;
                        header("Location: /dashboard.php?welcome=1");
                        exit;
                    } else {
                        $error = "Registration failed. Please try again.";
                    }
                }
            } else {
                $error = "Database connection error.";
            }
        }
    }
}
?>
<div class="mobile-content" style="padding: 24px 20px;">
  <div style="text-align: center; margin-bottom: 20px;">
    <div style="display:inline-flex; align-items:center; justify-content:center; width:58px; height:58px; background:linear-gradient(135deg, #facc15 0%, #ca8a04 100%); border-radius:16px; box-shadow:0 6px 20px rgba(234, 179, 8, 0.35); margin-bottom: 10px;">
      <span style="font-size: 24px; font-weight: 900; color: #000;">GM</span>
    </div>
    <h2 style="font-size: 1.3rem; font-weight: 800; color:#fff;">Gold<span style="color:#eab308;">Mine</span></h2>
    <p style="font-size: 0.75rem; color: #a1a1aa; text-transform: uppercase;">Investment Platform</p>
  </div>

  <h3 style="font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 18px;">Create an Account</h3>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/register.php">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label"><i class="fa-regular fa-user" style="color:var(--gm-gold); margin-right:6px;"></i> Full Name</label>
      <input type="text" name="full_name" class="form-control" placeholder="e.g. Hamisu Isiyaka" required value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>">
    </div>

    <div class="form-group">
      <label class="form-label"><i class="fa-regular fa-envelope" style="color:var(--gm-gold); margin-right:6px;"></i> Email Address</label>
      <input type="email" name="email" class="form-control" placeholder="e.g. user@example.com" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
    </div>

    <div class="form-group">
      <label class="form-label"><i class="fa-solid fa-phone" style="color:var(--gm-gold); margin-right:6px;"></i> Phone Number</label>
      <input type="tel" name="phone" class="form-control" placeholder="e.g. 08012345678" required value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
    </div>

    <div class="form-group" style="position:relative;">
      <label class="form-label"><i class="fa-solid fa-lock" style="color:var(--gm-gold); margin-right:6px;"></i> Password</label>
      <input type="password" name="password" class="form-control" placeholder="Minimum 8 characters" required>
      <i class="fa-regular fa-eye toggle-password" style="position: absolute; right: 14px; top: 40px; color: #71717a; cursor: pointer;"></i>
    </div>

    <div class="form-group" style="position:relative;">
      <label class="form-label"><i class="fa-solid fa-lock" style="color:var(--gm-gold); margin-right:6px;"></i> Confirm Password</label>
      <input type="password" name="confirm_password" class="form-control" placeholder="Confirm password" required>
      <i class="fa-regular fa-eye toggle-password" style="position: absolute; right: 14px; top: 40px; color: #71717a; cursor: pointer;"></i>
    </div>

    <div style="display:flex; align-items:center; gap:8px; margin: 16px 0 22px 0;">
      <input type="checkbox" id="agree" name="agree" required style="accent-color: var(--gm-gold); width:18px; height:18px;">
      <label for="agree" style="font-size: 0.8rem; color: #a1a1aa;">
        I agree to the <a href="#" style="color:var(--gm-gold); text-decoration:underline;">Terms & Conditions</a>
      </label>
    </div>

    <button type="submit" class="btn-gold" style="margin-bottom: 16px;">Register</button>
  </form>

  <p style="text-align: center; font-size: 0.85rem; color: #a1a1aa;">
    Already have an account? <a href="/login.php" style="color:var(--gm-gold); font-weight:700;">Login</a>
  </p>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
