<?php
/**
 * Global Helper Functions
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

function sanitize(string $data): string {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function format_currency(float|int|string $amount): string {
    return APP_CURRENCY . ' ' . number_format((float)$amount, 2);
}

function generate_reference(string $prefix = 'GM'): string {
    return $prefix . '-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
}

function log_audit_action(?int $admin_id, ?int $user_id, string $action, string $details = ''): void {
    $pdo = get_db_connection();
    if (!$pdo) return;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("INSERT INTO audit_logs (admin_id, user_id, action, details, ip_address) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$admin_id, $user_id, $action, $details, $ip]);
    } catch (PDOException $e) {
        error_log("Audit log failed: " . $e->getMessage());
    }
}

function add_user_notification(int $user_id, string $title, string $message, string $type = 'info', ?string $link = null): bool {
    $pdo = get_db_connection();
    if (!$pdo) return false;
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$user_id, $title, $message, $type, $link]);
    } catch (PDOException $e) {
        error_log("Notification insert failed: " . $e->getMessage());
        return false;
    }
}

function get_unread_notification_count(int $user_id): int {
    $pdo = get_db_connection();
    if (!$pdo) return 0;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

function check_and_update_matured_investments(): void {
    $pdo = get_db_connection();
    if (!$pdo) return;
    try {
        $now = date('Y-m-d H:i:s');
        $stmt = $pdo->prepare("SELECT * FROM investments WHERE status = 'active' AND maturity_date <= ?");
        $stmt->execute([$now]);
        $matured = $stmt->fetchAll();

        foreach ($matured as $inv) {
            $upd = $pdo->prepare("UPDATE investments SET status = 'completed', updated_at = NOW() WHERE id = ?");
            $upd->execute([$inv['id']]);

            add_user_notification(
                (int)$inv['user_id'],
                "Investment Completed: " . $inv['plan_name'],
                "Your investment {$inv['reference_code']} for " . format_currency($inv['amount']) . " has matured on " . $inv['maturity_date'] . ".",
                "success",
                "/counting-date.php"
            );
        }
    } catch (PDOException $e) {
        error_log("Maturity check error: " . $e->getMessage());
    }
}
