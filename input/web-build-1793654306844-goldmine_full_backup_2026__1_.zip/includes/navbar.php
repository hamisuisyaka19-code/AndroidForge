<?php
declare(strict_types=1);
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav class="bottom-nav">
  <a href="/dashboard.php" class="nav-tab <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
    <i class="fa-solid fa-house"></i>
    <span>Home</span>
  </a>
  <a href="/invest.php" class="nav-tab <?php echo $current_page === 'invest.php' ? 'active' : ''; ?>">
    <i class="fa-solid fa-sack-dollar"></i>
    <span>Invest</span>
  </a>
  <a href="/my-invest.php" class="nav-tab <?php echo $current_page === 'my-invest.php' ? 'active' : ''; ?>">
    <i class="fa-solid fa-coins"></i>
    <span>My Invest</span>
  </a>
  <a href="/profile.php" class="nav-tab <?php echo in_array($current_page, ['profile.php', 'settings.php', 'transactions.php']) ? 'active' : ''; ?>">
    <i class="fa-solid fa-bars"></i>
    <span>More</span>
  </a>
</nav>
