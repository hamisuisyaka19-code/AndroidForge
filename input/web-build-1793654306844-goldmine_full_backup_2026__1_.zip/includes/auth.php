<?php
/**
 * Authentication Guards
 */

declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/../config/database.php';

function is_user_logged_in(): bool {
    return !empty($_SESSION['user_id']) && !empty($_SESSION['user_email']);
}

function require_user_login(): void {
    if (!is_user_logged_in()) {
        header("Location: /login.php");
        exit;
    }
}

function get_current_user_data(): ?array {
    if (!is_user_logged_in()) return null;
    $pdo = get_db_connection();
    if (!$pdo) return null;

    $stmt = $pdo->prepare("SELECT id, full_name, email, phone, balance, total_invested, total_profit, status, email_verified, created_at FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function is_admin_logged_in(): bool {
    return !empty($_SESSION['admin_id']) && !empty($_SESSION['admin_email']);
}

function require_admin_login(): void {
    if (!is_admin_logged_in()) {
        header("Location: /admin/login.php");
        exit;
    }
}
