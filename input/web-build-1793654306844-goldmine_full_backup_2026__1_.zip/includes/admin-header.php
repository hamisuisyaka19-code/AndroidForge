<?php
/**
 * GoldMine Admin - Shared Header & Navigation Sidebar
 */
declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/functions.php';
require_admin_login();

$pdo = get_db_connection();
check_and_update_matured_investments();

// Calculate pending badges for sidebar
$pending_invests_count = 0;
$pending_deposits_count = 0;
$pending_withdrawals_count = 0;

if ($pdo) {
    try {
        $pending_invests_count = (int)$pdo->query("SELECT COUNT(*) FROM investments WHERE status = 'pending'")->fetchColumn();
        $pending_deposits_count = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")->fetchColumn();
        $pending_withdrawals_count = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")->fetchColumn();
    } catch (PDOException $e) {
        // Table fallback
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($admin_page_title) ? htmlspecialchars($admin_page_title) . ' - ' : ''; ?>GoldMine Admin</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: #0a0a0c; color: #f4f4f5; display: flex; min-height: 100vh; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .admin-layout { display: flex; width: 100%; min-height: 100vh; }
    .admin-sidebar { width: 260px; background: #111114; border-right: 1px solid #222226; padding: 20px 14px; display: flex; flex-direction: column; justify-content: space-between; shrink: 0; }
    .admin-main { flex: 1; padding: 26px 36px; overflow-y: auto; max-height: 100vh; background: #0a0a0c; }
    .admin-nav-item { display: flex; align-items: center; justify-content: space-between; padding: 11px 14px; border-radius: 12px; color: #a1a1aa; font-weight: 600; font-size: 0.88rem; margin-bottom: 3px; transition: all 0.2s; text-decoration: none; }
    .admin-nav-item:hover, .admin-nav-item.active { background: #1a1a1f; color: var(--gm-gold); }
    .admin-nav-item.active { border-left: 3px solid var(--gm-gold); }
    .admin-card { background: #131316; border: 1px solid #242429; border-radius: 18px; padding: 22px; margin-bottom: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { padding: 12px 14px; font-size: 0.75rem; text-transform: uppercase; color: #71717a; border-bottom: 1px solid #27272a; font-weight: 700; letter-spacing: 0.5px; }
    td { padding: 14px 14px; font-size: 0.84rem; border-bottom: 1px solid #1f1f23; vertical-align: middle; }
    .btn-action-approve { background: #15803d; color: #fff; border: none; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; transition: 0.2s; text-decoration: none; }
    .btn-action-approve:hover { background: #16a34a; }
    .btn-action-reject { background: #b91c1c; color: #fff; border: none; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; transition: 0.2s; text-decoration: none; }
    .btn-action-reject:hover { background: #dc2626; }
    .badge-count { font-size: 0.7rem; font-weight: 800; padding: 2px 7px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="admin-layout">
  <!-- Sidebar Navigation -->
  <aside class="admin-sidebar">
    <div>
      <div style="display:flex; align-items:center; gap: 10px; margin-bottom: 26px; padding: 0 8px;">
        <div style="width: 38px; height: 38px; background: var(--gm-gold-gradient); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: 900; color: #000; box-shadow: 0 4px 14px rgba(234,179,8,0.3);">GM</div>
        <div>
          <h4 style="font-size: 1.05rem; font-weight: 800; color: #fff; margin:0; line-height: 1.1;">Gold<span style="color:var(--gm-gold);">Mine</span></h4>
          <span style="font-size: 0.7rem; color: #a1a1aa; text-transform: uppercase; letter-spacing: 0.5px;">Admin Panel</span>
        </div>
      </div>

      <nav>
        <a href="/admin/dashboard.php" class="admin-nav-item <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-gauge-high"></i> <span>Dashboard</span></div>
        </a>

        <a href="/admin/users.php" class="admin-nav-item <?php echo in_array($current_page, ['users.php', 'user-details.php']) ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-users"></i> <span>Users</span></div>
        </a>

        <a href="/admin/investments.php" class="admin-nav-item <?php echo $current_page === 'investments.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-file-invoice-dollar"></i> <span>Investment Orders</span></div>
          <?php if ($pending_invests_count > 0): ?>
            <span class="badge-count" style="background:#ea580c; color:#fff;"><?php echo $pending_invests_count; ?></span>
          <?php endif; ?>
        </a>

        <a href="/admin/deposits.php" class="admin-nav-item <?php echo $current_page === 'deposits.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-money-bill-transfer"></i> <span>Deposits</span></div>
          <?php if ($pending_deposits_count > 0): ?>
            <span class="badge-count" style="background:#059669; color:#fff;"><?php echo $pending_deposits_count; ?></span>
          <?php endif; ?>
        </a>

        <a href="/admin/withdrawals.php" class="admin-nav-item <?php echo $current_page === 'withdrawals.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-money-bill-wave"></i> <span>Withdrawals</span></div>
          <?php if ($pending_withdrawals_count > 0): ?>
            <span class="badge-count" style="background:#dc2626; color:#fff;"><?php echo $pending_withdrawals_count; ?></span>
          <?php endif; ?>
        </a>

        <!-- Dedicated Counting Date Management -->
        <a href="/admin/counting-date.php" class="admin-nav-item <?php echo $current_page === 'counting-date.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-clock"></i> <span>Counting Date</span></div>
        </a>

        <!-- Dedicated Investment Plans Manager -->
        <a href="/admin/investment-plans.php" class="admin-nav-item <?php echo $current_page === 'investment-plans.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-gem"></i> <span>Investment Plans</span></div>
        </a>

        <a href="/admin/transactions.php" class="admin-nav-item <?php echo $current_page === 'transactions.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-receipt"></i> <span>Transactions</span></div>
        </a>

        <a href="/admin/notifications.php" class="admin-nav-item <?php echo $current_page === 'notifications.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-regular fa-bell"></i> <span>Notifications</span></div>
        </a>

        <a href="/admin/settings.php" class="admin-nav-item <?php echo $current_page === 'settings.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-gear"></i> <span>Settings</span></div>
        </a>

        <a href="/admin/profile.php" class="admin-nav-item <?php echo $current_page === 'profile.php' ? 'active' : ''; ?>">
          <div style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-user-shield"></i> <span>Admin Profile</span></div>
        </a>
      </nav>
    </div>

    <div style="padding-top: 16px; border-top: 1px solid #222226;">
      <a href="/dashboard.php" target="_blank" class="admin-nav-item" style="color:var(--gm-gold); margin-bottom: 6px;">
        <div style="display:flex; align-items:center; gap:8px;"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>View User Portal</span></div>
      </a>
      <a href="/admin/logout.php" class="admin-nav-item" style="color:#ef4444;">
        <div style="display:flex; align-items:center; gap:8px;"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Logout</span></div>
      </a>
    </div>
  </aside>

  <!-- Main Content Wrapper -->
  <main class="admin-main">
    <!-- Top Bar -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #1f1f23;">
      <div>
        <h2 style="font-size: 1.45rem; font-weight: 800; color: #fff; margin:0;"><?php echo htmlspecialchars($admin_page_title ?? 'Dashboard'); ?></h2>
        <span style="font-size: 0.78rem; color: #a1a1aa;"><?php echo htmlspecialchars($admin_page_subtitle ?? 'GoldMine Administrative Portal'); ?></span>
      </div>

      <div style="display:flex; align-items:center; gap: 16px;">
        <a href="/admin/notifications.php" style="position:relative; color:#a1a1aa; text-decoration:none;">
          <i class="fa-regular fa-bell" style="font-size: 1.15rem;"></i>
          <?php if (($pending_invests_count + $pending_deposits_count + $pending_withdrawals_count) > 0): ?>
            <span style="position:absolute; top:-4px; right:-6px; width:8px; height:8px; background:#ef4444; border-radius:50%;"></span>
          <?php endif; ?>
        </a>

        <div style="display:flex; align-items:center; gap: 9px; padding-left: 12px; border-left: 1px solid #222226;">
          <div style="width:34px; height:34px; border-radius:50%; background:#1f1f23; border: 1px solid var(--gm-gold); display:flex; align-items:center; justify-content:center; color:var(--gm-gold); font-size: 12px;">
            <i class="fa-solid fa-user-shield"></i>
          </div>
          <div>
            <span style="font-size: 0.85rem; font-weight: 700; color: #fff; display:block; line-height: 1.2;"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Super Admin'); ?></span>
            <span style="font-size: 0.7rem; color: #71717a;"><?php echo htmlspecialchars($_SESSION['admin_role'] ?? 'super_admin'); ?></span>
          </div>
        </div>
      </div>
    </div>
