<?php
declare(strict_types=1);
?>
</div>
<script src="/assets/js/app.js"></script>
</body>
</html>
