-- GoldMine Manual Bank Transfer receipt support (additive migration only)
-- Run once in phpMyAdmin on the EXISTING GoldMine database.
ALTER TABLE deposits
  ADD COLUMN receipt_path VARCHAR(255) NULL AFTER gateway_ref;
-- Existing deposits are preserved and will have NULL receipt_path.
