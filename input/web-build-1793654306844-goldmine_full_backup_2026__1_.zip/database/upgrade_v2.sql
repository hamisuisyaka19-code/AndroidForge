-- ========================================================
-- GoldMine Investment Platform - Safe Database Upgrade v2
-- Non-destructive migration for existing cPanel deployments
-- ========================================================

SET NAMES utf8mb4;
SET time_zone = '+01:00';

-- 1. Ensure investment_plans has all required columns and proper indexes
CREATE TABLE IF NOT EXISTS `investment_plans` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `min_amount` DECIMAL(15,2) NOT NULL,
  `max_amount` DECIMAL(15,2) NOT NULL,
  `roi_percentage` DECIMAL(5,2) NOT NULL,
  `duration_days` INT UNSIGNED NOT NULL,
  `description` TEXT DEFAULT NULL,
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_plans_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Verify settings has all keys
INSERT INTO `settings` (`key_name`, `value`) VALUES
('app_name', 'GoldMine Investment Platform'),
('site_url', 'https://goalmindai.com.ng'),
('currency_symbol', '₦'),
('currency_code', 'NGN'),
('contact_email', 'support@goalmindai.com.ng'),
('financial_settlement_enabled', '0'),
('min_withdrawal', '2000.00'),
('max_withdrawal', '500000.00'),
('flutterwave_mode', 'sandbox')
ON DUPLICATE KEY UPDATE `key_name`=VALUES(`key_name`);

-- 3. Ensure default verified plans exist
INSERT INTO `investment_plans` (`name`, `slug`, `min_amount`, `max_amount`, `roi_percentage`, `duration_days`, `description`, `sort_order`) VALUES
('Starter Plan', 'starter-plan', 500.00, 4999.00, 35.00, 2, 'Entry level plan. 35% return on completion.', 1),
('Growth Plan', 'growth-plan', 5000.00, 9999.00, 35.00, 7, 'Popular weekly growth plan. 35% return on completion.', 2),
('Premium Plan', 'premium-plan', 10000.00, 49999.00, 35.00, 15, 'Mid-tier investment plan. 35% return on completion.', 3),
('VIP Plan', 'vip-plan', 50000.00, 10000000.00, 35.00, 30, 'High-volume tier. 35% return on completion.', 4)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);
