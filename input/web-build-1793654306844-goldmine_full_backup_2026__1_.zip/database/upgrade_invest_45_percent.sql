-- ========================================================
-- GoldMine Investment Platform - 45% ROI Investment Migration
-- File: upgrade_invest_45_percent.sql
-- Safe & Non-destructive migration for existing cPanel deployments
-- ========================================================

SET NAMES utf8mb4;
SET time_zone = '+01:00';

-- 1. Update investments table default ROI to 45.00
ALTER TABLE `investments` MODIFY COLUMN `roi_percentage` DECIMAL(5,2) NOT NULL DEFAULT 45.00;

-- 2. Upsert the four official GoldMine 45% ROI investment plans:
-- 1. Starter Gold (2 Days, 45% ROI)
-- 2. Classic Gold (7 Days, 45% ROI)
-- 3. Premium Gold (15 Days, 45% ROI)
-- 4. VIP Gold (30 Days, 45% ROI)

INSERT INTO `investment_plans` (`name`, `slug`, `min_amount`, `max_amount`, `roi_percentage`, `duration_days`, `description`, `sort_order`, `status`) VALUES
('Starter Gold', 'starter-gold', 500.00, 4999.00, 45.00, 2, 'Entry level gold tier. 45% return rate on maturity.', 1, 'active'),
('Classic Gold', 'classic-gold', 5000.00, 9999.00, 45.00, 7, 'Popular classic weekly plan. 45% return rate on maturity.', 2, 'active'),
('Premium Gold', 'premium-gold', 10000.00, 49999.00, 45.00, 15, 'Mid-tier gold growth plan. 45% return rate on maturity.', 3, 'active'),
('VIP Gold', 'vip-gold', 50000.00, 10000000.00, 45.00, 30, 'High-volume executive gold tier. 45% return rate on maturity.', 4, 'active')
ON DUPLICATE KEY UPDATE 
  `name` = VALUES(`name`),
  `min_amount` = VALUES(`min_amount`),
  `max_amount` = VALUES(`max_amount`),
  `roi_percentage` = 45.00,
  `duration_days` = VALUES(`duration_days`),
  `description` = VALUES(`description`),
  `status` = 'active',
  `sort_order` = VALUES(`sort_order`);

-- Also update any older plans with 35% ROI to 45% ROI for full consistency
UPDATE `investment_plans` SET `roi_percentage` = 45.00 WHERE `roi_percentage` = 35.00;

-- Complete. All user balances, historical orders, and transactions remain 100% intact.
