-- ========================================================
-- GoldMine Investment Platform - Safe Database Upgrade v3.0.0
-- Comprehensive Production Migration Script
-- Compatible with: MySQL 5.7+ / 8.0+ / MariaDB 10.3+
-- Timezone: Africa/Lagos (+01:00) | Currency: NGN (₦)
-- SAFE TO RUN: Does NOT drop tables or delete user data.
-- ========================================================

SET NAMES utf8mb4;
SET time_zone = '+01:00';

-- 1. Ensure table structure for investment_plans
CREATE TABLE IF NOT EXISTS `investment_plans` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `min_amount` DECIMAL(15,2) NOT NULL,
  `max_amount` DECIMAL(15,2) NOT NULL,
  `roi_percentage` DECIMAL(5,2) NOT NULL DEFAULT 45.00,
  `duration_days` INT UNSIGNED NOT NULL,
  `description` TEXT DEFAULT NULL,
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_plans_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Verify or insert default investment plans matching the 45% ROI specification
INSERT INTO `investment_plans` (`name`, `slug`, `min_amount`, `max_amount`, `roi_percentage`, `duration_days`, `description`, `sort_order`, `status`) VALUES
('Starter Gold', 'starter-gold', 500.00, 4999.00, 45.00, 2, 'Entry level gold tier. 45% return rate on maturity.', 1, 'active'),
('Classic Gold', 'classic-gold', 5000.00, 9999.00, 45.00, 7, 'Popular classic weekly plan. 45% return rate on maturity.', 2, 'active'),
('Premium Gold', 'premium-gold', 10000.00, 49999.00, 45.00, 15, 'Mid-tier gold growth plan. 45% return rate on maturity.', 3, 'active'),
('VIP Gold', 'vip-gold', 50000.00, 10000000.00, 45.00, 30, 'High-volume executive gold tier. 45% return rate on maturity.', 4, 'active')
ON DUPLICATE KEY UPDATE 
  `name` = VALUES(`name`),
  `roi_percentage` = VALUES(`roi_percentage`),
  `description` = VALUES(`description`);

-- 3. Verify settings table and configuration keys
CREATE TABLE IF NOT EXISTS `settings` (
  `key_name` VARCHAR(100) NOT NULL,
  `value` TEXT,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`key_name`, `value`) VALUES
('app_name', 'GoldMine Investment Platform'),
('site_url', 'https://goalmindai.com.ng'),
('currency_symbol', '₦'),
('currency_code', 'NGN'),
('contact_email', 'support@goalmindai.com.ng'),
('financial_settlement_enabled', '0'),
('min_withdrawal', '2000.00'),
('max_withdrawal', '500000.00'),
('flutterwave_mode', 'sandbox')
ON DUPLICATE KEY UPDATE `key_name` = `key_name`;

-- 4. Audit Log Table structure
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_id` INT UNSIGNED DEFAULT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_admin` (`admin_id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Upgrade completed safely.
