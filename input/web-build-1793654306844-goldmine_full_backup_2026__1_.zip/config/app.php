<?php
/**
 * GoldMine Investment Platform - Application Settings
 */

declare(strict_types=1);

// Set default timezone to Nigeria / Lagos
date_default_timezone_set('Africa/Lagos');

define('APP_NAME', 'GoldMine Investment Platform');
define('APP_SHORT_NAME', 'GoldMine');
define('APP_URL', 'https://goalmindai.com.ng');
define('APP_CURRENCY', '₦');
define('APP_CURRENCY_CODE', 'NGN');
define('APP_VERSION', '1.0.0');

// Environment: 'production' or 'development'
define('APP_ENV', 'production');

// Financial settlements gate (compliance lock until payment gateway & legal oversight is signed off)
define('FINANCIAL_SETTLEMENT_ENABLED', false);

// Session lifetime (seconds)
define('SESSION_LIFETIME', 3600); // 1 hour
