<?php
/**
 * GoldMine Investment Platform - Database Configuration
 * Compatible with PHP 8.1+ & MySQL / MariaDB via PDO
 */

declare(strict_types=1);

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'lhzmylpw_goldmine');
define('DB_USER', getenv('DB_USER') ?: 'lhzmylpw_goldmineapp');
define('DB_PASS', getenv('DB_PASS') ?: 'D)YYim9b}xH8Xa.C'); // Set your cPanel MySQL user password here
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO instance with strict error reporting and prepared statements.
 */
function get_db_connection(): ?PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone = '+01:00'"
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Safe logging without exposing credentials to visitors
        error_log("Database connection error: " . $e->getMessage());
        return null;
    }
}
