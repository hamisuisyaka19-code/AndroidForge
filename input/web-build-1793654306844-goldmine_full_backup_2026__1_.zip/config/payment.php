<?php
/** GoldMine Investment Platform - Manual Bank Transfer Settings */
declare(strict_types=1);

// Manual bank transfer details supplied by the account owner.
define('COMPANY_BANK_NAME', 'Kuda Bank');
define('COMPANY_ACCOUNT_NUMBER', '2009888249');
define('COMPANY_ACCOUNT_NAME', 'Hamisu Isiyaka');
