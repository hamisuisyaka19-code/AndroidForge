# GoldMine Investment Platform - cPanel API Installation Guide

Target Domain: https://goalmindai.com.ng/
API Folder: public_html/api/

## Quick 3-Step Setup

1. Locate the `cpanel-api/` directory (or use `goldmine-cpanel-api.zip`).
2. In your cPanel File Manager, upload and place the contents of `cpanel-api/` into `public_html/api/`.
3. Verify by visiting:
   https://goalmindai.com.ng/api/health.php

Expected Output:
```json
{"success":true,"message":"GoldMine API is online and operational.","data":{"database":"Connected"}}
```

All existing website templates, user records, and admin panel dashboards remain 100% untouched and functional.
