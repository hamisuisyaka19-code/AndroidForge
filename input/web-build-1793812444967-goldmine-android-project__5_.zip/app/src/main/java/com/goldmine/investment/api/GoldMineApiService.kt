package com.goldmine.investment.api

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface GoldMineApiService {

    @POST("auth/login.php")
    suspend fun login(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthData>>

    @POST("auth/register.php")
    suspend fun register(
        @Body request: Map<String, String>
    ): Response<ApiResponse<AuthData>>

    @GET("auth/profile.php")
    suspend fun getProfile(): Response<ApiResponse<UserDto>>

    @POST("auth/profile.php")
    suspend fun updateProfile(
        @Body request: Map<String, String>
    ): Response<ApiResponse<Map<String, String>>>

    @GET("plans/index.php")
    suspend fun getPlans(): Response<ApiResponse<List<PlanDto>>>

    @GET("investments/index.php")
    suspend fun getInvestments(): Response<ApiResponse<InvestmentData>>

    @POST("investments/index.php")
    suspend fun createInvestment(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("deposits/bank-details.php")
    suspend fun getBankDetails(): Response<ApiResponse<BankDetailsDto>>

    @GET("deposits/index.php")
    suspend fun getDeposits(): Response<ApiResponse<List<DepositDto>>>

    @Multipart
    @POST("deposits/index.php")
    suspend fun submitDepositMultipart(
        @Part("amount") amount: RequestBody,
        @Part("payment_method") method: RequestBody,
        @Part receipt: MultipartBody.Part?
    ): Response<ApiResponse<Map<String, Any>>>

    @POST("deposits/index.php")
    suspend fun submitDepositJson(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("withdrawals/index.php")
    suspend fun getWithdrawals(): Response<ApiResponse<List<WithdrawalDto>>>

    @POST("withdrawals/index.php")
    suspend fun requestWithdrawal(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("transactions/index.php")
    suspend fun getTransactions(): Response<ApiResponse<List<TransactionDto>>>

    @GET("health.php")
    suspend fun healthCheck(): Response<ApiResponse<Map<String, Any>>>
}
