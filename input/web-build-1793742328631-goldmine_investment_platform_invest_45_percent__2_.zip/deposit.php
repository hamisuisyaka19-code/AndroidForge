<?php
$page_title = "Deposit";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/config/payment.php';
require_user_login();

$user_id = (int)$_SESSION['user_id'];
$pdo = get_db_connection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Session expired or invalid security token.";
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        $method = sanitize($_POST['payment_method'] ?? 'Flutterwave');

        if ($amount < 500) {
            $error = "Minimum deposit amount is ₦500.00";
        } else {
            $ref = generate_reference('DEP');
            try {
                $ins = $pdo->prepare("INSERT INTO deposits (reference_code, user_id, amount, payment_method, status) VALUES (?, ?, ?, ?, 'pending')");
                $ins->execute([$ref, $user_id, $amount, $method]);

                // Create pending transaction record
                $tx = $pdo->prepare("INSERT INTO transactions (reference_code, user_id, type, amount, status, description) VALUES (?, ?, 'deposit', ?, 'pending', ?)");
                $tx->execute([$ref, $user_id, $amount, "Deposit request via " . $method]);

                add_user_notification($user_id, "Deposit Request Submitted", "Your deposit of " . format_currency($amount) . " ($ref) is awaiting administrator approval.", "info", "/deposit.php");
                log_audit_action(null, $user_id, "Deposit Request Submitted", "Deposit $ref for " . format_currency($amount));

                $success = "Deposit request submitted! Once verified by administrator, your balance will be credited.";
            } catch (Exception $e) {
                $error = "Deposit error: " . $e->getMessage();
            }
        }
    }
}

// Fetch deposit history
$history = [];
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 10");
    $stmt->execute([$user_id]);
    $history = $stmt->fetchAll();
}
?>
<div class="mobile-content">
  <div style="display:flex; align-items:center; gap: 14px; margin-bottom: 20px;">
    <a href="/dashboard.php" style="color: #fff; font-size: 1.1rem;"><i class="fa-solid fa-arrow-left"></i></a>
    <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin:0;">Deposit</h3>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #f87171; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($error); ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.4); color: #4ade80; padding: 12px; border-radius: 12px; font-size: 0.85rem; margin-bottom: 18px;">
      <?php echo htmlspecialchars($success); ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="/deposit.php" style="margin-bottom: 28px;">
    <?php echo csrf_input(); ?>
    <div class="form-group">
      <label class="form-label">Deposit Amount (₦)</label>
      <input type="number" step="100" name="amount" class="form-control" placeholder="Enter amount" required min="500">
    </div>

    <div class="form-group">
      <label class="form-label">Payment Method</label>
      <div style="background:#18181b; border: 1px solid var(--gm-gold); border-radius: 12px; padding: 14px; display:flex; align-items:center; gap: 12px;">
        <div style="width:36px; height:36px; border-radius:8px; background:#f97316; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:900;">
          <i class="fa-solid fa-bolt"></i>
        </div>
        <div style="flex:1;">
          <span style="font-size: 0.9rem; font-weight: 700; color:#fff;">Flutterwave</span>
          <p style="font-size: 0.72rem; color:#a1a1aa; margin:0;">(Card, Bank, USSD)</p>
        </div>
        <i class="fa-solid fa-circle-check" style="color:var(--gm-gold);"></i>
      </div>
      <input type="hidden" name="payment_method" value="Flutterwave">
    </div>

    <button type="submit" class="btn-gold" style="margin-top: 10px;">Proceed to Pay</button>
  </form>

  <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin-bottom: 14px;">Deposit History</h4>
  <div style="display:flex; flex-direction:column; gap: 10px;">
    <?php if (empty($history)): ?>
      <p style="color:#71717a; font-size:0.8rem; text-align:center;">No deposit records found.</p>
    <?php else: ?>
      <?php foreach ($history as $dep): ?>
        <div class="gm-card" style="padding: 14px; margin-bottom: 0;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-size: 1rem; font-weight: 800; color: #fff;">₦<?php echo number_format((float)$dep['amount'], 2); ?></span>
              <p style="font-size: 0.7rem; color: #a1a1aa; margin:2px 0 0 0;"><?php echo date('M d, Y, h:i A', strtotime($dep['created_at'])); ?></p>
            </div>
            <span class="badge badge-<?php echo $dep['status']; ?>"><?php echo ucfirst(str_replace('_', ' ', $dep['status'])); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<?php
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
?>
