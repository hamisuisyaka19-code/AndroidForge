<?php
/**
 * GoldMine Investment Platform - Payment Gateway Settings (Flutterwave)
 */

declare(strict_types=1);

define('FLUTTERWAVE_ENV', 'sandbox'); // sandbox or live
define('FLUTTERWAVE_PUBLIC_KEY', getenv('FLUTTERWAVE_PUBLIC_KEY') ?: 'FLWPUBK_TEST-SANDBOX-DEMO-X');
define('FLUTTERWAVE_SECRET_KEY', getenv('FLUTTERWAVE_SECRET_KEY') ?: 'FLWSECK_TEST-SANDBOX-DEMO-X');
define('FLUTTERWAVE_ENCRYPTION_KEY', getenv('FLUTTERWAVE_ENCRYPTION_KEY') ?: 'FLWSECK_TEST-DEMO-KEY');

// Bank transfer details for manual/review mode
define('COMPANY_BANK_NAME', 'Guaranty Trust Bank (GTBank)');
define('COMPANY_ACCOUNT_NUMBER', '0123456789');
define('COMPANY_ACCOUNT_NAME', 'GoldMine Global Ventures Ltd');
