package com.goldmine.investment.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.api.PlanDto
import com.goldmine.investment.util.CurrencyFormatter

class PlanAdapter(private val onInvestClick: (PlanDto) -> Unit) :
    RecyclerView.Adapter<PlanAdapter.PlanViewHolder>() {

    private var items = listOf<PlanDto>()

    fun submitList(list: List<PlanDto>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_plan, parent, false)
        return PlanViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class PlanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName = itemView.findViewById<TextView>(R.id.tvPlanName)
        private val tvProfitBadge = itemView.findViewById<TextView>(R.id.tvPlanProfitBadge)
        private val tvMeta = itemView.findViewById<TextView>(R.id.tvPlanMeta)
        private val btnInvestNow = itemView.findViewById<Button>(R.id.btnInvestNow)

        fun bind(plan: PlanDto) {
            tvName.text = plan.name
            tvProfitBadge.text = "${plan.roiPercentage.toInt()}% Profit"
            tvMeta.text = "Min: ${CurrencyFormatter.formatClean(plan.minAmount)}   |   Duration: ${plan.durationDays} Days"

            btnInvestNow.setOnClickListener {
                onInvestClick(plan)
            }
        }
    }
}
