package com.goldmine.investment.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.adapters.InvestmentAdapter
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MyInvestmentsFragment : Fragment() {

    private val repository = GoldMineRepository()
    private lateinit var adapter: InvestmentAdapter
    private var showingActive = true
    private var tickerJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_my_investments, container, false)
        val rv = root.findViewById<RecyclerView>(R.id.rvInvestments)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = InvestmentAdapter()
        rv.adapter = adapter

        val cardActive = root.findViewById<View>(R.id.cardActiveCounting)
        val cardCompleted = root.findViewById<View>(R.id.cardCompleted)
        val tvSectionHeader = root.findViewById<TextView>(R.id.tvSectionHeader)

        loadInvestments(root)

        cardActive?.setOnClickListener {
            showingActive = true
            tvSectionHeader?.text = "Active Investments"
            loadInvestments(root)
        }

        cardCompleted?.setOnClickListener {
            showingActive = false
            tvSectionHeader?.text = "Matured & Completed Investments"
            loadInvestments(root)
        }

        // Active continuous 1-second ticker coroutine
        startCountdownTicker()

        return root
    }

    private fun startCountdownTicker() {
        tickerJob?.cancel()
        tickerJob = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                delay(1000)
                adapter.tick()
            }
        }
    }

    private fun loadInvestments(root: View) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.getInvestments().onSuccess { data ->
                root.findViewById<TextView>(R.id.tvActiveCount)?.text = data.totalActive.toString()
                root.findViewById<TextView>(R.id.tvCompletedCount)?.text = data.totalCompleted.toString()
                adapter.submitList(if (showingActive) data.active else data.completed)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        tickerJob?.cancel()
    }
}
