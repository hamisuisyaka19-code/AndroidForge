package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.goldmine.investment.R
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val homeFragment = HomeFragment()
    private val investPlansFragment = InvestPlansFragment()
    private val myInvestmentsFragment = MyInvestmentsFragment()
    private val walletFragment = WalletFragment()
    private val profileFragment = ProfileFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadFragment(homeFragment)
                R.id.nav_invest -> loadFragment(investPlansFragment)
                R.id.nav_my_invest -> loadFragment(myInvestmentsFragment)
                R.id.nav_wallet -> loadFragment(walletFragment)
                R.id.nav_profile -> loadFragment(profileFragment)
                else -> false
            }
        }

        val initialTab = intent.getIntExtra(EXTRA_NAV_TAB, R.id.nav_home)
        navigateToTab(initialTab)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tabId = intent?.getIntExtra(EXTRA_NAV_TAB, -1) ?: -1
        if (tabId != -1) {
            navigateToTab(tabId)
        }
    }

    fun navigateToTab(tabId: Int) {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNav.selectedItemId = tabId
    }

    private fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
        return true
    }

    companion object {
        const val EXTRA_NAV_TAB = "extra_nav_tab"
    }
}
