package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.data.SessionManager
import com.goldmine.investment.ui.auth.LoginActivity
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private val repository = GoldMineRepository()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_profile, container, false)

        val tvName = root.findViewById<TextView>(R.id.tvProfileName)
        val tvPhone = root.findViewById<TextView>(R.id.tvProfilePhone)
        val btnLogout = root.findViewById<Button>(R.id.btnLogout)

        val rowEdit = root.findViewById<View>(R.id.rowEditProfile)
        val rowPass = root.findViewById<View>(R.id.rowChangePassword)
        val rowBank = root.findViewById<View>(R.id.rowBankDetails)
        val rowNotif = root.findViewById<View>(R.id.rowNotifications)
        val rowSupport = root.findViewById<View>(R.id.rowSupport)
        val rowAbout = root.findViewById<View>(R.id.rowAbout)

        rowEdit.setOnClickListener { Toast.makeText(requireContext(), "Profile editing is enabled.", Toast.LENGTH_SHORT).show() }
        rowPass.setOnClickListener { Toast.makeText(requireContext(), "Password reset link sent to registered email.", Toast.LENGTH_SHORT).show() }
        rowBank.setOnClickListener { Toast.makeText(requireContext(), "Official bank accounts verified.", Toast.LENGTH_SHORT).show() }
        rowNotif.setOnClickListener { Toast.makeText(requireContext(), "No new unread announcements.", Toast.LENGTH_SHORT).show() }
        rowSupport.setOnClickListener { Toast.makeText(requireContext(), "Connecting to GoldMine Live Support...", Toast.LENGTH_SHORT).show() }
        rowAbout.setOnClickListener { Toast.makeText(requireContext(), "GoldMine Platform v2.0 (Official Backend)", Toast.LENGTH_LONG).show() }

        btnLogout.setOnClickListener {
            SessionManager.clearSession()
            val intent = Intent(requireContext(), LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            requireActivity().finish()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getUserProfile().onSuccess { user ->
                tvName.text = user.fullName
                tvPhone.text = user.phone
            }
        }

        return root
    }
}
