package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private val repository = GoldMineRepository()
    private var isBalanceHidden = false
    private var actualBalance = 250000.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)

        val tvGreeting = root.findViewById<TextView>(R.id.tvGreeting)
        val tvTotalBalance = root.findViewById<TextView>(R.id.tvTotalBalance)
        val tvTotalInvested = root.findViewById<TextView>(R.id.tvTotalInvested)
        val tvTotalProfit = root.findViewById<TextView>(R.id.tvTotalProfit)
        val btnToggleBalance = root.findViewById<ImageView>(R.id.btnToggleBalance)

        val btnQuickDeposit = root.findViewById<View>(R.id.btnQuickDeposit)
        val btnQuickInvest = root.findViewById<View>(R.id.btnQuickInvest)
        val btnQuickWithdraw = root.findViewById<View>(R.id.btnQuickWithdraw)
        val btnQuickSupport = root.findViewById<View>(R.id.btnQuickSupport)
        val tvSeeAllPlans = root.findViewById<TextView>(R.id.tvSeeAllPlans)

        btnQuickDeposit.setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }

        btnQuickInvest.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }

        btnQuickWithdraw.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }

        btnQuickSupport.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_profile)
        }

        tvSeeAllPlans.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_invest)
        }

        btnToggleBalance.setOnClickListener {
            isBalanceHidden = !isBalanceHidden
            if (isBalanceHidden) {
                tvTotalBalance.text = "••••••••"
            } else {
                tvTotalBalance.text = CurrencyFormatter.format(actualBalance)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getUserProfile().onSuccess { user ->
                tvGreeting.text = "Hello, ${user.fullName.split(" ").firstOrNull() ?: "Member"} 👋"
                actualBalance = user.balance
                if (!isBalanceHidden) {
                    tvTotalBalance.text = CurrencyFormatter.format(user.balance)
                }
                tvTotalInvested.text = CurrencyFormatter.format(user.totalInvested)
                tvTotalProfit.text = CurrencyFormatter.format(user.totalProfit)
            }
        }

        return root
    }
}
