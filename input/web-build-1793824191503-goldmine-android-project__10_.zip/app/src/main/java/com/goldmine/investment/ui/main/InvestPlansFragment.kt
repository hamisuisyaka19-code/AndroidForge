package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.adapters.PlanAdapter
import com.goldmine.investment.ui.invest.InvestActivity
import kotlinx.coroutines.launch

class InvestPlansFragment : Fragment() {

    private val repository = GoldMineRepository()
    private lateinit var adapter: PlanAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_invest_plans, container, false)
        val rv = root.findViewById<RecyclerView>(R.id.rvPlans)
        rv.layoutManager = LinearLayoutManager(requireContext())

        // FIX BUG 1: Opening dedicated InvestActivity when clicking Invest Now
        adapter = PlanAdapter { plan ->
            val intent = Intent(requireContext(), InvestActivity::class.java).apply {
                putExtra(InvestActivity.EXTRA_PLAN_ID, plan.id)
                putExtra(InvestActivity.EXTRA_PLAN_NAME, plan.name)
                putExtra(InvestActivity.EXTRA_MIN_AMOUNT, plan.minAmount)
                putExtra(InvestActivity.EXTRA_MAX_AMOUNT, plan.maxAmount)
                putExtra(InvestActivity.EXTRA_ROI_PERCENTAGE, plan.roiPercentage)
                putExtra(InvestActivity.EXTRA_DURATION_DAYS, plan.durationDays)
            }
            startActivity(intent)
        }
        rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getPlans().onSuccess { plans ->
                adapter.submitList(plans)
            }.onFailure {
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
            }
        }

        return root
    }
}
