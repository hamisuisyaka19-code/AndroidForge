package com.goldmine.investment.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.goldmine.investment.R
import com.goldmine.investment.data.GoldMineRepository
import com.goldmine.investment.ui.deposit.DepositActivity
import com.goldmine.investment.ui.transactions.TransactionsActivity
import com.goldmine.investment.ui.withdraw.WithdrawActivity
import com.goldmine.investment.util.CurrencyFormatter
import kotlinx.coroutines.launch

class WalletFragment : Fragment() {

    private val repository = GoldMineRepository()
    private var isHidden = false
    private var balanceAmount = 250000.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_wallet, container, false)

        val tvBalance = root.findViewById<TextView>(R.id.tvWalletBalance)
        val btnToggle = root.findViewById<ImageView>(R.id.btnToggleWalletBalance)

        val btnDeposit = root.findViewById<View>(R.id.btnWalletDeposit)
        val btnWithdraw = root.findViewById<View>(R.id.btnWalletWithdraw)
        val btnTransfer = root.findViewById<View>(R.id.btnWalletTransfer)

        val rowTx = root.findViewById<View>(R.id.rowTxHistory)
        val rowDep = root.findViewById<View>(R.id.rowDepositHistory)
        val rowWth = root.findViewById<View>(R.id.rowWithdrawalHistory)

        btnToggle.setOnClickListener {
            isHidden = !isHidden
            tvBalance.text = if (isHidden) "••••••••" else CurrencyFormatter.format(balanceAmount)
        }

        btnDeposit.setOnClickListener {
            startActivity(Intent(requireContext(), DepositActivity::class.java))
        }

        btnWithdraw.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawActivity::class.java))
        }

        btnTransfer.setOnClickListener {
            Toast.makeText(requireContext(), "Member-to-member transfer is available for VIP accounts.", Toast.LENGTH_SHORT).show()
        }

        rowTx.setOnClickListener {
            startActivity(Intent(requireContext(), TransactionsActivity::class.java))
        }

        rowDep.setOnClickListener {
            startActivity(Intent(requireContext(), TransactionsActivity::class.java))
        }

        rowWth.setOnClickListener {
            startActivity(Intent(requireContext(), TransactionsActivity::class.java))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getUserProfile().onSuccess { user ->
                balanceAmount = user.balance
                if (!isHidden) {
                    tvBalance.text = CurrencyFormatter.format(user.balance)
                }
            }
        }

        return root
    }
}
