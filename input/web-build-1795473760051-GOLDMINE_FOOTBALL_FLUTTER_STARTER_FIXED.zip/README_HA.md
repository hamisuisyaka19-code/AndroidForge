# GOLDMINE FOOTBALL — Flutter Starter

Wannan shi ne farkon Flutter source project na GOLDMINE FOOTBALL.

## Abubuwan da ke ciki
- Flutter app shell da bottom navigation
- Green / white / dark-gold design
- Home screen
- Live, Fixtures, Predictions, Account placeholder screens
- API client foundation
- Babu fake fixtures, fake scores, ko fake predictions

## Muhimmin bayani
Mobile API na PHP ba a ƙirƙira ko tura shi zuwa Hostinger ba tukuna. Saboda haka `mobileApiEnabled` yana `false` a `lib/core/config/app_config.dart`. Kada a kunna shi sai an gina kuma an gwada endpoints a server.

## Buɗewa da gwadawa
1. Extract ZIP.
2. Buɗe project folder a Flutter-capable environment.
3. Run `flutter pub get`.
4. Run `flutter analyze`.
5. Run `flutter run`.

## AndroidForge
Yi amfani da Flutter project ZIP ɗin nan a matsayin source. Idan AndroidForge yana buƙatar GitHub repository, ka fara upload project ɗin zuwa sabon private repository. Kada ka saka secrets ko production credentials a repository.

## Mataki na gaba
A gina `public_html/api/mobile/v1/` a matsayin sabon API layer, ba tare da canza `api/actions.php`, `includes/config.php`, ko database data ba. Bayan an gwada API, sai a saita `apiBaseUrl` da `mobileApiEnabled=true`.

## Tsaro
- Kada a saka Sportmonks token a cikin Flutter app.
- Kada a saka database credentials a cikin Flutter app.
- Kada a adana password plain text.
- Yi amfani da HTTPS.

## Gyaran build na farko
An gyara amfani da `shade700` a kan `Color` wanda zai iya haifar da Dart compile error. An maye gurbinsa da launin gold ɗin theme kai tsaye.
