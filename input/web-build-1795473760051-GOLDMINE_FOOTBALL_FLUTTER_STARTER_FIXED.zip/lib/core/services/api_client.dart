import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class ApiClient {
  final http.Client _client;

  ApiClient({http.Client? client}) : _client = client ?? http.Client();

  bool get isConfigured => AppConfig.mobileApiEnabled;

  Future<Map<String, dynamic>> getJson(String path) async {
    if (!isConfigured) {
      throw const ApiNotConfiguredException();
    }
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/$path');
    final response = await _client.get(uri, headers: {
      'Accept': 'application/json',
    }).timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException('Server ya dawo da HTTP ${response.statusCode}.');
    }
    final decoded = jsonDecode(response.body);
    if (decoded is! Map<String, dynamic>) {
      throw ApiException('Amsar server ba JSON object ba ce.');
    }
    return decoded;
  }

  void close() => _client.close();
}

class ApiNotConfiguredException implements Exception {
  const ApiNotConfiguredException();
  @override
  String toString() => 'Mobile API bai gama shiryawa ba tukuna.';
}

class ApiException implements Exception {
  const ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}
