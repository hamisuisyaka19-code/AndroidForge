class AppConfig {
  // Mobile API will be implemented separately on the existing PHP website.
  // Keep this URL unchanged until the mobile endpoints have been deployed.
  static const String apiBaseUrl = 'https://goalmindai.com.ng/api/mobile/v1';

  // Change to true only after the server-side mobile API is deployed and tested.
  static const bool mobileApiEnabled = false;
}
