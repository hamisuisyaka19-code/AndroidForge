import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import 'home_screen.dart';
import 'simple_section_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;

  final pages = const [
    HomeScreen(),
    SimpleSectionScreen(title: 'Live Football', subtitle: 'Live scores daga GOLDMINE API za su bayyana nan.'),
    SimpleSectionScreen(title: 'Fixtures', subtitle: 'Wasannin yau da masu zuwa za su bayyana nan.'),
    SimpleSectionScreen(title: 'Predictions', subtitle: 'Predictions da Admin ya wallafa za su bayyana nan.'),
    SimpleSectionScreen(title: 'My Account', subtitle: 'Login da bayanan account za a haɗa a mataki na gaba.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: selected, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (value) => setState(() => selected = value),
        backgroundColor: Colors.white,
        indicatorColor: AppTheme.gold.withValues(alpha: .18),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Fixtures'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Tips'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }
}
