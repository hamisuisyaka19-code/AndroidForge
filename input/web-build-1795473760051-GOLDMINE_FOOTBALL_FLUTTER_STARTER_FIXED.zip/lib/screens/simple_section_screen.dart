import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class SimpleSectionScreen extends StatelessWidget {
  const SimpleSectionScreen({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 20),
      const Text('GOLDMINE FOOTBALL', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontSize: 11)),
      const SizedBox(height: 8),
      Text(title, style: const TextStyle(color: AppTheme.deepGreen, fontWeight: FontWeight.w900, fontSize: 25)),
      const SizedBox(height: 18),
      Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Column(children: [
        const Icon(Icons.hourglass_empty_rounded, size: 34, color: AppTheme.green),
        const SizedBox(height: 10),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(height: 1.5, color: Colors.black54)),
      ])),
    ]),
  );
}
