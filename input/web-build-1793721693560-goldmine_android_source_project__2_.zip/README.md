# GoldMine Investment Platform — Android Native Application Project

**Application Name:** GoldMine Investment Platform  
**Target Platform:** Android (API 24 to 34+ / Android 7.0 to Android 14+)  
**Theme:** Premium Black & Gold (`#080D0A`, `#121814`, `#EAB308`, `#10B981`)  
**Backend Host:** `https://goalmindai.com.ng` (cPanel MySQL & PHP 8.1+ PDO)  

---

## 1. Project Architecture & Features

This repository is a complete, native Android Studio project built in Java with modern Android Jetpack architecture components:

- **Retrofit 2 & OkHttp 3:** Secure HTTPS API communication with connection pooling, logging, and automated token/session injection.
- **SessionManager:** SharedPreferences user session persistence, remember-me support, and balance caching.
- **Material Components (MDC):** High-end gold gradient buttons, rounded elevation cards, and bottom navigation bar.
- **Counting Date Engine:** Real-time ticking countdown timer (days, hours, minutes, seconds) with dynamic progress calculation based on start and maturity timestamps.
- **Live 45% ROI Investment Confirmation:** Separate dedicated screen with client-side and server-side balance checking, instant expected payout calculation, and duplicate submission prevention.
- **Manual Bank Transfer Deposit:** Direct funding interface displaying the official **Kuda Bank account (2009888249 - Hamisu Isiyaka)** with one-click clipboard copying and payment proof attachment.
- **Direct Support Integration:** Direct links to official WhatsApp support, Telegram channel, and email helpdesk.

---

## 2. Compilation & APK Building Methods

### Option A: Compile with Android Studio (Local Computer)
1. Download or extract the project ZIP.
2. Open **Android Studio** (Hedgehog, Iguana, Koala, or Ladybug).
3. Select **File -> Open...** and choose the `android-project/` folder.
4. Allow Gradle to sync dependencies automatically.
5. In the top toolbar, click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
6. The compiled APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Option B: Build via AndroidForge / Cloud APK Builders
1. Upload the `goldmine_android_source_project.zip` to your GitHub repository or AndroidForge builder.
2. Select Gradle Version `8.2+` and JDK `17`.
3. Set Build Command: `./gradlew assembleRelease` or `./gradlew assembleDebug`.
4. Download your signed or debug APK directly.

### Option C: Instant Compilation via GitHub Actions
1. Push this project to any GitHub repository.
2. The included `.github/workflows/build-apk.yml` workflow will automatically trigger.
3. Once the build completes (~2 minutes), click the **Actions** tab on GitHub and download the compiled **GoldMine-Debug-APK** artifact!

---

## 3. Connecting to the Backend

The Android app communicates with your existing cPanel backend at `https://goalmindai.com.ng`.

### Backend API Addon Installation (Zero DB Changes):
1. In your cPanel File Manager, upload the contents of `backend-api-addon/api/` into `public_html/api/`.
2. All endpoints (`index.php?action=login`, `action=dashboard`, `action=plans`, `action=invest`, etc.) directly utilize your existing `config/database.php`, `config/payment.php`, and MySQL tables (`users`, `investments`, `deposits`, `withdrawals`).
3. No database tables are modified, deleted, or altered.

---

## 4. Default Official Bank Details

- **Bank Name:** Kuda Bank
- **Account Number:** 2009888249
- **Account Name:** Hamisu Isiyaka
- **Official ROI Rate:** 45.00% Guaranteed Return on Plan Maturity
