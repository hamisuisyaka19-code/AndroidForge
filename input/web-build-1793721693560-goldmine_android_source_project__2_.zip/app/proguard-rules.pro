# Add project specific ProGuard rules here.
-keep class com.goldmine.investmentplatform.model.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-dontwarn okhttp3.**
-dontwarn retrofit2.**
