package com.goldmine.investmentplatform.api;

import android.content.Context;
import android.content.SharedPreferences;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.util.Constants;

public class SessionManager {
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveUserSession(User user, String token) {
        editor.putBoolean(Constants.KEY_IS_LOGGED_IN, true);
        editor.putString(Constants.KEY_AUTH_TOKEN, token != null ? token : String.valueOf(user.getId()));
        editor.putInt(Constants.KEY_USER_ID, user.getId());
        editor.putString(Constants.KEY_USER_NAME, user.getFullName());
        editor.putString(Constants.KEY_USER_EMAIL, user.getEmail());
        editor.putString(Constants.KEY_USER_PHONE, user.getPhone());
        editor.putString(Constants.KEY_USER_BALANCE, String.valueOf(user.getBalance()));
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(Constants.KEY_IS_LOGGED_IN, false);
    }

    public int getUserId() {
        return prefs.getInt(Constants.KEY_USER_ID, 0);
    }

    public String getAuthToken() {
        return prefs.getString(Constants.KEY_AUTH_TOKEN, "");
    }

    public String getUserName() {
        return prefs.getString(Constants.KEY_USER_NAME, "Investor");
    }

    public String getUserEmail() {
        return prefs.getString(Constants.KEY_USER_EMAIL, "");
    }

    public String getUserPhone() {
        return prefs.getString(Constants.KEY_USER_PHONE, "");
    }

    public double getUserBalance() {
        try {
            return Double.parseDouble(prefs.getString(Constants.KEY_USER_BALANCE, "0.00"));
        } catch (Exception e) {
            return 0.00;
        }
    }

    public void updateUserBalance(double balance) {
        editor.putString(Constants.KEY_USER_BALANCE, String.valueOf(balance));
        editor.apply();
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
