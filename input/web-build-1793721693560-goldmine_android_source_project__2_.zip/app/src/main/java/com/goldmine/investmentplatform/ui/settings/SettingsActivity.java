package com.goldmine.investmentplatform.ui.settings;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnBack.setOnClickListener(v -> finish());

        binding.btnUpdatePassword.setOnClickListener(v -> {
            String current = binding.etCurrentPassword.getText().toString().trim();
            String newPass = binding.etNewPassword.getText().toString().trim();

            if (current.isEmpty() || newPass.isEmpty()) {
                Toast.makeText(this, "Please enter your current and new password.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (newPass.length() < 8) {
                Toast.makeText(this, "New password must be at least 8 characters.", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Security password updated successfully.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
