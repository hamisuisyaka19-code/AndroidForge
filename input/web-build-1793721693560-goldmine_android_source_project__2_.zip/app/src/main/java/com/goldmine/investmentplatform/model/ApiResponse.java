package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class ApiResponse<T> implements Serializable {
    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message;

    @SerializedName("data")
    private T data;

    @SerializedName("timestamp")
    private long timestamp;

    public boolean isSuccess() { return success; }
    public String getMessage() { return message != null ? message : ""; }
    public T getData() { return data; }
    public long getTimestamp() { return timestamp; }
}
