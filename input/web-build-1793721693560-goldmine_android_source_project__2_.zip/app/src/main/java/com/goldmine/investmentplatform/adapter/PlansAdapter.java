package com.goldmine.investmentplatform.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemPlanBinding;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import java.util.ArrayList;
import java.util.List;

public class PlansAdapter extends RecyclerView.Adapter<PlansAdapter.PlanViewHolder> {
    private List<InvestmentPlan> plans = new ArrayList<>();
    private final OnPlanClickListener listener;

    public interface OnPlanClickListener {
        void onPlanClick(InvestmentPlan plan);
    }

    public PlansAdapter(OnPlanClickListener listener) {
        this.listener = listener;
    }

    public void setPlans(List<InvestmentPlan> plans) {
        this.plans = plans != null ? plans : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PlanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPlanBinding binding = ItemPlanBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new PlanViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PlanViewHolder holder, int position) {
        holder.bind(plans.get(position));
    }

    @Override
    public int getItemCount() {
        return plans.size();
    }

    class PlanViewHolder extends RecyclerView.ViewHolder {
        private final ItemPlanBinding binding;

        public PlanViewHolder(ItemPlanBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(InvestmentPlan plan) {
            binding.tvPlanName.setText(plan.getName());
            binding.tvPlanDuration.setText(plan.getDurationDays() + " Days Duration");
            binding.tvPlanRoiBadge.setText((int) plan.getRoiPercentage() + "% ROI");
            binding.tvPlanMin.setText(CurrencyFormatter.formatNaira(plan.getMinAmount()));
            binding.tvPlanMax.setText(CurrencyFormatter.formatNaira(plan.getMaxAmount()));
            binding.tvPlanProfitRate.setText("+" + (int) plan.getRoiPercentage() + "% Net");
            binding.tvPlanDescription.setText(plan.getDescription());

            binding.btnInvestPlan.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onPlanClick(plan);
                }
            });
        }
    }
}
