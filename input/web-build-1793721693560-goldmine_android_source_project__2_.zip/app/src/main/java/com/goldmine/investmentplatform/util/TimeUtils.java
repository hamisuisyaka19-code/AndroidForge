package com.goldmine.investmentplatform.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class TimeUtils {
    private TimeUtils() {}

    private static final SimpleDateFormat DISPLAY_FORMAT = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
    private static final SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.US);
    private static final SimpleDateFormat SQL_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

    public static String formatDate(String sqlDateStr) {
        if (sqlDateStr == null || sqlDateStr.trim().isEmpty()) {
            return "N/A";
        }
        try {
            Date date = SQL_FORMAT.parse(sqlDateStr);
            if (date != null) {
                return DISPLAY_FORMAT.format(date);
            }
        } catch (Exception ignored) {}
        return sqlDateStr;
    }

    public static String formatDateTime(String sqlDateStr) {
        if (sqlDateStr == null || sqlDateStr.trim().isEmpty()) {
            return "N/A";
        }
        try {
            Date date = SQL_FORMAT.parse(sqlDateStr);
            if (date != null) {
                return DATETIME_FORMAT.format(date);
            }
        } catch (Exception ignored) {}
        return sqlDateStr;
    }

    public static String formatCountdown(long secondsRemaining) {
        if (secondsRemaining <= 0) {
            return "00d : 00h : 00m : 00s";
        }
        long days = secondsRemaining / 86400;
        long hours = (secondsRemaining % 86400) / 3600;
        long minutes = (secondsRemaining % 3600) / 60;
        long seconds = secondsRemaining % 60;
        return String.format(Locale.US, "%02dd : %02dh : %02dm : %02ds", days, hours, minutes, seconds);
    }
}
