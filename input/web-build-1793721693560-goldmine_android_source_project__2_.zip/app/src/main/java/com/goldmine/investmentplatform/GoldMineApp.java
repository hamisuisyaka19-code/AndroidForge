package com.goldmine.investmentplatform;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;

public class GoldMineApp extends Application {
    private static GoldMineApp instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        // Default to dark mode for the premium Black & Gold aesthetic
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }

    public static GoldMineApp getInstance() {
        return instance;
    }
}
