package com.goldmine.investmentplatform.ui.main;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityMainBinding;
import com.goldmine.investmentplatform.ui.countingdate.CountingDateFragment;
import com.goldmine.investmentplatform.ui.dashboard.DashboardFragment;
import com.goldmine.investmentplatform.ui.notifications.NotificationsFragment;
import com.goldmine.investmentplatform.ui.plans.PlansFragment;
import com.goldmine.investmentplatform.ui.profile.ProfileFragment;
import com.goldmine.investmentplatform.ui.wallet.WalletFragment;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);

        updateHeader();

        // Default to Dashboard
        if (savedInstanceState == null) {
            loadFragment(new DashboardFragment());
        }

        binding.bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                loadFragment(new DashboardFragment());
                return true;
            } else if (itemId == R.id.nav_plans) {
                loadFragment(new PlansFragment());
                return true;
            } else if (itemId == R.id.nav_countdown) {
                loadFragment(new CountingDateFragment());
                return true;
            } else if (itemId == R.id.nav_wallet) {
                loadFragment(new WalletFragment());
                return true;
            } else if (itemId == R.id.nav_profile) {
                loadFragment(new ProfileFragment());
                return true;
            }
            return false;
        });

        binding.btnNotifications.setOnClickListener(v -> {
            loadFragment(new NotificationsFragment());
        });
    }

    public void updateHeader() {
        if (binding != null && sessionManager != null) {
            binding.tvWelcomeUser.setText("Welcome, " + sessionManager.getUserName());
        }
    }

    public void setNotificationBadgeVisible(boolean visible) {
        if (binding != null) {
            binding.vNotificationBadge.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
    }

    public void navigateToTab(int navItemId) {
        if (binding != null) {
            binding.bottomNav.setSelectedItemId(navItemId);
        }
    }

    public void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.commit();
    }
}
