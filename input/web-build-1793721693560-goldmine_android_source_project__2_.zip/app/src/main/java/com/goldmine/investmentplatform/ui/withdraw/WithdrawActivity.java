package com.goldmine.investmentplatform.ui.withdraw;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityWithdrawBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WithdrawActivity extends AppCompatActivity {
    private ActivityWithdrawBinding binding;
    private SessionManager sessionManager;
    private double availableBalance = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWithdrawBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);
        availableBalance = sessionManager.getUserBalance();

        binding.tvAvailableBalance.setText(CurrencyFormatter.formatNaira(availableBalance));
        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnSubmitWithdrawal.setOnClickListener(v -> submitWithdrawal());
    }

    private void submitWithdrawal() {
        String bankName = binding.etBankName.getText().toString().trim();
        String accountNumber = binding.etAccountNumber.getText().toString().trim();
        String accountName = binding.etAccountName.getText().toString().trim();
        String amountStr = binding.etWithdrawAmount.getText().toString().trim();

        if (bankName.isEmpty() || accountNumber.isEmpty() || accountName.isEmpty() || amountStr.isEmpty()) {
            showError("Please fill in all bank details and amount.");
            return;
        }

        if (accountNumber.length() < 10) {
            showError("Account number must be 10 digits.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (Exception e) {
            showError("Invalid withdrawal amount.");
            return;
        }

        if (amount < 1000) {
            showError("Minimum withdrawal amount is ₦1,000.00.");
            return;
        }

        if (availableBalance < amount) {
            showError("Insufficient balance. Available: " + CurrencyFormatter.formatNaira(availableBalance));
            return;
        }

        binding.tvError.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnSubmitWithdrawal.setEnabled(false);

        int userId = sessionManager.getUserId();

        ApiClient.getService().submitWithdrawal(userId, amount, bankName, accountNumber, accountName).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitWithdrawal.setEnabled(true);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    availableBalance -= amount;
                    sessionManager.updateUserBalance(availableBalance);

                    Toast.makeText(WithdrawActivity.this, "Withdrawal request submitted! It will be reviewed and transferred by administrators shortly.", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }

                String msg = "Withdrawal request failed.";
                if (response.body() != null && response.body().getMessage() != null) {
                    msg = response.body().getMessage();
                }
                showError(msg);
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitWithdrawal.setEnabled(true);
                showError("Network error: " + t.getMessage());
            }
        });
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
