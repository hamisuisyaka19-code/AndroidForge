package com.goldmine.investmentplatform.ui.plans;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.adapter.PlansAdapter;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.databinding.FragmentPlansBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.ui.invest.InvestActivity;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PlansFragment extends Fragment {
    private FragmentPlansBinding binding;
    private PlansAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPlansBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new PlansAdapter(plan -> {
            Intent intent = new Intent(requireContext(), InvestActivity.class);
            intent.putExtra("selected_plan", plan);
            startActivity(intent);
        });

        binding.rvPlans.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvPlans.setAdapter(adapter);

        binding.swipeRefresh.setOnRefreshListener(this::fetchPlans);
        fetchPlans();
    }

    private void fetchPlans() {
        binding.progressBar.setVisibility(View.VISIBLE);

        ApiClient.getService().getPlans().enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("plans")) {
                        JsonArray arr = data.getAsJsonArray("plans");
                        List<InvestmentPlan> list = new ArrayList<>();
                        Gson gson = new Gson();
                        for (JsonElement el : arr) {
                            list.add(gson.fromJson(el, InvestmentPlan.class));
                        }
                        adapter.setPlans(list);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
