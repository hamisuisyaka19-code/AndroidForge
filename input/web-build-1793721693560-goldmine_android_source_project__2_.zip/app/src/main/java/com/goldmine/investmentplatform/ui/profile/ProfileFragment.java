package com.goldmine.investmentplatform.ui.profile;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentProfileBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.ui.auth.LoginActivity;
import com.goldmine.investmentplatform.ui.deposit.DepositActivity;
import com.goldmine.investmentplatform.ui.settings.SettingsActivity;
import com.goldmine.investmentplatform.ui.support.CustomerSupportActivity;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding binding;
    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        displayCachedProfile();
        setupClickListeners();
        refreshProfile();
    }

    private void displayCachedProfile() {
        binding.tvProfileName.setText(sessionManager.getUserName());
        binding.tvProfileEmail.setText(sessionManager.getUserEmail());
        binding.tvProfilePhone.setText(sessionManager.getUserPhone());
        binding.tvProfileBalance.setText(CurrencyFormatter.formatNaira(sessionManager.getUserBalance()));
    }

    private void setupClickListeners() {
        binding.btnProfileDeposit.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), DepositActivity.class));
        });

        binding.rowSettings.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), SettingsActivity.class));
        });

        binding.rowSupport.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), CustomerSupportActivity.class));
        });

        binding.rowBankInfo.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Official Platform Bank Account")
                    .setMessage("Bank: Kuda Bank\nAccount Number: 2009888249\nAccount Name: Hamisu Isiyaka\n\nUse this account to make manual bank transfer deposits to fund your GoldMine wallet.")
                    .setPositiveButton("OK", null)
                    .show();
        });

        binding.btnLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Sign Out")
                    .setMessage("Are you sure you want to sign out of your GoldMine account?")
                    .setPositiveButton("Sign Out", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(requireContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        if (getActivity() != null) {
                            getActivity().finish();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    private void refreshProfile() {
        int userId = sessionManager.getUserId();
        ApiClient.getService().getDashboard(userId).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                if (!isAdded()) return;
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("user")) {
                        User user = new Gson().fromJson(data.get("user"), User.class);
                        binding.tvProfileName.setText(user.getFullName());
                        binding.tvProfileEmail.setText(user.getEmail());
                        binding.tvProfilePhone.setText(user.getPhone());
                        binding.tvProfileBalance.setText(CurrencyFormatter.formatNaira(user.getBalance()));
                        sessionManager.updateUserBalance(user.getBalance());
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                // Ignore, cached data displayed
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
