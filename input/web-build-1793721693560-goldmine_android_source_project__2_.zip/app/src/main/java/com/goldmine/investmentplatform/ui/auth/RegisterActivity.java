package com.goldmine.investmentplatform.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityRegisterBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.ui.main.MainActivity;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private ActivityRegisterBinding binding;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);

        binding.btnRegister.setOnClickListener(v -> performRegistration());
        binding.tvLoginLink.setOnClickListener(v -> finish());
    }

    private void performRegistration() {
        String name = binding.etFullName.getText().toString().trim();
        String email = binding.etEmail.getText().toString().trim();
        String phone = binding.etPhone.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();
        boolean agree = binding.cbAgree.isChecked();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            showError("Please fill in all required fields.");
            return;
        }
        if (password.length() < 6) {
            showError("Password must be at least 6 characters.");
            return;
        }
        if (!agree) {
            showError("You must agree to the Terms & Conditions.");
            return;
        }

        binding.tvError.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnRegister.setEnabled(false);

        ApiClient.getService().register(name, email, phone, password, 1).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnRegister.setEnabled(true);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("user")) {
                        User user = new Gson().fromJson(data.get("user"), User.class);
                        String token = data.has("token") ? data.get("token").getAsString() : String.valueOf(user.getId());
                        sessionManager.saveUserSession(user, token);

                        Toast.makeText(RegisterActivity.this, "Welcome to GoldMine, " + user.getFullName() + "!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                        return;
                    }
                }

                String msg = "Registration failed. Please check your information.";
                if (response.body() != null && response.body().getMessage() != null) {
                    msg = response.body().getMessage();
                }
                showError(msg);
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnRegister.setEnabled(true);
                showError("Connection failed: " + t.getMessage());
            }
        });
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
