package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Transaction implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("reference_code")
    private String referenceCode;

    @SerializedName("type")
    private String type; // deposit, investment, withdrawal

    @SerializedName("amount")
    private double amount;

    @SerializedName("balance_after")
    private double balanceAfter;

    @SerializedName("status")
    private String status; // pending, approved, completed, rejected

    @SerializedName("description")
    private String description;

    @SerializedName("created_at")
    private String createdAt;

    public int getId() { return id; }
    public String getReferenceCode() { return referenceCode != null ? referenceCode : ""; }
    public String getType() { return type != null ? type : "transaction"; }
    public double getAmount() { return amount; }
    public double getBalanceAfter() { return balanceAfter; }
    public String getStatus() { return status != null ? status : "completed"; }
    public String getDescription() { return description != null ? description : ""; }
    public String getCreatedAt() { return createdAt != null ? createdAt : ""; }
}
