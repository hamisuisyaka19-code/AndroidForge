package com.goldmine.investmentplatform.ui.wallet;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentWalletBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.ui.deposit.DepositActivity;
import com.goldmine.investmentplatform.ui.main.MainActivity;
import com.goldmine.investmentplatform.ui.transactions.TransactionsFragment;
import com.goldmine.investmentplatform.ui.withdraw.WithdrawActivity;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WalletFragment extends Fragment {
    private FragmentWalletBinding binding;
    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentWalletBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        binding.btnDeposit.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), DepositActivity.class));
        });

        binding.btnWithdraw.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), WithdrawActivity.class));
        });

        binding.btnViewTxHistory.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new TransactionsFragment());
            }
        });

        binding.swipeRefresh.setOnRefreshListener(this::fetchWalletData);
        fetchWalletData();
    }

    private void fetchWalletData() {
        binding.swipeRefresh.setRefreshing(true);
        int userId = sessionManager.getUserId();

        ApiClient.getService().getDashboard(userId).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                if (!isAdded()) return;
                binding.swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("user")) {
                        User user = new Gson().fromJson(data.get("user"), User.class);
                        binding.tvWalletBalance.setText(CurrencyFormatter.formatNaira(user.getBalance()));
                        binding.tvWalletInvested.setText(CurrencyFormatter.formatNaira(user.getTotalInvested()));
                        binding.tvWalletProfit.setText(CurrencyFormatter.formatNaira(user.getTotalProfit()));
                        sessionManager.updateUserBalance(user.getBalance());
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                binding.swipeRefresh.setRefreshing(false);
                binding.tvWalletBalance.setText(CurrencyFormatter.formatNaira(sessionManager.getUserBalance()));
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchWalletData();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
