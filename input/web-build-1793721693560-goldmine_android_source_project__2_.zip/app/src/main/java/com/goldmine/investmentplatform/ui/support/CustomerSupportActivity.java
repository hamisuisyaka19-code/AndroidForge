package com.goldmine.investmentplatform.ui.support;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.databinding.ActivityCustomerSupportBinding;
import com.goldmine.investmentplatform.util.Constants;

public class CustomerSupportActivity extends AppCompatActivity {
    private ActivityCustomerSupportBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCustomerSupportBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnBack.setOnClickListener(v -> finish());

        binding.cardWhatsApp.setOnClickListener(v -> openUrl(Constants.SUPPORT_WHATSAPP));
        binding.cardTelegram.setOnClickListener(v -> openUrl(Constants.SUPPORT_TELEGRAM));
        binding.cardEmail.setOnClickListener(v -> {
            try {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:" + Constants.SUPPORT_EMAIL));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "GoldMine Support Inquiry");
                startActivity(Intent.createChooser(emailIntent, "Send Email"));
            } catch (Exception e) {
                Toast.makeText(this, "Email: " + Constants.SUPPORT_EMAIL, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not launch link: " + url, Toast.LENGTH_SHORT).show();
        }
    }
}
