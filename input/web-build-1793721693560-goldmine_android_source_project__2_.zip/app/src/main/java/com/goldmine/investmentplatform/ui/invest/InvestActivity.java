package com.goldmine.investmentplatform.ui.invest;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityInvestBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.InvestmentPlan;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InvestActivity extends AppCompatActivity {
    private ActivityInvestBinding binding;
    private SessionManager sessionManager;
    private InvestmentPlan selectedPlan;
    private double userBalance = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInvestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);
        userBalance = sessionManager.getUserBalance();

        selectedPlan = (InvestmentPlan) getIntent().getSerializableExtra("selected_plan");

        setupUI();
        setupCalculations();

        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnSubmitInvestment.setOnClickListener(v -> submitOrder());
    }

    private void setupUI() {
        binding.tvAvailableBalancePill.setText("Bal: " + CurrencyFormatter.formatNaira(userBalance));

        if (selectedPlan != null) {
            binding.tvPlanName.setText(selectedPlan.getName());
            binding.tvPlanDuration.setText("Maturity: " + selectedPlan.getDurationDays() + " Days Duration");
            binding.tvPlanRoi.setText((int) selectedPlan.getRoiPercentage() + "% ROI");
            binding.tvPlanLimits.setText("Allowed Range: " +
                    CurrencyFormatter.formatNaira(selectedPlan.getMinAmount()) + " – " +
                    CurrencyFormatter.formatNaira(selectedPlan.getMaxAmount()));

            // Pre-fill with min amount
            binding.etInvestmentAmount.setText(String.valueOf((int) selectedPlan.getMinAmount()));
            updateCalculations(selectedPlan.getMinAmount());
        }
    }

    private void setupCalculations() {
        binding.etInvestmentAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    String str = s.toString().trim();
                    double amount = str.isEmpty() ? 0 : Double.parseDouble(str);
                    updateCalculations(amount);
                } catch (Exception e) {
                    updateCalculations(0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void updateCalculations(double amount) {
        double roi = selectedPlan != null ? selectedPlan.getRoiPercentage() : 45.0;
        double netProfit = amount * (roi / 100.0);
        double totalPayout = amount + netProfit;
        double balanceAfter = userBalance - amount;

        binding.tvSummaryCapital.setText(CurrencyFormatter.formatNaira(amount));
        binding.tvSummaryProfit.setText("+" + CurrencyFormatter.formatNaira(netProfit));
        binding.tvSummaryTotalPayout.setText(CurrencyFormatter.formatNaira(totalPayout));
        binding.tvSummaryBalanceAfter.setText(CurrencyFormatter.formatNaira(balanceAfter));

        if (balanceAfter < 0) {
            binding.tvSummaryBalanceAfter.setTextColor(android.graphics.Color.parseColor("#EF4444"));
        } else {
            binding.tvSummaryBalanceAfter.setTextColor(android.graphics.Color.parseColor("#A1A1AA"));
        }
    }

    private void submitOrder() {
        String amountStr = binding.etInvestmentAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            showError("Please enter an investment amount.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (Exception e) {
            showError("Invalid amount format.");
            return;
        }

        if (selectedPlan == null) {
            showError("No investment plan selected.");
            return;
        }

        if (amount < selectedPlan.getMinAmount()) {
            showError("Minimum investment for " + selectedPlan.getName() + " is " + CurrencyFormatter.formatNaira(selectedPlan.getMinAmount()));
            return;
        }

        if (amount > selectedPlan.getMaxAmount()) {
            showError("Maximum investment for " + selectedPlan.getName() + " is " + CurrencyFormatter.formatNaira(selectedPlan.getMaxAmount()));
            return;
        }

        if (userBalance < amount) {
            showError("Insufficient balance (" + CurrencyFormatter.formatNaira(userBalance) + "). Please deposit funds into your wallet first.");
            return;
        }

        binding.tvError.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnSubmitInvestment.setEnabled(false);

        int userId = sessionManager.getUserId();
        ApiClient.getService().submitInvestment(userId, selectedPlan.getId(), amount).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitInvestment.setEnabled(true);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    // Update user balance locally
                    userBalance -= amount;
                    sessionManager.updateUserBalance(userBalance);

                    Toast.makeText(InvestActivity.this, "Investment order placed successfully! Awaiting admin review.", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }

                String msg = "Failed to submit investment order.";
                if (response.body() != null && response.body().getMessage() != null) {
                    msg = response.body().getMessage();
                }
                showError(msg);
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitInvestment.setEnabled(true);
                showError("Network error: " + t.getMessage());
            }
        });
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
