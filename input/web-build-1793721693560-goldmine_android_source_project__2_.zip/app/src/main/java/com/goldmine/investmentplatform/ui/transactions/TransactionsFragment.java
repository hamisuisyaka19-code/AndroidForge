package com.goldmine.investmentplatform.ui.transactions;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.adapter.TransactionsAdapter;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentTransactionsBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.Transaction;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TransactionsFragment extends Fragment {
    private FragmentTransactionsBinding binding;
    private SessionManager sessionManager;
    private TransactionsAdapter adapter;
    private String currentType = "all";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentTransactionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        adapter = new TransactionsAdapter();
        binding.rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvTransactions.setAdapter(adapter);

        setupFilterButtons();

        binding.swipeRefresh.setOnRefreshListener(() -> fetchTransactions(currentType));
        fetchTransactions("all");
    }

    private void setupFilterButtons() {
        binding.btnTxAll.setOnClickListener(v -> setFilter("all", binding.btnTxAll));
        binding.btnTxDeposits.setOnClickListener(v -> setFilter("deposit", binding.btnTxDeposits));
        binding.btnTxInvestments.setOnClickListener(v -> setFilter("investment", binding.btnTxInvestments));
        binding.btnTxWithdrawals.setOnClickListener(v -> setFilter("withdrawal", binding.btnTxWithdrawals));
    }

    private void setFilter(String type, Button selectedBtn) {
        this.currentType = type;
        resetFilterStyles();
        selectedBtn.setBackgroundResource(R.drawable.bg_gold_button);
        selectedBtn.setTextColor(Color.parseColor("#0A0D0A"));
        fetchTransactions(type);
    }

    private void resetFilterStyles() {
        Button[] buttons = {binding.btnTxAll, binding.btnTxDeposits, binding.btnTxInvestments, binding.btnTxWithdrawals};
        for (Button b : buttons) {
            b.setBackgroundResource(R.drawable.bg_card);
            b.setTextColor(Color.parseColor("#A1A1AA"));
        }
    }

    private void fetchTransactions(String type) {
        binding.progressBar.setVisibility(View.VISIBLE);
        int userId = sessionManager.getUserId();

        ApiClient.getService().getTransactions(userId, type).enqueue(new Callback<ApiResponse<JsonObject>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Response<ApiResponse<JsonObject>> response) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    JsonObject data = response.body().getData();
                    if (data != null && data.has("transactions")) {
                        JsonArray arr = data.getAsJsonArray("transactions");
                        List<Transaction> list = new ArrayList<>();
                        Gson gson = new Gson();
                        for (JsonElement el : arr) {
                            list.add(gson.fromJson(el, Transaction.class));
                        }
                        adapter.setTransactions(list);
                        binding.tvEmptyState.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<JsonObject>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
