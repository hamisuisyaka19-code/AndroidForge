package com.goldmine.investmentplatform.api;

import com.goldmine.investmentplatform.model.ApiResponse;
import com.google.gson.JsonObject;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    @FormUrlEncoded
    @POST("index.php?action=login")
    Call<ApiResponse<JsonObject>> login(
            @Field("login_input") String loginInput,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("index.php?action=register")
    Call<ApiResponse<JsonObject>> register(
            @Field("full_name") String fullName,
            @Field("email") String email,
            @Field("phone") String phone,
            @Field("password") String password,
            @Field("agree") int agree
    );

    @GET("index.php?action=dashboard")
    Call<ApiResponse<JsonObject>> getDashboard(
            @Query("user_id") int userId
    );

    @GET("index.php?action=plans")
    Call<ApiResponse<JsonObject>> getPlans();

    @FormUrlEncoded
    @POST("index.php?action=invest")
    Call<ApiResponse<JsonObject>> submitInvestment(
            @Field("user_id") int userId,
            @Field("plan_id") int planId,
            @Field("amount") double amount
    );

    @GET("index.php?action=my_investments")
    Call<ApiResponse<JsonObject>> getMyInvestments(
            @Query("user_id") int userId,
            @Query("filter") String filter
    );

    @GET("index.php?action=counting_date")
    Call<ApiResponse<JsonObject>> getCountingDate(
            @Query("user_id") int userId
    );

    @Multipart
    @POST("index.php?action=deposit")
    Call<ApiResponse<JsonObject>> submitDepositWithReceipt(
            @Part("user_id") RequestBody userId,
            @Part("amount") RequestBody amount,
            @Part MultipartBody.Part receipt
    );

    @FormUrlEncoded
    @POST("index.php?action=deposit")
    Call<ApiResponse<JsonObject>> submitDeposit(
            @Field("user_id") int userId,
            @Field("amount") double amount
    );

    @FormUrlEncoded
    @POST("index.php?action=withdraw")
    Call<ApiResponse<JsonObject>> submitWithdrawal(
            @Field("user_id") int userId,
            @Field("amount") double amount,
            @Field("bank_name") String bankName,
            @Field("account_number") String accountNumber,
            @Field("account_name") String accountName
    );

    @GET("index.php?action=transactions")
    Call<ApiResponse<JsonObject>> getTransactions(
            @Query("user_id") int userId,
            @Query("type") String type
    );

    @GET("index.php?action=notifications")
    Call<ApiResponse<JsonObject>> getNotifications(
            @Query("user_id") int userId
    );

    @GET("index.php?action=support")
    Call<ApiResponse<JsonObject>> getSupportInfo();
}
