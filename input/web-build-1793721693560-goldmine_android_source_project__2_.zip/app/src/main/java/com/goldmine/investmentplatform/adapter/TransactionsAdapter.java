package com.goldmine.investmentplatform.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemTransactionBinding;
import com.goldmine.investmentplatform.model.Transaction;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;

public class TransactionsAdapter extends RecyclerView.Adapter<TransactionsAdapter.TxViewHolder> {
    private List<Transaction> list = new ArrayList<>();

    public void setTransactions(List<Transaction> transactions) {
        this.list = transactions != null ? transactions : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TxViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTransactionBinding binding = ItemTransactionBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new TxViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TxViewHolder holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class TxViewHolder extends RecyclerView.ViewHolder {
        private final ItemTransactionBinding binding;

        public TxViewHolder(ItemTransactionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Transaction t) {
            binding.tvTxType.setText(t.getType());
            binding.tvTxDescription.setText(t.getDescription());
            binding.tvTxDate.setText(TimeUtils.formatDateTime(t.getCreatedAt()));

            boolean isWithdrawal = "withdrawal".equalsIgnoreCase(t.getType());
            String prefix = isWithdrawal ? "-" : "+";
            binding.tvTxAmount.setText(prefix + CurrencyFormatter.formatNaira(t.getAmount()));
            binding.tvTxAmount.setTextColor(isWithdrawal ? Color.parseColor("#EF4444") : Color.parseColor("#EAB308"));

            String status = t.getStatus().toLowerCase();
            binding.tvTxStatusBadge.setText(status);
            if ("approved".equals(status) || "completed".equals(status)) {
                binding.tvTxStatusBadge.setTextColor(Color.parseColor("#10B981"));
                binding.tvTxStatusBadge.setBackgroundColor(Color.parseColor("#2010B981"));
            } else if ("rejected".equals(status) || "cancelled".equals(status)) {
                binding.tvTxStatusBadge.setTextColor(Color.parseColor("#EF4444"));
                binding.tvTxStatusBadge.setBackgroundColor(Color.parseColor("#20EF4444"));
            } else {
                binding.tvTxStatusBadge.setTextColor(Color.parseColor("#EAB308"));
                binding.tvTxStatusBadge.setBackgroundColor(Color.parseColor("#20EAB308"));
            }
        }
    }
}
