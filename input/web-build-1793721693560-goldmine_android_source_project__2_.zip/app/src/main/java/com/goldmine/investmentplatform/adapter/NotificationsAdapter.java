package com.goldmine.investmentplatform.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.goldmine.investmentplatform.databinding.ItemNotificationBinding;
import com.goldmine.investmentplatform.model.NotificationItem;
import com.goldmine.investmentplatform.util.TimeUtils;
import java.util.ArrayList;
import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NoteViewHolder> {
    private List<NotificationItem> notes = new ArrayList<>();

    public void setNotifications(List<NotificationItem> list) {
        this.notes = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemNotificationBinding binding = ItemNotificationBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new NoteViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        holder.bind(notes.get(position));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        private final ItemNotificationBinding binding;

        public NoteViewHolder(ItemNotificationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(NotificationItem n) {
            binding.tvNoteTitle.setText(n.getTitle());
            binding.tvNoteMessage.setText(n.getMessage());
            binding.tvNoteDate.setText(TimeUtils.formatDateTime(n.getCreatedAt()));
            binding.vUnreadDot.setVisibility(n.isRead() ? View.GONE : View.VISIBLE);
        }
    }
}
