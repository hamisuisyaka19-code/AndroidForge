package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class CompanyBank implements Serializable {
    @SerializedName("bank_name")
    private String bankName;

    @SerializedName("account_number")
    private String accountNumber;

    @SerializedName("account_name")
    private String accountName;

    public String getBankName() { return bankName != null ? bankName : "Kuda Bank"; }
    public String getAccountNumber() { return accountNumber != null ? accountNumber : "2009888249"; }
    public String getAccountName() { return accountName != null ? accountName : "Hamisu Isiyaka"; }
}
