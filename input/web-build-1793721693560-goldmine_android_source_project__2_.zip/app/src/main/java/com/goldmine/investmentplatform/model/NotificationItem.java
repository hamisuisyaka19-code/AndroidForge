package com.goldmine.investmentplatform.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class NotificationItem implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("title")
    private String title;

    @SerializedName("message")
    private String message;

    @SerializedName("type")
    private String type;

    @SerializedName("is_read")
    private int isRead;

    @SerializedName("created_at")
    private String createdAt;

    public int getId() { return id; }
    public String getTitle() { return title != null ? title : "Notification"; }
    public String getMessage() { return message != null ? message : ""; }
    public String getType() { return type != null ? type : "info"; }
    public boolean isRead() { return isRead == 1; }
    public String getCreatedAt() { return createdAt != null ? createdAt : ""; }
}
