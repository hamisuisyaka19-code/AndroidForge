(function() {
  try {
    // 1. Ensure viewport meta tag exists
    var vp = document.querySelector('meta[name="viewport"]');
    if (!vp) {
      vp = document.createElement('meta');
      vp.name = 'viewport';
      vp.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
      document.head.appendChild(vp);
    }

    // 2. Set dark background immediately to eliminate any white flash
    document.documentElement.style.backgroundColor = '#090D16';
    if (document.body) {
      document.body.style.backgroundColor = '#090D16';
    }

    // 3. Inject CSS if not loaded
    if (!document.getElementById('gm-injected-theme')) {
      var link = document.createElement('link');
      link.id = 'gm-injected-theme';
      link.rel = 'stylesheet';
      link.type = 'text/css';
      link.href = 'file:///android_asset/css/goldmine-theme.css';
      document.head.appendChild(link);
    }

    // 4. Inject 6-Item Bottom Navigation if not already present
    if (!document.getElementById('gm-fixed-bottom-bar') && document.body) {
      var bar = document.createElement('nav');
      bar.id = 'gm-fixed-bottom-bar';
      var loc = window.location.pathname.toLowerCase();

      var items = [
        { name: 'Dashboard', path: '/dashboard', match: ['dashboard', 'home', 'user/dashboard'], svg: '<svg viewBox="0 0 24 24"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>' },
        { name: 'Invest', path: '/invest', match: ['invest', 'plans', 'investment'], svg: '<svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>' },
        { name: 'My Invest', path: '/my-invest', match: ['my-invest', 'history', 'portfolio'], svg: '<svg viewBox="0 0 24 24"><rect width="20" height="14" x="2" y="7" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>' },
        { name: 'Counting', path: '/countdown', match: ['countdown', 'counting'], svg: '<svg viewBox="0 0 24 24"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg>' },
        { name: 'Wallet', path: '/wallet', match: ['wallet', 'deposit', 'withdraw'], svg: '<svg viewBox="0 0 24 24"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/></svg>' },
        { name: 'Profile', path: '/profile', match: ['profile', 'account', 'user'], svg: '<svg viewBox="0 0 24 24"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>' }
      ];

      var html = '';
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        var isActive = false;
        for (var j = 0; j < it.match.length; j++) {
          if (loc.indexOf(it.match[j]) !== -1) { isActive = true; break; }
        }
        if (i === 0 && (loc === '/' || loc === '' || loc.indexOf('dashboard') !== -1)) isActive = true;
        html += '<a href="' + it.path + '" class="' + (isActive ? 'active' : '') + '">' + it.svg + '<span>' + it.name + '</span></a>';
      }
      bar.innerHTML = html;
      document.body.appendChild(bar);
    }
  } catch (err) {}
})();
