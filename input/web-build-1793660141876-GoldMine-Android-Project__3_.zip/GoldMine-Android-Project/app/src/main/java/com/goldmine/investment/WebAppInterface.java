package com.goldmine.investment;

import android.content.Context;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 * JavaScript interface exposed to the WebView.
 * Fixed: Zero illegal escape characters, clean string handling.
 */
public class WebAppInterface {
    private final Context mContext;
    private final MainActivity mActivity;

    public WebAppInterface(MainActivity activity) {
        this.mActivity = activity;
        this.mContext = activity.getApplicationContext();
    }

    @JavascriptInterface
    public void showToast(String message) {
        if (message == null) return;
        final String cleanMsg = message.replace("\\", "");
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, cleanMsg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @JavascriptInterface
    public void vibrate(long milliseconds) {
        try {
            Vibrator v = (Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                v.vibrate(Math.min(milliseconds, 500));
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public String getAppVersion() {
        return "2.0.0-BlackGold";
    }

    @JavascriptInterface
    public void reloadBackend() {
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mActivity.loadGoldMineBackend();
            }
        });
    }
}
