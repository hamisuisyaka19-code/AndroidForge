package com.goldmine.investment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * MainActivity for GoldMine Investment Platform.
 * Redesigned for Premium Black & Gold Theme with 6-Item Navigation.
 * 
 * Features:
 * - Direct connection to https://goalmindai.com.ng
 * - Automatic session cookie preservation
 * - Intercepts blocked CSS stylesheets to guarantee Black & Gold UI styling
 * - Injects 6-item bottom navigation bar (Dashboard, Invest, My Invest, Counting Date, Wallet, Profile)
 * - Safe file chooser for payment receipts & proof uploads
 * - Custom gold swipe-to-refresh
 * - Offline fallback with embedded Black & Gold UI
 * - Fixed: zero illegal escape sequences or invalid regexes
 */
public class MainActivity extends AppCompatActivity {

    public static final String BACKEND_URL = "https://goalmindai.com.ng";
    public static final String LOCAL_OFFLINE_URL = "file:///android_asset/www/index.html";
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    private WebView mWebView;
    private ProgressBar mProgressBar;
    private SwipeRefreshLayout mSwipeRefresh;
    private ValueCallback<Uri[]> mFilePathCallback;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mWebView = findViewById(R.id.webView);
        mProgressBar = findViewById(R.id.progressBar);
        mSwipeRefresh = findViewById(R.id.swipeRefresh);

        // Set WebView background to dark black immediately to prevent white flashing
        mWebView.setBackgroundColor(Color.parseColor("#090D16"));

        // Configure SwipeRefresh with Gold & Dark branding colors
        mSwipeRefresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#111827"));
        mSwipeRefresh.setColorSchemeColors(
                Color.parseColor("#D4AF37"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#B45309")
        );
        mSwipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mWebView.reload();
            }
        });

        setupWebViewSettings();
        setupWebViewClients();

        loadGoldMineBackend();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebViewSettings() {
        WebSettings settings = mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(mWebView, true);
        }

        // Set modern mobile user agent
        String customUA = settings.getUserAgentString() + " GoldMineAndroid/2.0.0 (BlackGoldEdition)";
        settings.setUserAgentString(customUA);

        // Bind Safe JavaScript Interface
        mWebView.addJavascriptInterface(new WebAppInterface(this), "GoldMineNative");
    }

    private void setupWebViewClients() {
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                mProgressBar.setVisibility(View.VISIBLE);
                // Inject early background styling to prevent white flash
                injectThemeScript(view);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                mProgressBar.setVisibility(View.GONE);
                mSwipeRefresh.setRefreshing(false);

                // Inject master Black & Gold CSS and 6-item bottom bar
                injectThemeScript(view);
            }

            // Intercept stylesheet requests to bypass server 403 Forbidden errors
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String urlStr = request.getUrl().toString();
                    String path = request.getUrl().getPath();
                    if ((path != null && (path.endsWith(".css") || path.contains("style.css"))) || urlStr.contains("/assets/css/")) {
                        try {
                            InputStream is = getAssets().open("css/goldmine-theme.css");
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Access-Control-Allow-Origin", "*");
                            headers.put("Cache-Control", "no-cache");
                            return new WebResourceResponse("text/css", "UTF-8", 200, "OK", headers, is);
                        } catch (Exception ignored) {
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (url != null && (url.endsWith(".css") || url.contains("style.css") || url.contains("/assets/css/"))) {
                    try {
                        InputStream is = getAssets().open("css/goldmine-theme.css");
                        return new WebResourceResponse("text/css", "UTF-8", is);
                    } catch (Exception ignored) {
                    }
                }
                return super.shouldInterceptRequest(view, url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    // Fallback to local offline Black & Gold app if internet is temporarily down
                    Toast.makeText(MainActivity.this, "Network unavailable: Loaded local GoldMine mode", Toast.LENGTH_SHORT).show();
                    mWebView.loadUrl(LOCAL_OFFLINE_URL);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
                return false; // Load inside WebView
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    mProgressBar.setVisibility(View.GONE);
                }
            }

            // File chooser for Payment receipts / proof upload
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    mFilePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    /**
     * Injects custom CSS rules and 6-item bottom navigation to seamlessly unify
     * any backend views into the Premium Black & Gold Theme.
     * Reads from bundled APK asset js/goldmine-theme.js with zero illegal escape syntax.
     */
    private void injectThemeScript(WebView webView) {
        if (webView == null) return;
        try {
            InputStream is = getAssets().open("js/goldmine-theme.js");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String js = new String(buffer, "UTF-8");
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            String fallback = "document.documentElement.style.backgroundColor='#090D16';if(document.body)document.body.style.backgroundColor='#090D16';";
            webView.evaluateJavascript(fallback, null);
        }
    }

    public void loadGoldMineBackend() {
        if (NetworkUtils.isNetworkAvailable(this)) {
            mWebView.loadUrl(BACKEND_URL);
        } else {
            mWebView.loadUrl(LOCAL_OFFLINE_URL);
        }
    }

    @Override
    public void onBackPressed() {
        if (mWebView != null && mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (mFilePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
