package com.goldmine.investment;

import android.app.Application;
import android.webkit.CookieManager;

/**
 * GoldMine Investment Platform Application
 * Premium Black & Gold Edition
 */
public class GoldMineApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // Ensure cookies are enabled for GoldMine session preservation
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
    }
}
