package com.goldmine.investmentplatform.model;

import com.goldmine.investmentplatform.util.TimeUtils;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Investment implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("reference_code")
    private String referenceCode;

    @SerializedName("user_id")
    private int userId;

    @SerializedName("plan_id")
    private int planId;

    @SerializedName("plan_name")
    private String planName;

    @SerializedName("amount")
    private double amount;

    @SerializedName("roi_percentage")
    private double roiPercentage;

    @SerializedName("expected_return")
    private double expectedReturn;

    @SerializedName("duration_days")
    private int durationDays;

    @SerializedName("start_date")
    private String startDate;

    @SerializedName("maturity_date")
    private String maturityDate;

    @SerializedName("status")
    private String status;

    @SerializedName("start_timestamp")
    private long startTimestamp;

    @SerializedName("maturity_timestamp")
    private long maturityTimestamp;

    @SerializedName("seconds_remaining")
    private long secondsRemaining;

    @SerializedName("progress_percent")
    private int progressPercent;

    @SerializedName("countdown_formatted")
    private String countdownFormatted;

    @SerializedName("days")
    private int days;

    @SerializedName("hours")
    private int hours;

    @SerializedName("minutes")
    private int minutes;

    @SerializedName("seconds")
    private int seconds;

    public int getId() { return id; }
    public String getReferenceCode() { return referenceCode != null ? referenceCode : "INV"; }
    public int getUserId() { return userId; }
    public int getPlanId() { return planId; }
    public String getPlanName() { return planName != null ? planName : "Gold Plan"; }
    public double getAmount() { return amount; }
    public double getRoiPercentage() {
        return TimeUtils.resolveRoiPercentage(amount);
    }
    public void setRoiPercentage(double roiPercentage) { this.roiPercentage = roiPercentage; }
    public double getExpectedReturn() {
        return TimeUtils.calculateExpectedReturn(amount);
    }
    public void setExpectedReturn(double expectedReturn) { this.expectedReturn = expectedReturn; }
    public int getDurationDays() {
        return TimeUtils.resolveCanonicalDurationDays(planName, durationDays);
    }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }
    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    public String getMaturityDate() { return maturityDate; }
    public void setMaturityDate(String maturityDate) { this.maturityDate = maturityDate; }
    public String getStatus() { return status != null ? status : "pending"; }
    public void setStatus(String status) { this.status = status; }

    public long getStartTimestamp() { return startTimestamp; }
    public void setStartTimestamp(long startTimestamp) { this.startTimestamp = startTimestamp; }
    public long getMaturityTimestamp() { return maturityTimestamp; }
    public void setMaturityTimestamp(long maturityTimestamp) { this.maturityTimestamp = maturityTimestamp; }
    public long getSecondsRemaining() { return secondsRemaining; }
    public void setSecondsRemaining(long secondsRemaining) { this.secondsRemaining = secondsRemaining; }
    public int getProgressPercent() { return progressPercent; }
    public void setProgressPercent(int progressPercent) { this.progressPercent = progressPercent; }
    public String getCountdownFormatted() { return countdownFormatted; }
    public int getDays() { return days; }
    public int getHours() { return hours; }
    public int getMinutes() { return minutes; }
    public int getSeconds() { return seconds; }
}
