package com.goldmine.investmentplatform.api;

import android.content.Context;
import com.goldmine.investmentplatform.GoldMineApp;
import com.goldmine.investmentplatform.util.Constants;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static Retrofit retrofit = null;
    private static OkHttpClient okHttpClient = null;
    private static SessionCookieJar cookieJar = null;

    public static synchronized SessionCookieJar getCookieJar(Context context) {
        if (cookieJar == null) {
            cookieJar = new SessionCookieJar(context.getApplicationContext());
        }
        return cookieJar;
    }

    public static synchronized OkHttpClient getOkHttpClient() {
        if (okHttpClient == null) {
            Context context = GoldMineApp.getInstance();
            if (context != null) {
                cookieJar = getCookieJar(context);
            }

            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);

            OkHttpClient.Builder builder = new OkHttpClient.Builder()
                    .addInterceptor(interceptor)
                    .addInterceptor(chain -> {
                        Request original = chain.request();
                        Request request = original.newBuilder()
                                .header("User-Agent", "GoldMine-Android/1.0.0 (Linux; Android)")
                                .header("Accept", "application/json, text/html, */*")
                                .method(original.method(), original.body())
                                .build();
                        return chain.proceed(request);
                    })
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS);

            if (cookieJar != null) {
                builder.cookieJar(cookieJar);
            }

            okHttpClient = builder.build();
        }
        return okHttpClient;
    }

    public static synchronized Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(getOkHttpClient())
                    .build();
        }
        return retrofit;
    }

    public static ApiService getService() {
        return getClient().create(ApiService.class);
    }
}
