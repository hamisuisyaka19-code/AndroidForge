package com.goldmine.investmentplatform.ui.deposit;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.ActivityDepositBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DepositActivity extends AppCompatActivity {
    private ActivityDepositBinding binding;
    private SessionManager sessionManager;
    private Uri selectedReceiptUri = null;

    private final ActivityResultLauncher<String> filePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedReceiptUri = uri;
                    binding.tvReceiptStatus.setText("Receipt attached: " + uri.getLastPathSegment());
                    binding.tvReceiptStatus.setTextColor(android.graphics.Color.parseColor("#10B981"));
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDepositBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);

        binding.btnBack.setOnClickListener(v -> finish());

        binding.btnCopyAccount.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("GoldMine Account Number", "2009888249");
            if (clipboard != null) {
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "Account number (2009888249) copied to clipboard!", Toast.LENGTH_SHORT).show();
            }
        });

        binding.btnSelectReceipt.setOnClickListener(v -> {
            filePickerLauncher.launch("image/*");
        });

        binding.btnSubmitDeposit.setOnClickListener(v -> submitDeposit());
    }

    private void submitDeposit() {
        String amountStr = binding.etDepositAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            showError("Please enter the deposit amount.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (Exception e) {
            showError("Invalid deposit amount.");
            return;
        }

        if (amount < 500) {
            showError("Minimum deposit amount is ₦500.00.");
            return;
        }

        binding.tvError.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnSubmitDeposit.setEnabled(false);

        // Submit to Dual-Engine GoldMine Repository
        com.goldmine.investmentplatform.api.GoldMineRepository.getInstance().submitDeposit(amount, new com.goldmine.investmentplatform.api.GoldMineRepository.ActionCallback() {
            @Override
            public void onSuccess(String message) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitDeposit.setEnabled(true);
                Toast.makeText(DepositActivity.this, message, Toast.LENGTH_LONG).show();
                finish();
            }

            @Override
            public void onError(String message) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnSubmitDeposit.setEnabled(true);
                showError(message);
            }
        });
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
