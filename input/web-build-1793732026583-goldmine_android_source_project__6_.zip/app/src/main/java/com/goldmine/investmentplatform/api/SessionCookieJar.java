package com.goldmine.investmentplatform.api;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;

public class SessionCookieJar implements CookieJar {
    private static final String PREF_COOKIES = "goldmine_cookies";
    private static final String KEY_COOKIE_SET = "cookie_set";
    private final SharedPreferences prefs;
    private final List<Cookie> memoryCookies = new ArrayList<>();

    public SessionCookieJar(Context context) {
        prefs = context.getSharedPreferences(PREF_COOKIES, Context.MODE_PRIVATE);
        loadPersistedCookies();
    }

    private void loadPersistedCookies() {
        Set<String> set = prefs.getStringSet(KEY_COOKIE_SET, null);
        if (set != null) {
            HttpUrl dummyUrl = HttpUrl.parse("https://goalmindai.com.ng/");
            if (dummyUrl != null) {
                for (String raw : set) {
                    Cookie c = Cookie.parse(dummyUrl, raw);
                    if (c != null) {
                        memoryCookies.add(c);
                    }
                }
            }
        }
    }

    @Override
    public synchronized void saveFromResponse(@NonNull HttpUrl url, @NonNull List<Cookie> cookies) {
        for (Cookie newCookie : cookies) {
            // Remove existing cookie with same name
            for (int i = memoryCookies.size() - 1; i >= 0; i--) {
                if (memoryCookies.get(i).name().equalsIgnoreCase(newCookie.name())) {
                    memoryCookies.remove(i);
                }
            }
            memoryCookies.add(newCookie);
        }

        // Persist to SharedPreferences
        Set<String> set = new HashSet<>();
        for (Cookie c : memoryCookies) {
            set.add(c.toString());
        }
        prefs.edit().putStringSet(KEY_COOKIE_SET, set).apply();
    }

    @NonNull
    @Override
    public synchronized List<Cookie> loadForRequest(@NonNull HttpUrl url) {
        List<Cookie> matching = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Cookie c : memoryCookies) {
            if (c.expiresAt() >= now && c.matches(url)) {
                matching.add(c);
            }
        }
        return matching;
    }

    public synchronized void clear() {
        memoryCookies.clear();
        prefs.edit().clear().apply();
    }

    public synchronized String getPhpSessionId() {
        for (Cookie c : memoryCookies) {
            if ("PHPSESSID".equalsIgnoreCase(c.name())) {
                return c.value();
            }
        }
        return "";
    }
}
