package com.goldmine.investmentplatform.ui.countingdate;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.adapter.CountdownAdapter;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentCountingDateBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.Investment;
import com.goldmine.investmentplatform.ui.main.MainActivity;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CountingDateFragment extends Fragment {
    private FragmentCountingDateBinding binding;
    private SessionManager sessionManager;
    private CountdownAdapter adapter;
    private Handler timerHandler;
    private Runnable timerRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentCountingDateBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        adapter = new CountdownAdapter();
        binding.rvCountdowns.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvCountdowns.setAdapter(adapter);

        binding.btnInvestFromCountdown.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToTab(R.id.nav_plans);
            }
        });

        binding.swipeRefresh.setOnRefreshListener(this::fetchCountingDate);
        fetchCountingDate();

        startTicker();
    }

    private void startTicker() {
        timerHandler = new Handler(Looper.getMainLooper());
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                if (adapter != null) {
                    boolean maturedNow = adapter.tick();
                    if (maturedNow) {
                        fetchCountingDate();
                    }
                }
                if (timerHandler != null) {
                    timerHandler.postDelayed(this, 1000);
                }
            }
        };
        timerHandler.postDelayed(timerRunnable, 1000);
    }

    private void fetchCountingDate() {
        binding.progressBar.setVisibility(View.VISIBLE);

        com.goldmine.investmentplatform.api.GoldMineRepository.getInstance().getCountingDate(new com.goldmine.investmentplatform.api.GoldMineRepository.InvestmentsCallback() {
            @Override
            public void onSuccess(List<Investment> list) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
                adapter.setCountdowns(list);
                binding.layoutEmptyCountdown.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
        binding = null;
    }
}
