package com.goldmine.investmentplatform.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.adapter.TransactionsAdapter;
import com.goldmine.investmentplatform.api.GoldMineRepository;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentDashboardBinding;
import com.goldmine.investmentplatform.model.Transaction;
import com.goldmine.investmentplatform.model.User;
import com.goldmine.investmentplatform.ui.countingdate.CountingDateFragment;
import com.goldmine.investmentplatform.ui.deposit.DepositActivity;
import com.goldmine.investmentplatform.ui.main.MainActivity;
import com.goldmine.investmentplatform.ui.myinvestments.MyInvestmentsFragment;
import com.goldmine.investmentplatform.ui.notifications.NotificationsFragment;
import com.goldmine.investmentplatform.ui.plans.PlansFragment;
import com.goldmine.investmentplatform.ui.profile.ProfileFragment;
import com.goldmine.investmentplatform.ui.transactions.TransactionsFragment;
import com.goldmine.investmentplatform.ui.withdraw.WithdrawActivity;
import com.goldmine.investmentplatform.util.CurrencyFormatter;
import java.util.List;

public class DashboardFragment extends Fragment {
    private FragmentDashboardBinding binding;
    private SessionManager sessionManager;
    private TransactionsAdapter transactionsAdapter;
    private boolean isBalanceVisible = true;
    private double currentBalance = 0.00;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        binding.tvUserNameGreeting.setText(sessionManager.getUserName());
        currentBalance = sessionManager.getUserBalance();
        binding.tvTotalInvested.setText(CurrencyFormatter.formatNaira(sessionManager.getUserTotalInvested()));
        binding.tvTotalProfit.setText(CurrencyFormatter.formatNaira(sessionManager.getUserTotalProfit()));
        updateBalanceDisplay();

        setupRecyclerView();
        setupClickListeners();
        loadDashboardData();
    }

    private void setupRecyclerView() {
        transactionsAdapter = new TransactionsAdapter();
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionsAdapter);
    }

    private void setupClickListeners() {
        binding.swipeRefresh.setOnRefreshListener(this::loadDashboardData);

        binding.btnQuickDeposit.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), DepositActivity.class));
        });

        binding.btnQuickWithdraw.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), WithdrawActivity.class));
        });

        binding.actionInvest.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new PlansFragment());
            }
        });

        binding.actionMyInvest.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new MyInvestmentsFragment());
            }
        });

        binding.actionCountingDate.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new CountingDateFragment());
            }
        });

        binding.actionTransactions.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new TransactionsFragment());
            }
        });

        binding.actionNotifications.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new NotificationsFragment());
            }
        });

        binding.actionProfile.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new ProfileFragment());
            }
        });

        binding.cardCountdownBanner.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new CountingDateFragment());
            }
        });

        binding.tvViewAllTransactions.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new TransactionsFragment());
            }
        });

        binding.ivToggleBalance.setOnClickListener(v -> {
            isBalanceVisible = !isBalanceVisible;
            updateBalanceDisplay();
        });
    }

    private void updateBalanceDisplay() {
        if (isBalanceVisible) {
            binding.tvAvailableBalance.setText(CurrencyFormatter.formatNaira(currentBalance));
        } else {
            binding.tvAvailableBalance.setText("₦ ••••••••");
        }
    }

    public void loadDashboardData() {
        binding.swipeRefresh.setRefreshing(true);

        GoldMineRepository.getInstance().getDashboard(new GoldMineRepository.DashboardCallback() {
            @Override
            public void onSuccess(User user, int activeInvestCount, int completedInvestCount, List<Transaction> recentTransactions) {
                if (!isAdded() || binding == null) return;
                binding.swipeRefresh.setRefreshing(false);

                currentBalance = user.getBalance();
                updateBalanceDisplay();

                binding.tvUserNameGreeting.setText(user.getFullName());
                binding.tvTotalInvested.setText(CurrencyFormatter.formatNaira(user.getTotalInvested()));
                binding.tvTotalProfit.setText(CurrencyFormatter.formatNaira(user.getTotalProfit()));
                binding.tvActiveInvestCount.setText(activeInvestCount + (activeInvestCount == 1 ? " Plan" : " Plans"));
                binding.tvCompletedInvestCount.setText(completedInvestCount + (completedInvestCount == 1 ? " Plan" : " Plans"));

                if (activeInvestCount > 0) {
                    binding.cardCountdownBanner.setVisibility(View.VISIBLE);
                    binding.tvCountdownSummary.setText(activeInvestCount + " active plan(s) maturing with up to 45% ROI. Tap to view live timer.");
                } else {
                    binding.cardCountdownBanner.setVisibility(View.GONE);
                }

                if (recentTransactions != null && !recentTransactions.isEmpty()) {
                    transactionsAdapter.setTransactions(recentTransactions);
                    binding.tvEmptyTransactions.setVisibility(View.GONE);
                } else {
                    binding.tvEmptyTransactions.setVisibility(View.VISIBLE);
                }

                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).updateHeader();
                }
            }

            @Override
            public void onError(String message) {
                if (!isAdded() || binding == null) return;
                binding.swipeRefresh.setRefreshing(false);
                currentBalance = sessionManager.getUserBalance();
                binding.tvTotalInvested.setText(CurrencyFormatter.formatNaira(sessionManager.getUserTotalInvested()));
                binding.tvTotalProfit.setText(CurrencyFormatter.formatNaira(sessionManager.getUserTotalProfit()));
                updateBalanceDisplay();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadDashboardData();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
