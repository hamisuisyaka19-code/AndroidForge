package com.goldmine.investmentplatform.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class TimeUtils {
    private TimeUtils() {}

    // Production server timezone on goalmindai.com.ng is Africa/Lagos (WAT, UTC+1)
    public static final TimeZone SERVER_TIMEZONE = TimeZone.getTimeZone("Africa/Lagos");

    public static String formatDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return "N/A";
        }
        Date date = parseAnyDate(dateStr);
        if (date != null) {
            SimpleDateFormat out = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
            out.setTimeZone(SERVER_TIMEZONE);
            return out.format(date);
        }
        return dateStr;
    }

    public static String formatDateTime(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return "N/A";
        }
        Date date = parseAnyDate(dateStr);
        if (date != null) {
            SimpleDateFormat out = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.US);
            out.setTimeZone(SERVER_TIMEZONE);
            return out.format(date);
        }
        return dateStr;
    }

    public static String formatSqlDateTime(long timestampSeconds) {
        if (timestampSeconds <= 0) return "";
        SimpleDateFormat sql = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        sql.setTimeZone(SERVER_TIMEZONE);
        return sql.format(new Date(timestampSeconds * 1000L));
    }

    public static long parseToEpochSeconds(String dateStr) {
        Date d = parseAnyDate(dateStr);
        return d != null ? (d.getTime() / 1000L) : 0L;
    }

    public static Date parseAnyDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        String clean = raw.trim();

        String[] patterns = new String[] {
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss",
                "yyyy-MM-dd HH:mm:ss",
                "MMM dd, yyyy hh:mm a",
                "MMM dd, yyyy HH:mm",
                "MMM d, yyyy hh:mm a",
                "MMM dd, yyyy",
                "MMM d, yyyy",
                "dd MMM yyyy HH:mm:ss",
                "dd MMM yyyy"
        };

        for (String pattern : patterns) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
                sdf.setTimeZone(SERVER_TIMEZONE);
                sdf.setLenient(false);
                Date parsed = sdf.parse(clean);
                if (parsed != null) {
                    return parsed;
                }
            } catch (ParseException ignored) {}
        }
        return null;
    }

    public static int resolveCanonicalDurationDays(String planName, int fallbackDays) {
        if (planName == null) return fallbackDays > 0 ? fallbackDays : 3;
        String lower = planName.toLowerCase(Locale.US);
        if (lower.contains("starter")) return 3;
        if (lower.contains("classic")) return 7;
        if (lower.contains("premium")) return 15;
        if (lower.contains("vip")) return 30;
        if (lower.contains("diamond")) return 60;
        return fallbackDays > 0 ? fallbackDays : 3;
    }

    /**
     * Official GoldMine 5-Package ROI Configuration & Calculation Formula:
     * - Starter Gold (₦1,000 – ₦5,000, 3 Days): 35% ROI
     * - Classic Gold (₦10,000 – ₦20,000, 7 Days): 45% ROI
     * - Premium Gold (₦30,000 – ₦50,000, 15 Days): 45% ROI
     * - VIP Gold (₦100,000 – ₦200,000, 30 Days): 45% ROI
     * - Diamond Gold (₦1,000,000, 60 Days): 45% ROI
     *
     * Profit = Investment Amount * ROI Percentage / 100
     * Total Return = Investment Amount + Profit
     */
    public static double resolveCanonicalRoiPercentage(String planName, double investmentAmount, double fallbackRoi) {
        if (planName != null) {
            String lower = planName.toLowerCase(Locale.US);
            if (lower.contains("starter")) return 35.0;
            if (lower.contains("classic") || lower.contains("premium") || lower.contains("vip") || lower.contains("diamond")) {
                return 45.0;
            }
        }
        if (fallbackRoi == 35.0 || fallbackRoi == 45.0) {
            return fallbackRoi;
        }
        if (investmentAmount > 0 && investmentAmount <= 5000.0) {
            return 35.0;
        }
        return 45.0;
    }

    public static double resolveRoiPercentage(double investmentAmount) {
        if (investmentAmount > 0 && investmentAmount <= 5000.0) {
            return 35.0;
        }
        return 45.0;
    }

    public static double resolveRoiPercentage(double investmentAmount, double baseRoi) {
        if (baseRoi == 35.0 || baseRoi == 45.0) {
            return baseRoi;
        }
        return resolveRoiPercentage(investmentAmount);
    }

    public static double calculateProfit(double investmentAmount) {
        double roi = resolveRoiPercentage(investmentAmount);
        return calculateProfit(investmentAmount, roi);
    }

    public static double calculateProfit(double investmentAmount, double roiPercentage) {
        double roi = roiPercentage > 0 ? roiPercentage : resolveRoiPercentage(investmentAmount);
        return (investmentAmount * roi) / 100.0;
    }

    public static double calculateDailyProfit(double investmentAmount, int durationDays) {
        double roi = resolveRoiPercentage(investmentAmount);
        return calculateDailyProfit(investmentAmount, roi, durationDays);
    }

    public static double calculateDailyProfit(double investmentAmount, double roiPercentage, int durationDays) {
        int days = Math.max(1, durationDays);
        return calculateProfit(investmentAmount, roiPercentage) / (double) days;
    }

    public static double calculateDailyRoiRate(int durationDays) {
        return calculateDailyRoiRate(35.0, durationDays);
    }

    public static double calculateDailyRoiRate(double roiPercentage, int durationDays) {
        int days = Math.max(1, durationDays);
        double roi = roiPercentage > 0 ? roiPercentage : 35.0;
        return roi / (double) days;
    }

    public static double calculateExpectedReturn(double investmentAmount) {
        double roi = resolveRoiPercentage(investmentAmount);
        return calculateExpectedReturn(investmentAmount, roi);
    }

    public static double calculateExpectedReturn(double investmentAmount, double roiPercentage) {
        double profit = calculateProfit(investmentAmount, roiPercentage);
        return investmentAmount + profit;
    }

    public static String formatCountdown(long secondsRemaining) {
        if (secondsRemaining <= 0) {
            return "00d : 00h : 00m : 00s";
        }
        long days = secondsRemaining / 86400;
        long hours = (secondsRemaining % 86400) / 3600;
        long minutes = (secondsRemaining % 3600) / 60;
        long seconds = secondsRemaining % 60;
        return String.format(Locale.US, "%02dd : %02dh : %02dm : %02ds", days, hours, minutes, seconds);
    }
}
