package com.goldmine.investmentplatform.util;

public final class Constants {
    private Constants() {}

    // Production GoldMine Backend URL (as defined in config/app.php)
    public static final String BASE_URL = "https://goalmindai.com.ng/";
    public static final String API_BASE_URL = "https://goalmindai.com.ng/api/";

    // Currency
    public static final String CURRENCY_SYMBOL = "₦";
    public static final String CURRENCY_CODE = "NGN";

    // Official Bank Information (as defined in config/payment.php)
    public static final String COMPANY_BANK_NAME = "Kuda Bank";
    public static final String COMPANY_ACCOUNT_NUMBER = "2009888249";
    public static final String COMPANY_ACCOUNT_NAME = "Hamisu Isiyaka";

    // Shared Preferences Keys
    public static final String PREF_NAME = "goldmine_prefs";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
    public static final String KEY_AUTH_TOKEN = "auth_token";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_PHONE = "user_phone";
    public static final String KEY_USER_BALANCE = "user_balance";
    public static final String KEY_USER_TOTAL_INVESTED = "user_total_invested";
    public static final String KEY_USER_TOTAL_PROFIT = "user_total_profit";

    // Support URLs
    public static final String SUPPORT_EMAIL = "support@goalmindai.com.ng";
    public static final String SUPPORT_TELEGRAM = "https://t.me/GoldMinePlatform";
    public static final String SUPPORT_WHATSAPP = "https://wa.me/2348000000000?text=Hello%20GoldMine%20Support";
}
