package com.goldmine.investmentplatform.ui.myinvestments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.goldmine.investmentplatform.R;
import com.goldmine.investmentplatform.adapter.InvestmentsAdapter;
import com.goldmine.investmentplatform.api.ApiClient;
import com.goldmine.investmentplatform.api.SessionManager;
import com.goldmine.investmentplatform.databinding.FragmentMyInvestmentsBinding;
import com.goldmine.investmentplatform.model.ApiResponse;
import com.goldmine.investmentplatform.model.Investment;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyInvestmentsFragment extends Fragment {
    private FragmentMyInvestmentsBinding binding;
    private SessionManager sessionManager;
    private InvestmentsAdapter adapter;
    private String currentFilter = "all";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentMyInvestmentsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());

        adapter = new InvestmentsAdapter();
        binding.rvInvestments.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvInvestments.setAdapter(adapter);

        setupFilterButtons();

        binding.swipeRefresh.setOnRefreshListener(() -> fetchInvestments(currentFilter));
        fetchInvestments("all");
    }

    private void setupFilterButtons() {
        binding.btnFilterAll.setOnClickListener(v -> setFilter("all", binding.btnFilterAll));
        binding.btnFilterActive.setOnClickListener(v -> setFilter("active", binding.btnFilterActive));
        binding.btnFilterPending.setOnClickListener(v -> setFilter("pending", binding.btnFilterPending));
        binding.btnFilterCompleted.setOnClickListener(v -> setFilter("completed", binding.btnFilterCompleted));
        binding.btnFilterRejected.setOnClickListener(v -> setFilter("rejected", binding.btnFilterRejected));
    }

    private void setFilter(String filter, Button selectedBtn) {
        this.currentFilter = filter;
        resetFilterStyles();
        selectedBtn.setBackgroundResource(R.drawable.bg_gold_button);
        selectedBtn.setTextColor(Color.parseColor("#0A0D0A"));
        fetchInvestments(filter);
    }

    private void resetFilterStyles() {
        Button[] buttons = {binding.btnFilterAll, binding.btnFilterActive, binding.btnFilterPending, binding.btnFilterCompleted, binding.btnFilterRejected};
        for (Button b : buttons) {
            b.setBackgroundResource(R.drawable.bg_card);
            b.setTextColor(Color.parseColor("#A1A1AA"));
        }
    }

    private void fetchInvestments(String filter) {
        binding.progressBar.setVisibility(View.VISIBLE);

        com.goldmine.investmentplatform.api.GoldMineRepository.getInstance().getMyInvestments(filter, new com.goldmine.investmentplatform.api.GoldMineRepository.InvestmentsCallback() {
            @Override
            public void onSuccess(List<Investment> list) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
                adapter.setInvestments(list);
                binding.tvEmptyState.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
