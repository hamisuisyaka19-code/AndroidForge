pluginManagement {
    repositories {
        google()
        maven { url = uri("https://maven.google.com") }
        mavenCentral()
        gradlePluginPortal()
        maven { url = uri("https://plugins.gradle.org/m2") }
        maven { url = uri("https://jitpack.io") }
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        maven { url = uri("https://maven.google.com") }
        mavenCentral()
        maven { url = uri("https://plugins.gradle.org/m2") }
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "GoldMine"
include(":app")
