package ng.com.goalmindai.goldmine

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.animation.AlphaAnimation
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TARGET_URL = "https://goalmindai.com.ng/goldmine-cpanel/"
        private const val EXIT_CONFIRM_INTERVAL_MS = 2000L
    }

    private lateinit var webView: WebView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var topProgressBar: ProgressBar
    private lateinit var splashOverlay: FrameLayout
    private lateinit var splashStatusText: TextView
    private lateinit var errorContainer: LinearLayout
    private lateinit var errorDetailText: TextView
    private lateinit var retryButton: Button

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var isSplashDismissed = false
    private var hasLoadError = false
    private var lastLoadedUrl: String = TARGET_URL
    private var lastBackPressTime: Long = 0L

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult

        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results: Array<Uri>? = when {
                data?.clipData != null -> {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            }
            callback.onReceiveValue(results)
        } else {
            callback.onReceiveValue(null)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions granted or handled gracefully by system picker
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        topProgressBar = findViewById(R.id.topProgressBar)
        splashOverlay = findViewById(R.id.splashOverlay)
        splashStatusText = findViewById(R.id.splashStatusText)
        errorContainer = findViewById(R.id.errorContainer)
        errorDetailText = findViewById(R.id.errorDetailText)
        retryButton = findViewById(R.id.retryButton)

        requestRuntimePermissionsIfNeeded()
        configureCookies()
        configureSwipeRefresh()
        configureWebView()
        configureBackNavigation()
        registerConnectivityMonitor()

        retryButton.setOnClickListener {
            if (isInternetAvailable()) {
                hideErrorScreen()
                webView.loadUrl(lastLoadedUrl)
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.still_offline_message),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            if (isInternetAvailable()) {
                webView.loadUrl(TARGET_URL)
            } else {
                dismissSplashIfVisible()
                showErrorScreen(getString(R.string.error_no_internet_detail))
            }
        }
    }

    private fun configureCookies() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)
    }

    private fun configureSwipeRefresh() {
        swipeRefreshLayout.isEnabled = true
        swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.gold_primary),
            ContextCompat.getColor(this, R.color.gold_accent)
        )
        swipeRefreshLayout.setProgressBackgroundColorSchemeColor(
            ContextCompat.getColor(this, R.color.surface_dark)
        )
        swipeRefreshLayout.setOnRefreshListener {
            if (isInternetAvailable()) {
                hideErrorScreen()
                webView.reload()
            } else {
                swipeRefreshLayout.isRefreshing = false
                showErrorScreen(getString(R.string.error_no_internet_detail))
            }
        }
        webView.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            swipeRefreshLayout.isEnabled = true && scrollY == 0
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.mediaPlaybackRequiresUserGesture = false

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                hasLoadError = false
                if (!url.isNullOrBlank() && !url.startsWith("about:")) {
                    lastLoadedUrl = url
                }
                topProgressBar.visibility = View.VISIBLE
                topProgressBar.progress = 15
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false

                if (scheme == "http" || scheme == "https") {
                    return false
                }

                return try {
                    val externalIntent = Intent(Intent.ACTION_VIEW, uri)
                    startActivity(externalIntent)
                    true
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.external_app_not_found),
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeRefreshLayout.isRefreshing = false
                topProgressBar.visibility = View.GONE
                CookieManager.getInstance().flush()
                dismissSplashIfVisible()

                if (!hasLoadError) {
                    hideErrorScreen()
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    hasLoadError = true
                    swipeRefreshLayout.isRefreshing = false
                    topProgressBar.visibility = View.GONE
                    dismissSplashIfVisible()
                    val desc = error?.description?.toString()
                        ?: getString(R.string.error_no_internet_detail)
                    showErrorScreen(desc)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                topProgressBar.progress = newProgress
                if (!isSplashDismissed) {
                    splashStatusText.text = getString(R.string.splash_loading_percent, newProgress)
                }
                if (newProgress >= 85) {
                    dismissSplashIfVisible()
                }
                if (newProgress == 100) {
                    topProgressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                return try {
                    val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        val acceptTypes = fileChooserParams?.acceptTypes
                        if (!acceptTypes.isNullOrEmpty() && acceptTypes.any { it.isNotBlank() }) {
                            putExtra(
                                Intent.EXTRA_MIME_TYPES,
                                acceptTypes.filter { it.isNotBlank() }.toTypedArray()
                            )
                        }
                        if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        }
                    }

                    val chooserIntent = Intent.createChooser(
                        contentSelectionIntent,
                        getString(R.string.file_chooser_title)
                    )
                    fileChooserLauncher.launch(chooserIntent)
                    true
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, true, false)
            }
        }

        webView.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                handleFileDownload(url, userAgent, contentDisposition, mimeType)
            }
        )
    }

    private fun handleFileDownload(
        url: String?,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?
    ) {
        if (url.isNullOrBlank()) return

        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(TARGET_URL))
                startActivity(browserIntent)
                return
            }

            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) {
                    addRequestHeader("Cookie", cookies)
                }
                if (!userAgent.isNullOrBlank()) {
                    addRequestHeader("User-Agent", userAgent)
                }
                setDescription(getString(R.string.downloading_file_description))
                setTitle(fileName)
                setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                )
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }

            val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            downloadManager.enqueue(request)
            Toast.makeText(
                this,
                getString(R.string.download_started_toast, fileName),
                Toast.LENGTH_LONG
            ).show()
        } catch (_: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
                Toast.makeText(
                    this,
                    getString(R.string.download_failed_toast),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun configureBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (errorContainer.visibility == View.VISIBLE && webView.canGoBack()) {
                    hideErrorScreen()
                    webView.goBack()
                    return
                }

                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    val now = System.currentTimeMillis()
                    if (now - lastBackPressTime < EXIT_CONFIRM_INTERVAL_MS) {
                        finish()
                    } else {
                        lastBackPressTime = now
                        Toast.makeText(
                            this@MainActivity,
                            getString(R.string.press_back_again_to_exit),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        })
    }

    private fun registerConnectivityMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        try {
            cm.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    runOnUiThread {
                        if (errorContainer.visibility == View.VISIBLE) {
                            hideErrorScreen()
                            webView.loadUrl(lastLoadedUrl)
                        }
                    }
                }
            })
        } catch (_: Exception) {
            // Safe fallback if network callback registration is restricted
        }
    }

    private fun dismissSplashIfVisible() {
        if (isSplashDismissed) return
        isSplashDismissed = true

        if (splashOverlay.visibility == View.VISIBLE) {
            val fadeOut = AlphaAnimation(1f, 0f).apply {
                duration = 320L
                fillAfter = false
            }
            splashOverlay.startAnimation(fadeOut)
            splashOverlay.visibility = View.GONE
        }
    }

    private fun showErrorScreen(detail: String) {
        errorDetailText.text = detail
        errorContainer.visibility = View.VISIBLE
        webView.visibility = View.INVISIBLE
    }

    private fun hideErrorScreen() {
        hasLoadError = false
        errorContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE
    }

    private fun isInternetAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun requestRuntimePermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onStop() {
        CookieManager.getInstance().flush()
        super.onStop()
    }

    override fun onDestroy() {
        CookieManager.getInstance().flush()
        webView.destroy()
        super.onDestroy()
    }
}
