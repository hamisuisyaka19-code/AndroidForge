// Top-level build file for GoldMine (ng.com.goalmindai.goldmine)
// Configured for AndroidForge CI (JDK 17 + Gradle 8.9 + AGP 8.7.2)
// kotlin_version = "1.9.24"

plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
