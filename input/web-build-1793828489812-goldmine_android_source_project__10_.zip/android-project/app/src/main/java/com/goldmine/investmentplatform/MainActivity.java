package com.goldmine.investmentplatform;

/**
 * GoldMine Investment Platform - Main Activity Root Entry Point
 * Provides direct root package access and backward compatibility for AndroidForge and GitHub Actions.
 */
public class MainActivity extends com.goldmine.investmentplatform.ui.main.MainActivity {
}
